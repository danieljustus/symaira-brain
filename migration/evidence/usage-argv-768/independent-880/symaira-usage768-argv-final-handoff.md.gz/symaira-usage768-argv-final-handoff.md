# Usage argv correction #768 — immutable author handoff

Clean final HEAD `eea73b7478e62f1bb174d456bbbecccc1de94034`; actual validated source `8803847278546f3161eaaa84d2e65bc2eec594a2`. The final checkpoint changes only evidence and observed ADR documentation (220 paths). Worktree `/workspace/symaira-usage768-argv`, branch `issue/768-usage-argv-bytes`, base abf20713; verified normal-main e3dbda6 ancestor. Original abf/00bcc source remains clean unchanged. No GitHub writes or approval/closure.

## Correction

Only production `rust/symbrain-cli/src/usage_cli.rs` changes. Reuse existing byte-preserving CLI normalization and Core Go quote. Implement the precise zero-local-flag first-argument syntax/terminator/help/precedence contract; unknown flag diagnostics preserve raw Unix bytes; positional diagnostics retain Go lowercase escapes. No provider, owner, HTTP, fallback-admission, dependency, frozen-Go or fixture changes.

The original12/22 literal-file mismatches remain retained. Permanent actual frozen-Go/current-abf-parent/candidate comparisons cover82 Unix cases, all exact, including all22 unchanged argument/file byte inputs. Original abf parent12 failures must reproduce; candidate and current abf parent have absent fallback. Three genuine diagnostic mutations fail. A separate22-triple rerun with fresh retained frozen-Go and accepted9aed parent passes; only accepted9aed has fallback available, matching its pre-admission behavior. No provider HTTP or host credential access; owned files/tree remain unchanged.

## Actual clean acceptance

Local89 inputs/81 full reports/8 gates/111 CLI/five controls; owner16 full constructors/16 CLI/22 Unix path cases/wrong-owner101 control. Original97 mapping66 retained/31 routing only unchanged. Files86/85 full/151 CLI, Hermes96/104 and Reference44/110, each five real controls. Original12 owner inputs and32 supplemental configured/source/status/Authorization public pairs pass with canned401/read-only state; supplemental surface is narrower than full constructor reports.

All four manifests69/61/59/55 agree on52 shared entries and native CLI `f657a231ac1bae1472718e10c9ae30418d7589286b2300f882eb4b51b7b04743`. Fresh actual frozen-Go CLI `0654376cf8fc33c3be0b03bd394b665842d04e6659b3dfd67c0d6786d2f136e2` matches every current gate build and is retained under `/workspace/oracles/symaira-usage768-argv-880-binaries/go-usage`; this differs honestly from older archived frozen fullGo a68dce5. All355 ordinary tests/zero failures/four explicitly replayed oracle ignores (33 summaries), strict all-target/all-feature CLI+Usage Clippy, workspace and18 included-fragment fmt, actionlint and diff checks pass.

## Artifact ownership and retained failures

One exclusively reused target `/workspace/symaira-usage768-argv/target`, originally released local-files target. Before reuse original36 executed CLI/test/rlib bytes were losslessly archived;103 raw review artifacts retained,100 nonbinary artifacts tracked and3 actual probes external. Earlier73/11 and accepted112/74 verified. Parent and candidate variants use explicit CLI-package-only cleaning: every dry-run regular file and top-level CLI is archived, decompressed and SHA/length checked before removal. Linux /proc checks occur before cleaning; no other target is touched. Initial and restored candidate CLI copies must match byte-for-byte.

The original dirty gate actually failed because a normal shared-target rebuild retained the parent CLI. Complete input/results/logs remain in `migration/evidence/usage-argv-768/presource-attempts/`; both failed CLI copies were exactly91e and remain in the original36-file archive. Subsequent clean d066 full successful proof is also retained, superseded solely by correcting the new helper's basename restriction so documented external macOS targets are accepted. No failed result/attempt is discarded.

Final actual executed/linked39 binary paths/38 unique SHA (33 ordinary test binaries plus actual current CLI/parent/freshGo/publicprobe/rlib) were losslessly archived and roundtrip checked: `/workspace/oracles/symaira-usage768-argv-880-binaries/receipt.json`. Current binaries remain present. Final receipt verification checks source against immutable Git and all actual retained paths against SHA.

## Limits and independent replay

Windows declares56 launchable/14 original cases/two mutation controls;26 invalid Unix-byte vectors cannot be launched through Python Windows strings and remain explicit skips. No Windows/macOS native runtime or surrogate proof here. Existing credential-source/host/HTTP gates and inherited Windows path-algorithm observations remain unchanged. Full768 stays open. Root independently reviews; author does not self-approve. Native exact-head Linux/macOS/Windows CI required.

Target is **RELEASED**, all author processes complete and /proc exe/cwd/fd users0. No more writes/executions by this author after handoff.

Replays: `. /home/agent/.cargo/env`; PATH `/workspace/toolchains/go1.26.7/bin:$PATH`; CARGO_TARGET_DIR `/workspace/symaira-usage768-argv/target`, CARGO_INCREMENTAL=0, CARGO_PROFILE_DEV_DEBUG=0, CARGO_PROFILE_TEST_DEBUG=0, umask022; lifecycle via `python3 /tmp/symaira-subreaper.py bash -c 'set -euo pipefail; umask 022; COMMAND'`. Commands: `bash scripts/usage-copilot-kimi-oracle/run.sh /tmp/REVIEW-local.json`; corresponding `usage-provider-files-oracle`, `usage-hermes-oracle`, `usage-credential-oracle` run.sh. Ordinary `cargo test --locked -p symbrain-cli -p symbrain-usage --all-targets --all-features`; strict Clippy same scope, cargo fmt/actionlint. Every replay retains partial/full logs and real controls. Parent CLI is rebuilt from immutable abf; no second compile target.

Primary tracked validation `/workspace/symaira-usage768-argv/migration/evidence/usage-argv-768/linux-8803847/linux-validation.json`. Full source-bound reports, exact stdout/stderr/argv/header/request/input bytes, all build/strict logs, SHA manifests, SDK flag/quote source hashes, original/failed proofs and archive references live under `migration/evidence/usage-argv-768/`. Full JSON handoff `/tmp/symaira-usage768-argv-final-handoff.json`.
