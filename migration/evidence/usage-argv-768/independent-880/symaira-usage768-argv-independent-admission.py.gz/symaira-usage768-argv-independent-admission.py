#!/usr/bin/env python3
import base64,hashlib,json,os,pathlib,subprocess,tempfile
GO=pathlib.Path('/workspace/oracles/symaira-usage768-argv-880-binaries/go-usage')
PARENT=pathlib.Path('/workspace/oracles/symaira-usage768-argv-880-binaries/parent-usage')
CLI=pathlib.Path('/workspace/symaira-usage768-argv/target/debug/symbrain')
ARGS=[[b'--unknown'],[b'--unknown',b'--help'],[b'--help'],[b'--help',b'owned'],[b'--',b'--help'],[b'owned',b'--help'],[b'-h=false',b'owned'],[b'----help']]
rows=[]
def state(home):
 result={}
 for p in home.rglob('*'):
  m=p.lstat();result[str(p.relative_to(home))]=dict(mode=m.st_mode,mtime_ns=m.st_mtime_ns,size=m.st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest() if p.is_file() else None)
 return result
with tempfile.TemporaryDirectory(prefix='symaira-usage768-review-admission-') as scratch:
 root=pathlib.Path(scratch)
 for variant in ['unsupported-base','ambiguous-copilot','unicode-kimi-device','overflow-nous-jwt']:
  home=root/variant;home.mkdir();env={b'HOME':os.fsencode(home),b'USERPROFILE':os.fsencode(home),b'PATH':b'',b'XDG_CONFIG_HOME':os.fsencode(home/'config'),b'XDG_DATA_HOME':os.fsencode(home/'data'),b'XDG_CACHE_HOME':os.fsencode(home/'cache'),b'ANTHROPIC_OAUTH_TOKEN':b'env://ABSENT'}
  inputs={}
  if variant=='unsupported-base':env[b'KIMI_CODE_BASE_URL']=b'http://owned.invalid'
  if variant=='ambiguous-copilot':inputs['.config/github-copilot/apps.json']=b'{"github.com:a":{"oauth_token":"owned-a"},"github.com:b":{"oauth_token":"owned-b"}}'
  if variant=='unicode-kimi-device':inputs={'.kimi-code/credentials/kimi-code.json':b'{"access_token":"owned-token"}', '.kimi-code/device_id':'owned-雪'.encode()}
  if variant=='overflow-nous-jwt':inputs['.hermes/auth.json']=b'{"providers":[{"id":"nous","invoke_jwt":"header.eyJleHAiOjFlMTl9.signature"}]}'
  for name,data in inputs.items():p=home/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data)
  before=state(home)
  calls=root/(variant+'-calls.jsonl');sentinel=root/(variant+'-forward.py')
  sentinel.write_text('#!/usr/bin/python3\nimport json,os,sys\n'+f'with open({str(calls)!r},"a") as f: f.write(json.dumps(sys.argv[1:])+"\\n")\nos.execv({str(GO)!r},[{str(GO)!r},*sys.argv[1:]])\n');sentinel.chmod(0o700)
  for mode in ['absent','actual-forward']:
   env[b'SYMBRAIN_GO_BINARY']=os.fsencode(root/'absent-fallback' if mode=='absent' else sentinel)
   for index,args in enumerate(ARGS):
    observed={};routed={}
    for label,binary in [('go',GO),('parent',PARENT),('rust',CLI)]:
     call_before=calls.read_bytes() if calls.exists() else b''
     p=subprocess.run([os.fsencode(binary),b'usage',*args],env=env,cwd=home,input=b'',stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=15)
     observed[label]=dict(exit=p.returncode,stdout_b64=base64.b64encode(p.stdout).decode(),stderr_b64=base64.b64encode(p.stderr).decode())
     call_after=calls.read_bytes() if calls.exists() else b'';routed[label]=call_after[len(call_before):].decode()
    assert observed['go']['exit']==2 and not observed['go']['stdout_b64']
    assert observed['parent']==observed['rust'],(variant,mode,index,observed)
    assert mode=='absent' or observed['go']==observed['rust']
    assert state(home)==before
    rows.append(dict(id=f'{variant}-{mode}-{index}',argv_hex=[v.hex() for v in args],observed=observed,sentinel_calls=routed,filesystem=before,read_only=True,parent_current_equal=True,go_equal=observed['go']==observed['rust']))
report=dict(cases=len(rows),parent_current_equal=sum(r['parent_current_equal'] for r in rows),forward_go_equal=sum(r['go_equal'] for r in rows if '-actual-forward-' in r['id']),records=rows,binaries={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in [GO,PARENT,CLI]},scope='Bounded unsupported credential/base/file admission probes; every frozenGo argv exits2 before report; parent/current unchanged routing; recording forward executor invokes actual frozenGo, absent executor explicitly recorded; private state metadata/bytes unchanged; Linux only')
path=pathlib.Path('/tmp/symaira-usage768-argv-independent-admission.json');path.write_text(json.dumps(report,indent=2)+'\n')
print({k:report[k] for k in ['cases','parent_current_equal','forward_go_equal']})
