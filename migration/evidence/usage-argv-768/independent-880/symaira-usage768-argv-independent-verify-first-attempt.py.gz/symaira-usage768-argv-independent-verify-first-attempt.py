#!/usr/bin/env python3
import hashlib,json,pathlib,re,subprocess,tarfile,os
R=pathlib.Path('/workspace/symaira-usage768-argv'); HEAD='eea73b7478e62f1bb174d456bbbecccc1de94034';SOURCE='8803847278546f3161eaaa84d2e65bc2eec594a2'
def sha(p):return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()==HEAD
assert not subprocess.check_output(['git','status','--porcelain'],cwd=R)
assert subprocess.run(['git','merge-base','--is-ancestor','e3dbda6cbb95429237d15a9b176209b7d107792c',HEAD],cwd=R).returncode==0
assert not subprocess.check_output(['git','diff',SOURCE,HEAD,'--name-only','--','rust','scripts','.github','Cargo.toml','Cargo.lock'],cwd=R)
reports={name:json.load(open('/tmp/symaira-usage768-argv-independent-'+name+'.json')) for name in ['local','files','hermes','reference']}
maps=[];counts={}
for name,report in reports.items():
 assert report['candidate_head']==HEAD and report['candidate_dirty'] is False and report['failed']==0
 counts[name]=len(report['source_sha256']);maps.append(report['source_sha256'])
 for file,digest in report['source_sha256'].items():
  assert sha(R/file)==digest
  assert (R/file).read_bytes()==subprocess.check_output(['git','show',HEAD+':'+file],cwd=R)
common=set.intersection(*[set(m) for m in maps]);assert len(common)==52
for path in common:assert len({m[path] for m in maps})==1
assert counts==dict(local=69,files=61,hermes=59,reference=55)
retained=[]
old=R/'migration/evidence/usage-argv-768/original-abf-review';manifest=json.load(open(old/'retention-manifest.json'))
assert len(manifest['records'])==103
for row in manifest['records']:
 p=old/row['tracked_path'] if row['tracked'] else pathlib.Path(row['retained']);assert sha(p)==row['sha256'];retained.append(str(p))
old73=R/'migration/evidence/usage-copilot-kimi-768/original-root-review-7e0b';m=json.load(open(old73/'retention-manifest.json'));assert len(m['records'])==73
for row in m['records']:assert sha(old73/row['retained'])==row['sha256']
archives=[]
for path,count,key in [('/workspace/oracles/symaira-usage768-argv-880-binaries/receipt.json',39,'records'),('/workspace/oracles/symaira-usage768-abf-binaries/receipt.json',36,'executed_review_files')]:
 receipt=json.load(open(path));assert len(receipt[key])==count;archive=pathlib.Path(receipt['archive']);assert sha(archive)==receipt['archive_sha256']
 with tarfile.open(archive,'r:gz') as bundle:
  for row in receipt[key]:
   data=bundle.extractfile(row.get('member','sha256/'+row['sha256'])).read();assert len(data)==row['bytes'] and hashlib.sha256(data).hexdigest()==row['sha256']
 archives.append({'receipt':path,'receipt_sha256':sha(path),'archive_sha256':receipt['archive_sha256'],'paths':count,'roundtrip_verified':True})
for path,key,field,count in [('/workspace/oracles/symaira-usage768-local-files-7e0b-binaries/archive-receipt.json','records','archive',11),('/workspace/oracles/symaira-usage768-files-f241-binaries/archive-receipt.json','executables','archived_path',112)]:
 receipt=json.load(open(path));assert len(receipt[key])==count
 for row in receipt[key]:
  p=pathlib.Path(row[field]);assert p.stat().st_size==row['bytes'] and sha(p)==row['sha256']
 archives.append({'receipt':path,'receipt_sha256':sha(path),'paths':count,'unique_hashes':len({x['sha256'] for x in receipt[key]}),'actual_archived_bytes_verified':True})
assert archives[-1]['unique_hashes']==74
for key,value in json.load(open('/tmp/symaira-usage768-argv-final-handoff.json'))['binaries_sha256'].items():assert sha(key)==value
old_failed=json.load(open(R/'migration/evidence/usage-argv-768/presource-attempts/symaira-usage768-argv-presource-local.evidence/argv-build.json'))
assert set(old_failed['binaries_sha256'].values())=={'91e25046826107a456fdbe9308b60193312edd2c51a222f355b02bb1fdff2d97'}
rawlog=pathlib.Path('/tmp/symaira-usage768-argv-independent-tests.log').read_text();summaries=[tuple(map(int,m)) for m in re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;',rawlog)]
assert len(summaries)==33 and tuple(sum(x[i] for x in summaries) for i in range(3))==(355,0,4)
target=R/'target';users=[]
for proc in pathlib.Path('/proc').iterdir():
 if not proc.name.isdigit():continue
 for link in [proc/'exe',proc/'cwd',*(proc/'fd').glob('*')]:
  try:value=os.readlink(link)
  except OSError:continue
  if value==str(target) or value.startswith(str(target)+'/'):users.append({'pid':proc.name,'link':str(link),'value':value})
assert not users,users
changed=subprocess.check_output(['git','diff','--name-only','e3dbda6cbb95429237d15a9b176209b7d107792c',HEAD,'--','rust','scripts','docs','.github','README.md','Cargo.lock','.gitattributes'],cwd=R,text=True).splitlines();files=[f for f in changed if '/evidence/'not in f]
receipt={'head':HEAD,'source':SOURCE,'normal_main':'e3dbda6cbb95429237d15a9b176209b7d107792c','candidate_clean':True,'source_manifests':counts,'common_entries':52,'source_files':{f:sha(R/f) for f in files},'archives':archives,'original_retained_artifacts':{'abf':103,'7e0b':73},'failed_stale_candidate_hashes':old_failed['binaries_sha256'],'ordinary':{'summaries':33,'passed':355,'failed':0,'ignored':4,'all_four_oracles_explicitly_replayed':True},'target_users':users,'target_released':True,'scope':'Full independent Linux review; no source edits/GitHub writes; native exact-head threeOS still required; no full768 closure/performance claim'}
path=pathlib.Path('/tmp/symaira-usage768-argv-independent-verification.json');path.write_text(json.dumps(receipt,indent=2)+'\n');print({'verified_manifests':counts,'archives':[x['paths'] for x in archives],'retention':'103+73 raw original;36+11+112/74+39/38 binary paths verified','source_files':len(files),'target_users':len(users)})
