# Independent full Usage credential and argv review

**Disposition: APPROVE this bounded correction. No actionable introduced findings.** Exact-head protected checks and native three-OS CI are still required. This does not approve full #768 closure or removal of Go fallback.

## Immutable artifact and review boundary

- Worktree: `/workspace/symaira-usage768-argv`.
- Final clean HEAD: `eea73b7478e62f1bb174d456bbbecccc1de94034`.
- Validated source: `8803847278546f3161eaaa84d2e65bc2eec594a2`.
- Originally reviewed parent: `abf20713bacdab562644256e27616a9dd7acb81e` (source `00bcc6f51a2fbc00581ca7f6b7af0e868d168971`).
- Normally integrated main ancestor: `e3dbda6cbb95429237d15a9b176209b7d107792c`.
- Frozen Go: `dcddcef0df5789123c7c9a7ebe6e01f10e941f2c`, actual SDK1.26.7. Source880→final changes evidence/docs only; production, tests, runners, dependencies and CI are unchanged.

The review covered all changed production layers relative to main, the immutable parent argv failure, provider constructors/admission/SecretRefs, lexical path ownership, bounded credential reads, JSON/JWT/Hermes state, HTTP request/error flow, all harness/mutant/cleanup runners, tests, dependency boundaries, workflow, public ADRs and retention records. The accompanying verification receipt lists all77 changed non-evidence files with current/Git-bound SHA256; the four source manifests bind69/61/59/55 entries and agree on52 shared entries. Original AGENTS/product boundaries were applied. No candidate source, frozen Go or fixtures were edited; no GitHub writes occurred.

## Correctness and ownership assessment

The new Usage parser applies the established whole-vector normalization exactly once, then implements the zero-local-flag Go FlagSet first-argument rules. It distinguishes terminators, positional arguments, malformed flag names, unknown names split at the first equals sign, and implicit h/help. Earlier positional/unknown input retains precedence over later help. Unknown names are written as bytes; positional diagnostics reuse Core Go quoting, preserving invalid Unix bytes and lowercase hex. It does not expand provider admission or construct a report on the tested invalid vectors.

The provider-config split retains private include fragments and reuses existing resolver/Go quoting/path helpers without extending public API. Environment/reference results remain bounded and source-specific; literal file tokens do not become secret references. File selection uses Go lexical Clean/Join before capability-based reads, preserving the selected credential owner across erased parents/symlinks. Regular-file/size restrictions and Unix nofollow/nonblocking constraints are explicit. Ambiguous Copilot maps, unsafe sources, numeric device/expiry/base/workspace boundaries, differing Windows homes and automatic Claude host Keychain retain their documented Go gates. Hermes backing slots, duplicate/null typed decoding, JWT depth/numbers, source/Auth headers and precedence are exercised by the full retained constructor oracles. Canned HTTP comparisons prove request/report behavior; live transport-error wording remains outside this acceptance.

The package-only clean runner addresses the previously observed stale shared-target CLI with verified archives of its dry-run file set, exclusive ownership and byte-identical restoration of the initial candidate. It preserves the actual failed build whose alleged candidate was still the parent. The CI selects `.exe` and normalizes temporary roots on Windows, pins Go, executes the owned ignored gates explicitly, and retains original controls. Linux declarations of56 launchable Windows argv cases/14 originals/two mutants plus26 explicit Unix raw-byte skips are not Windows runtime evidence.

## Fresh independent verification

All runs used the exclusively released target, subreaper lifecycle wrapper, umask022, GoSDK1.26.7, incremental0, dev/test debug0 and jobs2. All four full gates were freshly replayed against actual frozen Go; their source manifests and actual CLI identity were independently checked against immutable Git bytes.

| Gate | Constructor/report corpus | Actual CLI corpus | Real original controls |
| --- | --- | --- | --- |
| Local Copilot/Kimi | 89 pass:81 full reports,8 retained gates |111 pass |5 rejected |
| Provider files |86 pass:85 full reports,1 ambiguity gate |151 pass |5 rejected |
| Hermes |96 pass |104 pass |5 rejected |
| Credential references |44 pass |110 pass |5 rejected |

The original97 local-file accounting remains66 retained comparisons plus31 native route-only cases; the latter are not recast as full parity. Owner checks pass16 complete constructor cases,16 CLI routes and22 Unix path pairs; the meaningful wrong-owner mutant exits101. Fresh argv checks pass82 actual Go/abf/current triples including all22 original inputs; the exact12 original-parent mismatches are reproduced and corrected. All three argv mutations are rejected for their intended byte/exit diagnostic mismatch.

Ordinary tests: **355 passed,0 failed,4 owned ignored,33 non-doc summaries**. All four ignored oracle gates were explicitly executed above. Strict all-target/all-feature Clippy, workspace fmt, all included-fragment fmt and actionlint pass. The first actionlint invocation failed because the reviewer shell omitted its toolchain directory; that exit127 log is preserved, followed by a successful explicit `/workspace/toolchains/bin/actionlint` run. This is not a candidate defect.

Additional independently replayed original12 owner inputs match and remain read-only.32 additional public constructor pairs compare configured/source/status/Authorization surfaces; these are deliberately narrower than complete report equality. All22 original argv vectors also match fresh frozen Go and the archived accepted9aed parent; only that accepted pre-admission parent has its Go fallback available, while the current candidate runs with fallback absent.

The corrected novel corpus passes **96/96 exact stdout/stderr/exit pairs** across Copilot, Kimi and mixed literal-file sources, including global output flags, terminators, value/name syntax, precedence, controls, Unicode and invalid Unix bytes. Each Go/native result returns2 with empty stdout and unchanged owned file/tree state.

The additional unsupported-admission corpus records **64 actual Go/abf/current triples** across unsupported base, distinct Copilot tokens, non-ASCII Kimi device and overflowing Nous JWT expiry, using unknown/help/positional/terminator input. Parent/current match64/64;32 logging-forwarder runs equal actual Go. In the32 absent-executor runs,28 preserve the parent's fallback-start error rather than Go's pre-report FlagSet diagnostic; sole help bypasses admission. This is the unchanged `requires_go_fallback` boundary, not newly admitted native parsing or a regression introduced here. All actual Go vectors exit2 before report, all sentinel calls/raw arguments are recorded, and private file bytes/metadata are unchanged. Public ADR/source explicitly scope parser equality to already admitted provider states.

## Preserved failed reviewer observations

The first novel96-case probe had93 exact pairs and three unaccepted report observations. Historical normalization converts `---` to `--`, so `[--output=json,---]` validly invoked a report. Synthetic private credentials attempted service calls and recorded connection-refused/network-unreachable errors; these are not accepted transport parity and are not candidate findings. The complete original runner/results remain unchanged. The corrected vector adds an owned positional after the terminator and explicitly asserts exit2/empty stdout, producing the96 exact no-report comparisons above. No operator credentials or host Keychain state were used.

The final verification initially asserted every current target artifact retained the author's hash. Fresh Cargo/Clippy regenerated the same-source rlib; its current hash differs from the original linked rlib. All actual CLI/Go/parent/public-probe executable hashes remain unchanged. The original rlib is preserved in the independently decompressed/hash/length-verified author archive, and the overstrict first assertion plus exact original/current hashes are retained. No stale executable was used to justify acceptance.

## Provenance, retention and release

Actual current CLI remains SHA256 `f657a231ac1bae1472718e10c9ae30418d7589286b2300f882eb4b51b7b04743`; the freshly retained frozen-Go CLI remains `0654376cf8fc33c3be0b03bd394b665842d04e6659b3dfd67c0d6786d2f136e2`. The actual abf parent is `91e25046826107a456fdbe9308b60193312edd2c51a222f355b02bb1fdff2d97`; the accepted parent is `9aed2a28060fe84f945db937def4ed10c83f13b15a008d4720ebebf3cd853f38`. Do not conflate these distinct source/build identities.

Independently verified original103 abf artifacts and73 prior Root artifacts against retained hashes; decompressed/hash/length-verified36 original abf executed files,11 prior actual binary entries,112 accepted-parent executable paths/74 unique hashes, and39 current executed/linked paths/38 unique hashes including33 ordinary test binaries. Every69/61/59/55 source manifest entry matches the clean immutable head. Both handoff files match their supplied hashes. The initial stale parent/candidate91e build failure and all original raw findings remain retained.

Fresh review artifacts are `/tmp/symaira-usage768-argv-independent-{local,files,hermes,reference}.json` with each `.evidence` directory; supplementary original-owner/extra/accepted-parent-fresh/extra-argv/admission runners and receipts are adjacent. Machine-readable full review receipt: `/tmp/symaira-usage768-argv-independent-review-receipt.json`; archive/source verification: `/tmp/symaira-usage768-argv-independent-verification.json`.

Final worktree remains clean at eea73b7. All build/replay processes have finished; `/proc` has zero target executable/cwd/FD users. **Target explicitly released to Root.** Exact-head native Linux/macOS/Windows acceptance, protected checks and remaining #768/full cutover work stay open. No performance or cross-platform runtime acceptance claim is made.
