#!/usr/bin/env python3
import base64,hashlib,json,os,pathlib,subprocess,tempfile
CLI=pathlib.Path('/workspace/symaira-usage768-argv/target/debug/symbrain')
GO=pathlib.Path('/workspace/oracles/symaira-usage768-argv-880-binaries/go-usage')
VECTORS=[[b'--json',b'--help'],[b'--json',b'-h=0'],[b'--json',b'--',b'--help'],[b'--output=json',b'---'],[b'--output',b'table',b'---help'],[b'--',b'--json',b'x'],[b'--',b'--output=json',b'x'],[b'--output=json',b'--unknown=\xff'],[b'--unknown=\xe2\x82',b'--json'],[b'---=\xff',b'--json'],[b'-=\xe2\x82'],[b'--help=a=b'],[b'-help='],[b'--h=false'],[b'--help\n'],[b'---h=false'],[b'--h=\xff',b'---bad'],[b'--json=true'],[b'--json=false'],[b'first',b'--output=json',b'--help'],[b'--',b'--',b'--output=json'],[b'owned-\x7f'],[b'owned-\xc2\x85'],[b'owned-\xe2\x80\xa8'],[b'owned-\xe2\x80\xa9'],[b'owned-\xef\xbf\xbd'],[b'owned-\xe2\x82'],[b'owned-\xf0\x90\x80'],[b'owned-\xed\xb0\x80'],[b'owned-<>&'],[b'--owned-\"\\\n=\xff'],[b'--output=bad',b'--help']]
rows=[]
with tempfile.TemporaryDirectory(prefix='symaira-usage768-review-argv-') as temporary:
 for provider in ['copilot','kimi','mixed']:
  home=pathlib.Path(temporary)/provider;home.mkdir()
  paths=[('.config/github-copilot/apps.json',b'{"github.com:a":{"oauth_token":"env://OWNED_LITERAL"}}'),('.kimi-code/credentials/kimi-code.json',b'{"access_token":"env://OWNED_LITERAL"}')]
  selected=paths if provider=='mixed' else [paths[0 if provider=='copilot' else 1]]
  for name,data in selected:
   p=home/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data)
  env={b'HOME':os.fsencode(home),b'USERPROFILE':os.fsencode(home),b'PATH':b'',b'XDG_CONFIG_HOME':os.fsencode(home/'config'),b'XDG_DATA_HOME':os.fsencode(home/'data'),b'XDG_CACHE_HOME':os.fsencode(home/'cache'),b'ANTHROPIC_OAUTH_TOKEN':b'env://ABSENT',b'SYMBRAIN_GO_BINARY':os.fsencode(home/'absent-fallback')}
  before={str(p.relative_to(home)):hashlib.sha256(p.read_bytes()).hexdigest() for p in home.rglob('*') if p.is_file()}
  tree=sorted(str(p.relative_to(home)) for p in home.rglob('*'))
  for index,args in enumerate(VECTORS):
   obs=[]
   for binary in [GO,CLI]:
    p=subprocess.run([os.fsencode(binary),b'usage',*args],input=b'',env=env,cwd=home,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=15)
    obs.append(dict(exit=p.returncode,stdout_b64=base64.b64encode(p.stdout).decode(),stderr_b64=base64.b64encode(p.stderr).decode()))
   after={str(p.relative_to(home)):hashlib.sha256(p.read_bytes()).hexdigest() for p in home.rglob('*') if p.is_file()}
   assert before==after and tree==sorted(str(p.relative_to(home)) for p in home.rglob('*'))
   rows.append(dict(id=f'{provider}-{index}',argv_hex=[a.hex() for a in args],go=obs[0],rust=obs[1],matched=obs[0]==obs[1],read_only=True,files_sha256=before))
report=dict(cases=len(rows),passed=sum(x['matched'] for x in rows),failed=sum(not x['matched'] for x in rows),records=rows,binaries={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in [GO,CLI]},scope='Actual current source-bound CLI/frozenGo; private synthetic literal-file credentials; novel global format/terminator/help/name/value/Unicode/raw-byte grammar; Linux only, no report HTTP')
path=pathlib.Path('/tmp/symaira-usage768-argv-independent-extra-argv.json');path.write_text(json.dumps(report,indent=2)+'\n')
print({k:report[k] for k in ['cases','passed','failed']})
for row in rows:
 if not row['matched']:print(row)
