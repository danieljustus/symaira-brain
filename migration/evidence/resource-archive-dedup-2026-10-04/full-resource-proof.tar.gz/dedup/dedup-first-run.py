from pathlib import Path
import ast,collections,gzip,hashlib,json,os,stat,subprocess,time,shutil
ROOT=Path('/workspace/oracles')
OUT=Path(__file__).resolve().parent
PLAN=json.loads((OUT/'gzip-dedup-manifest.json').read_bytes())
TARGET=int(2.4*2**30)
ns={'Path':Path,'os':os}
f=next(x for x in ast.parse(Path('/workspace/review-proof/review-pr800-worktree-audit/retire.py').read_text()).body if isinstance(x,ast.FunctionDef) and x.name=='visible_users')
exec(compile(ast.Module(body=[f],type_ignores=[]),'read-only-visible-users', 'exec'),ns)

def event(d):
 with (OUT/'dedup-journal.jsonl').open('ab') as f:
  f.write((json.dumps({'at_ns':time.time_ns(),**d},sort_keys=True)+'\n').encode());f.flush();os.fsync(f.fileno())

def digest(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  while b:=f.read(2**20):h.update(b)
 return h.hexdigest()

def raw_digest(p):
 h=hashlib.sha256();n=0
 with gzip.open(p,'rb') as f:
  while b:=f.read(2**20):h.update(b);n+=len(b)
 return h.hexdigest(),n

refs=collections.defaultdict(list)
# Retain receipt paths/hash and every direct gzip reference, without altering provenance.
for p in ROOT.rglob('*.json'):
 if p.name not in ['receipt.json','manifest.json'] or p.stat().st_size>32*2**20:continue
 b=p.read_bytes()
 try:d=json.loads(b)
 except (json.JSONDecodeError,UnicodeDecodeError):continue
 def walk(x,at=''):
  if isinstance(x,dict):
   for k,v in x.items():walk(v,at+'/'+k)
  elif isinstance(x,list):
   for i,v in enumerate(x):walk(v,at+'/'+str(i))
  elif isinstance(x,str) and x.endswith('.gz') and x.startswith('/workspace/oracles/'):
   refs[x].append({'receipt':str(p),'receipt_sha256':hashlib.sha256(b).hexdigest(),'pointer':at})
 walk(d)

baseline=shutil.disk_usage('/workspace').free
approved=[];skips=[]
event({'phase':'preflight-start','authorization':'Root exact compressed immutable sameFS/mode/uid/gid dedup; metadata restore policy','baseline_free':baseline,'maximum_groups':608,'target_free':TARGET,'privileged_services_UNVERIFIED':[198,249],'no_global_zero_claim':True})
assert len(PLAN['duplicate_groups'])==608
# Complete original metadata, hashes, gzip roundtrip and visible-reader audit before any mutation.
for group in PLAN['duplicate_groups']:
 buckets=collections.defaultdict(list)
 for old in group['files']:
  p=Path(old['path']);assert p.is_relative_to(ROOT) and p.resolve()==p and not p.is_symlink()
  s=p.stat();assert stat.S_ISREG(s.st_mode) and s.st_size==old['bytes']
  assert digest(p)==group['sha256'],('changed compressed original',str(p))
  raw,n=raw_digest(p)
  users,unknown=ns['visible_users'](p)
  if users:skips.append({'path':str(p),'reason':'visible consumer','users':users});continue
  row={'path':str(p),'compressed_sha256':group['sha256'],'compressed_bytes':s.st_size,'raw_sha256':raw,'raw_bytes':n,'dev':s.st_dev,'inode':s.st_ino,'allocated_bytes':s.st_blocks*512,'mode':stat.S_IMODE(s.st_mode),'uid':s.st_uid,'gid':s.st_gid,'mtime_ns':s.st_mtime_ns,'atime_ns':s.st_atime_ns,'nlink':s.st_nlink,'xattrs':{k:os.getxattr(p,k).hex() for k in os.listxattr(p)},'visible_users':users,'privileged_services_UNVERIFIED':unknown,'receipt_refs':refs.get(str(p),[]),'gzip_roundtrip_verified':True}
  buckets[(s.st_dev,s.st_mode,s.st_uid,s.st_gid,json.dumps(row['xattrs'],sort_keys=True))].append(row)
 for key,rows in buckets.items():
  if len({x['inode'] for x in rows})>1:
   assert len({(x['raw_sha256'],x['raw_bytes']) for x in rows})==1
   approved.append({'compressed_sha256':group['sha256'],'files':rows,'potential_bytes':sum(x['allocated_bytes'] for x in {x['inode']:x for x in rows}.values())-max(x['allocated_bytes'] for x in rows)})
result={'authorization':'Root exact reversible dedup','original_plan_sha256':digest(OUT/'gzip-dedup-manifest.json'),'baseline_free':baseline,'groups':approved,'skips':skips,'atime_mtime_policy':'original per-path timestamps retained; canonical shared inode timestamp after link; copy-break restore before future write','original_payload_inner_header_paths_mode_uid_gid_refs_preserved':True,'privileged_services_UNVERIFIED':[198,249],'global_complete_zero_user_claim':False}
(OUT/'full-original-restore-manifest.json').write_text(json.dumps(result,indent=2)+'\n')
event({'phase':'preflight-complete','groups':len(approved),'skips':len(skips),'potential_upperbound':sum(x['potential_bytes'] for x in approved),'manifest_sha256':digest(OUT/'full-original-restore-manifest.json')})
p=subprocess.run(['docker','ps','-q','--no-trunc'],capture_output=True,check=False)
event({'phase':'Docker-precondition','argv':['docker','ps','-q','--no-trunc'],'exit':p.returncode,'stdout_hex':p.stdout.hex(),'stderr_hex':p.stderr.hex()});assert p.returncode==0 and not p.stdout.strip()
changes=[]
try:
 for gi,group in enumerate(sorted(approved,key=lambda x:x['potential_bytes'],reverse=True)):
  if shutil.disk_usage('/workspace').free>=TARGET:event({'phase':'budget-stop','available':shutil.disk_usage('/workspace').free});break
  rows=group['files'];canonical=Path(rows[0]['path']);assert digest(canonical)==group['compressed_sha256']
  for row in rows[1:]:
   if shutil.disk_usage('/workspace').free>=TARGET:break
   path=Path(row['path']);s=path.stat();c=canonical.stat()
   if s.st_ino==c.st_ino:continue
   assert (s.st_dev,s.st_ino,stat.S_IMODE(s.st_mode),s.st_uid,s.st_gid,s.st_mtime_ns)==(row['dev'],row['inode'],row['mode'],row['uid'],row['gid'],row['mtime_ns'])
   assert digest(path)==row['compressed_sha256']
   for check in [path,canonical]:
    users,unknown=ns['visible_users'](check);assert not users,('new visible consumer; stop',str(check),users)
   temporary=path.with_name(path.name+'.dedup-owned-'+str(os.getpid()))
   assert not temporary.exists() and not temporary.is_symlink()
   before=shutil.disk_usage('/workspace').free
   event({'phase':'atomic-link-start','source':str(canonical),'target':str(path),'temporary':str(temporary),'original_metadata':row,'free_before':before})
   os.link(canonical,temporary,follow_symlinks=False)
   try:
    os.replace(temporary,path)
    fd=os.open(path.parent,os.O_RDONLY|os.O_DIRECTORY)
    try:os.fsync(fd)
    finally:os.close(fd)
   finally:
    if temporary.exists():temporary.unlink()
   assert path.stat().st_ino==canonical.stat().st_ino and digest(path)==row['compressed_sha256']
   change={'source':str(canonical),'target':str(path),'new_inode':path.stat().st_ino,'compressed_sha256':row['compressed_sha256'],'free_before':before,'free_after':shutil.disk_usage('/workspace').free,'original_metadata_recorded':True}
   changes.append(change);event({'phase':'atomic-link-finish','exit':0,**change})
 # Every original path, byte hash and mode/owner remains present, including untouched rows.
 for group in approved:
  for row in group['files']:
   p=Path(row['path']);s=p.stat();assert digest(p)==row['compressed_sha256'];assert (stat.S_IMODE(s.st_mode),s.st_uid,s.st_gid)==(row['mode'],row['uid'],row['gid'])
 final=shutil.disk_usage('/workspace').free
 summary={'baseline_free':baseline,'final_free':final,'observed_available_change':final-baseline,'target_free':TARGET,'atomic_replacements':len(changes),'all_paths_compressed_hashes_modes_owners_verified_after':True,'original_raw_SHA_roundtrips_verified_before':True,'all_refs_preserved':True,'all_original_perpath_timestamps_in_restore_manifest':True,'canonical_inode_timestamp_is_storage_metadata':True,'no_Git_source_target_cache_or_other_filesystem_mutation':True,'privileged_services_UNVERIFIED':[198,249],'global_zero_claim':False,'changes':changes}
 (OUT/'dedup-result.json').write_text(json.dumps(summary,indent=2)+'\n');event({'phase':'finished','replacements':len(changes),'final_free':final,'observed_change':final-baseline})
 print(json.dumps({k:v for k,v in summary.items() if k!='changes'}),flush=True)
except BaseException as e:
 event({'phase':'FAIL_STOP','exception':type(e).__name__,'error':str(e),'completed_replacements':len(changes),'available':shutil.disk_usage('/workspace').free});raise
