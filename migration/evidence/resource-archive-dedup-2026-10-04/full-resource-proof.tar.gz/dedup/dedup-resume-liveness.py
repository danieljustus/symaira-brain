from pathlib import Path
import ast,collections,gzip,hashlib,json,os,stat,subprocess,time,shutil
ROOT=Path('/workspace/oracles')
OUT=Path(__file__).resolve().parent
PLAN=json.loads((OUT/'gzip-dedup-manifest.json').read_bytes())
TARGET=int(2.4*2**30)
ns={'Path':Path,'os':os}
f=next(x for x in ast.parse(Path('/workspace/review-proof/review-pr800-worktree-audit/retire.py').read_text()).body if isinstance(x,ast.FunctionDef) and x.name=='visible_users')
# Re-check liveness after a denied access; vanished executors are not live readers.
source=ast.unparse(f).replace('except PermissionError:', '''except PermissionError:
            try:
                fields = dict(line.split(':',1) for line in (proc/'status').read_text().splitlines() if ':' in line)
            except FileNotFoundError:
                continue''')
exec(compile(source,'read-only-visible-users-race-liveness','exec'),ns)

def event(d):
 with (OUT/'dedup-journal.jsonl').open('ab') as f:
  f.write((json.dumps({'at_ns':time.time_ns(),**d},sort_keys=True)+'\n').encode());f.flush();os.fsync(f.fileno())

def digest(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  while b:=f.read(2**20):h.update(b)
 return h.hexdigest()

def raw_digest(p):
 h=hashlib.sha256();n=0
 with gzip.open(p,'rb') as f:
  while b:=f.read(2**20):h.update(b);n+=len(b)
 return h.hexdigest(),n

result=json.loads((OUT/'full-original-restore-manifest.json').read_bytes())
approved=result['groups'];baseline=shutil.disk_usage('/workspace').free
assert len(approved)<=608
prior=[json.loads(line) for line in (OUT/'dedup-journal.jsonl').read_bytes().splitlines()]
completed={e['target']:e for e in prior if e['phase']=='atomic-link-finish'}
event({'phase':'resume-preflight-start','baseline_free':baseline,'prior_replacements':len(completed),'original_manifest_preserved':True})
for group in approved:
 for row in group['files']:
  path=Path(row['path']);s=path.stat()
  assert path.is_relative_to(ROOT) and path.resolve()==path and not path.is_symlink()
  assert stat.S_ISREG(s.st_mode)
  assert digest(path)==row['compressed_sha256']
  assert raw_digest(path)==(row['raw_sha256'],row['raw_bytes'])
  assert (s.st_dev,stat.S_IMODE(s.st_mode),s.st_uid,s.st_gid)==(row['dev'],row['mode'],row['uid'],row['gid'])
  assert {k:os.getxattr(path,k).hex() for k in os.listxattr(path)}==row['xattrs']
  if row['path'] in completed:
   assert s.st_ino==completed[row['path']]['new_inode']
  else:
   assert (s.st_ino,s.st_mtime_ns)==(row['inode'],row['mtime_ns'])
  users,unknown=ns['visible_users'](path);assert not users
 for row in group['files']:
  for ref in row['receipt_refs']:
   assert digest(Path(ref['receipt']))==ref['receipt_sha256']
event({'phase':'resume-preflight-complete','groups':len(approved),'original_restore_manifest_sha256':digest(OUT/'full-original-restore-manifest.json')})
p=subprocess.run(['docker','ps','-q','--no-trunc'],capture_output=True,check=False)
event({'phase':'Docker-precondition','argv':['docker','ps','-q','--no-trunc'],'exit':p.returncode,'stdout_hex':p.stdout.hex(),'stderr_hex':p.stderr.hex()});assert p.returncode==0 and not p.stdout.strip()
changes=[]
try:
 for gi,group in enumerate(sorted(approved,key=lambda x:x['potential_bytes'],reverse=True)):
  if shutil.disk_usage('/workspace').free>=TARGET:event({'phase':'budget-stop','available':shutil.disk_usage('/workspace').free});break
  rows=group['files'];canonical=Path(rows[0]['path']);assert digest(canonical)==group['compressed_sha256']
  for row in rows[1:]:
   if shutil.disk_usage('/workspace').free>=TARGET:break
   path=Path(row['path']);s=path.stat();c=canonical.stat()
   if s.st_ino==c.st_ino:continue
   assert (s.st_dev,s.st_ino,stat.S_IMODE(s.st_mode),s.st_uid,s.st_gid,s.st_mtime_ns)==(row['dev'],row['inode'],row['mode'],row['uid'],row['gid'],row['mtime_ns'])
   assert digest(path)==row['compressed_sha256']
   for check in [path,canonical]:
    users,unknown=ns['visible_users'](check);assert not users,('new visible consumer; stop',str(check),users)
   temporary=path.with_name(path.name+'.dedup-owned-'+str(os.getpid()))
   assert not temporary.exists() and not temporary.is_symlink()
   before=shutil.disk_usage('/workspace').free
   event({'phase':'atomic-link-start','source':str(canonical),'target':str(path),'temporary':str(temporary),'original_metadata':row,'free_before':before})
   os.link(canonical,temporary,follow_symlinks=False)
   try:
    os.replace(temporary,path)
    fd=os.open(path.parent,os.O_RDONLY|os.O_DIRECTORY)
    try:os.fsync(fd)
    finally:os.close(fd)
   finally:
    if temporary.exists():temporary.unlink()
   assert path.stat().st_ino==canonical.stat().st_ino and digest(path)==row['compressed_sha256']
   change={'source':str(canonical),'target':str(path),'new_inode':path.stat().st_ino,'compressed_sha256':row['compressed_sha256'],'free_before':before,'free_after':shutil.disk_usage('/workspace').free,'original_metadata_recorded':True}
   changes.append(change);event({'phase':'atomic-link-finish','exit':0,**change})
 # Every original path, byte hash and mode/owner remains present, including untouched rows.
 for group in approved:
  for row in group['files']:
   p=Path(row['path']);s=p.stat();assert digest(p)==row['compressed_sha256'];assert (stat.S_IMODE(s.st_mode),s.st_uid,s.st_gid)==(row['mode'],row['uid'],row['gid'])
 final=shutil.disk_usage('/workspace').free
 summary={'baseline_free':baseline,'final_free':final,'observed_available_change':final-baseline,'target_free':TARGET,'atomic_replacements':len(changes),'all_paths_compressed_hashes_modes_owners_verified_after':True,'original_raw_SHA_roundtrips_verified_before':True,'all_refs_preserved':True,'all_original_perpath_timestamps_in_restore_manifest':True,'canonical_inode_timestamp_is_storage_metadata':True,'no_Git_source_target_cache_or_other_filesystem_mutation':True,'privileged_services_UNVERIFIED':[198,249],'global_zero_claim':False,'changes':changes}
 (OUT/'dedup-resume-result.json').write_text(json.dumps(summary,indent=2)+'\n');event({'phase':'finished','replacements':len(changes),'final_free':final,'observed_change':final-baseline})
 print(json.dumps({k:v for k,v in summary.items() if k!='changes'}),flush=True)
except BaseException as e:
 event({'phase':'FAIL_STOP','exception':type(e).__name__,'error':str(e),'completed_replacements':len(changes),'available':shutil.disk_usage('/workspace').free});raise
