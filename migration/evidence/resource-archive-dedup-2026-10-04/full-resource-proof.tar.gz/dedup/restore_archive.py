"""Restore one original path's storage metadata and break its shared inode.

An explicit manifest and exact approved path are mandatory. This does not run
automatically during dedup. Use it before writing to a shared immutable archive.
"""
from pathlib import Path
import argparse
import gzip
import hashlib
import json
import os
import shutil
import stat


def digest(path, compressed=True):
    h = hashlib.sha256()
    size = 0
    opener = Path.open if compressed else gzip.open
    with opener(path, 'rb') as stream:
        while data := stream.read(1024 * 1024):
            h.update(data)
            size += len(data)
    return h.hexdigest(), size


def restore(row):
    path = Path(row['path'])
    assert not path.is_symlink() and path.resolve() == path
    assert stat.S_ISREG(path.stat().st_mode)
    assert digest(path) == (row['compressed_sha256'], row['compressed_bytes'])
    assert digest(path, False) == (row['raw_sha256'], row['raw_bytes'])
    temporary = path.with_name(path.name + '.restore-owned-' + str(os.getpid()))
    assert not temporary.exists() and not temporary.is_symlink()
    original_inode = path.stat().st_ino
    try:
        with temporary.open('xb') as output, path.open('rb') as source:
            shutil.copyfileobj(source, output)
            output.flush()
            os.fsync(output.fileno())
        os.chmod(temporary, row['mode'])
        info = temporary.stat()
        if (info.st_uid, info.st_gid) != (row['uid'], row['gid']):
            os.chown(temporary, row['uid'], row['gid'])
        for key, value in row['xattrs'].items():
            os.setxattr(temporary, key, bytes.fromhex(value))
        assert digest(temporary) == (row['compressed_sha256'], row['compressed_bytes'])
        assert digest(temporary, False) == (row['raw_sha256'], row['raw_bytes'])
        os.replace(temporary, path)
        fd = os.open(path.parent, os.O_RDONLY | os.O_DIRECTORY)
        try:
            os.fsync(fd)
        finally:
            os.close(fd)
        assert path.stat().st_ino != original_inode
        assert digest(path) == (row['compressed_sha256'], row['compressed_bytes'])
        os.utime(path, ns=(row['atime_ns'], row['mtime_ns']))
        fd = os.open(path, os.O_RDONLY)
        try:
            os.fsync(fd)
        finally:
            os.close(fd)
        info = path.stat()
        assert (info.st_mode & 0o7777, info.st_uid, info.st_gid,
                info.st_atime_ns, info.st_mtime_ns) == (
                    row['mode'], row['uid'], row['gid'],
                    row['atime_ns'], row['mtime_ns'])
        return dict(path=str(path), restored=True, original_inode=original_inode,
                    new_inode=info.st_ino, original_payload_verified=True)
    finally:
        if temporary.exists():
            temporary.unlink()


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--manifest', type=Path, required=True)
    parser.add_argument('--path', required=True)
    args = parser.parse_args()
    manifest = json.loads(args.manifest.read_bytes())
    rows = [row for group in manifest['groups'] for row in group['files']
            if row['path'] == args.path]
    assert len(rows) == 1, 'exact approved archive path required'
    print(json.dumps(restore(rows[0]), sort_keys=True))
