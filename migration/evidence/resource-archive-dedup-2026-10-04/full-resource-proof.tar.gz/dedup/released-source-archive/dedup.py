from pathlib import Path
import hashlib,json,os,stat,shutil,subprocess,time
BASE=Path('/workspace/review-proof/review-pr800-resource-derivatives')
helper=(BASE/'dedup-resume-known-service.py').read_text().split("result=json.loads((OUT/")[0]
helper=helper.replace("OUT=Path(__file__).resolve().parent", "OUT=BASE")
exec(compile(helper,'unchanged-conservative-dedup-helpers','exec'))
OUT=BASE/'released-source-archive'
SOURCE=Path('/workspace/symaira-source765-runtime-review-run/rust-elf-archive')
THRESHOLD=2362232013
MAX_GAIN=209715200
first=json.loads((BASE/'full-original-restore-manifest.json').read_bytes())
known={r['compressed_sha256']:r for g in first['groups'] for r in g['files']}
refs=[]
for p in SOURCE.parent.glob('*.json'):
 refs.append({'path':str(p),'sha256':digest(p),'bytes':p.stat().st_size})
approved=[];skipped=[]
baseline=shutil.disk_usage('/workspace').free
event({'phase':'exact-released-preflight-start','prefix':str(SOURCE),'initial_free':baseline,'threshold':THRESHOLD,'maximum_gain':MAX_GAIN,'Root_and_Usage_release':True,'first_original_manifest_sha256':digest(BASE/'full-original-restore-manifest.json')})
for path in sorted(SOURCE.glob('*.gz')):
 s=path.lstat();assert stat.S_ISREG(s.st_mode) and path.resolve()==path and not path.is_symlink()
 h=digest(path)
 if h not in known:skipped.append({'path':str(path),'reason':'no exact prior verified compressed match','sha256':h});continue
 old=known[h];canonical=Path(old['path']);cs=canonical.stat()
 assert digest(canonical)==h
 if s.st_ino==cs.st_ino:skipped.append({'path':str(path),'reason':'already shares inode','sha256':h});continue
 attrs={k:os.getxattr(path,k).hex() for k in os.listxattr(path)}
 if (s.st_dev,stat.S_IMODE(s.st_mode),s.st_uid,s.st_gid,attrs)!=(cs.st_dev,old['mode'],old['uid'],old['gid'],old['xattrs']):
  skipped.append({'path':str(path),'reason':'permission/filesystem mismatch','sha256':h});continue
 raw,size=raw_digest(path);assert (raw,size)==(old['raw_sha256'],old['raw_bytes'])
 for check in [path,canonical]:
  users,unknown=ns['visible_users'](check);assert not users,('visible consumer',str(check),users)
 approved.append({'path':str(path),'canonical':str(canonical),'dev':s.st_dev,'inode':s.st_ino,'mode':stat.S_IMODE(s.st_mode),'uid':s.st_uid,'gid':s.st_gid,'mtime_ns':s.st_mtime_ns,'atime_ns':s.st_atime_ns,'nlink':s.st_nlink,'xattrs':attrs,'allocated_bytes':s.st_blocks*512,'compressed_sha256':h,'compressed_bytes':s.st_size,'raw_sha256':raw,'raw_bytes':size,'visible_consumers':[],'privileged_services_UNVERIFIED':unknown})
manifest={'groups':[{'files':approved}],'refs':refs,'skipped':skipped,'original_baseline_free':baseline,'first_original_manifest':str(BASE/'full-original-restore-manifest.json'),'maximum_actual_gain':MAX_GAIN,'actual_free_stop_threshold':THRESHOLD,'original_perpath_storage_timestamps_retained':True}
(OUT/'full-original-restore-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
event({'phase':'exact-released-preflight-complete','approved':len(approved),'skipped':len(skipped),'allocated_upperbound':sum(r['allocated_bytes'] for r in approved),'manifest_sha256':digest(OUT/'full-original-restore-manifest.json')})
ps=subprocess.run(['docker','ps','-q','--no-trunc'],capture_output=True);event({'phase':'docker-precondition','exit':ps.returncode,'stdout_hex':ps.stdout.hex(),'stderr_hex':ps.stderr.hex()});assert ps.returncode==0 and not ps.stdout.strip()
changes=[]
try:
 for row in sorted(approved,key=lambda r:r['allocated_bytes'],reverse=True):
  free=shutil.disk_usage('/workspace').free
  if free>=THRESHOLD or free-baseline>=MAX_GAIN:break
  # Never authorize more than the stage's200MiB allocation ceiling.
  if sum(r['allocated_bytes'] for r in changes)+row['allocated_bytes']>MAX_GAIN:continue
  path=Path(row['path']);canonical=Path(row['canonical']);s=path.stat()
  assert (s.st_dev,s.st_ino,stat.S_IMODE(s.st_mode),s.st_uid,s.st_gid,s.st_mtime_ns)==(row['dev'],row['inode'],row['mode'],row['uid'],row['gid'],row['mtime_ns'])
  assert digest(path)==digest(canonical)==row['compressed_sha256']
  for check in [path,canonical]:
   users,unknown=ns['visible_users'](check);assert not users,('new visible consumer',str(check),users)
  temp=path.with_name(path.name+'.dedup-owned-'+str(os.getpid()));assert not temp.exists() and not temp.is_symlink()
  event({'phase':'atomic-link-start','row':row,'temporary':str(temp),'free_before':free})
  os.link(canonical,temp,follow_symlinks=False)
  try:
   os.replace(temp,path);fd=os.open(path.parent,os.O_RDONLY|os.O_DIRECTORY)
   try:os.fsync(fd)
   finally:os.close(fd)
  finally:
   if temp.exists():temp.unlink()
  assert path.stat().st_ino==canonical.stat().st_ino and digest(path)==row['compressed_sha256']
  changes.append(row);event({'phase':'atomic-link-finish','path':str(path),'source':str(canonical),'sha256':row['compressed_sha256'],'exit':0,'free_after':shutil.disk_usage('/workspace').free})
 for row in approved:
  p=Path(row['path']);s=p.stat();assert digest(p)==row['compressed_sha256'];assert (stat.S_IMODE(s.st_mode),s.st_uid,s.st_gid)==(row['mode'],row['uid'],row['gid'])
 for ref in refs:assert digest(Path(ref['path']))==ref['sha256']
 free=shutil.disk_usage('/workspace').free
 result={'status':'complete exact released subset','baseline_free':baseline,'final_free':free,'observed_delta':free-baseline,'isolated_gain_claim':False,'threshold':THRESHOLD,'actual_2GiB_lease_floor_met':free>=2**31,'approved':len(approved),'skipped':len(skipped),'replacements':len(changes),'replaced_allocated_upperbound':sum(r['allocated_bytes'] for r in changes),'all_original_paths_SHA_mode_owner_and_refs_verified':True,'original_raw_gzip_roundtrip_verified':True,'original_timestamps_in_restore_manifest':True,'unmodified_original_first_stage':True,'other_source_target_scratch_bin_not_mutated':True,'privileged_services_UNVERIFIED':[198,249],'no_global_zero_reader_claim':True}
 (OUT/'result.json').write_text(json.dumps(result,indent=2)+'\n');event({'phase':'finished',**result});print(json.dumps(result))
except BaseException as error:
 event({'phase':'FAIL_STOP','error':str(error),'exception':type(error).__name__,'completed_replacements':len(changes),'free':shutil.disk_usage('/workspace').free});raise
