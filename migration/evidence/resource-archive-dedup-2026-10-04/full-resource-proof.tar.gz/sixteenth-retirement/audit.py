from pathlib import Path
import os,json,hashlib,subprocess,stat,gzip,shutil,time
OUT=Path(__file__).resolve().parent
ROOT=Path('/workspace/symaira-source765-windows-job-cleanup')
SURVIVOR=Path('/workspace/symaira-source765-windows-job-runtime-review')
HEAD='7b10ff20027407ca9bc32f3d72e28d07003fce77'
BASE=Path('/workspace/review-proof/review-pr800-resource-derivatives')
helper=(BASE/'dedup-resume-known-service.py').read_text().split("result=json.loads((OUT/")[0].replace('OUT=Path(__file__).resolve().parent','OUT=BASE')
namespace={'BASE':BASE,'__file__':__file__};exec(compile(helper,'verified-read-only-conservative-audit','exec'),namespace)
commands=[]
def command(argv,cwd=ROOT):
 p=subprocess.run(argv,cwd=cwd,capture_output=True);commands.append({'argv':argv,'cwd':str(cwd),'exit':p.returncode,'stdout_hex':p.stdout.hex(),'stderr_hex':p.stderr.hex()});assert p.returncode==0;return p.stdout
assert ROOT.parent==Path('/workspace') and ROOT.resolve()==ROOT and not ROOT.is_symlink()
assert command(['git','rev-parse','HEAD']).decode().strip()==HEAD
assert command(['git','rev-parse','HEAD'],SURVIVOR).decode().strip()==HEAD
branch=command(['git','symbolic-ref','HEAD']).decode().strip()
assert command(['git','rev-parse',branch]).decode().strip()==HEAD
assert not (ROOT/'target').exists() and not (ROOT/'target').is_symlink()
status=command(['git','status','--porcelain=v1','-z','--ignored','--untracked-files=normal'])
ignored=[]
for entry in status.split(b'\0'):
 if not entry:continue
 assert entry.startswith(b'!! ')
 rel=os.fsdecode(entry[3:]);assert '__pycache__' in Path(rel).parts
 ignored.append(rel)
files=[]
for entry in command(['git','ls-files','--stage','-z']).split(b'\0'):
 if not entry:continue
 meta,relative=entry.split(b'\t',1);mode,blob,stage=meta.split();assert stage==b'0'
 path=ROOT/os.fsdecode(relative);survivor=SURVIVOR/os.fsdecode(relative);info=path.lstat();other=survivor.lstat()
 if mode==b'120000':
  assert stat.S_ISLNK(info.st_mode) and stat.S_ISLNK(other.st_mode);data=os.fsencode(os.readlink(path));copy=os.fsencode(os.readlink(survivor))
 else:
  assert stat.S_ISREG(info.st_mode) and stat.S_ISREG(other.st_mode);data=path.read_bytes();copy=survivor.read_bytes()
 assert data==copy,(relative,'surviving fullsource mismatch')
 assert hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()==blob.decode()
 files.append({'relative_path_hex':relative.hex(),'git_mode':mode.decode(),'blob':blob.decode(),'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data),'original_native_mode':stat.S_IMODE(info.st_mode),'surviving_native_mode':stat.S_IMODE(other.st_mode),'survivor_full_bytes_equal':True})
(OUT/'full-tracked-manifest.json').write_text(json.dumps(files,indent=2)+'\n')
derivatives=[]
for rel in ignored:
 for path in (ROOT/rel).rglob('*'):
  if path.is_dir():continue
  assert path.is_file() and not path.is_symlink() and path.suffix=='.pyc'
  data=path.read_bytes();archive=OUT/(hashlib.sha256(data).hexdigest()+'.pyc.gz')
  archive.write_bytes(gzip.compress(data,mtime=0));assert gzip.decompress(archive.read_bytes())==data
  derivatives.append({'path':str(path),'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data),'mode':stat.S_IMODE(path.stat().st_mode),'archive':str(archive),'archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'derivative_only_not_deleted':True})
users,unknown=namespace['ns']['visible_users'](ROOT);assert not users
ps=command(['docker','ps','-q','--no-trunc']);assert not ps.strip()
refs=command(['git','for-each-ref','--contains',HEAD,'--format=%(refname) %(objectname)']).decode().splitlines();assert any(x==branch+' '+HEAD for x in refs)
assert command(['git','rev-parse','HEAD']).decode().strip()==HEAD
assert command(['git','status','--porcelain=v1','-z','--ignored','--untracked-files=normal'])==status
result={'status':'READ_ONLY_READY_ROOT_DECISION','exact_source':str(ROOT),'HEAD':HEAD,'branch_ref':branch,'survivor_exact_same_HEAD':str(SURVIVOR),'survivor_all_tracked_bytes_equal':True,'all_tracked_Git_blob_identity_verified':True,'tracked_files':len(files),'tracked_bytes':sum(f['bytes'] for f in files),'native_modes_fully_recorded':True,'persistent_refs_containing_HEAD':refs,'strict_published_ancestor_claim':False,'reason':'obsolete exact-HEAD duplicate; Root currentruntime counterpart andallsource/rawGitobjects survive','target_absent':True,'unknown_untracked_ignored_absent':True,'only_ignored_derivatives':derivatives,'visible_consumers':users,'privileged_services_UNVERIFIED':unknown,'Docker_containers':0,'global_zero_reader_claim':False,'restore_argv':['git','-C','/workspace/symaira-brain','worktree','add',str(ROOT),branch],'restore_native_modes':'apply original_native_mode from every complete tracked manifest record','original_source_deleted':False,'free_at_audit':shutil.disk_usage('/workspace').free,'commands':commands}
(OUT/'receipt.json').write_text(json.dumps(result,indent=2)+'\n');print({k:v for k,v in result.items() if k not in ['commands','persistent_refs_containing_HEAD','only_ignored_derivatives','privileged_services_UNVERIFIED']})
