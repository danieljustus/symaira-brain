from pathlib import Path
import json,hashlib,os,stat,subprocess,shutil,gzip,time
OUT=Path(__file__).resolve().parent;ROOT=Path('/workspace/symaira-source765-windows-job-cleanup');SURVIVOR=Path('/workspace/symaira-source765-windows-job-runtime-review');SHARED=Path('/workspace/symaira-brain')
r=json.loads((OUT/'receipt.json').read_bytes());m=json.loads((OUT/'full-tracked-manifest.json').read_bytes());assert hashlib.sha256((OUT/'receipt.json').read_bytes()).hexdigest()=='3f1a8e7c2fa9a06d7b9c94404f02777c19c95517dfc982a0c4c3a28f0564f4d5';assert hashlib.sha256((OUT/'full-tracked-manifest.json').read_bytes()).hexdigest()=='024145eeed2fe7a6cec46b613cc824d698d2c418df53e65c08532625a144be05'
BASE=Path('/workspace/review-proof/review-pr800-resource-derivatives');helper=(BASE/'dedup-resume-known-service.py').read_text().split("result=json.loads((OUT/")[0].replace('OUT=Path(__file__).resolve().parent','OUT=BASE');ns2={'BASE':BASE,'__file__':__file__};exec(compile(helper,'same-conservative-visible-users','exec'),ns2)
baseline=shutil.disk_usage('/workspace').free

def journal(value):
 with (OUT/'retirement-journal.jsonl').open('ab') as f:f.write((json.dumps({'at_ns':time.time_ns(),**value},sort_keys=True)+'\n').encode());f.flush();os.fsync(f.fileno())
def command(argv,cwd=SHARED):
 journal({'phase':'command-start','argv':argv,'cwd':str(cwd),'free':shutil.disk_usage('/workspace').free});p=subprocess.run(argv,cwd=cwd,capture_output=True,timeout=120);journal({'phase':'command-finish','argv':argv,'exit':p.returncode,'stdout_hex':p.stdout.hex(),'stderr_hex':p.stderr.hex(),'free':shutil.disk_usage('/workspace').free});assert p.returncode==0;return p.stdout
journal({'phase':'Root-concrete-authorization','exact_one_tree':str(ROOT),'HEAD':r['HEAD'],'root_review_receipt':'/workspace/review-proof/root-source765-old-tree-retirement/verification.json','baseline_free':baseline,'branch_ref_preserved':r['branch_ref'],'known_visibility_gaps':[198,249]})
try:
 assert ROOT.resolve()==ROOT and not ROOT.is_symlink()
 for cwd in [ROOT,SURVIVOR]:assert command(['git','rev-parse','HEAD'],cwd).decode().strip()==r['HEAD']
 assert command(['git','symbolic-ref','HEAD'],ROOT).decode().strip()==r['branch_ref']
 assert command(['git','rev-parse',r['branch_ref']]).decode().strip()==r['HEAD']
 assert not (ROOT/'target').exists() and not (ROOT/'target').is_symlink()
 status=command(['git','status','--porcelain=v1','-z','--ignored','--untracked-files=normal'],ROOT)
 old=next(x for x in r['commands'] if x['argv']==['git','status','--porcelain=v1','-z','--ignored','--untracked-files=normal'])
 assert status.hex()==old['stdout_hex']
 for row in m:
  relative=os.fsdecode(bytes.fromhex(row['relative_path_hex']));p=ROOT/relative;s=p.lstat()
  data=os.fsencode(os.readlink(p)) if row['git_mode']=='120000' else p.read_bytes()
  assert hashlib.sha256(data).hexdigest()==row['sha256'] and stat.S_IMODE(s.st_mode)==row['original_native_mode']
  assert hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()==row['blob']
  q=SURVIVOR/relative;copy=os.fsencode(os.readlink(q)) if row['git_mode']=='120000' else q.read_bytes();assert copy==data
 users,unknown=ns2['ns']['visible_users'](ROOT);assert not users
 assert not command(['docker','ps','-q','--no-trunc']).strip()
 journal({'phase':'fresh-full-verification','tracked_files':len(m),'native_modes_SHA_Gitblobs_survivorbytes':True,'visible_users':users,'privileged_services_UNVERIFIED':unknown,'no_global_zero_claim':True,'target_absent':True,'free':shutil.disk_usage('/workspace').free})
 for row in r['only_ignored_derivatives']:
  p=Path(row['path']);archive=Path(row['archive']);assert p.is_relative_to(ROOT) and '__pycache__' in p.parts and not p.is_symlink();data=p.read_bytes();assert hashlib.sha256(data).hexdigest()==row['sha256'];assert stat.S_IMODE(p.stat().st_mode)==row['mode'];assert hashlib.sha256(archive.read_bytes()).hexdigest()==row['archive_sha256'];assert gzip.decompress(archive.read_bytes())==data
  journal({'phase':'derivative-unlink-start','row':row});p.unlink();journal({'phase':'derivative-unlink-finish','exit':0,'path':str(p)})
 for directory in sorted({Path(x['path']).parent for x in r['only_ignored_derivatives']},key=lambda x:len(x.parts),reverse=True):
  assert '__pycache__' in directory.parts and not list(directory.iterdir());journal({'phase':'empty-pyc-dir-remove-start','path':str(directory)});directory.rmdir();journal({'phase':'empty-pyc-dir-remove-finish','path':str(directory),'exit':0})
 assert not command(['git','status','--porcelain=v1','-z','--ignored','--untracked-files=normal'],ROOT)
 users,unknown=ns2['ns']['visible_users'](ROOT);assert not users;assert not command(['docker','ps','-q','--no-trunc']).strip()
 assert not (ROOT/'target').exists();assert command(['git','rev-parse','HEAD'],ROOT).decode().strip()==r['HEAD']
 command(['git','worktree','remove',str(ROOT)])
 assert not ROOT.exists();assert command(['git','rev-parse',r['branch_ref']]).decode().strip()==r['HEAD'];assert command(['git','rev-parse','HEAD'],SURVIVOR).decode().strip()==r['HEAD']
 for row in m:
  q=SURVIVOR/os.fsdecode(bytes.fromhex(row['relative_path_hex']));data=os.fsencode(os.readlink(q)) if row['git_mode']=='120000' else q.read_bytes();assert hashlib.sha256(data).hexdigest()==row['sha256']
 refs=command(['git','for-each-ref','--contains',r['HEAD'],'--format=%(refname) %(objectname)']).decode().splitlines();assert r['branch_ref']+' '+r['HEAD'] in refs
 free=shutil.disk_usage('/workspace').free;result={'exact_one_tree_retired':str(ROOT),'regular_git_worktree_remove_exit':0,'force_used':False,'baseline_free':baseline,'final_free':free,'observed_global_delta':free-baseline,'isolated_no_interference_gain_claim':False,'actual_2GiB_Source_floor':free>=2**31,'persistent_branch_ref':r['branch_ref'],'HEAD':r['HEAD'],'all4502_survivor_SHA_reverified_after':True,'surviving_source_and_target_not_mutated':True,'all_Gitobjects_retained':True,'refs_after':refs,'full_native_modes_restoration_manifest':str(OUT/'full-tracked-manifest.json'),'restore_argv':r['restore_argv'],'pyc_originals_archive_roundtrips':len(r['only_ignored_derivatives']),'other_trees_targets_cache_deleted':False,'privileged_services_UNVERIFIED':[198,249],'no_global_zero_claim':True,'total_explicitly_authorized_trees_retired':16};(OUT/'retirement-result.json').write_text(json.dumps(result,indent=2)+'\n');journal({'phase':'finished',**result});print(json.dumps({k:v for k,v in result.items() if k!='refs_after'}))
except BaseException as error:journal({'phase':'FAIL_STOP','exception':type(error).__name__,'error':str(error),'free':shutil.disk_usage('/workspace').free});raise
