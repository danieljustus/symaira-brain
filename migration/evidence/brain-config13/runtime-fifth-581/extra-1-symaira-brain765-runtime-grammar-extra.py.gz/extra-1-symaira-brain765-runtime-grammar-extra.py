import base64,gzip,hashlib,json,os,shutil,subprocess,tempfile
from pathlib import Path
ROOT=Path('/workspace/symaira-brain765-runtime');CURRENT=Path('/tmp/symaira-brain765-runtime-111-fifth');PRIOR=Path('/tmp/symaira-brain765-runtime-876-fourth');OUT=Path('/tmp/symaira-brain765-runtime-581-grammar-extra.json')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
b64=lambda b:base64.b64encode(b).decode()
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip();assert head=='5817161902f59db897c9d578692cd4bb173eef53';assert not subprocess.check_output(['git','status','--porcelain'],cwd=ROOT)
bind=json.loads((CURRENT/'binaries.json').read_text());assert bind['source_head']==head
native=CURRENT/'bin/brain_config13_probe';assert sha(native)==bind['actual']['brain_config13_probe']['sha256'];go=PRIOR/'go-probe';old=json.loads((PRIOR/'go-actual-binaries/receipt.json').read_text());assert sha(go)==old['actual_Go_binaries']['go-probe']['sha256']
cases=[('bare-before-utf8',b'invalid=[unterminated\n#\xff\n'),('utf8-before-bare',b'#\xff\ninvalid=[unterminated\n'),('closed-basic-utf8',b'unknown="owned\xff"\n'),('unclosed-basic-utf8',b'unknown="owned\xff'),('closed-literal-utf8',b"unknown='owned\xff'\n"),('unclosed-literal-utf8',b"unknown='owned\xff"),('multiline-basic-utf8',b'unknown="""owned\n\xff\n"""\n'),('multiline-literal-utf8',b"unknown='''owned\n\xff\n'''\n"),('bad-escape-before-utf8',b'unknown="\\uZZZZ\xff"\n'),('table-before-utf8',b'[bad config\n#\xff\n'),('array-before-utf8',b'unknown=[\nunterminated\n#\xff\n'),('fffe-valid',b'\xff\xfeaudit.enabled=false\n'),('feff-valid',b'\xfe\xffaudit.enabled=false\n'),('utf8-bom-valid',b'\xef\xbb\xbfaudit.enabled=false\n'),('fffe-repeated',b'\xff\xfe\xff\xfeaudit.enabled=false\n'),('numeric-token-valid',b'patterns.promotion_threshold=0x10\n'),('inline-grammar-before-utf8',b'unknown={bad=unterminated}\n#\xff\n'),('comment-word-before-utf8',b'# invalid=[unterminated\n#\xff\n')]
def state(root):
 return {str(p.relative_to(root)):{'mode':oct(p.stat().st_mode&0o777),'bytes_b64':b64(p.read_bytes())if p.is_file()else None}for p in sorted(root.rglob('*'))}
rows=[]
with tempfile.TemporaryDirectory(prefix='brain765-owned-grammar-extra-')as temp:
 root=Path(temp)
 for name,data in cases:
  sides={}
  for label,binary in [('go',go),('native',native)]:
   for part in ['home','config/symbrain','project']:(root/part).mkdir(parents=True,exist_ok=True)
   (root/'config/symbrain/config.toml').write_bytes(data);before=state(root)
   env={'HOME':str(root/'home'),'USERPROFILE':str(root/'home'),'XDG_CONFIG_HOME':str(root/'config'),'PATH':'','SYMBRAIN_GO_BINARY':str(root/'absent-go')}
   p=subprocess.run([str(binary)],env=env,cwd=root/'project',input=b'',capture_output=True,timeout=5)
   sides[label]={'exit':p.returncode,'stdout_b64':b64(p.stdout),'stderr_b64':b64(p.stderr),'before':before,'after':state(root)}
   for child in root.iterdir():shutil.rmtree(child)if child.is_dir()else child.unlink()
  rows.append({'id':name,'input_b64':b64(data),'input_sha256':hashlib.sha256(data).hexdigest(),**sides,'exact_equal':sides['go']==sides['native']})
result={'source_head':head,'source_receipt_sha256':sha(CURRENT/'source.json'),'native_Cargo_binding_sha256':sha(CURRENT/'binaries.json'),'go_source_receipt_sha256':sha(PRIOR/'source.json'),'go_preserved_binary_receipt_sha256':sha(PRIOR/'go-actual-binaries/receipt.json'),'go_sha256':sha(go),'native_sha256':sha(native),'runner_sha256':sha(__file__),'actual_os':'linux','total':len(rows),'exact_equal':sum(r['exact_equal']for r in rows),'observations':rows,'no_acceptance_projection':True}
OUT.write_text(json.dumps(result,indent=2)+'\n');print(result['total'],result['exact_equal'])
for r in rows:
 if not r['exact_equal']:
  print(r['id'])
  for side in ['go','native']:print(side,r[side]['exit'],base64.b64decode(r[side]['stderr_b64']).decode('utf8','backslashreplace'))
