from pathlib import Path
import base64, hashlib, json, os, subprocess, tempfile, shutil
GO = Path('/tmp/symaira-brain765-runtime-111-fifth/go-cli')
NATIVE = Path('/tmp/symaira-brain765-runtime-111-fifth/bin/cli')
rows = []
PROFILE = b'[profile]\nname="owned"\n[servers.vault]\nenabled=false\n[servers.memory]\nenabled=false\n[servers.skills]\nenabled=false\n[servers.usage]\nenabled=false\n[audit]\nenabled=false\n'
base = {k: v for k, v in os.environ.items() if not k.startswith(('SYMBRAIN_', 'SYMMEMORY_', 'XDG_')) and k not in ['HOME', 'USERPROFILE', 'HOMEDRIVE', 'HOMEPATH', 'PWD']}
b64 = lambda b: base64.b64encode(b).decode()
sha = lambda b: hashlib.sha256(b).hexdigest()

def state(root):
    result = {}
    for p in root.rglob('*'):
        entry = {'mode': oct(p.lstat().st_mode & 511)}
        if p.is_symlink():
            entry.update(kind='link', target_hex=os.fsencode(os.readlink(p)).hex())
        elif p.is_file():
            entry.update(kind='file', sha256=sha(p.read_bytes()))
        else:
            entry['kind'] = 'directory'
        result[os.fsencode(p.relative_to(root)).hex()] = entry
    return result
with tempfile.TemporaryDirectory(prefix='brain-config13-boundaries-owned-') as td:
    top = Path(td)
    for name, command in [('empty-home', 'mcp'), ('global-directory', 'mcp'), ('project-directory', 'mcp'), ('raw-environment-bool', 'mcp'), ('raw-environment-int', 'mcp'), ('raw-home-read-directory', 'mcp'), ('lexical-xdg-symlink', 'install'), ('lexical-home-symlink', 'install'), ('raw-default-profile-env', 'install'), ('stored-config-path-home-symlink', 'config-path'), ('default-path-with-no-home', 'config-path')]:
        root = top / name
        processes = {}
        for label, binary in [('go', GO), ('native', NATIVE)]:
            if root.exists():
                shutil.rmtree(root)
            for p in ['home', 'work', 'config/symbrain', 'data', 'cache', 'owner/home/.config/symbrain', 'home/.config/symbrain', 'owner/config/symbrain']:
                (root / p).mkdir(parents=True, exist_ok=True)
            (root / 'profile.toml').write_bytes(PROFILE)
            global_path = root / 'config/symbrain/config.toml'
            global_path.write_bytes(b'default_profile="global"\n[audit]\nenabled=false\n')
            env = {**base, 'HOME': str(root / 'home'), 'USERPROFILE': str(root / 'home'), 'XDG_CONFIG_HOME': str(root / 'config'), 'XDG_DATA_HOME': str(root / 'data'), 'XDG_CACHE_HOME': str(root / 'cache'), 'PATH': '', 'SYMBRAIN_GO_BINARY': str(GO)}
            if name in ['empty-home', 'default-path-with-no-home']:
                env['HOME'] = ''
                env['USERPROFILE'] = ''
            if name == 'global-directory':
                global_path.unlink()
                global_path.mkdir()
            if name == 'project-directory':
                (root / 'work/.symbrain.toml').mkdir()
            if name == 'raw-environment-bool':
                env['SYMBRAIN_AUDIT_ENABLED'] = os.fsdecode(b'bad\xff')
            if name == 'raw-environment-int':
                env['SYMBRAIN_PATTERNS_PROMOTION_THRESHOLD'] = os.fsdecode(b'3\xff')
            if name == 'raw-home-read-directory':
                home = root / os.fsdecode(b'home\xff')
                (home / '.config/symbrain/config.toml').mkdir(parents=True)
                env['HOME'] = str(home)
                env['USERPROFILE'] = str(home)
                env.pop('XDG_CONFIG_HOME')
            if name == 'lexical-xdg-symlink':
                (root / 'link').symlink_to('owner/home', target_is_directory=True)
                env['XDG_CONFIG_HOME'] = str(root / 'link/../config')
                (root / 'owner/config/symbrain/config.toml').write_bytes(b'default_profile="other_owner"\n')
            if name in ['lexical-home-symlink', 'stored-config-path-home-symlink']:
                (root / 'link').symlink_to('owner/home', target_is_directory=True)
                env['HOME'] = str(root / 'link/../home')
                env['USERPROFILE'] = env['HOME']
                env.pop('XDG_CONFIG_HOME')
                (root / 'home/.config/symbrain/config.toml').write_bytes(b'default_profile="correct_owner"\n')
                (root / 'owner/home/.config/symbrain/config.toml').write_bytes(b'default_profile="other_owner"\n')
            if name == 'raw-default-profile-env':
                env['SYMBRAIN_DEFAULT_PROFILE'] = os.fsdecode(b'owned\xff')
            args = ['mcp', '--profile-file', str(root / 'profile.toml')] if command == 'mcp' else ['install', '--harness', 'claude', '--dry-run'] if command == 'install' else ['config', 'path']
            before = state(root)
            p = subprocess.run([str(binary), *args], input=b'', cwd=root / 'work', env=env, capture_output=True, timeout=20)
            processes[label] = dict(exit=p.returncode, stdout_b64=b64(p.stdout), stderr_b64=b64(p.stderr), before=before, after=state(root), env_hex={k: os.fsencode(v).hex() for k, v in env.items() if k.startswith(('HOME', 'USERPROFILE', 'SYMBRAIN_', 'XDG_'))})
        rows.append(dict(id=name, command=command, argv=args, observations=processes, raw_process_equal=all((processes['go'][k] == processes['native'][k] for k in ['exit', 'stdout_b64', 'stderr_b64']))))
        Path('/tmp/symaira-brain765-runtime-111-fifth/historical/symaira-brain-config13-boundaries.json').write_text(json.dumps(dict(source='5817161902f59db897c9d578692cd4bb173eef53', native_sha256=sha(NATIVE.read_bytes()), Go_sha256=sha(GO.read_bytes()), no_builds=True, no_review_target_access=True, actual_OS='Linux', observations=rows), indent=2) + '\n')
print([(r['id'], r['observations']['go']['exit'], r['observations']['native']['exit'], r['raw_process_equal']) for r in rows])
