"""Read-only current58fe/frozenGo config census with private roots and owned HTTP."""
from pathlib import Path
import base64, hashlib, json, os, shutil, subprocess, tempfile, threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
GO = Path('/tmp/symaira-brain765-runtime-111-fifth/go-cli')
NATIVE = Path('/tmp/symaira-brain765-runtime-111-fifth/bin/cli')
OUT = Path('/tmp/symaira-brain765-runtime-111-fifth/historical/symaira-brain-config13-inventory.json')
EXPECTED = '205d15b88d215dd761bba39c5c1c03fa0b0cb7c0624ede63260c5a9eb061f7d0'
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert sha(NATIVE) == EXPECTED
PROFILE = b'[profile]\nname="owned"\n[servers.vault]\nenabled=false\n[servers.memory]\nenabled=false\n[servers.skills]\nenabled=false\n[servers.usage]\nenabled=false\n[audit]\nenabled=false\n'
FIELDS = [('default_profile', 'string', 'default_profile = 7\n'), ('audit.enabled', 'pointer bool', '[audit]\nenabled = "yes"\n'), ('audit.verbose', 'plain bool', '[audit]\nverbose = 1\n'), ('gateway.identity_injection', 'pointer bool', '[gateway]\nidentity_injection = "yes"\n'), ('updatecheck.enabled', 'pointer bool', '[updatecheck]\nenabled = []\n'), ('servers.vault.binary_path', 'string', '[servers.vault]\nbinary_path = 1\n'), ('servers.operate.binary_path', 'string', '[servers.operate]\nbinary_path = true\n'), ('servers.scope.binary_path', 'string', '[servers.scope]\nbinary_path = ["x"]\n'), ('patterns.enabled', 'pointer bool', '[patterns]\nenabled = {}\n'), ('patterns.promotion_threshold', 'int64', '[patterns]\npromotion_threshold = "9223372036854775808"\n'), ('modules.browse', 'plain bool', '[modules]\nbrowse = 1\n'), ('modules.operate', 'plain bool', '[modules]\noperate = "yes"\n'), ('modules.scope', 'plain bool', '[modules]\nscope = [false]\n')]
requests = []

class Handler(BaseHTTPRequestHandler):

    def do_GET(self):
        requests.append(self.path)
        self.send_response(503)
        self.end_headers()
        self.wfile.write(b'owned census release refusal')

    def log_message(self, *args):
        pass
server = ThreadingHTTPServer(('127.0.0.1', 0), Handler)
thread = threading.Thread(target=server.serve_forever)
thread.start()
base = {k: v for k, v in os.environ.items() if not k.startswith(('SYMBRAIN_', 'SYMMEMORY_', 'XDG_')) and k not in ['HOME', 'USERPROFILE', 'HOMEDRIVE', 'HOMEPATH', 'PWD']}
rows = []
with tempfile.TemporaryDirectory(prefix='brain-config13-owned-') as raw:
    owned = Path(raw)
    sentinel = owned / 'fallback'
    sentinel.write_text('#!/usr/bin/python3\nimport os,sys,json\nfrom pathlib import Path\nPath(os.environ["INVENTORY_MARKER"]).write_text(json.dumps([os.fsencode(v).hex()for v in sys.argv[1:]]))\nsys.exit(73)\n')
    sentinel.chmod(448)

    def fixture(root, g=b'', p=b''):
        for part in ['home', 'project', 'config/symbrain', 'source', 'data', 'cache']:
            (root / part).mkdir(parents=True, exist_ok=True)
        (root / 'config/symbrain/config.toml').write_bytes(g)
        (root / 'project/.symbrain.toml').write_bytes(p)
        (root / 'profile.toml').write_bytes(PROFILE)

    def env(root, extra={}):
        return {**base, 'HOME': str(root / 'home'), 'USERPROFILE': str(root / 'home'), 'XDG_CONFIG_HOME': str(root / 'config'), 'XDG_DATA_HOME': str(root / 'data'), 'XDG_CACHE_HOME': str(root / 'cache'), 'PATH': '', 'SYMBRAIN_RELEASE_BASE_URL': f'http://127.0.0.1:{server.server_port}', **extra}

    def snapshot(root):
        return {os.fsencode(p.relative_to(root)).hex(): dict(kind='directory' if p.is_dir() else 'file', sha256=sha(p) if p.is_file() else None, mode=oct(p.stat().st_mode & 511)) for p in root.rglob('*') if p.name != 'marker.json'}

    def obs(binary, args, root, e):
        before = snapshot(root)
        requests.clear()
        process = subprocess.run([str(binary), *args], input=b'', cwd=root / 'project', env=e, capture_output=True, timeout=20)
        return dict(exit=process.returncode, stdout_b64=base64.b64encode(process.stdout).decode(), stderr_b64=base64.b64encode(process.stderr).decode(), before=before, after=snapshot(root), owned_release_requests=list(requests))

    def persist():
        OUT.write_text(json.dumps(dict(source='5817161902f59db897c9d578692cd4bb173eef53', actual_OS='Linux', no_builds=True, no_review_target_access=True, native_sha256=sha(NATIVE), frozenGo_sha256=sha(GO), fields=[dict(path=f, type=t) for f, t, _ in FIELDS], observations=rows), indent=2) + '\n')

    def pair(name, command, g=b'', p=b'', extra={}, route=False, extra_args=[]):
        root = owned / name
        fixture(root, g, p)
        args = {'install': ['install', '--harness', 'claude', '--dry-run'], 'mcp': ['mcp', '--profile-file', str(root / 'profile.toml')], 'setup': ['setup', '--json'], 'setup-fix': ['setup', '--fix', '--json'], 'doctor-fix': ['doctor', '--fix'], 'source': ['setup', '--from-source', str(root / 'source'), '--json'], 'config-get': ['config', 'get', 'audit.enabled'], 'doctor': ['doctor', '--json']}[command]
        args += extra_args
        e = env(root, extra)
        go = obs(GO, args, root, e)
        shutil.rmtree(root)
        fixture(root, g, p)
        native = obs(NATIVE, args, root, {**e, 'SYMBRAIN_GO_BINARY': str(GO)})
        row = dict(id=name, command=command, argv=args, global_b64=base64.b64encode(g).decode(), project_b64=base64.b64encode(p).decode(), extra_env=extra, go=go, native=native, equal=go == native)
        if route:
            shutil.rmtree(root)
            fixture(root, g, p)
            marker = root / 'marker.json'
            r = obs(NATIVE, args, root, {**e, 'SYMBRAIN_GO_BINARY': str(sentinel), 'INVENTORY_MARKER': str(marker)})
            row.update(sentinel=r, fallback_invoked=marker.exists(), fallback_argv_hex=json.loads(marker.read_text()) if marker.exists() else None)
        rows.append(row)
        persist()
    try:
        for field, kind, invalid in FIELDS:
            content = invalid.encode()
            if field != 'default_profile':
                content = b'default_profile="owned"\n' + content
            for cmd in ['install', 'mcp', 'setup', 'setup-fix', 'doctor-fix', 'source']:
                pair(field.replace('.', '-') + '-' + cmd, cmd, content, route=cmd in ['setup-fix', 'doctor-fix', 'source'])
        for name, command, g, p, extra in [('project-default', 'install', b'', b'default_profile="owned"\n', {}), ('project-over-global', 'install', b'default_profile="global"\n', b'default_profile="owned"\n', {}), ('global-valid-default', 'install', b'default_profile="owned"\n', b'', {}), ('stored-global-bypass-project-env', 'config-get', b'[audit]\nenabled=true\n', b'[audit]\nenabled="bad"\n', {'SYMBRAIN_AUDIT_ENABLED': 'bad'}), ('file-declaration-error-order', 'mcp', b'[modules]\nscope="bad"\n[audit]\nenabled="bad"\n', b'', {}), ('global-before-project', 'mcp', b'[audit]\nenabled="globalbad"\n', b'[audit]\nenabled="projectbad"\n', {}), ('project-before-env', 'mcp', b'', b'[audit]\nverbose="projectbad"\n', {'SYMBRAIN_AUDIT_ENABLED': 'envbad'}), ('env-declaration-order', 'mcp', b'', b'', {'SYMBRAIN_MODULES_SCOPE': 'bad', 'SYMBRAIN_AUDIT_ENABLED': 'bad'}), ('plain-false-pointer-false', 'mcp', b'[audit]\nenabled=false\nverbose=false\n[modules]\nbrowse=false\n', b'', {}), ('ignore-unknown-scalar-struct', 'mcp', b'audit="ignored"\nmodules=[]\nunknown=true\n', b'', {}), ('bool-alias-file', 'mcp', b'[audit]\nenabled="FALSE"\n[gateway]\nidentity_injection="0"\n', b'', {}), ('empty-env-ignored', 'install', b'default_profile="owned"\n', b'', {'SYMBRAIN_DEFAULT_PROFILE': ''})]:
            pair(name, command, g, p, extra)
        pair('explicit-profile-bypasses-invalid-config', 'install', b'[audit]\nenabled="bad"\n', extra_args=['--profile', 'owned'])
    finally:
        server.shutdown()
        server.server_close()
        thread.join()
print(json.dumps(dict(groups=len(rows), route_sentinel_groups=sum(('fallback_invoked' in r for r in rows)), fallback_invocations=sum((r.get('fallback_invoked', False) for r in rows)), mismatching_groups=sum((not r['equal'] for r in rows)))))
