"""Additional owned Doctor filesystem and managed-owner path boundaries."""
import base64, hashlib, importlib.util, json, os, pathlib, shutil, subprocess, sys, tempfile
ROOT = pathlib.Path('/workspace/symaira-brain765-runtime')
GO = pathlib.Path('/tmp/symaira-brain765-runtime-111-fifth/go-cli')
RUST = pathlib.Path('/tmp/symaira-brain765-runtime-111-fifth/bin/cli')
sys.path.insert(0, str(ROOT / 'scripts/doctor-repair-oracle'))
spec = importlib.util.spec_from_file_location('doctor_second_boundaries', ROOT / 'scripts/doctor-repair-oracle/replay.py')
d = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = d
spec.loader.exec_module(d)
original = d.configure
records = []
with tempfile.TemporaryDirectory(prefix='doctor-second-boundary-tools-') as temporary, d.legacy.ReleaseFixtureServer() as url:
    temp = pathlib.Path(temporary)
    probe = d.build_probe(temp)
    d.legacy.RELEASE_BASE_URL = url
    for name, raw, fault, lexical in [('home-symlink-parent', False, False, 'symlink-parent')]:

        def configure(case, root, env, probe):
            if raw:
                env['HOME'] = str(root / os.fsdecode(b'home\xff\xe2\x82'))
            home = env['HOME']
            if lexical == 'dot':
                env['HOME'] = home + '/./'
            elif lexical == 'parent':
                env['HOME'] = home + '/../' + pathlib.Path(home).name
            elif lexical == 'slash':
                env['HOME'] = home + '//'
            elif lexical == 'symlink-parent':
                (root / 'owner/nested').mkdir(parents=True)
                (root / 'link').symlink_to('owner/nested', target_is_directory=True)
                env['HOME'] = str(root / 'link') + '/../home'
            original(case, root, env, probe)
            if fault:
                binary_dir = pathlib.Path(env['HOME']) / '.symaira/bin'
                shutil.rmtree(binary_dir)
                binary_dir.write_bytes(b'owned obstruction')
        d.configure = configure
        case = d.cases()[0].__class__(name, args=('doctor', '--fix', '--force-release'), verifier=True)
        record = {'case': name, 'raw_home': raw, 'bin_file': fault, 'lexical': lexical}
        for label, binary in [('go', GO), ('rust', RUST)]:
            with tempfile.TemporaryDirectory(prefix='doctor-second-boundary-case-') as root:
                record[label] = d.observe(binary, case, pathlib.Path(root), probe, GO)
        record['differences'] = [key for key in record['go']['contract'] if record['go']['contract'][key] != record['rust']['contract'][key]]
        records.append(record)
    result = dict(head=subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip(), dirty=bool(subprocess.check_output(['git', 'status', '--porcelain'], cwd=ROOT)), go_sha=d.digest(GO), rust_sha=d.digest(RUST), probe_sha=d.digest(probe), cases=records)
    pathlib.Path('/tmp/symaira-brain765-runtime-111-fifth/historical/symaira-doctor765-sixth-independent-supplement-symlink.json').write_bytes((json.dumps(result, indent=2) + '\n').encode())
    print(json.dumps([(r['case'], r['differences']) for r in records]))
