from pathlib import Path
import json, os, tempfile, subprocess, base64, hashlib, shutil
GO = Path('/tmp/symaira-brain765-runtime-111-fifth/go-cli')
NATIVE = Path('/tmp/symaira-brain765-runtime-111-fifth/bin/cli')
PROFILE = b'[profile]\nname="owned"\n[servers.vault]\nenabled=false\n[servers.memory]\nenabled=false\n[servers.skills]\nenabled=false\n[servers.usage]\nenabled=false\n[audit]\nenabled=false\n'
requests = [dict(jsonrpc='2.0', id=1, method='initialize', params={'protocolVersion': '2024-11-05', 'capabilities': {}, 'clientInfo': {'name': 'owned', 'version': '1'}}), dict(jsonrpc='2.0', method='notifications/initialized'), dict(jsonrpc='2.0', id=2, method='tools/call', params={'name': 'patterns', 'arguments': {}})]
input = b''.join(((json.dumps(r) + '\n').encode() for r in requests))
rows = []
base = {k: v for k, v in os.environ.items() if not k.startswith(('SYMBRAIN_', 'SYMMEMORY_', 'XDG_')) and k not in ['HOME', 'USERPROFILE', 'HOMEDRIVE', 'HOMEPATH', 'PWD']}
with tempfile.TemporaryDirectory(prefix='brain-config13-patterns-owned-') as raw:
    top = Path(raw)
    for name, value in [('integer5', '5'), ('float4-9', '4.9'), ('string4', '"4"'), ('zero', '0'), ('negative', '-2'), ('positive-infinity', 'inf'), ('nan', 'nan')]:
        root = top / name
        observations = {}
        for who, binary in [('go', GO), ('native', NATIVE)]:
            if root.exists():
                shutil.rmtree(root)
            for p in ['home', 'work', 'config/symbrain', 'data', 'cache']:
                (root / p).mkdir(parents=True, exist_ok=True)
            (root / 'profile.toml').write_bytes(PROFILE)
            (root / 'config/symbrain/config.toml').write_text('[audit]\nenabled=false\n[patterns]\npromotion_threshold=' + value + '\n')
            e = {**base, 'HOME': str(root / 'home'), 'USERPROFILE': str(root / 'home'), 'XDG_CONFIG_HOME': str(root / 'config'), 'XDG_DATA_HOME': str(root / 'data'), 'XDG_CACHE_HOME': str(root / 'cache'), 'PATH': '', 'SYMBRAIN_GO_BINARY': str(GO)}
            p = subprocess.run([str(binary), 'mcp', '--profile-file', str(root / 'profile.toml')], input=input, cwd=root / 'work', env=e, capture_output=True, timeout=15)
            frames = [json.loads(line) for line in p.stdout.splitlines()]
            call = next((r for r in frames if r.get('id') == 2), None)
            payload = None
            if call and 'result' in call:
                content = call['result'].get('content', [])
                if content and content[0].get('type') == 'text':
                    try:
                        payload = json.loads(content[0]['text'])
                    except json.JSONDecodeError:
                        pass
            observations[who] = dict(exit=p.returncode, stdout_b64=base64.b64encode(p.stdout).decode(), stderr_b64=base64.b64encode(p.stderr).decode(), actual_patterns_payload=payload)
        rows.append(dict(id=name, global_value=value, observations=observations))
        Path('/tmp/symaira-brain765-runtime-111-fifth/historical/symaira-brain-config13-patterns.json').write_text(json.dumps(dict(source='5817161902f59db897c9d578692cd4bb173eef53', native_sha256=hashlib.sha256(NATIVE.read_bytes()).hexdigest(), frozenGo_sha256=hashlib.sha256(GO.read_bytes()).hexdigest(), actual_OS='Linux', input_base64=base64.b64encode(input).decode(), no_builds=True, no_embedding_endpoint=True, observations=rows), indent=2) + '\n')
print([(r['id'], r['observations']['go']['actual_patterns_payload'], r['observations']['native']['actual_patterns_payload']) for r in rows])
