from pathlib import Path
import tempfile, os, subprocess, json, base64
GO = Path('/tmp/symaira-brain765-runtime-111-fifth/go-cli')
NATIVE = Path('/tmp/symaira-brain765-runtime-111-fifth/bin/cli')
rows = []
base = {k: v for k, v in os.environ.items() if not k.startswith(('SYMBRAIN_', 'SYMMEMORY_', 'XDG_')) and k not in ['HOME', 'USERPROFILE', 'HOMEDRIVE', 'HOMEPATH', 'PWD']}
with tempfile.TemporaryDirectory(prefix='brain-config13-admission-owned-') as raw:
    root = Path(raw)
    for p in ['home', 'config/symbrain', 'data', 'cache', 'work', 'work/source']:
        (root / p).mkdir(parents=True, exist_ok=True)
    (root / 'config/symbrain/config.toml').write_bytes(b'[audit]\nenabled="bad"\n')
    env = {**base, 'HOME': str(root / 'home'), 'USERPROFILE': str(root / 'home'), 'XDG_CONFIG_HOME': str(root / 'config'), 'XDG_DATA_HOME': str(root / 'data'), 'XDG_CACHE_HOME': str(root / 'cache'), 'PATH': '', 'SYMBRAIN_GO_BINARY': str(GO)}
    for name, args in [('mcp-profile-first', ['mcp']), ('install-harness-first', ['install']), ('source-root-first', ['setup', '--from-source', 'missing']), ('modules-require-source-first', ['setup', '--modules', 'browse']), ('doctor-help-before-config', ['doctor', '--help']), ('doctor-nonfix-typed-config', ['doctor', '--json'])]:
        pair = {}
        for who, binary in [('go', GO), ('native', NATIVE)]:
            p = subprocess.run([str(binary), *args], input=b'', cwd=root / 'work', env=env, capture_output=True, timeout=20)
            record = dict(exit=p.returncode, stdout_b64=base64.b64encode(p.stdout).decode(), stderr_b64=base64.b64encode(p.stderr).decode())
            if name == 'doctor-nonfix-typed-config':
                record['config_member'] = json.loads(p.stdout).get('config')
            pair[who] = record
        rows.append(dict(id=name, argv=args, observations=pair, exact_process_equal=pair['go'] == pair['native']))
Path('/tmp/symaira-brain765-runtime-111-fifth/historical/symaira-brain-config13-admission.json').write_text(json.dumps(dict(source='5817161902f59db897c9d578692cd4bb173eef53', actual_OS='Linux', no_builds=True, observations=rows), indent=2) + '\n')
print([(r['id'], r['exact_process_equal']) for r in rows])
