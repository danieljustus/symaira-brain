"""Pure prepared-comparator controls; no product, database, SDK or peer runs."""
import copy
import importlib.util
import json
import sys
from pathlib import Path

out = Path('/workspace/symaira-brain765-bc0-independent-source')
scripts = out / 'candidate/scripts/brain-config13'
sys.path.insert(0, str(scripts))
spec = importlib.util.spec_from_file_location('reviewed_startup_replay', scripts / 'startup_replay.py')
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
root = Path('/owned-synthetic-review')
paths = dict(secret=str(root/'jwt.secret'), database=str(root/'default.db'), rotation=str(root/'jwt.secrets'))
go = dict(exit=0, stdout_base64='', stderr_base64='', before={},
    after={'73656e74696e656c': dict(kind='file',mode='0o600',sha256='unchanged')},
    key_contract=None, wal=None, shm=None, actual_interval=[0,1],
    sql=dict(raw_schema=[['trigger','owned_sentinel','memories','CREATE TRIGGER owned_sentinel AFTER INSERT ON memories BEGIN SELECT 1; END']],
        tables=dict(memories=dict(columns=[['content','TEXT']],rows=[['original']],foreign_keys=[],indexes=[])),
        integrity=[('ok',)],indexes={},fts_queries={},semantic_controls={'fts_integrity':True},persistent_pragmas={}))
def compare(native):
    return module.compare(go,native,dict(kind='literal'),paths,root)
rows = [dict(control='equal-synthetic',differences=compare(copy.deepcopy(go)))]
assert not rows[0]['differences']
for name, mutate in [
    ('readonly-byte',lambda n:n['after']['73656e74696e656c'].update(sha256='changed')),
    ('application-row',lambda n:n['sql']['tables']['memories'].update(rows=[['changed']])),
    ('table-default',lambda n:n['sql']['tables']['memories'].update(columns=[['content','TEXT','wrongdefault']])),
    ('foreign-key',lambda n:n['sql']['tables']['memories'].update(foreign_keys=[['wrong']])),
    ('index',lambda n:n['sql']['indexes'].update(owned=['wrong'])),
]:
    native=copy.deepcopy(go);mutate(native);differences=compare(native)
    assert differences, name
    rows.append(dict(control=name,differences=differences))
for name,schema in [('missing-trigger',[]),('changed-trigger-body', [['trigger','owned_sentinel','memories','CREATE TRIGGER owned_sentinel AFTER INSERT ON memories BEGIN SELECT 2; END']])]:
    native=copy.deepcopy(go);native['sql']['raw_schema']=schema
    differences=compare(native)
    assert not differences, (name,differences)
    rows.append(dict(control=name,differences=differences,escaped=True,go=go,native=native))
report=dict(scope='Executed pure Python candidate comparator on invented in-memory structures. Zero product/SDK/SQLite/process evidence; loss of trigger coverage is demonstrated only at prepared comparator boundary.',
    rows=rows, expected_rejections=5, observed_escapes=2)
(out/'static-controls.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(dict(equal=1,rejected=5,escaped=2,product_runs=0,sdk_runs=0,sqlite_opens=0)))
