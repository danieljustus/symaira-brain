import ast
import gzip
import hashlib
import json
import subprocess
from pathlib import Path

root = Path('/workspace/symaira-brain765-runtime')
out = Path('/workspace/symaira-brain765-bc0-independent-source')
head = 'bc0fc7778b8c4afb43e50028158de15220cedf3d'
parent = '43f7d6e85b1889bbd1e9b46b2561b7a66515ef1a'
sha = lambda data: hashlib.sha256(data).hexdigest()
def git(*args):
    return subprocess.check_output(['git', *args], cwd=root)
def blob(name):
    return git('show', head + ':' + name)
def load(name):
    return json.loads(blob(name))

verification_path = Path('/workspace/oracles/symaira-brain765-bc0-source-verification/source.json')
verification = json.loads(verification_path.read_bytes())
assert verification['head'] == head
checked = {}
for name, expected in verification['source'].items():
    data = blob(name)
    assert sha(data) == expected, name
    assert sha((root / name).read_bytes()) == expected, name
    checked[name] = expected
refs = dict(verification['references'])
prep = load('migration/evidence/brain-config13/startup-preparation/checkpoint.json')
for name, record in prep['selected_sdk_sources'].items():
    refs[name] = record['sha256']
sdk_extra = [
    '/home/agent/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/chrono-0.4.45/src/format/parse.rs',
    '/home/agent/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/chrono-0.4.45/src/format/scan.rs',
    '/home/agent/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/serde_json-1.0.145/src/de.rs',
    '/workspace/toolchains/go1.26.7/src/os/path.go',
    '/home/agent/go/pkg/mod/github.com/danieljustus/symaira-corekit@v0.17.0/fsutil/safewrite.go',
    '/home/agent/go/pkg/mod/github.com/danieljustus/symaira-corekit@v0.17.0/fsutil/safewrite_windows.go',
    '/home/agent/go/pkg/mod/github.com/danieljustus/symaira-corekit@v0.17.0/sqlitekit/sqlitekit.go',
]
for name in sdk_extra:
    refs[name] = sha(Path(name).read_bytes())
for name, expected in refs.items():
    assert sha(Path(name).read_bytes()) == expected, name
prior_path = 'migration/evidence/brain-config13/independent-826/symaira-brain765-corrections-independent-provenance.json.gz'
prior = json.loads(gzip.decompress(blob(prior_path)))
frozen = Path('/workspace/oracles/daemon772-go-source')
for name, expected in prior['frozen_source'].items():
    assert sha((frozen / name).read_bytes()) == expected, name
checkpoint = load('migration/evidence/brain-config13/corrections-source-only/checkpoint.json')
for name, expected in checkpoint['candidate_source_sha256'].items():
    if name in verification['explicit_source_updates']:
        update = verification['explicit_source_updates'][name]
        assert update['original_sha256'] == expected, name
        expected = update['current_sha256']
    assert sha(blob(name)) == expected, name
archives = []
for original, record in prior['archives'].items():
    archive = Path(original)
    if not archive.exists():
        archive = root / ('migration/' + original.split('/migration/', 1)[1])
    data = archive.read_bytes()
    assert sha(data) == record['archive_sha256'], str(archive)
    raw = gzip.decompress(data)
    assert sha(raw) == record['sha256'] and len(raw) == record['bytes']
    archives.append(dict(original=original, actual=str(archive), **record))
new_retention = []
baseline = load('migration/evidence/brain-config13/startup-go-go-baseline/retention.json')
for record in [*prep['retention'], *baseline['files']]:
    data = blob(record['gzip'])
    assert sha(data) == record['gzip_sha256']
    raw = gzip.decompress(data)
    assert sha(raw) == record['sha256'] and len(raw) == record['bytes']
    new_retention.append(record)
changed = git('diff', '--name-only', parent, head).decode().splitlines()
frozen_changed = {}
python = []
for name in changed:
    data = blob(name)
    frozen_changed[name] = sha(data)
    dest = out / 'candidate' / name
    dest.parent.mkdir(parents=True, exist_ok=True)
    dest.write_bytes(data)
    if name.endswith('.py'):
        ast.parse(data, filename=name)
        python.append(name)
additive = git('diff', '--name-only', head, '9804c0b1b278e71ce5d533e8ee348945b68e530e').decode().splitlines()
assert additive == ['docs/adr/brain-config13-runtime-preparation-765.md', 'migration/evidence/brain-config13/startup-preparation/checkpoint.json', 'rust/symbrain-gateway/tests/startup_owner.rs']
extra = {}
for name in additive:
    data = git('show', '9804c0b1b278e71ce5d533e8ee348945b68e530e:' + name)
    dest = out / 'additive-9804' / name
    dest.parent.mkdir(parents=True, exist_ok=True)
    dest.write_bytes(data)
    extra[name] = sha(data)
assert git('status', '--porcelain') == b''
record = dict(source=head, parent=parent, observed_head=git('rev-parse','HEAD').decode().strip(),
    source_verification=dict(path=str(verification_path), sha256=sha(verification_path.read_bytes())),
    candidate_source=checked, validated_checkpoint_entries=len(checkpoint['candidate_source_sha256']),
    explicit_updates=verification['explicit_source_updates'], pinned33=verification['references'], sdk_all=refs,
    frozen_source=prior['frozen_source'], archives=archives, retained_original135_maps=prior['archive_mappings'],
    startup_originals=new_retention, original_go_go_census=baseline['census'], changed=frozen_changed,
    python_ast=python, additive9804=extra, actual_product_runs=0, sdk_runs=0, compiler_runs=0,
    target_access=False, port_access=False, git_remote_writes=False, candidate_modified=False)
(out / 'provenance.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(dict(source=head, mapped_source=len(checked),checkpoint570=record['validated_checkpoint_entries'],
    sdk=len(refs),frozen_go=len(prior['frozen_source']),old_unique_archives=len(archives),
    new_retention_maps=len(new_retention),changed=len(changed),python_AST=len(python),additive9804=len(extra),actual_product_runs=0)))
