"""Full pure immutable source/body/archive verification; no SDK/product execution."""
from pathlib import Path
import ast,gzip,hashlib,json,os,subprocess,tomllib,zipfile
R=Path('/workspace/symaira-brain765-startup-final-corrections')
OLD=Path('/workspace/symaira-brain765-startup-fixes')
O=Path(__file__).parent
PARENT='8afb9a9bf3c266478adea2f154bee9d5e0e1ebe1'
HEAD='ee4b85fbf6f53f4f2638483874cc3be7ec61c837'
sha=lambda b:hashlib.sha256(b).hexdigest()
j=lambda p:json.loads(Path(p).read_bytes())
def git(*args):return subprocess.check_output(['git',*args],cwd=R)
def bodies(commit,names):
    raw=subprocess.run(['git','cat-file','--batch'],cwd=R,input=('\n'.join(commit+':'+name for name in names)+'\n').encode(),capture_output=True,check=True).stdout
    at=0;result={}
    for name in names:
        end=raw.index(b'\n',at);head=raw[at:end].split();assert head[1]==b'blob',name
        count=int(head[2]);at=end+1;result[name]=raw[at:at+count];at+=count+1
    assert at==len(raw)
    return result
assert git('rev-parse','HEAD').decode().strip()==HEAD and not git('status','--porcelain')
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=OLD).decode().strip()==PARENT
assert not subprocess.check_output(['git','status','--porcelain'],cwd=OLD)
b=j('/workspace/review-proof/review-pr800-brain765-startup-8afb/source-bindings.json')
parent_sources=bodies(PARENT,b['all_current_source'])
metadata={}
for name,expected in b['all_current_source'].items():
    path=OLD/name;s=path.lstat();raw=path.read_bytes()
    assert raw==parent_sources[name] and sha(raw)==expected,name
    metadata[name]={key:getattr(s,key)for key in ['st_dev','st_ino','st_mode','st_uid','st_gid','st_nlink','st_size','st_atime_ns','st_mtime_ns','st_ctime_ns']}
source=j(O/'current-driver-check/source.json')['source']
current_bodies=bodies(HEAD,source)
for name,expected in source.items():assert sha((R/name).read_bytes())==expected and current_bodies[name]==(R/name).read_bytes(),name
refs={**b['references'],**b['additive14']}
reference_metadata={}
for name,expected in refs.items():
    path=Path(name);s=path.lstat();assert sha(path.read_bytes())==expected,name
    reference_metadata[name]={key:getattr(s,key)for key in ['st_dev','st_ino','st_mode','st_uid','st_gid','st_size','st_atime_ns','st_mtime_ns','st_ctime_ns']}
frozen_bodies=bodies('dcddcef0df5789123c7c9a7ebe6e01f10e941f2c',b['frozen1219'])
for name,expected in b['frozen1219'].items():
    raw=(Path('/workspace/oracles/daemon772-go-source')/name).read_bytes()
    assert sha(raw)==expected and frozen_bodies[name]==raw,name
corpus=bodies(HEAD,b['original_corpus6'])
for name,expected in b['original_corpus6'].items():assert sha(corpus[name])==expected and sha((R/name).read_bytes())==expected,name
historical={row['path']:row for row in b['historical']}
prior_blobs=bodies(HEAD,historical)
for name,row in historical.items():
    raw=prior_blobs[name];assert sha(raw)==row['compressed_sha256'],name
    decoded=gzip.decompress(raw);assert sha(decoded)==row['raw_sha256'] and len(decoded)==row['bytes'],name
for row in b['roundtrips']:
    raw=Path(row['path']).read_bytes();assert sha(raw)==row['compressed_sha256']
    decoded=gzip.decompress(raw);assert sha(decoded)==row['raw_sha256'] and len(decoded)==row['bytes']
for row in b['retained_go_binaries']:
    raw=Path(row['gzip']).read_bytes();assert sha(raw)==row['gzip_sha256']
    decoded=gzip.decompress(raw);assert sha(decoded)==row['sha256'] and len(decoded)==row['bytes']
ret=j(O/'before-preservation.json');tracking=[]
for row in ret['files']:
    path=R/'migration/evidence/brain-config13/startup-four-final-corrections/original-review'/(row['sha256']+'.gz')
    compressed=path.read_bytes();assert sha(compressed)==row['gzip_sha256']
    decoded=gzip.decompress(compressed);assert sha(decoded)==row['sha256'] and len(decoded)==row['bytes']
    assert sha(Path(row['path']).read_bytes())==row['sha256'],row['path']
    tracking.append(dict(original=row['path'],archive=str(path.relative_to(R)),sha256=row['sha256'],gzip_sha256=row['gzip_sha256'],bytes=row['bytes'],metadata=row['metadata']))
mac=b['mac_source_context'];z=Path(mac['zip']);assert sha(z.read_bytes())==mac['zip_sha256']
with zipfile.ZipFile(z) as archive:
    assert set(archive.namelist())=={row['name']for row in mac['members']}
    for row in mac['members']:
        raw=archive.read(row['name']);assert sha(raw)==row['sha256'] and len(raw)==row['bytes']
maclog=Path('/workspace/review-proof/root-discovery801-8e-macARM/job-111412706458.logs.decoded')
assert sha(maclog.read_bytes())==mac['full_log_sha256'] and maclog.stat().st_size==mac['full_log_bytes']
assert (R/'Cargo.toml').read_bytes()==parent_sources['Cargo.toml']
assert (R/'Cargo.lock').read_bytes()==parent_sources['Cargo.lock']
packages=tomllib.loads((R/'Cargo.lock').read_text())['package']
python=list((R/'scripts/brain-config13').glob('*.py'))
for path in python:ast.parse(path.read_bytes(),filename=str(path))
changed=git('diff','--name-only',PARENT,HEAD).decode().splitlines()
assert not any(name.endswith(('.go','.go.txt'))or name in ['go.mod','go.sum']for name in changed)
assert all(len((R/name).read_text().splitlines())<400 for name in changed if name.startswith('rust/') and name.endswith('.rs'))
checks={}
commands=[['bash','-n','scripts/brain-config13/runtime.sh'],['git','diff','--check',PARENT,HEAD],['/workspace/toolchains/bin/actionlint'],['rustfmt','--edition','2024','--check','--config','skip_children=true',*['rust/symbrain-core/src/config/resolved/mod.rs','rust/symbrain-cli/src/memory_cli/config.rs','rust/symbrain-cli/src/memory_cli/config_document_tests.rs','rust/symbrain-memory/src/startup_time.rs','rust/symbrain-memory/src/startup_rotation_json.rs','rust/symbrain-memory/src/startup_review_tests.rs']]]]
for index,command in enumerate(commands):
    result=subprocess.run(command,cwd=R,capture_output=True)
    (O/f'check-{index}.stdout').write_bytes(result.stdout);(O/f'check-{index}.stderr').write_bytes(result.stderr)
    checks[str(index)]=dict(command=command,exit=result.returncode,stdout_sha256=sha(result.stdout),stderr_sha256=sha(result.stderr))
    assert result.returncode==0,command
payload=sum(path.stat().st_size for path in R.rglob('*')if path.is_file())
assert payload<=15*1024*1024
assert os.statvfs('/workspace').f_bavail*os.statvfs('/workspace').f_frsize>=700*1024*1024
assert not git('status','--porcelain')
record=dict(source_head=HEAD,production_head='f9b79327b9ad4cc7d6178588a813f7afccf7d136',parent=PARENT,clean=True,current_source_sha256=source,parent742=b['all_current_source'],unchanged_old_source=len(set(source)&set(b['all_current_source']))-len(j(R/'migration/evidence/brain-config13/startup-four-final-corrections/source-updates.json')['changes']),original_source_observed_native_metadata=metadata,source_metadata_note='Collected from unchanged original worktree after successor source preparation; original sources were never edited. Original proof metadata was collected before successor edits.',references=refs,reference_observed_native_metadata=reference_metadata,frozen1219=b['frozen1219'],original_corpus6=b['original_corpus6'],historical_archives=len(historical),prior_original_roundtrips=len(b['roundtrips']),prior_Go_ELF_roundtrips=len(b['retained_go_binaries']),preserved_original_paths=tracking,mac_context=mac,python_ast=len(python),locked_packages=len(packages),checks=checks,payload_bytes=payload,executions=dict(compiler=0,Cargo=0,SDK=0,product=0,SQLite=0,network=0,target=0,ports=0),status='SOURCE READY; no compiled/native acceptance or self-approval')
(O/'source-verification.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({key:record[key]for key in ['source_head','current_source_sha256','historical_archives','prior_original_roundtrips','prior_Go_ELF_roundtrips','python_ast','locked_packages','payload_bytes','executions','status']}))
