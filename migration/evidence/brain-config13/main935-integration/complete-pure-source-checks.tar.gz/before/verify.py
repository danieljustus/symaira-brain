"""Full immutable source/retention binding verification; zero SDK/product/SQL."""
import ast
import gzip
import hashlib
import json
from pathlib import Path
import subprocess
import tomllib
import zipfile

ROOT = Path('/workspace/symaira-brain765-startup-final-corrections')
OUT = Path(__file__).parent
AUTHOR = Path('/workspace/review-artifacts/brain765-8afb-four-fixes')
HEAD = 'e30676fdaced483a3cd1588a78253a3f15096d04'
SOURCE = 'f9b79327b9ad4cc7d6178588a813f7afccf7d136'
PARENT = '8afb9a9bf3c266478adea2f154bee9d5e0e1ebe1'
BASE = '43f7d6e85b1889bbd1e9b46b2561b7a66515ef1a'
sha = lambda data: hashlib.sha256(data).hexdigest()
git = lambda *args: subprocess.check_output(['git', *args], cwd=ROOT)
readj = lambda path: json.loads(path.read_bytes())
save = lambda name, value: (OUT / name).write_text(json.dumps(value, indent=2) + '\n')
assert git('rev-parse', 'HEAD').decode().strip() == HEAD
assert not git('status', '--porcelain')
assert sha((AUTHOR / 'handoff.md').read_bytes()) == '41edf5f8bf20d515334800220a40134a943056742ff61d252396d6552bacfcb9'
assert sha((AUTHOR / 'final-source-ready-receipt.json').read_bytes()) == '889dd3797d571e7dc5af3c5ec82ddf4faac47f9709cb079b2ca092d40478b8a9'
proof = readj(AUTHOR / 'final-source-ready-receipt.json')
for key in ('proof_source_verification', 'final_driver_source', 'old_original_preservation',
            'proof_manifest', 'historical_all_roles_coverage'):
    row = proof[key]
    assert sha(Path(row['path']).read_bytes()) == row['sha256']
value = readj(AUTHOR / 'source-verification.json')
current = value['current_source_sha256']
assert len(current) == 746 and len(value['parent742']) == 742
for path, expected in current.items():
    data = (ROOT / path).read_bytes()
    assert sha(data) == expected and data == git('show', HEAD + ':' + path)
    assert sha(git('show', SOURCE + ':' + path)) == expected
for path, expected in value['parent742'].items():
    assert sha(git('show', PARENT + ':' + path)) == expected
assert sum(current.get(path) == expected for path, expected in value['parent742'].items()) == 731
for path, expected in value['references'].items():
    assert sha(Path(path).read_bytes()) == expected
frozen = Path('/workspace/oracles/daemon772-go-source')
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=frozen).decode().strip() == 'dcddcef0df5789123c7c9a7ebe6e01f10e941f2c'
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=frozen)
for path, expected in value['frozen1219'].items():
    assert sha((frozen / path).read_bytes()) == expected
    assert sha(git('show', 'dcddcef0df5789123c7c9a7ebe6e01f10e941f2c:' + path)) == expected
for path, expected in value['original_corpus6'].items():
    assert sha((ROOT / path).read_bytes()) == expected

updated = readj(ROOT / 'migration/evidence/brain-config13/startup-four-final-corrections/source-updates.json')
old = readj(ROOT / 'migration/evidence/brain-config13/corrections-source-only/checkpoint.json')
intermediate = readj(ROOT / 'migration/evidence/brain-config13/runtime-source-updates.json')['changes']
for path, expected in old['candidate_source_sha256'].items():
    if path in intermediate:
        assert intermediate[path]['original_sha256'] == expected
        expected = intermediate[path]['current_sha256']
    if path in updated['changes']:
        assert updated['changes'][path]['parent_sha256'] == expected
        expected = updated['changes'][path]['current_sha256']
    assert sha((ROOT / path).read_bytes()) == expected
for path, row in updated['changes'].items():
    assert sha(git('show', PARENT + ':' + path)) == row['parent_sha256']
    assert sha((ROOT / path).read_bytes()) == row['current_sha256']
for path, expected in updated['added_source_sha256'].items():
    assert sha((ROOT / path).read_bytes()) == expected

def retained_blob(path):
    # Sparse worktree exclusions remain available in immutable Git objects.
    file = ROOT / path
    return file.read_bytes() if file.is_file() else git('show', HEAD + ':' + path)

preserved = []
for row in value['preserved_original_paths']:
    compressed = retained_blob(row['archive'])
    raw = gzip.decompress(compressed)
    assert sha(compressed) == row['gzip_sha256']
    assert sha(raw) == row['sha256'] and len(raw) == row['bytes']
    original = Path(row['original'])
    if original.is_file():
        assert original.read_bytes() == raw
    preserved.append(row)
coverage = readj(AUTHOR / 'historical-all-records-coverage.json')
historical = []
for row in coverage['records']:
    compressed = retained_blob(row['path']); raw = gzip.decompress(compressed)
    assert sha(compressed) == row['compressed_sha256']
    assert sha(raw) == row['raw_sha256'] and len(raw) == row['bytes']
    historical.append(row)
assert len(historical) == 131 and len({row['path'] for row in historical}) == 130

prior_review = ROOT / 'migration/evidence/brain-config13/startup-review-corrections/original-review'
tracked = readj(prior_review / 'retention.json')['records']
external = readj(Path('/workspace/oracles/symaira-brain765-9804-requestchanges6-source/receipt.json'))['records']
roundtrips = []
for label, rows in [('tracked', tracked), ('external', external)]:
    for row in rows:
        path = Path(row['archive'])
        compressed = path.read_bytes() if path.is_absolute() else retained_blob(row['archive'])
        raw = gzip.decompress(compressed)
        assert sha(compressed) == row['gzip_sha256'] and sha(raw) == row['sha256'] and len(raw) == row['bytes']
        roundtrips.append({'role': label, **row})
original = json.loads(gzip.decompress(retained_blob(str((prior_review / '053-provenance.json.gz').relative_to(ROOT)))))
for row in original['retained_go_binaries']:
    compressed = Path(row['gzip']).read_bytes(); raw = gzip.decompress(compressed)
    assert sha(compressed) == row['gzip_sha256'] and sha(raw) == row['sha256'] and len(raw) == row['bytes']
    assert raw.startswith(b'\x7fELF')
mac = Path('/workspace/review-proof/root-discovery801-8e-macARM')
mac_receipt = readj(mac / 'receipt.json')
assert sha((mac / 'job-111412706458.logs.decoded').read_bytes()) == mac_receipt['full_log_sha256']
assert sha(Path(mac_receipt['zip']).read_bytes()) == mac_receipt['zip_sha256']
with zipfile.ZipFile(mac_receipt['zip']) as archive:
    assert sorted(archive.namelist()) == sorted(row['name'] for row in mac_receipt['members'])
    for row in mac_receipt['members']:
        raw = archive.read(row['name'])
        assert sha(raw) == row['sha256'] and len(raw) == row['bytes']
        assert raw == (mac / row['name']).read_bytes()
identity = lambda package: (package['name'], package['version'], package.get('source'), package.get('checksum'))
packages = tomllib.loads((ROOT / 'Cargo.lock').read_text())['package']
original_packages = tomllib.loads(git('show', BASE + ':Cargo.lock').decode())['package']
assert sorted(map(identity, packages), key=str) == sorted(map(identity, original_packages), key=str)
assert (ROOT / 'Cargo.lock').read_bytes() == git('show', PARENT + ':Cargo.lock')
assert (ROOT / 'Cargo.toml').read_bytes() == git('show', PARENT + ':Cargo.toml')
python = list((ROOT / 'scripts/brain-config13').glob('*.py'))
for path in python:
    ast.parse(path.read_bytes(), filename=str(path))
checks = {}
for label, argv in [('bash', ['bash', '-n', 'scripts/brain-config13/runtime.sh']),
                    ('diff', ['git', 'diff', '--check', BASE, HEAD]),
                    ('actionlint', ['/workspace/toolchains/bin/actionlint'])]:
    result = subprocess.run(argv, cwd=ROOT, stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=30)
    (OUT / (label + '.stdout')).write_bytes(result.stdout)
    (OUT / (label + '.stderr')).write_bytes(result.stderr)
    checks[label] = {'argv': argv, 'exit': result.returncode, 'stdout_sha256': sha(result.stdout), 'stderr_sha256': sha(result.stderr)}
    assert result.returncode == 0
assert not git('status', '--porcelain')
save('bindings.json', {'head': HEAD, 'source': SOURCE, 'parent': PARENT, 'full_base': BASE,
                      'current_source746': current, 'parent742': value['parent742'],
                      'old570': old['candidate_source_sha256'], 'references47': value['references'],
                      'frozen1219': value['frozen1219'], 'original_corpus6': value['original_corpus6'],
                      'new_preserved102': preserved, 'historical131roles130unique': historical,
                      'prior_review_roundtrips120': roundtrips, 'retained_Go_binaries': original['retained_go_binaries'],
                      'original_mac_context': mac_receipt})
result = {'head': HEAD, 'source': SOURCE, 'clean_before_after': True, 'current_source': len(current),
          'parent_source': len(value['parent742']), 'unchanged_parent_source': 731,
          'old_checkpoint': len(old['candidate_source_sha256']), 'pinned_refs': len(value['references']),
          'frozen': len(value['frozen1219']), 'new_original_roundtrips': len(preserved),
          'historical_roles': 131, 'historical_unique_paths': 130, 'prior_review_roundtrips': len(roundtrips),
          'prior_Go_ELF_roundtrips': len(original['retained_go_binaries']), 'mac_ZIP_members': len(mac_receipt['members']),
          'locked_package_identities': len(packages), 'python_AST': len(python), 'checks': checks,
          'SDK': 0, 'Cargo': 0, 'compiler': 0, 'SQLite': 0, 'product': 0, 'target': 0, 'ports': 0}
save('verification.json', result)
print(json.dumps(result, indent=2))
