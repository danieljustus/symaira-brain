from pathlib import Path
import subprocess,hashlib,json
root=Path('/workspace/symaira-brain765-main-integration');sha=lambda b:hashlib.sha256(b).hexdigest()
def git(*args):return subprocess.check_output(['git',*args],cwd=root)
def tree(rev):
 d={}
 for line in git('ls-tree','-rz',rev).split(b'\0'):
  if not line:continue
  meta,path=line.split(b'\t');mode,kind,oid=meta.decode().split()
  if kind=='blob':d[path.decode()]={'mode':mode,'sha256':sha(git('cat-file','blob',oid)),'git_blob':oid}
 return d
brain='e30676fdaced483a3cd1588a78253a3f15096d04';main='9353520a34c5819c7d0a6cd58d3bfaa2b22b045b'
previous=tree(brain);intended=tree(main);composed=tree('e4b5fe69')
source={p:{k:v for k,v in r.items() if k!='git_blob'} for p,r in composed.items() if p.startswith(('rust/','scripts/')) or p in ['Cargo.toml','Cargo.lock']}
changes={}
for p in git('diff','--name-only','5e232700',main).decode().splitlines():
 if p.startswith(('rust/','scripts/')) and p!='rust/symbrain-core/src/config/mod.rs':
  assert source[p]=={k:v for k,v in intended[p].items() if k!='git_blob'}
  changes[p]={'owner':'published-main','historical':{k:v for k,v in previous[p].items() if k!='git_blob'} if p in previous else None}
for p in ['scripts/brain-config13/runtime_tools.py','scripts/brain-config13/integration_owners.py','scripts/brain-config13/integration_owners_tests.py']:
 file=root/p;source[p]={'mode':'100755' if file.stat().st_mode&0o111 else '100644','sha256':sha(file.read_bytes())}
 changes[p]={'owner':'additive-source-preflight','historical':{k:v for k,v in previous[p].items() if k!='git_blob'} if p in previous else None}
for p in json.loads((root/'migration/evidence/brain-config13/main935-integration/original-inherited-format-bindings.json').read_text()):
 name=p['path'];source[name]={'mode':'100644','sha256':sha((root/name).read_bytes())};changes[name]={'owner':'formatting-only-reviewed-Brain','historical':{k:v for k,v in previous[name].items() if k!='git_blob'}}
result={'brain_parent':brain,'main_parent':main,'normal_merge':'7185ac7b902fe593cd538a2ae4bfdab6524c4f6b','effective_source':source,'changed_owners':changes,'Core_mod_union':{'source':brain,'mode':previous['rust/symbrain-core/src/config/mod.rs']['mode'],'sha256':previous['rust/symbrain-core/src/config/mod.rs']['sha256'],'reason':'exact e306 additive resolved/os_bytes exports include exact published main byte-quoter export'},'original_assertions_retained':True,'runtime':0}
(root/'migration/evidence/brain-config13/main935-integration/effective-owners.json').write_text(json.dumps(result,indent=2)+'\n')
print('effective',len(source),'changed',len(changes))
