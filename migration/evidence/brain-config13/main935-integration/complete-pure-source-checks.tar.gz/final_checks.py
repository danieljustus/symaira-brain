from pathlib import Path
import gzip,hashlib,json,subprocess
root=Path('/workspace/symaira-brain765-main-integration');out=Path('/workspace/review-proof/brain765-main-integration');sha=lambda b:hashlib.sha256(b).hexdigest()
def git(*args):return subprocess.check_output(['git',*args],cwd=root)
def modes(rev):
 result={}
 for line in git('ls-tree','-rz',rev).split(b'\0'):
  if not line:continue
  meta,name=line.split(b'\t');mode,kind,oid=meta.decode().split()
  if kind=='blob':result[name.decode()]={'mode':mode,'blob':oid}
 return result
brain='e30676fdaced483a3cd1588a78253a3f15096d04';main='9353520a34c5819c7d0a6cd58d3bfaa2b22b045b';current=modes('HEAD');a=modes(brain);b=modes(main)
manifest=json.loads((root/'migration/evidence/brain-config13/main935-integration/effective-owners.json').read_text());changed=set(manifest['changed_owners']);counts={}
for name in manifest['effective_source']:
 if name in a and name not in changed:assert current[name]==a[name],name
for name,row in manifest['changed_owners'].items():
 if row['owner']=='published-main':assert current[name]==b[name],name
# Preserve full workflow structure aside from the exact reviewed four-line leaf.
leaf='      - name: Fetch the immutable native Skills comparison parent\n        shell: bash\n        run: git fetch --no-tags origin 01f41906e2e021db3c693ec97617bb701e4dad8a\n\n'
merged=git('show','7185ac7b:.github/workflows/ci.yml');present=(root/'.github/workflows/ci.yml').read_bytes();assert present.count(leaf.encode())==1 and present.replace(leaf.encode(),b'')==merged
paths=['docs/adr/skills-ci-immutable-parent-acquisition.md','migration/evidence/skills-render-drift-621/ci-parent-object-e605/full-original-failure.tar.gz','migration/evidence/skills-render-drift-621/ci-parent-object-e605/retention.json','migration/evidence/skills-render-drift-621/ci-parent-object-e605/depth-review/full-independent-depth-review.tar.gz','migration/evidence/skills-render-drift-621/ci-parent-object-e605/depth-review/retention.json']
for name in paths:assert current[name]==modes('e0036533')[name],name
for parent in [brain,main]:
 for name,row in modes(parent).items():
  if name.endswith(('.go','go.mod','go.sum')):assert current[name]==row,name
# Exact old assertions/generators and corpora were already checked; no Go SDK invocation.
result=dict(head=git('rev-parse','HEAD').decode().strip(),complete_mode_blob_owner_checks=True,CI_exact_merged_body_plus_reviewed_leaf=True,exact_e003_ADR_and_four_artifact_bodies=paths,all_parent_Go_modes_blobs_exact=True,effective_source_count=len(manifest['effective_source']),changed_owner_count=len(changed),runtime=0)
(out/'final-owner-checks.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
