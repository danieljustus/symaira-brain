from pathlib import Path
import hashlib,json,re,subprocess,tarfile
root=Path('/workspace/symaira-brain765-main-integration');out=root/'migration/evidence/brain-config13/main935-integration';tool=Path('/home/agent/.rustup/toolchains/1.98.0-x86_64-unknown-linux-gnu/bin/rustfmt');sha=lambda b:hashlib.sha256(b).hexdigest();rows=[]
# Compare literal token interiors exactly; no repaired/sorted JSON/content.
literal=re.compile(r'(?:br|r)(?P<hashes>\#*)".*?"(?P=hashes)|(?:b|c)?"(?:\\.|[^"\\])*"|(?:b)?\'(?:\\(?:u\{[0-9a-fA-F]+\}|x[0-9a-fA-F]{2}|.)|[^\'\\])\'',re.S)
with tarfile.open(out/'original-inherited-format-failure.tar.gz') as tar:
 for old in json.loads((out/'original-inherited-format-bindings.json').read_text()):
  path=old['path'];before=tar.extractfile(path).read();after=(root/path).read_bytes()
  p=subprocess.run([str(tool),'--edition','2024','--emit','stdout','--config','skip_children=true'],input=before,stdout=subprocess.PIPE,stderr=subprocess.PIPE);assert p.returncode==0 and p.stdout==after,(path,p.stderr)
  before_literals=[m.group(0) for m in literal.finditer(before.decode())];after_literals=[m.group(0) for m in literal.finditer(after.decode())];assert before_literals==after_literals,path
  rows.append(dict(path=path,parent_sha256=sha(before),current_sha256=sha(after),mode='100644',deterministic_formatter_output_exact=True,literal_token_sequence_exact=True,literal_tokens=len(before_literals),original_Git_body_exact=True))
(out/'formatting-source-projections.json').write_text(json.dumps(dict(tool=str(tool),tool_sha256=sha(tool.read_bytes()),compiler=False,rows=rows,module_import_reordering='Rustfmt module/import declarations retain attached cfg; no macro_use attributes in changed lib',logic_assertion_corpus_timeout_edits=False),indent=2)+'\n')
print('complete deterministic formatter +literal projections',len(rows))
