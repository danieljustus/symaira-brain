from pathlib import Path
import hashlib,io,json,tarfile
root=Path('/workspace/symaira-brain765-main-integration');proof=Path('/workspace/review-proof/brain765-main-integration');out=root/'migration/evidence/brain-config13/main935-integration';sha=lambda b:hashlib.sha256(b).hexdigest();rows=[]
with tarfile.open(out/'complete-pure-source-checks.tar.gz','w:gz',compresslevel=9) as tar:
 for p in sorted(proof.rglob('*')):
  if not p.is_file():continue
  raw=p.read_bytes();st=p.stat();name=str(p.relative_to(proof));info=tarfile.TarInfo(name);info.size=len(raw);info.mode=st.st_mode&0o777;info.mtime=st.st_mtime;tar.addfile(info,io.BytesIO(raw));rows.append(dict(path=str(p),member=name,bytes=len(raw),sha256=sha(raw),native_mode=st.st_mode,mtime_ns=st.st_mtime_ns))
with tarfile.open(out/'complete-pure-source-checks.tar.gz') as tar:
 for row in rows:assert sha(tar.extractfile(row['member']).read())==row['sha256']
(out/'complete-pure-source-checks-retention.json').write_text(json.dumps(dict(validated_source='e40cc6512275a53089151641240db17c6c21d63c',records=rows,archive_sha256=sha((out/'complete-pure-source-checks.tar.gz').read_bytes()),all_roundtrips=True,compiler_Cargo_SDK_product_SQLite_target_port_GitHub=0),indent=2)+'\n')
print('retained pure output/source/proof files',len(rows))
