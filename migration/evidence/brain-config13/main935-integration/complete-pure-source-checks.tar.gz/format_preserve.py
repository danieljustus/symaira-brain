from pathlib import Path
import gzip,hashlib,io,json,re,subprocess,tarfile
root=Path('/workspace/symaira-brain765-main-integration');out=root/'migration/evidence/brain-config13/main935-integration';raw=Path('/workspace/review-proof/brain765-main-integration/checks/rustfmt.stdout').read_bytes()
files=sorted(set(re.findall(rb'^Diff in (.*?):\d+:',raw,re.M)));records=[]
with tarfile.open(out/'original-inherited-format-failure.tar.gz','w:gz') as tar:
 for path in files:
  p=Path(path.decode());body=p.read_bytes();relative=str(p.relative_to(root));st=p.stat();old=subprocess.check_output(['git','show','e30676fd:'+relative],cwd=root);assert old==body
  info=tarfile.TarInfo(relative);info.size=len(body);info.mode=st.st_mode&0o777;tar.addfile(info,io.BytesIO(body));records.append(dict(path=relative,sha256=hashlib.sha256(body).hexdigest(),bytes=len(body),mode=oct(st.st_mode&0o777),mtime_ns=st.st_mtime_ns,git_blob=subprocess.check_output(['git','rev-parse','HEAD:'+relative],cwd=root).decode().strip()))
 info=tarfile.TarInfo('full-rustfmt.stdout');info.size=len(raw);tar.addfile(info,io.BytesIO(raw))
(out/'original-inherited-format-bindings.json').write_text(json.dumps(records,indent=2)+'\n')
with tarfile.open(out/'original-inherited-format-failure.tar.gz','r:gz') as tar:
 for row in records:assert hashlib.sha256(tar.extractfile(row['path']).read()).hexdigest()==row['sha256']
 assert tar.extractfile('full-rustfmt.stdout').read()==raw
print('preserved',len(records))
