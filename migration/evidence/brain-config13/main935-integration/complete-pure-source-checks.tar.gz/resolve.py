from pathlib import Path
import subprocess,json,base64,gzip
root=Path('/workspace/symaira-brain765-main-integration')
out=root/'migration/evidence/brain-config13/main935-integration'
rows=[]
for line in subprocess.check_output(['git','ls-files','-u'],cwd=root).decode().splitlines():
 meta,path=line.split('\t');mode,oid,stage=meta.split();data=subprocess.check_output(['git','cat-file','blob',oid],cwd=root);rows.append({'path':path,'mode':mode,'stage':stage,'git_blob':oid,'bytes_base64':base64.b64encode(data).decode()})
for name in ['.github/workflows/ci.yml','MIGRATION-RUST.md','migration/contract-matrix.csv','rust/symbrain-core/src/config/format.rs']:
 p=root/name;rows.append({'path':name,'working_conflict_bytes_base64':base64.b64encode(p.read_bytes()).decode()})
(out/'all-original-conflicts.json.gz').write_bytes(gzip.compress(json.dumps(rows).encode(),mtime=0))
for name in ['MIGRATION-RUST.md','migration/contract-matrix.csv','.github/workflows/ci.yml']:
 p=root/name;s=p.read_text();before,rest=s.split('<<<<<<< HEAD\n',1);ours,rest=rest.split('=======\n',1);theirs,after=rest.split('>>>>>>> 9353520a34c5819c7d0a6cd58d3bfaa2b22b045b\n',1)
 if name.startswith('.github'):
  ours+='          if-no-files-found: error\n          retention-days: 14\n\n'
 p.write_text(before+ours+theirs+after)
(root/'rust/symbrain-core/src/config/format.rs').write_bytes(subprocess.check_output(['git','show','9353520a:rust/symbrain-core/src/config/format.rs'],cwd=root))
