from pathlib import Path
import glob,json,subprocess,tomllib
root=Path('/workspace/symaira-brain765-main-integration');out=Path('/workspace/review-proof/brain765-main-integration');workspace=tomllib.loads((root/'Cargo.toml').read_text());entries=set();packages=[]
for pattern in workspace['workspace']['members']:
 for path in glob.glob(str(root/pattern)):
  package=Path(path);data=tomllib.loads((package/'Cargo.toml').read_text());packages.append(str(package.relative_to(root)))
  candidates=[]
  if data.get('lib',{}).get('path'):candidates.append(package/data['lib']['path'])
  elif (package/'src/lib.rs').exists():candidates.append(package/'src/lib.rs')
  explicit={'bin':'src/bin','example':'examples','test':'tests','bench':'benches'}
  for kind,folder in explicit.items():
   for target in data.get(kind,[]):
    if target.get('path'):candidates.append(package/target['path'])
    else:candidates.append(package/folder/(target['name']+'.rs'))
   if data.get('package',{}).get('auto'+{'bin':'bins','example':'examples','test':'tests','bench':'benches'}[kind],True):
    candidates.extend((package/folder).glob('*.rs'));candidates.extend((package/folder).glob('*/main.rs'))
  if data.get('package',{}).get('autobins',True) and (package/'src/main.rs').exists():candidates.append(package/'src/main.rs')
  build=data.get('package',{}).get('build','build.rs')
  if build and (package/build).exists():candidates.append(package/build)
  for p in candidates:
   if p.is_file():entries.add(str(p.relative_to(root)))
argv=['/home/agent/.rustup/toolchains/1.98.0-x86_64-unknown-linux-gnu/bin/rustfmt','--edition','2024','--check',*sorted(entries)]
p=subprocess.run(argv,cwd=root,stdout=subprocess.PIPE,stderr=subprocess.PIPE);(out/'module-root-rustfmt.stdout').write_bytes(p.stdout);(out/'module-root-rustfmt.stderr').write_bytes(p.stderr)
(out/'module-root-rustfmt.json').write_text(json.dumps(dict(packages=packages,source_projected_Cargo_module_entrypoints=sorted(entries),entrypoints=len(entries),exit=p.returncode,actual_Cargo_invocations=0,standalone_formatter=True,Cargo_fmt_still_required=True),indent=2)+'\n')
print('package manifests',len(packages),'module entrypoints',len(entries),'exit',p.returncode)
assert p.returncode==0
