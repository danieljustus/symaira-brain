import ast,collections,csv,gzip,hashlib,json,pathlib,subprocess,tomllib
root=pathlib.Path('/workspace/symaira-brain765-main-integration');out=pathlib.Path('/workspace/review-proof/brain765-main-integration/checks-composed-final-1');out.mkdir(exist_ok=True)
sha=lambda b:hashlib.sha256(b).hexdigest()
def git(*args):return subprocess.check_output(['git',*args],cwd=root)
brain='e30676fdaced483a3cd1588a78253a3f15096d04';main='9353520a34c5819c7d0a6cd58d3bfaa2b22b045b';head=git('rev-parse','HEAD').decode().strip()
paths=lambda rev:[p for p in git('ls-tree','-rz','--name-only',rev).decode().split('\0') if p]
mainchanged=git('diff','--name-only','5e232700',main).decode().splitlines()
mainowners=[p for p in mainchanged if p.startswith(('rust/','scripts/')) and p!='rust/symbrain-core/src/config/mod.rs']
for p in mainowners: assert git('show',head+':'+p)==git('show',main+':'+p),p
brainpaths=[p for p in paths(brain) if p.startswith(('rust/','scripts/brain-config13/','migration/fixtures/brain-config13/'))]
formatted={r['path'] for r in json.loads((root/'migration/evidence/brain-config13/main935-integration/original-inherited-format-bindings.json').read_text())}
exception={'rust/symbrain-core/src/config/format.rs','scripts/brain-config13/runtime_tools.py'}|set(mainowners)|formatted
brainmatched=[]
for p in brainpaths:
 if p in exception:continue
 assert git('show',head+':'+p)==git('show',brain+':'+p),p
 brainmatched.append(p)
old_tree=ast.parse(git('show',brain+':scripts/brain-config13/runtime_tools.py'));new_tree=ast.parse((root/'scripts/brain-config13/runtime_tools.py').read_bytes())
old_fns={n.name:ast.dump(n,include_attributes=False) for n in old_tree.body if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef)) and n.name!='source'}
new_fns={n.name:ast.dump(n,include_attributes=False) for n in new_tree.body if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef)) and n.name!='source'}
assert old_fns==new_fns
for p in ['Cargo.toml','Cargo.lock']:
 assert git('show',head+':'+p)==git('show',brain+':'+p)
module=(root/'rust/symbrain-core/src/config/mod.rs').read_text()
assert 'pub mod resolved;' in module and 'format_go_quoted_bytes' in module and 'os_bytes' in module
rows=list(csv.reader((root/'migration/contract-matrix.csv').open()));byid={r[0]:r for r in rows};assert len(rows)==len(byid)
for rev in [brain,main]:
 for row in csv.reader(git('show',rev+':migration/contract-matrix.csv').decode().splitlines()):
  if (rev==brain and row[0]=='SKL-006') or (rev==main and row[0]=='SET-002'):assert byid[row[0]][:-1]==row[:-1]
  else:assert byid[row[0]]==row,(rev,row[0])
for p in sorted((root/'scripts').rglob('*.py')):ast.parse(p.read_bytes(),filename=str(p))
# Match complete step dictionaries from both published parents, not step names.
import yaml
workflow=yaml.safe_load((root/'.github/workflows/ci.yml').read_text())
for rev in [brain,main]:
 parent=yaml.safe_load(git('show',rev+':.github/workflows/ci.yml'))
 for job,value in parent['jobs'].items():
  assert job in workflow['jobs']
  original=value.get('steps',[]);current=workflow['jobs'][job].get('steps',[])
  for step in original:assert step in current,(rev,job,step.get('name'))
# No executable/provider invocation in plan generation or comparator projections.
commands=[('plans',['python3','scripts/brain-config13/startup_final_preparation.py','--out',str(out/'prepared.json')]),('bash',['bash','-n','scripts/brain-config13/runtime.sh']),('actionlint',['/workspace/toolchains/bin/actionlint'])]
results={}
for label,argv in commands:
 p=subprocess.run(argv,cwd=root,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
 (out/(label+'.stdout')).write_bytes(p.stdout);(out/(label+'.stderr')).write_bytes(p.stderr);results[label]=p.returncode;assert p.returncode==0,(label,p.stderr)
changed=set()
for rev in [brain,main,'5e232700']:
 changed.update(git('diff','--name-only',rev,head,'--','rust').decode().splitlines())
files=sorted(p for p in changed if p.endswith('.rs') and (root/p).is_file())
argv=['/home/agent/.rustup/toolchains/1.98.0-x86_64-unknown-linux-gnu/bin/rustfmt','--edition','2024','--check',*files]
p=subprocess.run(argv,cwd=root,stdout=subprocess.PIPE,stderr=subprocess.PIPE);(out/'rustfmt.stdout').write_bytes(p.stdout);(out/'rustfmt.stderr').write_bytes(p.stderr);results['whole_inherited_rustfmt']=p.returncode;assert p.returncode==0,'whole inherited module formatter differs'
integration_files=sorted(p for p in git('diff','--name-only',brain,head,'--','rust').decode().splitlines() if p.endswith('.rs'))
p=subprocess.run(['/home/agent/.rustup/toolchains/1.98.0-x86_64-unknown-linux-gnu/bin/rustfmt','--edition','2024','--config','skip_children=true','--check',*integration_files],cwd=root,stdout=subprocess.PIPE,stderr=subprocess.PIPE);(out/'integration-rustfmt.stdout').write_bytes(p.stdout);(out/'integration-rustfmt.stderr').write_bytes(p.stderr);results['integration_rustfmt']=p.returncode;assert p.returncode==0,'integration Rust formatting differs'
# Scope source whitespace separately from unchanged historical raw evidence.
p=subprocess.run(['git','diff','--check',brain,head,'--','rust','scripts','.github','Cargo.toml','Cargo.lock','MIGRATION-RUST.md','migration/contract-matrix.csv'],cwd=root,stdout=subprocess.PIPE,stderr=subprocess.PIPE);(out/'source-diff.stdout').write_bytes(p.stdout);(out/'source-diff.stderr').write_bytes(p.stderr);assert p.returncode==0
maps=[]
for line in git('ls-tree','-rz',head).split(b'\0'):
 if not line:continue
 meta,name=line.split(b'\t');mode,kind,oid=meta.decode().split();p=name.decode()
 if kind=='blob' and (p.startswith(('rust/','scripts/','.github/','migration/fixtures/brain-config13/')) or p in ['Cargo.toml','Cargo.lock','MIGRATION-RUST.md','migration/contract-matrix.csv']):maps.append({'path':p,'git_mode':mode,'git_blob':oid,'sha256':sha(git('cat-file','blob',oid))})
result=dict(head=head,brain_parent=brain,main_parent=main,exact_main_changed_owners=mainowners,exact_Brain_owner_count=len(brainmatched),matrix_rows=len(rows),all_parent_rows_exact_except_explicit_SKL006_SET002_status_owners=True,all_parent_CI_steps_exact=True,exact_reviewed_Brain_Cargo_graph=True,prepared_plans={'Unix':94,'Windows':82},runtime_executions=0,source_checks=results,whole_inherited_rustfmt_files=len(files),integration_rustfmt_files=len(integration_files),full_current_source_map=maps)
(out/'result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k not in ['full_current_source_map','exact_main_changed_owners']},indent=2))
