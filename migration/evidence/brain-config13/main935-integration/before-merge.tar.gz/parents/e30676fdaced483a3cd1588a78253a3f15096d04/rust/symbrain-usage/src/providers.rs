use crate::parser::parse_snapshot;
use crate::transport::{Cancellation, Request, Transport};
use crate::{AuthStatus, UsageSnapshot};
use chrono::Utc;
use serde_json::Value;
use std::sync::Arc;

#[path = "provider_errors.rs"]
mod provider_errors;
pub use provider_errors::UsageError;
use provider_errors::status_error;
#[path = "provider_requests.rs"]
mod provider_requests;
pub(crate) use provider_requests::trusted_https_url;
use provider_requests::{command_output_with_cancel, request_for};
#[path = "provider_antigravity.rs"]
mod provider_antigravity;
#[path = "provider_fetch.rs"]
mod provider_fetch;
#[path = "provider_identity.rs"]
mod provider_identity;
use provider_antigravity::fetch_antigravity_from_observations;
#[cfg(test)]
use provider_antigravity::{
    AntigravityCandidate, parse_antigravity_candidates, parse_antigravity_ports,
};
#[path = "provider_opencode.rs"]
mod provider_opencode;
#[cfg(test)]
#[path = "usage_fetch_oracle_tests.rs"]
mod usage_fetch_oracle_tests;
use provider_fetch::fetch_one;

#[path = "provider_config.rs"]
mod provider_config;
pub use provider_config::{
    all_providers, is_secret_reference, is_vault_uri, needs_go_fallback, resolve_reference,
    resolve_reference_bytes, resolve_reference_or_env, secretref_timeout, set_secretref_timeout,
};
#[cfg(test)]
pub(crate) use provider_config::{
    claude_from_resolved, codex_from_resolved, copilot_from_resolved, cursor_from_resolved,
    kimi_from_resolved, moonshot_from_resolved, nous_from_resolved, opencode_from_resolved,
    openrouter_from_resolved, parse_claude_keychain_blob,
};

const MAX_CREDENTIAL_FILE_BYTES: u64 = 64 * 1024;

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct ProviderSpec {
    pub id: String,
    pub display_name: String,
    pub credential_sources: Vec<&'static str>,
}

#[derive(Debug, Clone)]
pub struct Provider {
    pub spec: ProviderSpec,
    pub id: String,
    pub display_name: String,
    pub configured: bool,
    pub auth_status: AuthStatus,
    credential: Option<String>,
    credentials: Vec<(String, String)>,
    base_url: Option<String>,
    region: String,
    fixture: bool,
    /// Device id the Kimi Code CLI persisted; sent as identity metadata on the
    /// CLI strategy's requests.
    device_id: Option<String>,
    enterprise_host: Option<String>,
}

impl Provider {
    fn new(
        id: &str,
        display_name: &str,
        sources: Vec<&'static str>,
        credentials: Vec<(String, String)>,
        status: AuthStatus,
    ) -> Self {
        let credential = credentials.first().map(|(_, v)| v.clone());
        Self {
            spec: ProviderSpec {
                id: id.into(),
                display_name: display_name.into(),
                credential_sources: sources,
            },
            id: id.into(),
            display_name: display_name.into(),
            configured: credential.is_some() || id == "antigravity",
            auth_status: status,
            credential,
            credentials,
            base_url: None,
            region: "ai".into(),
            fixture: false,
            device_id: None,
            enterprise_host: None,
        }
    }

    /// A configured provider that performs no process, home, keychain, or network reads.
    #[must_use]
    pub fn fixture(id: &str, display_name: &str) -> Self {
        let mut p = Self::new(
            id,
            display_name,
            Vec::new(),
            vec![("fixture".into(), "fixture".into())],
            AuthStatus {
                status: "available".into(),
                detail: "configured by fixture".into(),
                source: Some("fixture".into()),
            },
        );
        p.fixture = true;
        if id == "opencode" {
            p.credentials
                .push(("workspace".into(), "wrk_fixture".into()));
        }
        p
    }

    /// Selects the Copilot enterprise API authority for an explicitly supplied
    /// provider. Default constructors retain github.com, matching Go; they do
    /// not infer a host from credential files or an environment variable.
    /// The transport validates HTTPS and refuses private or ambiguous hosts
    /// before sending credentials. Other providers ignore this setting.
    #[must_use]
    pub fn with_copilot_enterprise_host(mut self, host: impl Into<String>) -> Self {
        self.enterprise_host = Some(host.into());
        self
    }

    pub(crate) fn fetch(
        &self,
        transport: &Arc<dyn Transport>,
        cancel: &Cancellation,
    ) -> Result<UsageSnapshot, UsageError> {
        let result = if self.fixture && self.id == "antigravity" && self.credential.is_none() {
            Err(UsageError::not_running())
        } else if self.fixture && self.id == "antigravity" {
            self.fetch_antigravity_fixture(transport, cancel)
        } else if self.fixture {
            let source = match self.id.as_str() {
                "claude" | "codex" => "oauth",
                "opencode" | "cursor" => "web",
                "antigravity" => "local",
                _ => "api",
            };
            fetch_one(
                self,
                transport,
                cancel,
                source,
                request_for(
                    self,
                    source,
                    if self.id == "opencode" {
                        ""
                    } else {
                        self.credential()
                    },
                    (self.id == "opencode").then_some("wrk_fixture"),
                ),
            )
        } else {
            match self.id.as_str() {
                "claude" => self.fetch_claude(transport, cancel),
                "codex" => self.fetch_one(
                    transport,
                    cancel,
                    "oauth",
                    request_for(self, "oauth", self.credential(), None),
                ),
                "copilot" | "moonshot" | "nous" | "openrouter" => self.fetch_one(
                    transport,
                    cancel,
                    "api",
                    request_for(self, "api", self.credential(), None),
                ),
                "cursor" => self.fetch_one(
                    transport,
                    cancel,
                    "web",
                    request_for(self, "web", self.credential(), None),
                ),
                "kimi" => self.fetch_kimi(transport, cancel),
                "opencode" => self.fetch_opencode(transport, cancel),
                "antigravity" => self.fetch_antigravity(transport, cancel),
                _ => Err(UsageError::parse(&self.id, "unknown provider")),
            }
        };
        wrap_fetch_error(&self.id, result)
    }

    fn credential(&self) -> &str {
        self.credential.as_deref().unwrap_or("")
    }
    fn fetch_one(
        &self,
        transport: &Arc<dyn Transport>,
        cancel: &Cancellation,
        source: &str,
        request: Request,
    ) -> Result<UsageSnapshot, UsageError> {
        fetch_one(self, transport, cancel, source, request)
    }
    fn fetch_claude(
        &self,
        transport: &Arc<dyn Transport>,
        cancel: &Cancellation,
    ) -> Result<UsageSnapshot, UsageError> {
        let mut errors = Vec::new();
        for (source, credential) in &self.credentials {
            let req = request_for(self, source, credential, None);
            match fetch_one(self, transport, cancel, source, req) {
                Ok(v) => return Ok(v),
                Err(e) => errors.push(e),
            }
        }
        Err(UsageError::chain(&self.id, errors))
    }
    fn fetch_kimi(
        &self,
        transport: &Arc<dyn Transport>,
        cancel: &Cancellation,
    ) -> Result<UsageSnapshot, UsageError> {
        let mut errors = Vec::new();
        for (source, credential) in &self.credentials {
            let req = request_for(self, source, credential, None);
            match fetch_one(self, transport, cancel, source, req) {
                Ok(v) => return Ok(v),
                Err(e) => errors.push(e),
            }
        }
        Err(UsageError::chain(&self.id, errors))
    }
    fn fetch_antigravity_fixture(
        &self,
        transport: &Arc<dyn Transport>,
        cancel: &Cancellation,
    ) -> Result<UsageSnapshot, UsageError> {
        let port = 43123_u16;
        let connect = request_for(
            self,
            "local",
            "",
            Some(&format!("https://127.0.0.1:{port}/GetUnleashData")),
        );
        let response = transport
            .request_with_cancel(connect, cancel)
            .map_err(|error| {
                UsageError::exact(format!(
                    "Antigravity probe failed: connect probe failed on port {port}: {error}"
                ))
            })?;
        if !(200..300).contains(&response.status) {
            return Err(UsageError::exact(format!(
                "Antigravity probe failed: connect probe failed on port {port}"
            )));
        }
        let mut last_error = UsageError::parse(&self.id, "all quota endpoints failed");
        for endpoint in [
            "RetrieveUserQuotaSummary",
            "GetUserStatus",
            "GetCommandModelConfigs",
        ] {
            let request = request_for(
                self,
                "local",
                "",
                Some(&format!("https://127.0.0.1:{port}/{endpoint}")),
            );
            match transport.request_with_cancel(request, cancel) {
                Ok(response) if (200..300).contains(&response.status) => {
                    match parse_snapshot(&self.id, "local", &response.body, Utc::now()) {
                        Ok(snapshot) => return Ok(snapshot),
                        Err(_) => {
                            last_error = UsageError::exact(format!(
                                "Antigravity returned an unreadable response: {endpoint} returned unreadable data"
                            ));
                        }
                    }
                }
                Ok(_) => {
                    last_error = UsageError::exact(format!(
                        "Antigravity probe failed: connect probe failed on port {port}"
                    ));
                }
                Err(error) => {
                    last_error = UsageError::exact(format!(
                        "Antigravity probe failed: connect probe failed on port {port}: {error}"
                    ));
                }
            }
        }
        Err(last_error)
    }

    fn fetch_antigravity(
        &self,
        transport: &Arc<dyn Transport>,
        cancel: &Cancellation,
    ) -> Result<UsageSnapshot, UsageError> {
        let process_list =
            command_output_with_cancel(cancel, "ps", &["-ax", "-o", "pid=,command="])
                .unwrap_or_default();
        fetch_antigravity_from_observations(self, transport, cancel, &process_list, |pid| {
            let pid = pid.to_string();
            command_output_with_cancel(
                cancel,
                "lsof",
                &["-nP", "-iTCP", "-sTCP:LISTEN", "-a", "-p", &pid],
            )
        })
    }
}

fn wrap_fetch_error(
    provider_id: &str,
    result: Result<UsageSnapshot, UsageError>,
) -> Result<UsageSnapshot, UsageError> {
    result.map_err(|error| match error {
        UsageError::Chain { .. } => error,
        error => UsageError::chain(provider_id, vec![error]),
    })
}

#[cfg(test)]
#[path = "opencode_discovery_tests.rs"]
mod opencode_discovery_tests;

#[cfg(test)]
#[path = "antigravity_tests.rs"]
mod antigravity_tests;
