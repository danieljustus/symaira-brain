import ast, base64, gzip, hashlib, importlib.util, json, os, pathlib, posixpath, subprocess, sys, tempfile, tomllib, types
sys.dont_write_bytecode = True
root = pathlib.Path('/workspace/symaira-brain765-resolved-config')
head = 'e63e20a6faf0f05b3d384b9d2b8e15ac0f234dae'
source = 'cf7d4b090748fd547b5eafccc5ea9f540f33d882'
base = 'fb6d68b337974b03efeb8e9bd547dfbb06bb8fae'
def digest(data): return hashlib.sha256(data).hexdigest()
def git(*args): return subprocess.check_output(['git','-C',str(root),*args])
assert git('rev-parse','HEAD').decode().strip() == head
assert not git('status','--porcelain').strip()
meta = json.loads((root/'migration/evidence/brain-config13/precompile-checkpoint.json').read_bytes())
checks = {p:digest((root/p).read_bytes()) == expected for p,expected in meta['source_sha256'].items()}
assert all(checks.values())
ret = json.loads((root/'migration/evidence/brain-config13/initial-58fe/retention.json').read_bytes())
archives = {}
for e in ret['entries']:
 p=root/'migration/evidence/brain-config13/initial-58fe'/e['archive']
 if str(p) not in archives:
  zipped=p.read_bytes(); plain=gzip.decompress(zipped)
  archives[str(p)] = dict(archive_sha256=digest(zipped),bytes=len(plain),sha256=digest(plain))
 observed=archives[str(p)]
 assert observed['archive_sha256']==e['archive_sha256'] and observed['sha256']==e['sha256'] and observed['bytes']==e['bytes']
fixture=json.loads((root/'rust/symbrain-core/tests/fixtures/brain13-types-go58.json').read_bytes())
inventory=json.loads(pathlib.Path(fixture['observation_source']).read_bytes())
# Validate against retained original bytes, not just an independently mutable /tmp file.
entry=next(e for e in ret['entries'] if e['original_path']==fixture['observation_source'])
assert digest(pathlib.Path(fixture['observation_source']).read_bytes()) == entry['sha256']
print('inventory keys:',list(inventory))
rows=inventory.get('observations',inventory.get('cases',[]))
type_checks=[]
for case in fixture['cases']:
 matches=[row for row in rows if row['id']==case['id']]
 assert len(matches)==1
 row=matches[0]
 go=row['go']; actual=base64.b64decode(go.get('stderr_b64',go.get('stderr_base64','')))
 assert actual==base64.b64decode(case['original_go_stderr_b64'])
 assert go.get('exit',go.get('exit_code')) == case['original_go_exit']==2
 assert actual.endswith(base64.b64decode(case['expected_conversion'])+b'\n')
 type_checks.append(case['id'])
sys.path.insert(0,str(root/'scripts/brain-config13'))
import process, values
cli_count=len(list(process.cases()));unix_count=len(list(values.cases()))
values.os=types.SimpleNamespace(name='nt',fsdecode=os.fsdecode)
windows_count=len(list(values.cases()))
assert (cli_count,unix_count,windows_count)==(102,152,174)
projections=[]
with tempfile.TemporaryDirectory(prefix='brain13-static-review-owned-') as tmp:
 r=pathlib.Path(tmp)
 for p in ['owner/deep','owner/project','project']:(r/p).mkdir(parents=True)
 link=r/'link';link.symlink_to(r/'owner/deep',target_is_directory=True)
 cwd=r/'owner/project';pwd=str(link)+'/../project'
 a,b=os.stat(cwd),os.stat(pwd)
 assert (a.st_dev,a.st_ino)==(b.st_dev,b.st_ino)
 go_path=pathlib.Path(posixpath.normpath(pwd+'/.symbrain.toml'))
 native_path=cwd/'.symbrain.toml'
 assert go_path!=native_path
 for name,lexical,physical in [
 ('valid-different-vault',b'servers.vault.binary_path="lexical-vault"\n',b'servers.vault.binary_path="physical-vault"\n'),
 ('lexical-error-physical-valid',b'audit.enabled="bad"\n',b'servers.vault.binary_path="physical-vault"\n'),
 ('lexical-valid-physical-error',b'servers.vault.binary_path="lexical-vault"\n',b'audit.enabled="bad"\n')]:
  go_path.write_bytes(lexical);native_path.write_bytes(physical)
  projections.append(dict(id=name,actual_same_file_PWD=True,pwd=pwd,physical_cwd=str(cwd),
   Go_Getwd_plus_lexical_Join_selected=str(go_path),OverrideSources_current_dir_selected=str(native_path),
   lexical_bytes_b64=base64.b64encode(go_path.read_bytes()).decode(),physical_bytes_b64=base64.b64encode(native_path.read_bytes()).decode(),
   lexical_python_tomllib=tomllib.loads(lexical.decode()),physical_python_tomllib=tomllib.loads(physical.decode()),
   proof_kind='owned filesystem plus source-derived owner selection; no product executable'))
# GoText one-byte repair projection of exactly the Rust loop; this is not Rust execution.
def repair(raw):
 out=''
 while raw:
  try:out+=raw.decode('utf8');break
  except UnicodeDecodeError as e:out+=raw[:e.start].decode('utf8')+'\ufffd';raw=raw[e.start+1:]
 return out.encode()
raw_projections=[]
for raw in [b'owned\xff',b'owned\xe2\x82',b'owned\xff\xe2\x82']:
 native=repair(raw)
 raw_projections.append(dict(input_hex=raw.hex(),native_Entry_argument_utf8_hex=native.hex(),
  frozen_BurntSushi_writeQuoted_content_hex=raw.hex(),equal=raw==native,
  proof_kind='byte transformation source projection, not Go/Rust executable output'))
# Explicitly supported parser prefix rejected by Rust prevalidation.
bom_projections=[]
for bom in [b'\xff\xfe',b'\xfe\xff']:
 document=bom+b'audit.enabled=false\n'
 trimmed=document[2:]
 assert tomllib.loads(trimmed.decode())=={'audit':{'enabled':False}}
 try:document.decode('utf8');invalid=False
 except UnicodeDecodeError:invalid=True
 assert invalid
 bom_projections.append(dict(input_hex=document.hex(),Go_parse_source_strips_initial_bytes=2,
  remainder_hex=trimmed.hex(),native_str_from_utf8_rejects=True,
  proof_kind='source-defined Go prefix and actual Python UTF8/TOML projection; not product execution'))
changed=git('diff','--name-only',base,head).decode().splitlines()
changed_source={p:digest((root/p).read_bytes()) for p in changed if p.startswith(('rust/','scripts/')) or p in ['Cargo.lock','docs/adr/brain-resolved-typed-config-765.md']}
external_paths=[
 '/home/agent/go/pkg/mod/github.com/danieljustus/symaira-corekit@v0.17.0/configkit/configkit.go',
 '/home/agent/go/pkg/mod/github.com/!burnt!sushi/toml@v1.6.0/parse.go',
 '/home/agent/go/pkg/mod/github.com/!burnt!sushi/toml@v1.6.0/encode.go',
 '/workspace/toolchains/go1.26.7/src/os/getwd.go',
 '/workspace/oracles/daemon772-go-source/internal/config/config.go',
 '/workspace/oracles/daemon772-go-source/cmd/symbrain/cmd_passthrough.go',
 '/workspace/oracles/daemon772-go-source/internal/harness/toml_document.go',
 '/workspace/oracles/daemon772-go-source/internal/gateway/server.go']
result=dict(scope='independent source-only review; no builds or product execution',base=base,source=source,head=head,
 source_manifest_verified=len(checks),publication_source_diff=git('diff','--name-only',source,head).decode().splitlines(),
 archives_verified_entries=len(ret['entries']),unique_archives=len(archives),archives=archives,
 original_Go_conversion_cases_verified=type_checks,prepared_counts=dict(CLI=cli_count,Unix=unix_count,Windows=windows_count),
 owned_PWD_projections=projections,raw_Codex_encoder_projections=raw_projections,BOM_acceptance_projections=bom_projections,
 changed_source_sha256=changed_source,external_sources_sha256={p:digest(pathlib.Path(p).read_bytes()) for p in external_paths},
 no_new_Cargo_or_Go_builds=True,no_target_access=True,no_ports_or_product_processes=True,
 source_clean_after=not git('status','--porcelain').strip())
out=pathlib.Path('/tmp/symaira-brain765-resolved-config-static-projections.json')
out.write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k in ['source_manifest_verified','archives_verified_entries','unique_archives','prepared_counts','source_clean_after']}))
