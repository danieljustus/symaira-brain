# Brain resolved configuration — independent static review

Disposition: REQUEST CHANGES before native acceptance. Three concrete source-proven P2 groups are listed below. This is a full changed-layer static review, not a compiled or native-runtime approval. The candidate remains clean and unchanged.

## Immutable scope

- Worktree: `/workspace/symaira-brain765-resolved-config`.
- Publication: `e63e20a6faf0f05b3d384b9d2b8e15ac0f234dae`.
- Production/test/harness source: `cf7d4b090748fd547b5eafccc5ea9f540f33d882`.
- Base publication: `fb6d68b337974b03efeb8e9bd547dfbb06bb8fae`; base source `58fe50b9d275f0cc8a7ab6a8252a6595a58e52ab`.
- Recorded main ancestor: `2b6d49f250a81650eda1b93cec7d859a171873bb`.
- Frozen Go: clean `dcddcef0df5789123c7c9a7ebe6e01f10e941f2c`, CoreKit v0.17.0, BurntSushi TOML v1.6.0, SDK Go1.26.7. The retained original executable is Linux AMD64; no platform extrapolation is made.

I read root AGENTS, all 43 changed Rust files or their complete changed fragments plus relevant unchanged consumer/lifecycle/serializer code, both changed Cargo manifests and lock diff, the five new harness files, ADR, checkpoint/plan/parser decision and retention receipts. The inspected changed files and their SHA256 values are enumerated in the receipt. No production Go files, original fixtures or workflow files are changed; the new Go file is an owned probe only. Publication differs from source only by `precompile-checkpoint.json`.

## Findings

### P2 — Vault bypasses the loader's Go-compatible PWD owner selection

`rust/symbrain-cli/src/vault_config.rs:38-39` implements `OverrideSources::current_directory` using `std::env::current_dir()`. `valid_configuration` at lines10-13 independently does the same. The new real `ProcessSources` at `resolved/source.rs:23-43` correctly implements Go's absolute-PWD/same-inode rule before lexical Join; neither Vault seam uses it.

A concrete owned layout has `link -> owner/deep`, physical cwd `owner/project`, and PWD `link/../project`. Kernel stat proves PWD and cwd identify the same inode, so Go Getwd returns the PWD spelling. Go filepath.Join then cleans it to the *lexical* `project/.symbrain.toml`; Vault's override adapter instead reads `owner/project/.symbrain.toml`. Those two files can contain different valid `servers.vault.binary_path` values. The candidate's Vault path can therefore select a different child from frozen Go. If the lexical file has a typed error and the physical file has a valid override, Go ignores the failed whole load and uses managed/PATH discovery, while native Vault selects the physical override. The opposite configuration loses an override Go accepts. The historical fallback validity predicate can also route a healthy invocation to Go because it reads the wrong owner.

Three owned filesystem/source projections are preserved in `static-projections.json`; they prove same-file identity and the differing selected file contents. They do **not** claim actual candidate execution. Frozen `os/getwd.go`, CoreKit `loadOnce`, Go `cmdPassthrough`, and the candidate adapter establish the source-level mismatch directly.

Required correction: delegate filesystem source operations, especially cwd, to `ProcessSources` while retaining only the environment-name injection seam. Make the retained validity/fallback predicate honor the same owner without emitting effects. Add actual raw/ordinary PWD Vault passthrough/admin and repair routing cases, including wrong-owner or wrong-child controls, before acceptance.

### P2 — Install destroys raw Codex profile bytes before format-specific serialization

`rust/symbrain-cli/src/install_cli.rs:356` calls `Entry::new(&profile.unicode_lossy())` for every harness. A raw default profile from the new loader, for example Unix `SYMBRAIN_DEFAULT_PROFILE=owned\xff\xe2\x82`, is therefore permanently converted to three U+FFFD characters before the selected harness format is known.

The frozen Codex backend (`internal/harness/toml_document.go`) forwards its Entry string to BurntSushi `Encoder.writeQuoted`. `encode.go:30` and `:344-345` apply a byte-preserving `strings.NewReplacer` for quote, slash and controls; they do **not** perform Unicode repair. The Go TOML output retains `ff e2 82`, while native can only output `ef bf bd` three times. This changes dry-run output and actual harness bytes, although the loader correctly retained the input value. The human installed-profile line already uses raw bytes correctly.

This finding is specifically the TOML consumer. The historical JSON harness has its own `ordered_map.go::writeJSONString` rune loop and repairs invalid bytes one byte at a time, emitting literal U+FFFD; the new `unicode_lossy` projection is appropriate for that existing JSON boundary. It must not be applied before choosing the format.

The receipt contains three exact byte-transform projections, identified as source-derived rather than actual Go/Rust encoder runs. The prepared loader raw-default case only observes the retained value; the prepared 102 CLI cases all choose Claude, so neither closes this Codex consumer gap.

Required correction: retain the byte-valued profile through format dispatch, use the Go-equivalent repair only for JSON, and preserve the historical TOML byte contract through an appropriate narrow encoding seam. Any intentional change to the accepted raw Codex contract needs a separate explicit decision and named real-Go/native evidence; it is not covered by the parser-wording decision. Add actual Codex and JSON install/dry-run/file-state cases plus malformed-vs-literal-U+FFFD controls.

### P2 — UTF8 prevalidation rejects prefixes accepted by frozen Go's parser

`rust/symbrain-core/src/config/resolved/document.rs:6` validates the entire original input as UTF8 before parser admission. Frozen BurntSushi `parse.go:44-50` strips either leading `ff fe` or `fe ff` before lexing, in addition to the UTF8 BOM. The complete byte inputs `ff fe` + `audit.enabled=false\n` and `fe ff` + the same ASCII document are accepted by the Go parser: after stripping the marker there is no NULL in its first-six-byte check, and the valid body converts the enabled pointer to false. Native returns a UTF8 failure immediately.

This is accepted-input/typed-value behavior, not a difference in the wording of a malformed-syntax error. It is therefore outside the narrow accepted diagnostic wording decision. Both exact byte inputs and the source-defined transformations are preserved. Python projections independently demonstrate valid remainder TOML and invalid original UTF8; no product execution is claimed. Neither prepared parser corpus includes these two prefix cases.

Required correction: preserve the pinned parser's admitted byte-prefix semantics before UTF8 validation, and run actual loader and consumer process pairs. The separately documented earlier-grammar/later-invalid-UTF8 priority issue also remains open; accepting a native diagnostic reason cannot erase either contract.

## Validated static layers

The typed field table matches the Go declaration order and all13 defaults: default profile; audit enabled/verbose; identity injection; updatecheck; three server overrides; patterns enabled/threshold; three module booleans. Pointer false applies, plain zero skips file overwrite, env empty skips, scalar/array nested structs are ignored, conversions and field chains follow CoreKit. Signed base10 integer accumulation preserves unsigned64-before-signed64 error precedence. Threshold normalization happens after all layers. AMD64 float/int instruction behavior is explicitly separated from unproved ARM64/native results.

Fresh per-call loading matches Go creating a new Loader per config.Load. HOME precedes even absolute-XDG file admission; absent file stat skips only NotFound; non-notfound stat continues to actual open/read; failed cwd skips project and continues env. Raw Unix values and Windows WTF8 codecs are distinct from human Display projections. CoreKit reflection ignores unknown fields; Guard's different warning/default diagnostic contracts are not reclassified or waived by this loader.

Setup's Browse-only release mapping and all-three source mapping are separate and match Go. Explicit source modules still require full config admission after source-root validation. Doctor report uses typed parsing; repair retains its checked first human header/write boundary; handshake has its separate load/default-on-failure policy. Install explicit profile bypasses resolved loading, while default selection loads after harness path admission. Vault whole-load failure ignores the override, subject to the owner defect above. Stored config get/set/path remains the global map API.

Broker and Harness gain Core dependencies only; lock changes add those two local dependency edges, with no version upgrade. Guard/Managed/Memory dependencies do not enter Core. Broker's native selector persists through spawn/restart; existing String API stays a lossy compatibility wrapper. Harness runtime no longer enumerates the full environment as Unicode and keeps trusted-root/AtomicFile boundaries. Existing unrelated raw argv/profile and other platform predicates are not promoted to new parity proof.

MCP consumes the typed value after profile loading and before backends; audit OR/verbose, routed identity and configured pattern threshold are wired. Session recording stores server/tool names only, excludes unknown/hidden/bootstrap/pattern calls, includes completed exposed errors, and takes the episode once for flush. End-of-session/cancellation ordering, log/store failure output, current Memory construction, and all option combinations still require process evidence. Existing conditional native Memory/JWT construction versus eager Go remains #759, not a loader-owned acceptance projection.

I also traced inherited optional-module discovery diagnostics: Go wraps invalid configured overrides and uses its `neither direct nor symcockpit` error, while the retained native path emits discovery errors directly. These are pre-existing MCP differences and must be included in whole-consumer acceptance, not relabeled as new loader regressions or covered by malformed-TOML wording.

## Evidence and prepared gates

Independent verification performed without compiler, target, ports or product execution:

- All563 checkpoint source SHA256 entries match the immutable current tree.
- All131 retained mappings and113 unique gzip payloads pass compressed SHA, decompressed SHA and byte count verification, including all55 original proof artifacts.
- All25 live frozen-contract/CoreKit/SDK files from the original receipt remain hash-identical; frozen Go tree is clean at DCdd.
- Original native SHA `256e5efe3d05b9fe5c8afa41d9821a13ee2dee32de9719a4acd7e79364fde8ee` and original Go SHA `a68dce5b6f34d10ed568d2a89fab880c889e5ff578735c7bf2ad0535285eda41` verified by reading, without execution.
- All13 checked-in type-error fixtures match their actual original Go exit2/full stderr observations and exact conversion suffixes from the retained inventory.
- Imported case-definition generators only:102 CLI,152 Unix and174 Windows definitions confirmed. Windows definitions were counted with an isolated os-name stub, not executed.
- Three owned PWD projections, three raw profile byte projections and two BOM admission projections retained; each is explicitly source-only.
- `git diff --check` passes; candidate clean before/after. No source or worktree changes, GitHub writes, Go/Rust builds, targets, endpoints or native-process execution.

The process runner compares exact raw outputs/exit/full owned filesystem state/local request observations; its default missing-Go sentinel distinguishes delegation. The value runner compares all13 values/config selector as hex with full output/state equality; it does not project parser errors. The prepared mutant executable actually delegates a candidate then injects owned filesystem/HTTP effects, corrupts exit/field text or a value; none has been built or run here. Staging refuses existing/inside-frozen destinations and copies receipt-bound Go config/module sources, not production modifications.

The strict prepared parser cases currently also compare inner diagnostics byte-for-byte. They are deliberately expected to fail until the narrowly accepted named diagnostic contract is implemented with full raw observations retained. That fact is documented; it is not a passing native gate or permission for generic normalization.

Original retained observations are115 groups/269 executions (91/221 inventory;11/22 boundaries;7/14 patterns;6/12 admission), including failures and provisional/preparation attempts. Parent501/54 results are historical only. **Zero successor compiled tests, zero successor product process pairs, zero native3/platform claims** in this review.

## Remaining acceptance

This checkpoint is correctly labeled unbuilt/not publishable. Full locked workspace tests, strict Clippy/fmt, all unchanged Source111/Doctor285/Setup201/Guard/Memory/stdio/raw/cancellation controls, new13-value/consumer controls and platform gates remain unexecuted. Supported TOML syntax/UTF8 priorities, SDK LookPath/ErrDot/Windows CWD/PATHEXT/same-file behavior and Windows Stat operation text are not waived. No new CI workflow claims these prepared cases have run. Full #765/#769, native Browse builders, Memory eager/JWT ownership, legacy schema and protected native CI remain open.

Different-author runtime review must follow correction and actual source-bound fresh gates. This static report is not author self-approval or permission to merge the current checkpoint.
