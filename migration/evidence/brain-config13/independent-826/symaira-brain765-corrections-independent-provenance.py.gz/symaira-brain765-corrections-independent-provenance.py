import ast, gzip, hashlib, importlib, json, os, pathlib, subprocess, sys, types
sys.dont_write_bytecode = True
R=pathlib.Path('/workspace/symaira-brain765-resolved-config-fixes')
O=pathlib.Path('/workspace/symaira-brain765-resolved-config')
F=pathlib.Path('/workspace/oracles/daemon772-go-source')
H='826af02e04d80d6d52603ca51ed8491dfe9f7e6f'
S='04f1acf90b9142d9bf8edd47c715de10caf4f8ef'
def sha(b):return hashlib.sha256(b).hexdigest()
def git(root,*args):return subprocess.check_output(['git','-C',str(root),*args]).decode().strip()
assert git(R,'rev-parse','HEAD')==H and not git(R,'status','--porcelain')
assert git(O,'rev-parse','HEAD')=='e63e20a6faf0f05b3d384b9d2b8e15ac0f234dae' and not git(O,'status','--porcelain')
assert git(F,'rev-parse','HEAD')=='dcddcef0df5789123c7c9a7ebe6e01f10e941f2c' and not git(F,'status','--porcelain')
c=json.loads((R/'migration/evidence/brain-config13/corrections-source-only/checkpoint.json').read_bytes())
source={p:sha((R/p).read_bytes()) for p in c['candidate_source_sha256']}
assert source==c['candidate_source_sha256'] and len(source)==570
pub=git(R,'diff','--name-only',S,H).splitlines()
assert pub==['migration/evidence/brain-config13/corrections-source-only/checkpoint.json']
old=json.loads(pathlib.Path('/tmp/symaira-brain765-resolved-config-independent-static-review-receipt.json').read_bytes())
external={p:sha(pathlib.Path(p).read_bytes()) for p in old['external_sources_sha256']}
assert external==old['external_sources_sha256']
external2={p:sha(pathlib.Path(p).read_bytes()) for p in old['live_frozen_contract_and_SDK_hashes_verified']}
assert external2==old['live_frozen_contract_and_SDK_hashes_verified']
assert all(sha(pathlib.Path(p).read_bytes())==h for p,h in c['pinned_source_sha256'].items())
archives={}; maps=0
for folder,key in [('initial-58fe','entries'),('independent-e63e','new_entries')]:
 base=R/'migration/evidence/brain-config13'/folder
 receipt=json.loads((base/'retention.json').read_bytes())
 for e in receipt[key]:
  p=base/e['archive'] if folder=='initial-58fe' else R/e['archive']
  z=p.read_bytes();b=gzip.decompress(z)
  assert sha(z)==e['archive_sha256'] and sha(b)==e['sha256'] and len(b)==e['bytes']
  archives[str(p)]=dict(archive_sha256=sha(z),sha256=sha(b),bytes=len(b));maps+=1
  if folder=='independent-e63e':assert pathlib.Path(e['original']).read_bytes()==b
assert maps==135 and len(archives)==117
unchanged=c['static_checks']['original_case_files_byte_identical']
assert all((R/p).read_bytes()==(O/p).read_bytes() for p in unchanged)
for p in ['Cargo.toml','Cargo.lock']:
 assert (R/p).read_bytes()==(O/p).read_bytes()
executables={p:sha(pathlib.Path(p).read_bytes()) for p in old['original_executables_verified_no_execution']}
assert executables==old['original_executables_verified_no_execution']
frozen={p:sha((F/p).read_bytes()) for p in git(F,'ls-files','*.go','go.mod','go.sum','guard/go.mod','guard/go.sum','browse/go.mod','browse/go.sum').splitlines()}
sys.path.insert(0,str(R/'scripts/brain-config13'))
import process, values, correction_cases
counts=dict(originalCLI=len(list(process.cases())),originalUnix=len(list(values.cases())),newUnixConsumers=len(list(correction_cases.consumer_cases())),newLoader=len(list(correction_cases.loader_cases())))
values.os=types.SimpleNamespace(name='nt',fsdecode=os.fsdecode)
correction_cases.os=types.SimpleNamespace(name='nt')
counts.update(originalWindows=len(list(values.cases())),newWindowsConsumers=len(list(correction_cases.consumer_cases())))
assert counts==dict(originalCLI=102,originalUnix=152,newUnixConsumers=182,newLoader=146,originalWindows=174,newWindowsConsumers=157)
python_paths=list((R/'scripts/brain-config13').glob('*.py'))
for p in python_paths:ast.parse(p.read_text(),filename=str(p))
fixture=json.loads((R/'rust/symbrain-core/tests/fixtures/brain13-types-go58.json').read_bytes())
assert len(fixture['cases'])==13
# Retain all source inspected, not a claim of compiling it.
changed=git(R,'diff','--name-only','fb6d68b337974b03efeb8e9bd547dfbb06bb8fae',H).splitlines()
reviewed={p:sha((R/p).read_bytes()) for p in changed if p.startswith(('rust/','scripts/brain-config13/')) or p in ('Cargo.toml','Cargo.lock','docs/adr/brain-resolved-typed-config-765.md')}
result=dict(scope='independent source and hashing only; no compiler/target/product/port',head=H,source=S,source_manifest=source,manifest_count=len(source),publication_diff=pub,external=external,external_live=external2,author_pinned=c['pinned_source_sha256'],archives=archives,archive_mappings=maps,unique_archives=len(archives),old_case_bytes_unchanged=unchanged,executables_read_only=executables,frozen_source=frozen,frozen_count=len(frozen),prepared_counts=counts,python_ast=[str(p.relative_to(R)) for p in python_paths],reviewed_source=reviewed,candidate_clean=not git(R,'status','--porcelain'),old_candidate_clean=not git(O,'status','--porcelain'))
pathlib.Path('/tmp/symaira-brain765-corrections-independent-provenance.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(dict(status='PASS',manifest=len(source),archive_mappings=maps,unique_archives=len(archives),frozen=len(frozen),external=len(set(external)|set(external2)|set(c['pinned_source_sha256'])),reviewed_sources=len(reviewed),prepared=counts)))
