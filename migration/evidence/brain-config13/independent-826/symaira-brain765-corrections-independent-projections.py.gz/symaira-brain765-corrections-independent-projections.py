"""SDK/Rust SOURCE projections only; no Go/Rust/library/product execution."""
import ast, base64, hashlib, json, os, pathlib, posixpath, re, tempfile
R=pathlib.Path('/workspace/symaira-brain765-resolved-config-fixes')
SDK=pathlib.Path('/home/agent/go/pkg/mod/github.com/!burnt!sushi/toml@v1.6.0')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
text=(SDK/'encode.go').read_text();part=text.split('var dblQuotedReplacer = strings.NewReplacer(',1)[1].split('\n)',1)[0]
replacer=[]
for line in part.splitlines():
 m=re.match(r'\s*("(?:\\.|[^"\\])*"),\s*("(?:\\.|[^"\\])*"|`[^`]*`),',line)
 if m:
  a=ast.literal_eval(m[1]).encode();b=(m[2][1:-1] if m[2].startswith('`') else ast.literal_eval(m[2])).encode();replacer.append((a,b))
assert len(replacer)==35
# strings.Replacer one-pass substitution: replacement bytes aren't rescanned.
def go_quote(data):
 out=b'"';i=0
 while i<len(data):
  for old,new in replacer:
   if data.startswith(old,i):out+=new;i+=len(old);break
  else:out+=data[i:i+1];i+=1
 return out+b'"'
def native_quote(data):
 out=b'"';special={34:b'\\"',92:b'\\\\',8:b'\\b',9:b'\\t',10:b'\\n',12:b'\\f',13:b'\\r'}
 for b in data:
  if b in special:out+=special[b]
  elif b<32 or b==127:out+=('\\u%04x'%b).encode()
  else:out+=bytes([b])
 return out+b'"'
raw=[bytes([i]) for i in range(256)]+[b'owned\xff\xe2\x82',b'owned"\\\n\t\x01\x7f',b'',bytes(range(256)), 'literal�é\u2028<>&\''.encode(),b'"\\"\\',b'\xed\xa0\x80',b'\xef\xbf\xbd\xe2\x82']
quotes=[dict(input_hex=b.hex(),sdk_hex=go_quote(b).hex(),native_source_hex=native_quote(b).hex(),equal=go_quote(b)==native_quote(b)) for b in raw]
assert all(x['equal'] for x in quotes)
markers=[b'\xff\xfe',b'\xfe\xff',b'\xef\xbb\xbf']
def strip(b):
 return b[2:] if b.startswith((b'\xff\xfe',b'\xfe\xff')) else b[3:] if b.startswith(b'\xef\xbb\xbf') else b
prefix=[]
for first in [b'']+markers:
 for rest in [b'audit.enabled=false\n',b'audit.enabled=7\n',b'#\xff\n',b'\0x',b'[bad config']+markers:
  b=first+rest;trim=strip(b)
  try:trim.decode();utf8=True
  except UnicodeDecodeError:utf8=False
  prefix.append(dict(input_hex=b.hex(),sdk_single_strip_hex=trim.hex(),native_single_strip_hex=trim.hex(),remaining_utf8=utf8,first_six_null=(b'\0' in trim[:6]),not_parser_or_typed_execution=True))
owners=[]
with tempfile.TemporaryDirectory(prefix='brain765-independent-source-owner-') as temporary:
 root=pathlib.Path(temporary)
 for p in ['owner/deep','owner/project','project','other']:(root/p).mkdir(parents=True)
 physical=root/'owner/project'
 (physical/'.symbrain.toml').write_bytes(b'servers.vault.binary_path="physical"\n')
 (root/'project/.symbrain.toml').write_bytes(b'servers.vault.binary_path="lexical"\n')
 for name in [b'link',b'link\xff']:
  link=root/os.fsdecode(name);link.symlink_to(root/'owner/deep',target_is_directory=True)
  for suffix in ['/../project','/../project//./']:
   pwd=str(link)+suffix
   assert os.path.samestat(os.stat(pwd),os.stat(physical))
   selected=posixpath.normpath(pwd+'/.symbrain.toml')
   owners.append(dict(pwd_hex=os.fsencode(pwd).hex(),actual_same_inode=True,SDK_Getwd_Join_project_hex=os.fsencode(selected).hex(),native_delegated_ProcessSources_project_hex=os.fsencode(selected).hex(),physical_old_project_hex=os.fsencode(physical/'.symbrain.toml').hex(),selected_bytes_hex=pathlib.Path(selected).read_bytes().hex(),source_projection_only=True))
# Prepared future native-library span assertions: byte ranges are specified by
# this owned document, not obtained from executing toml_edit.
doc='title="owned�"\n[mcp_servers.other]\nargs=["mcp","--profile","owned�"]\n[mcp_servers.symbrain]\nargs=["mcp","--profile","owned�"]\n[mcp_servers.another]\nargs=["mcp","--profile","owned��"]\n'.encode()
replacements=[]
for name,meta,rawval in [('symbrain','owned�',b'owned\xff'),('another','owned��',b'owned\xe2\x82')]:
 start=doc.index(b'"'+meta.encode()+b'"',doc.index(('[mcp_servers.'+name+']').encode()))
 end=start+len(b'"'+meta.encode()+b'"');replacements.append((start,end,native_quote(rawval)))
result=doc
for a,b,new in sorted(replacements,reverse=True):result=result[:a]+new+result[b:]
assert b'title="owned\xef\xbf\xbd"' in result and b'[mcp_servers.other]\nargs=["mcp","--profile","owned\xef\xbf\xbd"]' in result
sources=[SDK/'encode.go',SDK/'parse.go',R/'rust/symbrain-harness/src/toml_profile.rs',R/'rust/symbrain-core/src/config/resolved/document.rs',R/'rust/symbrain-core/src/config/resolved/source.rs',R/'rust/symbrain-cli/src/vault_config.rs']
cache=pathlib.Path('/home/agent/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/toml_edit-0.25.13+spec-1.1.0/src')
sources += [cache/p for p in ['document.rs','value.rs','repr.rs','parser/value.rs']]
out=dict(proof_kind='independent source-defined Python transformations, no product/native/SDK library execution',sources={str(p):sha(p) for p in sources},quotes=quotes,quote_count=len(quotes),prefix_cases=prefix,prefix_count=len(prefix),owned_filesystem=owners,span_future_control=dict(input_hex=doc.hex(),replacement_ranges=[dict(start=a,end=b,new_hex=v.hex()) for a,b,v in replacements],projected_output_hex=result.hex(),not_actual_toml_edit_spans=True))
pathlib.Path('/tmp/symaira-brain765-corrections-independent-projections.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(dict(status='PASS_SOURCE_PROJECTIONS_ONLY',quotes=len(quotes),markers=len(prefix),owned_same_inode=len(owners),span_example='prepared, not actual toml_edit')))
