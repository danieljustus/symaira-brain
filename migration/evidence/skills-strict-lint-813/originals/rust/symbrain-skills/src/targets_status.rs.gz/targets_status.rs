//! Read-only harness target inventory behind `symbrain skills targets`.
//!
//! Every field is observed, never guessed: evidence names the file or binary
//! it came from, and a missing skill root is reported as `missing` rather than
//! as an empty installation. Declared runtime capabilities stay `unknown`
//! unless the target registry states them, because symskills does not inspect
//! harness runtimes.

use std::collections::BTreeMap;
use std::fs;
use std::path::{Path, PathBuf};

use serde::Serialize;

use crate::target::{self, TargetSpec, lookup};

/// What symskills can do toward a target, in report order.
const CAPABILITIES: [&str; 4] = ["render", "install", "symlink", "copy"];

/// Runtime capability vocabulary, in report order. Each entry is reported for
/// every target with the state the registry declares for it.
const RUNTIME_CAPABILITIES: [&str; 6] = [
    "subagents",
    "background_tasks",
    "mcp",
    "slash_commands",
    "hooks",
    "scheduled_tasks",
];

const CAPABILITY_SUPPORTED: &str = "supported";
const CAPABILITY_UNSUPPORTED: &str = "unsupported";
const CAPABILITY_UNKNOWN: &str = "unknown";

const MARKER_FILE: &str = ".symskills.json";

/// One row of `skills targets`.
///
/// Field order matches the Go struct so the JSON bytes match too.
#[derive(Debug, Serialize)]
pub struct TargetStatus {
    /// Stable target name.
    pub target: String,
    /// Human-readable target name.
    pub display_name: String,
    /// Whether any harness evidence (binary or config directory) was found.
    pub installed: bool,
    /// First evidence source(s), e.g. `binary:/usr/local/bin/opencode`.
    pub evidence: crate::GoText,
    /// Skill root the target would read for the requested scope.
    #[serde(serialize_with = "crate::text::serialize_path")]
    pub effective_skill_root: PathBuf,
    /// Whether the skill root exists on disk.
    pub skill_root_exists: bool,
    /// Whether the skill root could be enumerated.
    pub skill_root_readable: bool,
    /// Installs carrying a symskills marker.
    pub managed_skills_count: usize,
    /// Unmanaged directories or links in the skill root.
    pub unmanaged_skills_count: usize,
    /// `missing` | `unreadable` | `managed` | `mixed` | `unmanaged` | `empty`.
    pub install_state: String,
    /// What symskills can do toward this target.
    pub capabilities: Vec<&'static str>,
    /// Declared runtime capability states.
    pub runtime_capabilities: BTreeMap<String, String>,
    /// Ready-to-run next step for this target.
    pub setup_hint: crate::GoText,
    /// `verified` when evidence was found, otherwise `not_verified`.
    pub verification_status: String,
}

/// Inputs for a target inventory scan.
#[derive(Debug, Clone, Default)]
pub struct StatusOptions {
    /// User home used to resolve harness roots.
    pub home_dir: PathBuf,
    /// Project root; empty disables project-scope resolution.
    pub project_dir: Option<PathBuf>,
    /// `user` (default) or `project`.
    pub scope: String,
}

/// Returns one status row per registered target, in registry order.
#[must_use]
pub fn list_status(options: &StatusOptions) -> Vec<TargetStatus> {
    target::target_names()
        .iter()
        .filter_map(|name| lookup(name))
        .map(|spec| inspect(spec, options))
        .collect()
}

fn inspect(spec: TargetSpec, options: &StatusOptions) -> TargetStatus {
    let scope = if options.scope.is_empty() {
        "user"
    } else {
        options.scope.as_str()
    };
    let project = options.project_dir.as_deref();
    let skill_root = target::skill_root(spec.name, &options.home_dir, project, scope)
        .unwrap_or_else(|| options.home_dir.clone());
    let config_dir = target::config_dir(spec.name, &options.home_dir, project, scope);

    let evidence = evidence_for(spec, config_dir.as_deref());
    let counts = SkillRootCounts::scan(&skill_root);
    let (install_state, setup_hint) = state_and_hint(spec, &skill_root, &counts);
    let runtime_capabilities = RUNTIME_CAPABILITIES
        .iter()
        .map(|name| ((*name).to_owned(), capability_state(spec, name).to_owned()))
        .collect();

    TargetStatus {
        target: spec.name.to_owned(),
        display_name: spec.display_name.to_owned(),
        installed: evidence.installed,
        evidence: evidence.text,
        effective_skill_root: skill_root.clone(),
        skill_root_exists: counts.exists,
        skill_root_readable: counts.readable,
        managed_skills_count: counts.managed,
        unmanaged_skills_count: counts.unmanaged,
        install_state,
        capabilities: CAPABILITIES.to_vec(),
        runtime_capabilities,
        setup_hint,
        verification_status: evidence.verification_status,
    }
}

/// Harness evidence: an installed binary and/or a present config directory.
struct Evidence {
    installed: bool,
    text: crate::GoText,
    verification_status: String,
}

fn evidence_for(spec: TargetSpec, config_dir: Option<&Path>) -> Evidence {
    let mut parts: Vec<crate::GoText> = Vec::new();
    if let Some(binary) = lookup_path(spec.binary_name) {
        parts.push(crate::GoText::from_path(&binary).prefixed("binary:"));
    }
    if let Some(config) = config_dir
        && config.is_dir()
    {
        parts.push(crate::GoText::from_path(config).prefixed("config_dir:"));
    }
    let installed = !parts.is_empty();
    let text = match parts.len() {
        0 => "none".into(),
        1 => parts[0].clone(),
        _ => {
            let mut bytes = parts[0].as_bytes().to_vec();
            bytes.push(b',');
            bytes.extend_from_slice(parts[1].as_bytes());
            crate::GoText::from_bytes(&bytes)
        }
    };
    Evidence {
        installed,
        text,
        verification_status: if installed {
            "verified"
        } else {
            "not_verified"
        }
        .to_owned(),
    }
}

/// Observed skill-root state for one target.
struct SkillRootCounts {
    exists: bool,
    readable: bool,
    managed: usize,
    unmanaged: usize,
}

impl SkillRootCounts {
    fn scan(skill_root: &Path) -> Self {
        let mut counts = Self {
            exists: false,
            readable: false,
            managed: 0,
            unmanaged: 0,
        };
        if fs::symlink_metadata(skill_root).is_err() {
            return counts;
        }
        counts.exists = true;
        let Ok(entries) = fs::read_dir(skill_root) else {
            return counts;
        };
        counts.readable = true;
        for (index, entry) in entries.flatten().enumerate() {
            if index >= crate::MAX_RESOURCE_ENTRIES {
                counts.readable = false;
                counts.managed = 0;
                counts.unmanaged = 0;
                break;
            }
            let path = skill_root.join(entry.file_name());
            if is_managed_skill(&path) {
                counts.managed += 1;
            } else if entry
                .file_type()
                .is_ok_and(|kind| kind.is_dir() || kind.is_symlink())
            {
                counts.unmanaged += 1;
            }
        }
        counts
    }
}

/// Derives the reported install state and the ready-to-run setup hint.
fn state_and_hint(
    spec: TargetSpec,
    skill_root: &Path,
    counts: &SkillRootCounts,
) -> (String, crate::GoText) {
    let managed = counts.managed;
    let unmanaged = counts.unmanaged;
    if !counts.exists {
        return ("missing".to_owned(), {
            let mut bytes = b"Create skill directory ".to_vec();
            bytes.extend_from_slice(skill_root.as_os_str().as_encoded_bytes());
            bytes.extend_from_slice(
                format!(" or run 'symskills install --target {} <skill>'", spec.name).as_bytes(),
            );
            crate::GoText::from_bytes(&bytes)
        });
    }
    if !counts.readable {
        return (
            "unreadable".to_owned(),
            crate::GoText::from_path(skill_root).prefixed("Check permissions for skill root "),
        );
    }
    if managed > 0 && unmanaged == 0 {
        return (
            "managed".to_owned(),
            format!("Harness is active with {managed} managed skill(s)").into(),
        );
    }
    if managed > 0 {
        return (
            "mixed".to_owned(),
            format!("Harness contains {managed} managed and {unmanaged} unmanaged skill(s)").into(),
        );
    }
    if unmanaged > 0 {
        return (
            "unmanaged".to_owned(),
            format!(
                "Harness contains {unmanaged} unmanaged skill(s); consider importing into library"
            )
            .into(),
        );
    }
    (
        "empty".to_owned(),
        format!(
            "Harness skill directory is ready; install skills with 'symskills install --target {} <skill>'",
            spec.name
        ).into(),
    )
}

/// Declared state of one runtime capability for a target.
fn capability_state(spec: TargetSpec, name: &str) -> &'static str {
    match spec
        .capabilities
        .iter()
        .find(|(capability, _)| *capability == name)
    {
        None => CAPABILITY_UNKNOWN,
        Some((_, true)) => CAPABILITY_SUPPORTED,
        Some((_, false)) => CAPABILITY_UNSUPPORTED,
    }
}

/// Reports whether an entry in a skill root is a symskills-managed install.
///
/// A marker directly inside the entry counts, and so does a marker behind a
/// link, because that is where symlink-mode installs keep it.
fn is_managed_skill(path: &Path) -> bool {
    if fs::metadata(path.join(MARKER_FILE)).is_ok() {
        return true;
    }
    let Ok(metadata) = fs::symlink_metadata(path) else {
        return false;
    };
    if !metadata.file_type().is_symlink() {
        return false;
    }
    let Ok(link) = fs::read_link(path) else {
        return false;
    };
    let resolved = if link.is_absolute() {
        link
    } else {
        path.parent()
            .map_or(link.clone(), |parent| parent.join(&link))
    };
    fs::metadata(resolved.join(MARKER_FILE)).is_ok()
}

/// Discovery is shared with the skills git caller, including Go ErrDot.
fn lookup_path(name: &str) -> Option<PathBuf> {
    crate::binary::executable(Path::new(name))
        .ok()
        .flatten()
        .map(|item| item.spelling)
}
