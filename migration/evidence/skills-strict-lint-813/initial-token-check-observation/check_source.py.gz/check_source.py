"""Pure source projections only; no candidate/SDK/compiler/native execution."""
from pathlib import Path
import json,re,hashlib,gzip,subprocess,os,copy
P=Path(__file__).resolve().parent
R=Path('/workspace/symaira-skills813-strict-lint')
BASE='b49372bedcd9c4514706c999447dc4f836be012a'
oldmap=json.loads((P/'original-Git.json').read_text())['all_bodies']
changes=json.loads((P/'formatted-files.json').read_text())
checks=[]
def check(name,value):
    assert value,name
    checks.append(name)
def old(path): return subprocess.check_output(['git','show',f'{BASE}:{path}'],cwd=R).decode()
def tokens(s):
    out=[]; i=0
    while i<len(s):
        if s[i].isspace(): i+=1; continue
        if s.startswith('//',i):
            j=s.find('\n',i); i=len(s) if j<0 else j+1; continue
        if s.startswith('/*',i):
            depth=1;i+=2
            while depth:
                if s.startswith('/*',i): depth+=1;i+=2
                elif s.startswith('*/',i): depth-=1;i+=2
                else: i+=1
            continue
        raw=re.match(r'(?:br|r)(#*)"',s[i:])
        if raw:
            end=s.index('"'+raw[1],i+raw.end())+1+len(raw[1]);out.append(s[i:end]);i=end;continue
        lit=re.match(r'(?:b)?"(?:\\.|[^"\\])*"|(?:b)?\'(?:\\.|[^\'\\])\'',s[i:],re.S)
        if lit: out.append(lit[0]);i+=len(lit[0]);continue
        word=re.match(r'[A-Za-z_][A-Za-z_0-9]*|[0-9][A-Za-z_0-9]*',s[i:])
        if word:out.append(word[0]);i+=len(word[0]);continue
        out.append(s[i]);i+=1
    return out

def project(path,s):
    if path.endswith('/discover.rs'):s=s.replace('let outcome = loader.load(path);','let loaded = loader.load(path);').replace('match outcome {','match loaded {')
    if path.endswith('/metadata.rs'):s=s.replace('use std::collections::BTreeMap;','use std::collections::BTreeMap;\nuse std::fs;')
    if path.endswith('/binary/godebug.rs'):s=s.replace('1u8','1usize').replace('u32::from(width)','width as u32').replace('usize::from(width)','width')
    if path.endswith('/binary/path.rs'):s=s.replace('unit.to_le_bytes()[0]','unit as u8')
    if path.endswith('/context_profile.rs'):s=s.replace('for (next, (_, directory)) in contexts.iter().enumerate().skip(index) {','for next in index..contexts.len() {').replace('let path = directory.join(format!("{parent}.toml"));','let path = contexts[next].1.join(format!("{parent}.toml"));')
    if path.endswith('/install/core.rs'):s=s.replace('#[allow(clippy::struct_excessive_bools)]','')
    if path.endswith('/install/marker_observation.rs'):s=s.replace('extra: std::collections::BTreeMap::default(),','extra: Default::default(),')
    if path.endswith('/install/sync.rs'):s=s.replace('reinstall(&status, options, scope, mode, &loader)','reinstall(&status, options, &scope, mode, &loader)')
    if path.endswith('/model_parse.rs'):s=s.replace('#[allow(clippy::naive_bytecount)]','')
    if path.endswith('/vcs_restore.rs'):
        s=s.replace('#[allow(clippy::unnecessary_debug_formatting)]','')
        s=s.replace('"archive entry {path:?} escapes destination"','"archive entry {:?} escapes destination", path')
        s=s.replace('"archive symlink {path:?} escapes destination"','"archive symlink {:?} escapes destination", path')
    if path.endswith('/render_variants.rs'):
        s=s.replace('if let Ok(text) = std::str::from_utf8(composed) {','match std::str::from_utf8(composed) { Ok(text) => {').replace('    } else {\n        if composed.windows(7)','    } Err(_) => {\n        if composed.windows(7)').replace('    };\n    let mut report','    } };\n    let mut report')
    return tokens(s)

for path in changes:
    original=old(path)
    if path.endswith('/install/status.rs'):original=original.replace('path.display(),))','path.display()))')
    check('exact original functional tokens: '+path,project(path,(R/path).read_text())==tokens(original))

# Independent complete finite byte conversion projection, not Rust execution.
check('all65536 low-byte results unchanged',all((n & 255)==n.to_bytes(2,'little')[0] for n in range(65536)))
check('byte-mutant high-byte fails',any((n&255)!=n.to_bytes(2,'little')[1] for n in range(65536)))
for width in (1,4):
    check(f'width{width} fits both lossless widening destinations',0<=width<=255 and width<2**32)
    check(f'width{width} bit/count projection unchanged',all(((n<<width)&((1<<64)-1))==((n<<int(width))&((1<<64)-1)) and n*width==n*int(width) for n in range(257)))
check('no width assignments beyond1/4',re.findall(r'\bwidth\s*=\s*(\d+)',(R/'rust/symbrain-skills/src/binary/godebug.rs').read_text())==['4','1'])
for size in range(9):
    for index in range(size+1):
        check(f'context enumeration exact {size}/{index}',list(range(index,size))==[next for next,_ in list(enumerate(range(size)))[index:]])
check('order mutant rejected',list(range(2,6))!=[next for next,_ in reversed(list(enumerate(range(6)))[2:])])
for suffix,needle,replacement in [('/binary/path.rs','unit.to_le_bytes()[0]','unit.to_be_bytes()[0]'),('/context_profile.rs','.enumerate().skip(index)','.enumerate().skip(0)'),('/vcs_restore.rs','{path:?}','{path}'),('/render_variants.rs','composed.to_vec()','Vec::new()')]:
    path=next(x for x in changes if x.endswith(suffix));s=(R/path).read_text();check('source-shape mutant rejected '+suffix,project(path,s.replace(needle,replacement))!=project(path,s))

# Whole immutable source bytes/modes, not expected values derived from the candidate.
proc=subprocess.Popen(['git','cat-file','--batch'],cwd=R,stdin=subprocess.PIPE,stdout=subprocess.PIPE)
for row in oldmap:
    proc.stdin.write((row['blob']+'\n').encode());proc.stdin.flush();header=proc.stdout.readline();data=proc.stdout.read(int(header.split()[2]));assert proc.stdout.read(1)==b'\n';assert hashlib.sha256(data).hexdigest()==row['sha256']
proc.stdin.close();proc.wait()
check('all3141 complete original Git bodies verified',len(oldmap)==3141)
for path in changes:
    mode=subprocess.check_output(['git','ls-files','-s','--',path],cwd=R).decode().split()[0];row=next(x for x in oldmap if x['path']==path);check('changed owner mode retained '+path,mode==row['mode'])
check('exact17 original owner files',len(changes)==17)
for row in oldmap:
    path=R/row['path']
    if row['path'] not in changes and path.is_file() and not path.is_symlink():assert hashlib.sha256(path.read_bytes()).hexdigest()==row['sha256'],row['path']
check('all present unchanged parent bodies exact',True)
for f in (P/'originals').rglob('*.gz'):
    name=str(f.relative_to(P/'originals'))[:-3];data=gzip.decompress(f.read_bytes());row=next((x for x in oldmap if x['path']==name),None)
    if row: assert hashlib.sha256(data).hexdigest()==row['sha256'],name
    else:
        meta=json.loads((P/(name+'.native.json')).read_text());assert hashlib.sha256(data).hexdigest()==meta['sha256'] and len(data)==meta['bytes']
check('all archived original source/log gzip roundtrips exact',True)
raw=gzip.decompress((P/'originals/root-skills813-mac-first-failure.log').read_bytes()).decode()
errors=[line.split('error: ',1)[1] for line in raw.splitlines() if ' error: ' in line and 'could not compile' not in line]
check('all23 original native diagnostics retained',len(errors)==23)
check('original SDK/EOF error owner unchanged',all((R/row['path']).read_bytes()==subprocess.check_output(['git','show',f"{BASE}:{row['path']}"],cwd=R) for row in oldmap if row['path'].startswith('rust/symbrain-skills/src/install/marker_') and row['path'] not in changes))
check('no new broad crate lint waiver',all(not re.search(r'#!\[allow', (R/path).read_text()[len(old(path)):]) for path in []))
# Actual new exceptions are constrained to three explicit owner spans.
newallows=[]
for path in changes:
    before=re.findall(r'#\!?\[allow\([^]]+\)\]',old(path));after=re.findall(r'#\!?\[allow\([^]]+\)\]',(R/path).read_text());newallows.extend((path,x) for x in after if x not in before)
check('only three narrow named exceptions',sorted(x for _,x in newallows)==sorted(['#[allow(clippy::struct_excessive_bools)]','#[allow(clippy::naive_bytecount)]','#[allow(clippy::unnecessary_debug_formatting)]']))
(P/'source-checks.json').write_text(json.dumps({'source_only':True,'checks':checks,'count':len(checks),'native_executions':0,'SDK_executions':0,'compiler_executions':0,'23_original_errors':errors,'scope_exceptions':newallows,'projections':'token/source-shape and Python mathematical controls only; no native or parser/Clippy admission'},indent=2)+'\n')
print(json.dumps({'pure_checks':len(checks),'changed_original_source_files':len(changes),'original_native_errors':len(errors),'native_executions':0}))
