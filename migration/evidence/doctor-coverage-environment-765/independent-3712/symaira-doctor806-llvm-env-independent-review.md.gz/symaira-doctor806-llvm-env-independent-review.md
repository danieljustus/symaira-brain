# Independent review: Doctor missing-home coverage environment

**APPROVE the precise test-only correction** at clean `3712c29ead8f37f35136cd16252285bd9fa8fee9` in `/workspace/symaira-doctor765`, parent `ac81b94f6d47250baf2ee1ed619802a4affa4817`. No introduced finding.

The four added lines in `rust/symbrain-cli/tests/doctor_fix_native.rs` preserve the caller's `LLVM_PROFILE_FILE` with `var_os` after `env_clear`, consistent with the existing Doctor test helper. The instrumented child therefore uses the coverage owner's output location rather than creating a default `.profraw` file inside the disposable product-state root. Missing/empty HOME precedence, absent fallback, exact exit/stdout/stderr, complete filesystem snapshot and fallback-directory absence assertions remain intact. The patch does not pass HOME or other product inputs through, filter the snapshot, skip tests, change production or alter dependencies.

All eight retained original CI artifacts are independently gzip/length/SHA verified against the original files. The original ZIP SHA `d140101a5bb1d3f062e8d63cd9f0b5d3df7d1bfdcbcedf93cdc837d4d46a776d` contains the exact10,848,071-byte job member SHA `928f79b7d68fc5aadd2f90818681fcdb2a393528c705f9cc9ed9431286e21ce2`; it names the missing-home test and actual `default_16407567936918546430_0_21257.profraw` snapshot pollution. This supports the concrete fixture correction rather than a guessed coverage failure.

Production, workflow, Makefile, coverage runner/report and policy bytes are unchanged. The policy still requires80% complete Rust workspace line coverage, all features, pinned cargo-llvm-cov0.6.21 and no additional exclusions. The actual runner still measures `cargo llvm-cov --workspace --all-features --locked`, rejects failed/incomplete output and enforces the same floor.

Review was source/original-actual-CI evidence only. No local LLVM build/target, test execution, resource/endpoint access, GitHub write or production runtime proof is claimed. Fresh full remote workspace coverage and exact published-head required CI remain mandatory before merge. Root's unbuilt Doctor649 combined work is excluded from this approval.
