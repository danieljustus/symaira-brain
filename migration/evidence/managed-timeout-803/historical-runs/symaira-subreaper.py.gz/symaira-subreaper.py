import ctypes, os, subprocess, sys, time
# Reap this command's adopted orphan children in a container without a reaping init.
assert ctypes.CDLL(None, use_errno=True).prctl(36, 1, 0, 0, 0) == 0
p = subprocess.Popen(sys.argv[1:])
while True:
    pid, status = os.waitpid(-1, os.WNOHANG)
    if pid == p.pid:
        p.returncode = os.waitstatus_to_exitcode(status)
        sys.exit(p.returncode)
    if pid == 0:
        time.sleep(.0001)
