import hashlib,json,pathlib,subprocess,tarfile,io,gzip,os
O=pathlib.Path(__file__).parent; R=pathlib.Path('/workspace/symaira-skills764-byte-contracts'); V=pathlib.Path('/workspace/review-proof/review-pr800-skills764-byte-contracts'); H='36c13305b56a71e9f6ffcef53f0a3bf5cba1a029'
s=lambda b:hashlib.sha256(b).hexdigest(); git=lambda *a:subprocess.check_output(['git',*a],cwd=R)
assert git('rev-parse','HEAD').decode().strip()==H and not git('status','--porcelain')
rows=json.loads((V/'proof-manifest.json').read_bytes()); assert len(rows)==66
sources=json.loads((V/'source-bindings.json').read_bytes())['graph271']; extra={}
T=pathlib.Path('/workspace/symaira-usage768-retry-main935'); TH=subprocess.check_output(['git','rev-parse','HEAD'],cwd=T).decode().strip()
for p in T.glob('rust/symbrain-usage/src/go_*'):
 if p.is_file(): extra[str(p)]=p
 else:
  for q in p.rglob('*'):
   if q.is_file():extra[str(q)]=q
extra[str(T/'migration/licenses/go-strconv-bsd.txt')]=T/'migration/licenses/go-strconv-bsd.txt'
records=[]
with tarfile.open(O/'before-edit.tar.gz','w:gz') as tar:
 for row in rows:
  p=pathlib.Path(row['path']); b=p.read_bytes(); assert len(b)==row['bytes'] and s(b)==row['sha256']; st=p.stat(); name='review/'+p.name; tar.add(p,arcname=name,recursive=False); records.append(dict(row,member=name,mode=st.st_mode,uid=st.st_uid,gid=st.st_gid,mtime_ns=st.st_mtime_ns,atime_ns=st.st_atime_ns))
 for relative,row in sources.items():
  b=git('show',H+':'+relative); assert len(b)==row['bytes'] and s(b)==row['sha256']; p=R/relative; name='source/'+relative
  if p.exists():
   assert p.read_bytes()==b; st=p.stat(); tar.add(p,arcname=name,recursive=False); meta=dict(mode=st.st_mode,uid=st.st_uid,gid=st.st_gid,mtime_ns=st.st_mtime_ns,atime_ns=st.st_atime_ns)
  else:
   info=tarfile.TarInfo(name); info.size=len(b); info.mode=int(git('ls-tree',H,relative).split()[0],8)&0o777; tar.addfile(info,io.BytesIO(b)); meta=dict(git_mode=git('ls-tree',H,relative).split()[0].decode(),native_metadata='not_materialized')
  records.append(dict(path=str(p),member=name,bytes=len(b),sha256=s(b),**meta))
 for _,p in extra.items():
  b=p.read_bytes(); rel=str(p.relative_to(T)); assert b==subprocess.check_output(['git','show',TH+':'+rel],cwd=T); st=p.stat(); name='retry/'+rel;tar.add(p,arcname=name,recursive=False); records.append(dict(path=str(p),member=name,bytes=len(b),sha256=s(b),mode=st.st_mode,uid=st.st_uid,gid=st.st_gid,mtime_ns=st.st_mtime_ns,atime_ns=st.st_atime_ns))
archive=(O/'before-edit.tar.gz').read_bytes()
with tarfile.open(fileobj=io.BytesIO(archive),mode='r:gz') as tar:
 assert len(tar.getmembers())==len(records)
 for row in records: assert s(tar.extractfile(row['member']).read())==row['sha256']
reused=[]
B=R/'migration/evidence/skills-native-764/byte-corrections'
for folder,receipt,count in [('original','retention.json',1919),('checks','boundary-source-retention.json',27)]:
 j=json.loads((B/folder/receipt).read_bytes()); p=B/folder/j['archive']; b=p.read_bytes(); assert s(b)==j.get('archive_sha256',j.get('sha256')); rr=j.get('members',j.get('files'))
 with tarfile.open(fileobj=io.BytesIO(b),mode='r:gz') as tar:
  assert len(tar.getmembers())==len(rr)==count
  for row in rr:
   d=tar.extractfile(row['member']).read(); assert len(d)==row['bytes'] and s(d)==row['sha256']
 reused.append(dict(path=str(p),bytes=len(b),sha256=s(b),members=count,full_roundtrip=True,receipt_sha256=s((B/folder/receipt).read_bytes())))
(O/'before-edit.json').write_text(json.dumps(dict(original_head=H,review_records=66,source_records=len(sources),retry_head=TH,retry_records=len(extra),archive_sha256=s(archive),archive_bytes=len(archive),decompressed_sha256=s(gzip.decompress(archive)),members=records,reused_archives=reused,runtime_product_compiler=0),indent=2)+'\n')
print(json.dumps(dict(review=66,sources=len(sources),retry=len(extra),archive_bytes=len(archive),reused=[r['members'] for r in reused])))
