# Prepared runtime driver — DO NOT execute without Root allocation

Current candidate/source: 114f63fb0d5b1b4b9ea97b03d2ca5d2a7f630f27.
No target, compiler, SDK executable, port or product execution is allocated.
Every count below is prepared only. Root must assign one existing target and
owned output/TMPDIR/cache directories, pinned Go1.26.7 and both filesystem
budget floors (700MiB), with jobs2/debug0/incremental0 and subreaper lifecycle.
Preserve original actual ELF/native metadata and every failed run before any
source correction or package-clean. Never reuse operator HOME/credentials.

1. Locked full affected all-target/all-feature graph: Core/MCP/Gateway/Skills/
   CLI/Audit; run required proper-fixture owners, not ignored-entrypoint success.
   Strict Clippy with all original diagnostics enabled; fmt/actionlint. Run the
   original preflight315, full raw/native Windows312+controls, render-drift12
   and every inherited unchanged gate with pinned source/executable bindings.
2. Use the unchanged main's `scripts/skills-argv-oracle/build_go.py` on the full
   frozen dcddcef0 archive with owned HOME/SDK caches and truthful receipt.
   Build the actual native CLI and git_stream_fixture example in that one
   allocated target. Core's new81-record SDK fixture tests must execute.
3. Use the unchanged options of `scripts/skills-native-oracle/run.py` with exact
   actual Go/native/Git/Git-fixture binaries and a fresh external output path.
   Full prepared926 Unix or884 Windows pairs and all7 actual input controls
   must pass. Old826/784 and earlier638/614/567 comparisons remain unchanged.
4. Verify complete stdout/stderr/exit/protocol error ID/message/read-only state
   and raw input/report/executable/source/native metadata. Deep metadata9,000
   and exact Go10,000 composite boundaries must reach/reject the correct owner;
   no serde128 fallback or arbitrary smaller exemption. Require first duplicate
   float/type ordering, both transports, signed/negative-zero/underflow/overflow,
   exact long-token Go/native constructor/report comparisons and real controls.
5. Preserve every sample, original failed attempt, complete logs and outputs.
   Native Linux/macOS/Windows actual CI and different-author full review remain
   separate publication gates. No whole #764 closure follows this source plan.
