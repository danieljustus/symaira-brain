import pathlib,re,json
p=pathlib.Path('/workspace/symaira-skills764-json-corrections/rust/symbrain-mcp/src/raw_skills_boundary_tests.rs');s=p.read_text();m=re.search(r'format!\(r#"(.*?)"#\)',s);raw=m[1].format(arguments='{}',extra='');print(json.loads(raw)['params']);print(raw)
