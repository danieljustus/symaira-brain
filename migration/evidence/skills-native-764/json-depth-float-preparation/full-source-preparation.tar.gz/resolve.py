import subprocess,pathlib,tarfile,io,json,hashlib
O=pathlib.Path(__file__).parent;R=pathlib.Path('/workspace/symaira-skills764-json-corrections');G=lambda *a:subprocess.check_output(['git',*a],cwd=R);s=lambda b:hashlib.sha256(b).hexdigest();records=[]
with tarfile.open(O/'merge-and-first-blob-originals.tar.gz','w:gz') as tar:
 def save(name,b,**extra):
  info=tarfile.TarInfo(name);info.size=len(b);info.mode=0o644;tar.addfile(info,io.BytesIO(b));records.append(dict(member=name,bytes=len(b),sha256=s(b),**extra))
 for rel in ['.github/workflows/ci.yml','MIGRATION-RUST.md','migration/contract-matrix.csv']:
  for stage in [1,2,3]:save('stages/'+str(stage)+'/'+rel,G('show',f':{stage}:{rel}'),stage=stage,git_index=G('ls-files','--stage',rel).decode())
  p=R/rel;st=p.stat();save('working-conflict/'+rel,p.read_bytes(),mode=st.st_mode,uid=st.st_uid,gid=st.st_gid,mtime_ns=st.st_mtime_ns)
 for p in (R/'scripts/skills-native-oracle/json-review-inputs').iterdir():
  rel=str(p.relative_to(R));b=p.read_bytes();st=p.stat();save('b617-git/'+p.name,G('show','b617558bea545829061c559aa55cf1bbc7ae3a9e:'+rel));save('exact-physical/'+p.name,b,mode=st.st_mode,uid=st.st_uid,gid=st.st_gid,mtime_ns=st.st_mtime_ns)
 save('original-attributes',G('show','HEAD:.gitattributes'))
archive=(O/'merge-and-first-blob-originals.tar.gz').read_bytes()
with tarfile.open(fileobj=io.BytesIO(archive),mode='r:gz') as tar:
 for row in records:assert s(tar.extractfile(row['member']).read())==row['sha256']
(O/'merge-and-first-blob-originals.json').write_text(json.dumps(dict(first_source='b617558bea545829061c559aa55cf1bbc7ae3a9e',actual_runtime=0,framed_provenance_failure='thirteen CRLF Git blobs normalized by text=auto; original physical bodies unchanged; retained before scoped -text fix',archive_sha256=s(archive),members=records),indent=2)+'\n')
ours=G('show',':2:.github/workflows/ci.yml');addition=b'      - name: Fetch the immutable native Skills comparison parent\n        shell: bash\n        run: git fetch --no-tags origin 01f41906e2e021db3c693ec97617bb701e4dad8a\n\n';assert addition in G('show',':3:.github/workflows/ci.yml');key=b'      - name: Frozen Go and native Windows wide Skills argv acceptance\n';assert ours.count(key)==1;(R/'.github/workflows/ci.yml').write_bytes(ours.replace(key,addition+key))
ours=G('show',':2:MIGRATION-RUST.md');theirs=G('show',':3:MIGRATION-RUST.md');start=theirs.index(b'For #621,');end=theirs.index(b'### Skills sync Windows',start);(R/'MIGRATION-RUST.md').write_bytes(ours+b'\n'+theirs[start:end])
(R/'migration/contract-matrix.csv').write_bytes(G('show',':2:migration/contract-matrix.csv'))
with (R/'.gitattributes').open('a') as out:out.write('\n# F7/F8/F9 independent exact protocol inputs retain literal CRLF/native bytes.\nscripts/skills-native-oracle/json-review-inputs/** -text\n')
# Physical originals are still exact; add after the scoped attribute is in place.
for row in json.loads((O/'reviewer-inputs.json').read_text()):
 p=R/'scripts/skills-native-oracle/json-review-inputs'/pathlib.Path(row['path']).name;assert s(p.read_bytes())==row['sha256']
print(json.dumps(dict(conflicts=3,retained=len(records),archive_bytes=len(archive),CI_exact_ours_plus_four_lines=True)))
