"""Immutable full-source/mode/criterion binding; zero compiler/SDK/product calls."""
import pathlib,subprocess,json,hashlib,tarfile,io,gzip,os,tomllib,ast,re
O=pathlib.Path(__file__).parent;R=pathlib.Path('/workspace/symaira-skills764-json-corrections');P=pathlib.Path('/workspace/symaira-skills764-byte-contracts');OLD='36c13305b56a71e9f6ffcef53f0a3bf5cba1a029';H='6cb8b11204e27a923807f24ab6f7472c980058ea';G=lambda *a:subprocess.check_output(['git',*a],cwd=R);s=lambda b:hashlib.sha256(b).hexdigest()
assert G('rev-parse','HEAD').decode().strip()==H and not G('status','--porcelain')
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=P).decode().strip()==OLD and not subprocess.check_output(['git','status','--porcelain'],cwd=P)
for rev in [OLD,'9353520a34c5819c7d0a6cd58d3bfaa2b22b045b','cc3f4e62dcb133b616c6b58c135463ad81058801','e00365333a041118dd0598157137e0ba3586013d']:
 subprocess.run(['git','merge-base','--is-ancestor',rev,H],cwd=R,check=True)
source={};native={}
for entry in G('ls-tree','-rz',H).split(b'\0'):
 if not entry:continue
 meta,name=entry.split(b'\t');mode,kind,oid=meta.split();rel=os.fsdecode(name);b=G('cat-file','blob',oid.decode());source[rel]=dict(git_mode=mode.decode(),git_blob=oid.decode(),bytes=len(b),sha256=s(b));p=R/rel
 if p.is_file():
  st=p.stat();assert p.read_bytes()==b;assert bool(st.st_mode&0o111)==(mode==b'100755');native[rel]=dict(mode=st.st_mode,uid=st.st_uid,gid=st.st_gid,mtime_ns=st.st_mtime_ns,atime_ns=st.st_atime_ns,bytes=len(b),sha256=s(b))
old=json.loads((O/'whole-original-git-source.json').read_text())['files'];protected=[]
for rel,row in old.items():
 if rel.startswith(('rust/symbrain-usage/','rust/symbrain-skills/','rust/symbrain-cli/','rust/symbrain-gateway/')) or rel.endswith('.go') or rel in ['go.mod','go.sum']:
  assert source[rel]['sha256']==row['sha256'] and source[rel]['git_mode']==row['git_mode'];protected.append(rel)
# Original six correction owners are retained exactly; only the scoped MCP
# validation seams and additive Core implementation change production Rust.
rustdelta=G('diff','--name-only',OLD,H,'--','rust').decode().splitlines();allowed={'rust/symbrain-core/src/lib.rs','rust/symbrain-mcp/Cargo.toml','rust/symbrain-mcp/src/raw_skills.rs','rust/symbrain-mcp/src/raw_skills_tests.rs'}
for rel in rustdelta:assert rel in allowed or rel.startswith('rust/symbrain-core/src/go_json_float') or rel in ['rust/symbrain-core/tests/fixtures/go_json_float_sdk_linux_amd64.json','rust/symbrain-mcp/src/raw_skills_syntax.rs','rust/symbrain-mcp/src/raw_skills_boundary_tests.rs']
review=json.loads((O/'reviewer-inputs.json').read_bytes())
for row in review:
 rel='scripts/skills-native-oracle/json-review-inputs/'+pathlib.Path(row['path']).name;assert source[rel]['sha256']==row['sha256'] and source[rel]['bytes']==row['bytes'];assert (R/rel).read_bytes()==G('show',H+':'+rel)
# Common CI exactly preserves source's original workflow plus four literal lines.
addition=b'      - name: Fetch the immutable native Skills comparison parent\n        shell: bash\n        run: git fetch --no-tags origin 01f41906e2e021db3c693ec97617bb701e4dad8a\n\n';ci=(R/'.github/workflows/ci.yml').read_bytes();assert ci.count(addition)==1 and ci.replace(addition,b'')==G('show',OLD+':.github/workflows/ci.yml');assert (R/'.github/workflows/skills-native.yml').read_bytes()==G('show',OLD+':.github/workflows/skills-native.yml')
# Every previous package entry remains exact except new MCP->Core direct edge.
lock=tomllib.loads((R/'Cargo.lock').read_text());oldlock=tomllib.loads(G('show',OLD+':Cargo.lock').decode());lp={ (p['name'],p['version']):p for p in lock['package']};op={ (p['name'],p['version']):p for p in oldlock['package']};assert lp.keys()==op.keys()
for key,v in op.items():
 expected=dict(v)
 if key[0]=='symbrain-mcp':expected['dependencies']=[*expected['dependencies'],'symbrain-core']
 assert lp[key]==expected
workspace=tomllib.loads((R/'Cargo.toml').read_text());edges={}
for folder in workspace['workspace']['members']:
 p=R/folder/'Cargo.toml';d=tomllib.loads(p.read_text());edges[d['package']['name']]=[x for x in d.get('dependencies',{}) if x.startswith('symbrain-')]
def visit(name,path):
 assert name not in path, path+[name]
 for dep in edges.get(name,[]):visit(dep,path+[name])
for name in edges:visit(name,[])
# Rebind every before-edit member and reused historical archive, without copying old payloads.
pres=json.loads((O/'before-edit.json').read_text());compressed=(O/'before-edit.tar.gz').read_bytes();assert s(compressed)==pres['archive_sha256']
with tarfile.open(fileobj=io.BytesIO(compressed),mode='r:gz') as tar:
 for row in pres['members']:assert s(tar.extractfile(row['member']).read())==row['sha256']
for row in pres['reused_archives']:
 b=pathlib.Path(row['path']).read_bytes();assert s(b)==row['sha256']; assert len(tarfile.open(fileobj=io.BytesIO(b),mode='r:gz').getmembers())==row['members']
# Historical Root SDK ELF remains lossless and source-bound, never executed here.
sdk=json.loads(pathlib.Path('/workspace/review-proof/review-pr800-skills764-byte-contracts/retained-sdk-exp-archive-receipt.json').read_bytes());compressed=pathlib.Path(sdk['archive']).read_bytes();assert s(compressed)==sdk['archive_sha256'] and s(gzip.decompress(compressed))==sdk['probe_elf_sha256']
physical=sum(p.stat().st_size for p in R.rglob('*') if p.is_file());assert physical<20*1024*1024
modes={rel:dict(original=old.get(rel),current=source.get(rel)) for rel in G('diff','--name-only',OLD,H).decode().splitlines()};(O/'full-current-source.json').write_text(json.dumps(dict(source=H,files=source,native=native,changed=modes,workspace_dependency_edges=edges),indent=2)+'\n')
summary=dict(kind='COMPLETE_SOURCE_BINDING_NOT_COMPILED_ACCEPTANCE',source=H,original=OLD,full_git_files=len(source),materialized_native_files=len(native),physical_file_bytes=physical,protected_Usage_Skills_CLI_Gateway_and_Go=len(protected),changed_Rust_files=rustdelta,exact_reviewer_raw_files=len(review),exact_original_CI_plus_four_fetch_lines=True,Cargo_package_entries=len(lp),only_dependency_change='MCP direct existing Core edge',acyclic=True,historical_Root_SDK_ELF_full_roundtrip=True,prepared_native_Unix=926,prepared_native_Windows=884,prepared_actual_input_controls=7,current_runtime_compiler_SDK_product_SQLite_Target_ports=0)
(O/'final-verification.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary))
