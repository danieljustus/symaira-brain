import pathlib,hashlib,json
O=pathlib.Path(__file__).parent; R=pathlib.Path('/workspace/review-proof/review-pr800-skills764-byte-contracts'); D=pathlib.Path('/workspace/symaira-skills764-json-corrections/scripts/skills-native-oracle/json-review-inputs');D.mkdir(parents=True)
records=json.loads((R/'pure-plans.json').read_bytes())['novel_prepared_inputs'];assert len(records)==26
for row in records:
 p=pathlib.Path(row['path']);b=p.read_bytes();assert hashlib.sha256(b).hexdigest()==row['sha256'];q=D/p.name;q.write_bytes(b)
(O/'reviewer-inputs.json').write_text(json.dumps(records,indent=2)+'\n')
