"""Source/pure preparation only: no SDK, compiler, fixture or product calls."""
import ast,hashlib,json,os,pathlib,subprocess,sys,tarfile,io,gzip,re
sys.dont_write_bytecode=True
O=pathlib.Path(__file__).parent;R=pathlib.Path('/workspace/symaira-skills764-json-corrections');H='36c13305b56a71e9f6ffcef53f0a3bf5cba1a029';V=pathlib.Path('/workspace/review-proof/review-pr800-skills764-byte-contracts')
s=lambda b:hashlib.sha256(b).hexdigest();git=lambda *a:subprocess.check_output(['git',*a],cwd=R)
sys.path.insert(0,str(R/'scripts/skills-native-oracle'));import run,json_cases,json_compare,byte_cases
all_sources={}
for record in git('ls-tree','-rz',H).split(b'\0'):
 if not record:continue
 meta,name=record.split(b'\t');mode,kind,oid=meta.split();rel=os.fsdecode(name);b=git('cat-file','blob',oid.decode());all_sources[rel]=dict(git_mode=mode.decode(),git_blob=oid.decode(),bytes=len(b),sha256=s(b))
(O/'whole-original-git-source.json').write_text(json.dumps(dict(head=H,files=all_sources),indent=2)+'\n')
old=git('show',H+':scripts/skills-native-oracle/run.py');new=(R/'scripts/skills-native-oracle/run.py').read_bytes()
def cases(raw,env):
 main=next(n for n in ast.parse(raw).body if isinstance(n,ast.FunctionDef) and n.name=='main'); assignments=[]
 for node in ast.walk(main):
  if isinstance(node,(ast.Assign,ast.AugAssign)):
   ts=node.targets if isinstance(node,ast.Assign) else [node.target]
   if len(ts)==1 and isinstance(ts[0],ast.Name) and ts[0].id=='cases':assignments.append(node)
 exec(compile(ast.Module(body=sorted(assignments,key=lambda n:n.lineno),type_ignores=[]),'<case-only-source-projection>','exec'),env);return env['cases']
import types, cases as case_module, output_cases, library_denied
modules=[run,case_module,byte_cases,output_cases,library_denied]
plans={};saved=[m.os for m in modules]
try:
 for platform in ['posix','nt']:
  proxy=types.SimpleNamespace(**{k:getattr(os,k) for k in dir(os) if not k.startswith('__')});proxy.name=platform
  for module in modules:module.os=proxy
  env=vars(run).copy();env['root']=pathlib.Path('/owned');a=cases(old,env.copy());b=cases(new,env.copy());assert b[:len(a)]==a
  totals=(len(a)+len(run.denied_ids())+len(run.output_ids()),len(b)+len(run.denied_ids())+len(run.output_ids()));assert totals==(826,926) if platform=='posix' else totals==(784,884)
  assert len(b)==len({x[0] for x in b});plans[platform]=dict(original_total=totals[0],prepared_total=totals[1],old_prefix_exact=True,added_json_inputs=100,ids=[r[0] for r in b])
finally:
 for module,original_os in zip(modules,saved):module.os=original_os
for name in ['cases.py','fixtures.py','compare.py','output_cases.py','library_denied.py','byte_cases.py']:
 assert (R/'scripts/skills-native-oracle'/name).read_bytes()==git('show',H+':scripts/skills-native-oracle/'+name)
for name in ['sha','terminate','invoke','incoming','actual_control']:
 select=lambda raw:next(n for n in ast.parse(raw).body if isinstance(n,ast.FunctionDef) and n.name==name)
 assert ast.dump(select(old),include_attributes=False)==ast.dump(select(new),include_attributes=False)
exact=[]
rows=json_cases.cases(pathlib.Path('/owned'),run.incoming)
for record in json.loads((V/'pure-plans.json').read_bytes())['novel_prepared_inputs']:
 p=pathlib.Path(record['path']);raw=p.read_bytes();assert len(raw)==record['bytes'] and s(raw)==record['sha256'];assert any(data.endswith(raw) for _,_,data,_ in rows);exact.append(record)
# Strict parse comparator negative control with labeled SYNTHETIC records only.
base={'exit':0,'stderr_hex':'','filesystem':{'files':{}}}
responses=[{'jsonrpc':'2.0','id':1,'result':{}},{'jsonrpc':'2.0','id':2,'result':{'tools':[]}},{'jsonrpc':'2.0','id':None,'error':{'code':-32700,'message':"Parse error: invalid character '[' exceeded max depth"}}]
names=re.findall(r'    "(skills_[a-z_]+)",',(R/'rust/symbrain-mcp/src/raw_skills.rs').read_text());assert len(names)==11;responses[1]['result']['tools']=[{'name':n} for n in names]
def rec(r):return dict(base,stdout_hex=b'\n'.join(json.dumps(x).encode() for x in r).hex())
assert json_compare.parse_view(rec(responses));negative=[]
for kind in ['id','code','missing','duplicate','result','catalog']:
 m=json.loads(json.dumps(responses))
 if kind=='id':m[2]['id']=3
 if kind=='code':m[2]['error']['code']=-32602
 if kind=='missing':m=m[:2]
 if kind=='duplicate':m.append(m[2])
 if kind=='result':m[2]['result']={}
 if kind=='catalog':m[1]['result']['tools']=[]
 try:json_compare.parse_view(rec(m))
 except (AssertionError,KeyError,IndexError):negative.append(kind)
 else:raise AssertionError('synthetic comparator mutant admitted '+kind)
# Exact six algorithm bodies, with documented local lint/documentation-only edits.
T=pathlib.Path('/workspace/symaira-usage768-retry-main935');adapt=json.loads((O/'float-adaptation.json').read_bytes())
for row in adapt:
 p=pathlib.Path(row['candidate']);b=p.read_bytes();original=pathlib.Path(row['original']).read_bytes();expected=original
 if p.name=='go_float.rs':expected=expected.replace(b'//! Go1.26.7 ParseFloat',b'//! Go1.26.7 `ParseFloat`').replace(b'fn hex_float(number: Number)',b'// Preserve the reviewed SDK transcription\'s local numeric working copy.\n#[allow(clippy::needless_pass_by_value)]\nfn hex_float(number: Number)')
 if p.name=='go_decimal.rs':expected=expected.replace(b'    fn rounded_integer',b'    // Preserve the pinned SDK\'s exact half-even parity expression.\n    #[allow(clippy::manual_is_multiple_of)]\n    fn rounded_integer')
 if p.name=='go_decimal_fast.rs':expected=expected.replace(b'pub(super) fn eisel',b'// Literal SDK masks keep the fallback decision auditable against atofeisel.go.\n#[allow(clippy::verbose_bit_mask)]\npub(super) fn eisel')
 assert b==expected;row.update(candidate_sha256=s(b),adaptation='only exact listed local lint attributes/comments and ParseFloat doc backticks' if b!=original else 'none')
(O/'float-adaptation-final.json').write_text(json.dumps(adapt,indent=2)+'\n')
# Current Usage owners, all Go, and frozen fixtures remain byte-identical.
unchanged=[]
for rel,row in all_sources.items():
 if rel.startswith('rust/symbrain-usage/') or rel.endswith('.go') or rel in ['go.mod','go.sum']:
  p=R/rel;b=p.read_bytes() if p.exists() else git('show',H+':'+rel);assert s(b)==row['sha256'];unchanged.append(rel)
checks=[]
changed=git('diff','--name-only').decode().splitlines()+git('ls-files','--others','--exclude-standard').decode().splitlines()
for rel in changed:
 p=R/rel
 if p.suffix=='.rs':
  assert len(p.read_text().splitlines())<400;r=subprocess.run(['/home/agent/.cargo/bin/rustfmt','--edition','2024','--check',str(p)],cwd=R,capture_output=True);checks.append(dict(path=rel,exit=r.returncode,stdout_sha256=s(r.stdout),stderr_sha256=s(r.stderr)));assert r.returncode==0
for p in (R/'scripts/skills-native-oracle').glob('*.py'):ast.parse(p.read_bytes())
for name,argv in [('actionlint',['/workspace/toolchains/bin/actionlint','.github/workflows/ci.yml','.github/workflows/skills-native.yml']),('diff',['git','diff','--check'])]:
 r=subprocess.run(argv,cwd=R,capture_output=True);(O/(name+'.stdout')).write_bytes(r.stdout);(O/(name+'.stderr')).write_bytes(r.stderr);assert r.returncode==0
# Acyclic new direct edge: Core does not depend on MCP, Gateway, Skills or Usage.
core=(R/'rust/symbrain-core/Cargo.toml').read_text();assert not any(x in core for x in ['symbrain-mcp','symbrain-gateway','symbrain-skills','symbrain-usage']);assert 'symbrain-core.workspace = true' in (R/'rust/symbrain-mcp/Cargo.toml').read_text()
result=dict(kind='PURE_SOURCE_PREPARATION_NOT_RUNTIME',old_head=H,whole_original_git_files=len(all_sources),plans=plans,reviewer26_exact=exact,synthetic_comparator_controls=negative,unchanged_usage_and_go_files=len(unchanged),direct_rustfmt_checks=checks,Python_AST_files=len(list((R/'scripts/skills-native-oracle').glob('*.py'))),real_child_control_plans=7,product_SDK_compiler_SQLite_target_ports=0)
(O/'checks.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(dict(plans={p:{k:v for k,v in d.items() if k!='ids'} for p,d in plans.items()},sources=len(all_sources),reviewer_wires=len(exact),rustfmt=len(checks),synthetic_mutants=len(negative))))
