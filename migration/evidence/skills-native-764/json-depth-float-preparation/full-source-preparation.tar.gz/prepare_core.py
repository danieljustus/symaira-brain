import pathlib,hashlib,json,subprocess,tarfile,io
O=pathlib.Path(__file__).parent; R=pathlib.Path('/workspace/symaira-usage768-retry-main935'); D=pathlib.Path('/workspace/symaira-skills764-json-corrections'); H=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R).decode().strip(); rows=[]
extra=['rust/symbrain-usage/src/retry_after.rs','rust/symbrain-usage/src/retry_after_oracle_tests.rs','rust/symbrain-usage/tests/fixtures/retry_decimal_sdk_linux_amd64.json','rust/symbrain-usage/src/lib.rs','rust/symbrain-usage/Cargo.toml']
with tarfile.open(O/'retry-policy-before-copy.tar.gz','w:gz') as tar:
 for rel in extra:
  p=R/rel;b=p.read_bytes();assert b==subprocess.check_output(['git','show',H+':'+rel],cwd=R);st=p.stat();tar.add(p,arcname=rel);rows.append(dict(path=str(p),member=rel,bytes=len(b),sha256=hashlib.sha256(b).hexdigest(),mode=st.st_mode,mtime_ns=st.st_mtime_ns,uid=st.st_uid,gid=st.st_gid))
with tarfile.open(O/'retry-policy-before-copy.tar.gz') as tar:
 for row in rows:assert hashlib.sha256(tar.extractfile(row['member']).read()).hexdigest()==row['sha256']
(O/'retry-policy-before-copy.json').write_text(json.dumps(dict(head=H,members=rows,archive_sha256=hashlib.sha256((O/'retry-policy-before-copy.tar.gz').read_bytes()).hexdigest()),indent=2)+'\n')
files=['go_float.rs','go_decimal.rs','go_decimal_shift.rs','go_decimal_fast.rs','go_decimal_fast/powers_negative.rs','go_decimal_fast/powers_positive.rs']; adaptation=[]
for name in files:
 original=(R/'rust/symbrain-usage/src'/name).read_bytes();p=D/'rust/symbrain-core/src/go_json_float'/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(original);adaptation.append(dict(original=str(R/'rust/symbrain-usage/src'/name),candidate=str(p),original_sha256=hashlib.sha256(original).hexdigest(),mechanical_change='none; relocated into private Core child module'))
license=R/'migration/licenses/go-strconv-bsd.txt';p=D/'migration/licenses/go-strconv-bsd.txt';p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(license.read_bytes())
(O/'float-adaptation.json').write_text(json.dumps(adaptation,indent=2)+'\n')
