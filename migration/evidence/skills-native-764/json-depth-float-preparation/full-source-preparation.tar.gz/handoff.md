# Skills764 F7/F8/F9 immutable SOURCE preparation handoff

Bounded author successor at `/workspace/symaira-skills764-json-corrections`,
branch `issue/764-json-depth-float-corrections`. Clean tested-by-pure-checks
source is `114f63fb0d5b1b4b9ea97b03d2ca5d2a7f630f27`. All current product,
compiler/Cargo/SDK executable/provider/SQLite/target/port/native runs are zero.
This handoff requests different-author full source review, not approval by the
implementer, compiled acceptance, publication or #764 closure.

Original clean `36c13305b56a71e9f6ffcef53f0a3bf5cba1a029` and all earlier
checkpoints remain untouched. Full original800 review SHA
`3d8735e6542752f7d7bbc2460628a691cb7d7c6e7a7f08cb9bf1adf73b561412` and receipt
`7872dcbd9b1d1a5021f51748ba34f91f1e26a7aab1199e88481150630d3c1e23`
were read and retained before edits with all66 bound artifacts,271 affected
sources/Git/native modes and exact Retry conversion/tests/fixture/policy files.
Existing1919-original and SDK27 archives are reused with full roundtrip hashes,
without another copy of their payloads. The original six corrections, all
Usage/Skills-library/CLI/Gateway owners and frozen Go remain byte-identical.

F7 adds full string-aware iterative syntax admission with Go depth10000 before
typed dispatch, including ignored envelope/args/meta and nil parse-error ID.
F8 walks original numeric spans iteratively without recursive subtree copying,
preserving duplicate/order/first float error. F9 adds one finite-JSON Core API
using the six exact reviewed Retry algorithm files/tables, with only three
narrow local lint allowances/comments and documentation backticks. Signed and
negative-zero/underflow/overflow cases are preserved. Current Usage is unchanged;
shared implementation relocation is a separate future review. Historical actual
Go SDK0.1 and SDK81/ELF results remain historical, not current native outcomes.

Prepared926Unix/884Windows plans append100 full inputs: all26 exact reviewer
wires plus depth/envelope/meta/signed/float/grammar/order boundaries. Old826/784,
638/614 and567 record prefixes remain. `compare.py`, fixtures, originalbytecases
and invocation/termination/incoming routines are unchanged. Only new explicitly
listed syntax cases use `json_compare.py`, which requires[1,2,null], -32700,
full error/status/stderr/state. Six SYNTHETIC comparator mutants are rejected;
these are not actual process controls. Five old real-input controls remain and
two new depth/overflow controls are prepared. Core SDK81 plus two domain tests,
four transport/metadata boundary Rust tests are prepared and unexecuted.

Full final source verification binds3116Gitfiles/663 materialized native files,
1513 exact protected owners and273 unchanged Cargo package entries (only direct
MCP→existingCore edge added; acyclic). All26 physical raw files equal both Git
and original review bytes. Initial physical source7,838,621B is below20MiB.
Pure checks pass13 formatted changed/new Rust files (<400 each),9 Python ASTs,
exact generator prefixes, complete archives/source/Git/modes, actionlint and
diff checks. No success is inferred for Rust tests or actual CLI/provider runs.

Normal merge8f78fabe retains main935 and cc3/e003 history. CommonCI is exactly
previous36c plus four immutable-parent fetch lines with no `--depth`, all render
and Activity/main gates retained. Native Skills workflow adds only Core to
existing strict/test package invocations so its converter tests are scheduled.
Original missing-parent and rejected-depth attempt archives remain inherited.

All author failures are retained: original full Retry CI four-lint failure;
Python3.12 platform/template helper mistakes; rejected redundant patch context;
first source b617 framed Git CRLF normalization; incomplete cached re-add at
6cb. Final scoped binary attributes follow existing fuzz corpus policy, and
scoped renormalize forces exact framed Git bytes. No original request/assertion
was altered to fix provenance. The full merge conflicts/stages and before/after
raw bytes, native metadata and Git heads are preserved.

ADR: `docs/adr/skills-native-json-depth-float-764.md`. Complete source maps,
mechanical converter adaptation, failed/successful pure logs, archive/native
receipts and future runtime plan are in this proof directory and the tracked
lossless preparation archive. Root/800 must independently review full owners
and then obtain a separate runtime allocation. Generic/non-Skills ID/Value
codecs, remaining config/wholemigration/3native gates stay open. No target lease
was used or changed; Brain's existing HOLD remains untouched.
