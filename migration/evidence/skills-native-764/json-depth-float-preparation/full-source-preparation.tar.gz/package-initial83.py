import pathlib,tarfile,hashlib,json,gzip,io,subprocess
O=pathlib.Path(__file__).parent;R=pathlib.Path('/workspace/symaira-skills764-json-corrections');H='114f63fb0d5b1b4b9ea97b03d2ca5d2a7f630f27';s=lambda b:hashlib.sha256(b).hexdigest();assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=R).decode().strip()==H and not subprocess.check_output(['git','status','--porcelain'],cwd=R)
rows=[]; dest=R/'migration/evidence/skills-native-764/json-depth-float-preparation';dest.mkdir(parents=True)
archive=dest/'full-source-preparation.tar.gz'
with tarfile.open(archive,'w:gz') as tar:
 for p in sorted(O.iterdir()):
  if not p.is_file() or p.name in ['handoff.json','archive-retention.json']:continue
  b=p.read_bytes();st=p.stat();tar.add(p,arcname=p.name,recursive=False);rows.append(dict(original=str(p),member=p.name,bytes=len(b),sha256=s(b),mode=st.st_mode,uid=st.st_uid,gid=st.st_gid,mtime_ns=st.st_mtime_ns,atime_ns=st.st_atime_ns))
b=archive.read_bytes()
with tarfile.open(fileobj=io.BytesIO(b),mode='r:gz') as tar:
 assert len(tar.getmembers())==len(rows)
 for row in rows:assert s(tar.extractfile(row['member']).read())==row['sha256']
ret=dict(source=H,archive=str(archive.relative_to(R)),archive_bytes=len(b),archive_sha256=s(b),payload_sha256=s(gzip.decompress(b)),full_roundtrip=True,members=rows,reused_prior_archives=json.loads((O/'before-edit.json').read_text())['reused_archives'],scope='Immutable source/pure only; no SDK/compiler/product runtime')
(dest/'retention.json').write_text(json.dumps(ret,indent=2)+'\n');(O/'archive-retention.json').write_text(json.dumps(ret,indent=2)+'\n')
checks=json.loads((O/'checks.json').read_text());final=json.loads((O/'final-verification.json').read_text());j=dict(kind='CLEAN_IMMUTABLE_SOURCE_PREPARATION_FOR_DIFFERENT_AUTHOR_REVIEW',source=H,publication_head='evidence-only commit follows',worktree=str(R),branch='issue/764-json-depth-float-corrections',original='36c13305b56a71e9f6ffcef53f0a3bf5cba1a029',full_verification=final,pure_checks=dict(platforms={k:{x:y for x,y in v.items() if x!='ids'} for k,v in checks['plans'].items()},Python_AST_files=checks['Python_AST_files'],formatted_changed_new_Rust_files=len(checks['direct_rustfmt_checks']),strict_synthetic_comparator_controls=checks['synthetic_comparator_controls']),retention=ret,all_proof_paths=rows,current_runtime_compiler_SDK_product_SQLite_Target_ports=0,target_and_Brain_HOLD='No target or port lease was used or changed; Brain HOLD untouched',actual_Go_long_token='Historical Root SDK0.1 only; current candidate Rust uncompiled',required_next='800 full different-author source review, then separate Root runtime allocation/full original+additive native3 gates')
(O/'handoff.json').write_text(json.dumps(j,indent=2)+'\n');print(json.dumps(dict(source=H,archive_bytes=len(b),proof_members=len(rows),archive_sha256=s(b),handoff_md_sha256=s((O/'handoff.md').read_bytes()),handoff_json_sha256=s((O/'handoff.json').read_bytes()))))
