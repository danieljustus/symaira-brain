//! Native `symbrain sync` CLI implementation.

use std::ffi::OsString;
use std::fs;
use std::io::Write;
use std::path::{Path, PathBuf};

use serde::Serialize;
use symbrain_adapter::{target_for_harness, write_atomic};
use symbrain_core::exit;
use symbrain_core::output::OutputFormat;
use symbrain_harness::{all, lookup};
use symbrain_instructions::Source;

/// Outcome of syncing one instruction target.
#[derive(Debug, Clone, PartialEq, Eq, Serialize)]
pub struct TargetStatus {
    /// Harness name.
    pub name: String,
    /// Absolute or relative path to the synced instruction file.
    pub path: String,
    /// Status: created, updated, unchanged, dry-run, skipped, error.
    pub status: String,
    /// Optional diagnostic or explanation.
    #[serde(skip_serializing_if = "Option::is_none")]
    pub message: Option<String>,
}

/// Outcome of syncing skills for one harness target.
#[derive(Debug, Clone, PartialEq, Eq, Serialize)]
pub struct SkillResult {
    /// Harness target name.
    pub target: String,
    /// Status: ok, skipped, error.
    pub status: String,
    /// Optional summary message.
    #[serde(skip_serializing_if = "Option::is_none")]
    pub message: Option<String>,
}

/// JSON payload returned by `symbrain sync`.
#[derive(Debug, Clone, PartialEq, Eq, Serialize)]
pub struct SyncSummary {
    /// Instruction target statuses.
    pub targets: Vec<TargetStatus>,
    /// Skills sync results per harness.
    pub skills: Vec<SkillResult>,
}

struct ParsedSyncArgs {
    project_dir: PathBuf,
    dry_run: bool,
    harnesses: Vec<String>,
}

/// The shipped `sync` flag set as the Go flag package prints it.
const SYNC_FLAGS_USAGE: &str = "Usage of sync:\n  -dry-run\n    \tshow what would be written without making changes\n  -project string\n    \tproject directory (default: current directory)\n";

/// Native sync covers every argument shape, including Go's flag terminator.
pub(crate) fn requires_go_fallback(_args: &[OsString]) -> bool {
    false
}

fn parse_args(args: &[OsString], stderr: &mut dyn Write) -> Result<ParsedSyncArgs, u8> {
    let mut project_dir = PathBuf::from(".");
    let mut dry_run = false;
    let mut harnesses = Vec::new();

    let mut i = 0;
    while i < args.len() {
        let arg = args[i].to_string_lossy();
        if arg == "--" {
            harnesses.extend(
                args[i + 1..]
                    .iter()
                    .map(|arg| arg.to_string_lossy().into_owned()),
            );
            break;
        } else if arg == "-dry-run" || arg == "--dry-run" {
            dry_run = true;
            i += 1;
        } else if let Some(value) = arg
            .strip_prefix("-dry-run=")
            .or_else(|| arg.strip_prefix("--dry-run="))
        {
            dry_run = match value {
                "1" | "t" | "T" | "TRUE" | "true" | "True" => true,
                "0" | "f" | "F" | "FALSE" | "false" | "False" => false,
                _ => {
                    let _ = writeln!(
                        stderr,
                        "invalid boolean value {value:?} for -dry-run: parse error"
                    );
                    let _ = write!(stderr, "{SYNC_FLAGS_USAGE}");
                    return Err(exit::USAGE);
                }
            };
            i += 1;
        } else if arg == "-project" || arg == "--project" {
            if i + 1 >= args.len() {
                let _ = writeln!(stderr, "symbrain sync: flag needs an argument: {arg}");
                return Err(exit::USAGE);
            }
            project_dir = PathBuf::from(&args[i + 1]);
            i += 2;
        } else if let Some(val) = arg
            .strip_prefix("-project=")
            .or_else(|| arg.strip_prefix("--project="))
        {
            project_dir = PathBuf::from(val);
            i += 1;
        } else if arg == "-h" || arg == "--h" || arg == "-help" || arg == "--help" {
            // Go's flag package special-cases an unregistered "-h"/"-help":
            // it prints the flag set's usage and returns flag.ErrHelp, never
            // "flag provided but not defined" (that message is reserved for
            // every other unrecognized flag).
            let _ = write!(stderr, "{SYNC_FLAGS_USAGE}");
            return Err(exit::USAGE);
        } else if arg.starts_with('-') {
            let trimmed = arg.trim_start_matches('-');
            let name = trimmed.split_once('=').map_or(trimmed, |(name, _)| name);
            let _ = writeln!(stderr, "flag provided but not defined: -{name}");
            let _ = write!(stderr, "{SYNC_FLAGS_USAGE}");
            return Err(exit::USAGE);
        } else {
            // Go's flag package stops parsing at the first positional value.
            // normalizeFlags still folds double-dash names before `--`.
            let mut terminated = false;
            for remaining in &args[i..] {
                let value = remaining.to_string_lossy();
                if value == "--" {
                    terminated = true;
                }
                harnesses.push(if !terminated && value.starts_with("--") {
                    format!("-{}", &value[2..])
                } else {
                    value.into_owned()
                });
            }
            break;
        }
    }

    Ok(ParsedSyncArgs {
        project_dir,
        dry_run,
        harnesses,
    })
}

/// Executes `symbrain sync`.
#[allow(clippy::too_many_lines)]
pub fn run(
    args: &[OsString],
    stdout: &mut dyn Write,
    stderr: &mut dyn Write,
    format: OutputFormat,
) -> u8 {
    let parsed = match parse_args(args, stderr) {
        Ok(parsed) => parsed,
        Err(code) => return code,
    };

    // Validate harness names
    let requested_harnesses = if parsed.harnesses.is_empty() {
        all()
            .iter()
            .map(|h| h.name.as_str().to_string())
            .collect::<Vec<_>>()
    } else {
        for name in &parsed.harnesses {
            if lookup(name).is_err() {
                let _ = writeln!(
                    stderr,
                    "symbrain sync: harness: want one of: {}: unknown harness {name:?}",
                    symbrain_harness::names().join(", ")
                );
                return exit::USAGE;
            }
        }
        parsed.harnesses.clone()
    };

    // Load instruction source
    let source = Source::new(Some(&parsed.project_dir));
    let instruction_content = match source.content() {
        Ok(content) => content,
        Err(err) => {
            let _ = writeln!(stderr, "symbrain sync: load instructions: {err}");
            return exit::GENERIC;
        }
    };

    let mut target_statuses = Vec::new();
    for name in &requested_harnesses {
        let harness_name = match lookup(name) {
            Ok(h) => h.name,
            Err(_) => continue,
        };

        let target = match target_for_harness(harness_name.as_str()) {
            Ok(Some(t)) => t,
            Ok(None) => {
                target_statuses.push(TargetStatus {
                    name: name.clone(),
                    path: String::new(),
                    status: "skipped".to_string(),
                    message: Some(format!("harness {name:?} has no instruction adapter")),
                });
                continue;
            }
            Err(err) => {
                target_statuses.push(TargetStatus {
                    name: name.clone(),
                    path: String::new(),
                    status: "error".to_string(),
                    message: Some(format!("resolve target: {err}")),
                });
                continue;
            }
        };

        let target_path = match target.path(&parsed.project_dir) {
            Ok(p) => p,
            Err(err) => {
                target_statuses.push(TargetStatus {
                    name: name.clone(),
                    path: String::new(),
                    status: "error".to_string(),
                    message: Some(err.to_string()),
                });
                continue;
            }
        };
        // Go's filepath.Join(".", target) removes the leading "./".
        let display_path = target_path
            .strip_prefix(".")
            .unwrap_or(&target_path)
            .to_string_lossy()
            .into_owned();

        let existing_bytes = fs::read(&target_path).unwrap_or_default();
        let rendered =
            match target.render(&existing_bytes, &instruction_content, &parsed.project_dir) {
                Ok(r) => r,
                Err(err) => {
                    target_statuses.push(TargetStatus {
                        name: name.clone(),
                        path: display_path.clone(),
                        status: "error".to_string(),
                        message: Some(err.to_string()),
                    });
                    continue;
                }
            };

        if rendered.output == existing_bytes {
            target_statuses.push(TargetStatus {
                name: name.clone(),
                path: display_path.clone(),
                status: "unchanged".to_string(),
                message: None,
            });
        } else if parsed.dry_run {
            target_statuses.push(TargetStatus {
                name: name.clone(),
                path: display_path.clone(),
                status: "dry-run".to_string(),
                message: Some("would update".to_string()),
            });
        } else {
            let existed = target_path.exists();
            match write_atomic(
                &parsed.project_dir,
                Path::new(target.relative_path()),
                &rendered.output,
            ) {
                Ok(()) => {
                    target_statuses.push(TargetStatus {
                        name: name.clone(),
                        path: display_path.clone(),
                        status: if existed { "updated" } else { "created" }.to_string(),
                        message: None,
                    });
                }
                Err(err) => {
                    target_statuses.push(TargetStatus {
                        name: name.clone(),
                        path: display_path,
                        status: "error".to_string(),
                        message: Some(err.to_string()),
                    });
                }
            }
        }
    }

    let summary = SyncSummary {
        targets: target_statuses,
        skills: native_skill_results(&requested_harnesses, parsed.dry_run),
    };

    let has_error = summary.targets.iter().any(|t| t.status == "error")
        || summary.skills.iter().any(|s| s.status == "error");

    match format {
        OutputFormat::Json => {
            let _ = symbrain_core::output::render_json(&mut *stdout, &summary);
        }
        OutputFormat::Table => {
            let _ = writeln!(stdout, "Instruction targets:");
            for t in &summary.targets {
                let msg = t
                    .message
                    .as_deref()
                    .map(|m| format!(" ({m})"))
                    .unwrap_or_default();
                let _ = writeln!(
                    stdout,
                    "  {:<12} {}{}",
                    format!("{}:", t.name),
                    t.status,
                    msg
                );
            }
            if !summary.skills.is_empty() {
                let _ = writeln!(stdout, "\nSkills:");
                for s in &summary.skills {
                    let msg = s
                        .message
                        .as_deref()
                        .map(|m| format!(" ({m})"))
                        .unwrap_or_default();
                    let _ = writeln!(
                        stdout,
                        "  {:<12} {}{}",
                        format!("{}:", s.target),
                        s.status,
                        msg
                    );
                }
            }
        }
    }

    if has_error { exit::GENERIC } else { exit::OK }
}

/// Runs the ported skills runner and maps its results onto the sync payload.
///
/// Mirrors `internal/sync/sync.go`: Go calls
/// `skillsrunner.Run(ctx, harnessNames, DefaultOptions(), dryRun)` with a
/// background context and turns each result into a summary entry, so a
/// per-target failure is reported as `status: "error"` and only affects the
/// exit code through `SkillsFailed`.
///
/// The runner resolves the same library, render and base roots the CLI does
/// (`resolve_skills_dirs`), so a native run installs into the same places Go
/// would; its defaults are the ones `config.Defaults()` produces.
fn native_skill_results(harnesses: &[String], dry_run: bool) -> Vec<SkillResult> {
    let (library_dir, base_dir, home_dir) = crate::skills_cli::resolve_skills_dirs();
    let opts = symbrain_skills::runner::Options {
        library_dir: library_dir.to_string_lossy().into_owned(),
        base_dir: base_dir.to_string_lossy().into_owned(),
        home_dir: home_dir.to_string_lossy().into_owned(),
        ..symbrain_skills::runner::Options::default()
    };
    // A render root is deliberately not set here: `DefaultOptions().RenderDir`
    // is derived from the XDG data root by the runner itself, and passing the
    // CLI's own view would duplicate that resolution.
    let mut ctx = symbrain_skills::runner::NoopContext;
    match symbrain_skills::runner::run(&mut ctx, harnesses, opts, dry_run) {
        Ok(results) => results
            .into_iter()
            .map(|result| SkillResult {
                target: result.target,
                status: result.status,
                message: result.message,
            })
            .collect(),
        Err(err) => vec![SkillResult {
            target: String::new(),
            status: "error".to_string(),
            message: Some(format!("sync: skills: {err}")),
        }],
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    /// Matches the frozen `go sync --unknown` fixture case byte-for-byte
    /// (see rust/symbrain-cli/tests/fixtures/cli_tree_expectations.json):
    /// exit 2, and the Go flag package's own rejection text.
    #[test]
    fn unknown_flag_matches_go_flag_package_rejection() {
        let mut stderr = Vec::new();
        let result = parse_args(&[OsString::from("--unknown")], &mut stderr);
        assert!(matches!(result, Err(code) if code == exit::USAGE));
        assert_eq!(
            String::from_utf8(stderr).unwrap(),
            "flag provided but not defined: -unknown\nUsage of sync:\n  -dry-run\n    \tshow what would be written without making changes\n  -project string\n    \tproject directory (default: current directory)\n"
        );
    }

    /// Matches the `sync_help` differential case in `scripts/rust-differential.py`
    /// byte-for-byte: `-h`/`--help` are Go flag-package special cases (bare
    /// usage, no "flag provided but not defined" line), not ordinary unknown
    /// flags. Caught by CI's `make parity-smoke`, not by the 81-case CLI tree
    /// fixture (which has no help-flag case for `sync`) — that gap is why this
    /// regressed unnoticed locally.
    #[test]
    fn help_flag_prints_bare_usage_not_unknown_flag_rejection() {
        for flag in ["-h", "--h", "-help", "--help"] {
            let mut stderr = Vec::new();
            let result = parse_args(&[OsString::from(flag)], &mut stderr);
            assert!(
                matches!(result, Err(code) if code == exit::USAGE),
                "flag {flag}"
            );
            assert_eq!(
                String::from_utf8(stderr).unwrap(),
                SYNC_FLAGS_USAGE,
                "flag {flag}"
            );
        }
    }
}
