"""Independent immutable source/hash checks; no products, SDK or test execution."""
import ast
import gzip
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import sys
import tarfile

sys.dont_write_bytecode = True
ROOT = Path('/workspace/symaira-skills764-corrections')
OUT = Path(__file__).parent
HEAD = '128e1bfc81733e488e25f5b4935300a33009e265'
BASE = 'db9760a3d312173e8cd096d05925319a78308b48'
SOURCE = '625e746a9ab9e31f631458244c7f82d6e1754457'

def git(*args):
    return subprocess.check_output(['git', '-C', str(ROOT), *args])

def sha(data):
    return hashlib.sha256(data).hexdigest()

def bind(path):
    raw = path.read_bytes()
    return {'path': str(path), 'sha256': sha(raw), 'bytes': len(raw)}

assert git('rev-parse', 'HEAD').decode().strip() == HEAD
assert not git('status', '--porcelain')
handoff = json.loads((ROOT / 'migration/evidence/skills-native-764/corrections/source-handoff-verification.json').read_bytes())
for row in handoff['changed_files']:
    raw = (ROOT / row['path']).read_bytes()
    assert sha(raw) == row['sha256'] and len(raw) == row['bytes'], row['path']
checks = json.loads((ROOT / 'migration/evidence/skills-native-764/corrections/source-checks/static-checks.json').read_bytes())
for row in checks['source_maps']:
    raw = (ROOT / row['path']).read_bytes()
    assert sha(raw) == row['sha256'] and len(raw) == row['bytes']
retention_dir = ROOT / 'migration/evidence/skills-native-764/corrections/original'
retention = json.loads((retention_dir / 'retention.json').read_bytes())
archive = retention_dir / 'original-review.tar.gz'
assert sha(archive.read_bytes()) == retention['archive_sha256']
with tarfile.open(archive) as tar:
    assert len(tar.getnames()) == len(set(tar.getnames())) == len(retention['members']) == 319
    assert set(tar.getnames()) == {row['archive_member'] for row in retention['members']}
    for row in retention['members']:
        raw = tar.extractfile(row['archive_member']).read()
        assert sha(raw) == row['sha256'] and len(raw) == row['bytes']
        # Review SDK/consumer source is copied as exact original bytes.
        if '/review-source/' in row['archive_member']:
            (OUT / 'source-bindings' / ('original-' + Path(row['archive_member']).name)).write_bytes(raw)
sdk_retention = json.loads((ROOT / 'migration/evidence/skills-native-764/corrections/sdk-io/retention.json').read_bytes())
for row in sdk_retention['files']:
    compressed = (ROOT / row['archive']).read_bytes()
    raw = gzip.decompress(compressed)
    assert sha(compressed) == row['archive_sha256']
    assert len(raw) == row['bytes'] and sha(raw) == row['sha256']
    assert Path(row['source']).read_bytes() == raw
go_files = [name for name in git('ls-files', '-z').decode().split('\0') if name.endswith('.go')]
for name in go_files:
    assert (ROOT / name).read_bytes() == git('show', BASE + ':' + name)
for name in ['Cargo.toml', 'Cargo.lock', 'rust/symbrain-skills/Cargo.toml',
             'rust/symbrain-cli/Cargo.toml', 'rust/symbrain-mcp/Cargo.toml',
             'rust/symbrain-gateway/Cargo.toml']:
    assert (ROOT / name).read_bytes() == git('show', BASE + ':' + name)

scripts = ROOT / 'scripts/skills-native-oracle'
for path in scripts.glob('*.py'):
    ast.parse(path.read_bytes())
old_ast = ast.parse(git('show', BASE + ':scripts/skills-native-oracle/cases.py'))
new_ast = ast.parse((scripts / 'cases.py').read_bytes())
old_functions = []
for old in old_ast.body:
    if isinstance(old, ast.FunctionDef):
        new = next(n for n in new_ast.body if isinstance(n, ast.FunctionDef) and n.name == old.name)
        assert ast.dump(old) == ast.dump(new)
        old_functions.append(old.name)
sys.path.insert(0, str(scripts))
def load(name):
    spec = importlib.util.spec_from_file_location(name, scripts / (name + '.py'))
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module
cases, outputs, denied = load('cases'), load('output_cases'), load('library_denied')
root = Path('/source-only/not-created')
old_ids = [n for n, _ in cases.cli_cases()] + [n for n, _ in cases.raw_cli_cases()]
old_ids += [n for n, _, _ in cases.config_cases()] + [n for n, _, _ in cases.mcp_cases(root)]
old_ids += [n for n, _, _, _ in cases.mcp_config_cases(root)]
extra_ids = [n for n, _, _, _ in cases.correction_cases(root)]
extra_ids += ['mcp-framed-' + n for n, _, _ in cases.raw_argument_cases()]
extra_ids += [f'library-{s}-{f}' for s in ('empty-entry', 'malformed-entry') for f in ('table', 'json')]
extra_ids += denied.required_ids() + outputs.required_ids()
assert len(old_ids) == len(set(old_ids)) == 567
assert len(old_ids + extra_ids) == len(set(old_ids + extra_ids)) == 638
assert len(outputs.required_ids()) == 36 and len(denied.required_ids()) == 4
# The Windows branch changes only raw argument fixture units and sink set.
windows_raw_ids = [n for n, _, _ in []]
original_os_name = os.name
try:
    os.name = 'nt'
    windows_raw_ids = [n for n, _ in cases.raw_cli_cases()]
    windows_output_ids = outputs.required_ids()
finally:
    os.name = original_os_name
assert len(windows_raw_ids) == 66 and len(windows_output_ids) == 12
assert len(old_ids + extra_ids) - 36 + 12 == 614

changed_rust = [r['path'] for r in handoff['changed_files'] if r['path'].endswith('.rs')]
assert len(changed_rust) == 27
lines = {name: len((ROOT / name).read_bytes().splitlines()) for name in changed_rust}
assert max(lines.values()) < 400
source_bound = {}
for name in git('ls-files', 'rust/symbrain-skills', 'rust/symbrain-cli', 'rust/symbrain-gateway',
                'rust/symbrain-mcp', 'scripts/skills-native-oracle',
                'scripts/skills-argv-oracle/build_go.py', '.github/workflows/skills-native.yml',
                'migration/skills-native-764-inventory.md', 'migration/contract-matrix.csv',
                'docs/adr/native-skills-source-corrections-764.md',
                'docs/adr/skills-native-surface-764.md', 'Cargo.lock', 'Cargo.toml').decode().splitlines():
    source_bound[name] = bind(ROOT / name)
    assert (ROOT / name).read_bytes() == git('show', SOURCE + ':' + name)

# Exact independent source copies for novel finding traces, never executions.
novel_names = ['rust/symbrain-cli/src/lib.rs', 'rust/symbrain-cli/src/skills_cli_misc.rs',
               'rust/symbrain-skills/src/config.rs', 'rust/symbrain-skills/src/model_parse.rs',
               'rust/symbrain-skills/src/library.rs', 'rust/symbrain-skills/src/discover.rs',
               'rust/symbrain-mcp/src/frame.rs', 'rust/symbrain-mcp/src/raw_skills.rs',
               'rust/symbrain-mcp/src/model.rs', 'cmd/symbrain/cmd_skills.go',
               'internal/skills/skill/frontmatter.go', 'internal/output/output.go']
novel_bindings = []
for name in novel_names:
    payload = (ROOT / name).read_bytes()
    dest = OUT / 'source-bindings' / name.replace('/', '__')
    dest.write_bytes(payload)
    novel_bindings.append(bind(dest))
sdk_paths = ['/workspace/toolchains/go1.26.7/src/encoding/json/encode.go',
             '/workspace/toolchains/go1.26.7/src/encoding/json/decode.go',
             '/workspace/toolchains/go1.26.7/VERSION',
             '/home/agent/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/serde_json-1.0.145/src/ser.rs']
for name in sdk_paths:
    path = Path(name)
    dest = OUT / 'source-bindings' / ('sdk-' + path.parent.name + '-' + path.name)
    dest.write_bytes(path.read_bytes())
    novel_bindings.append({**bind(dest), 'original_source': name, 'source_sha256': sha(path.read_bytes())})
result = {'kind': 'INDEPENDENT SOURCE ONLY; Python hashes/AST/fixture-name projections, not candidate tests or runtime',
          'head': HEAD, 'source': SOURCE, 'base': BASE, 'clean': True,
          '57_delta_bindings': len(handoff['changed_files']), '50_check_bindings': len(checks['source_maps']),
          '319_full_tar_members': len(retention['members']), '8_sdk_roundtrips': len(sdk_retention['files']),
          '24_sdk_consumer_copies': 24, 'original_Go_byte_equal': len(go_files),
          'original_generator_AST_equal': old_functions, 'original_ids': old_ids,
          'additive_Unix_ids': extra_ids, 'prepared_Unix': 638, 'prepared_Windows': 614,
          'changed_Rust_files': lines, 'full_source_bindings': source_bound,
          'novel_finding_source_copies': novel_bindings,
          'actual_products': 0, 'actual_tests': 0, 'SDK_execution': 0,
          'compiler_target_port_GitHub_access': 0}
assert not git('status', '--porcelain')
(OUT / 'verification.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({key: result[key] for key in ['head', '57_delta_bindings', '50_check_bindings',
      '319_full_tar_members', '8_sdk_roundtrips', 'original_Go_byte_equal', 'prepared_Unix', 'prepared_Windows']}))
