//! Native `symbrain harness` CLI implementation.

use std::ffi::OsString;
use std::io::Write;
use std::path::PathBuf;

use serde::Serialize;
use symbrain_core::exit;
use symbrain_core::output::{self, OutputFormat};
use symbrain_harness::{ServerInfo, list};

use crate::health_probe::{HEALTH_SCHEMA_VERSION, HealthOutcome, probe_server};

const HARNESS_USAGE: &str = "symbrain harness — inspect configured AI harnesses

Usage:
  symbrain harness list [--project DIR]
  symbrain harness health [--harness NAME] [--project DIR]

The global --output table|json flag (or --json) selects the output format.
";

#[derive(Debug, Clone, Serialize)]
pub(crate) struct HarnessHealthEntry {
    pub harness: String,
    pub config: String,
    pub server: String,
    pub transport: String,
    pub healthy: bool,
    pub outcome: HealthOutcome,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub probe_method: Option<&'static str>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub latency_ms: Option<f64>,
    #[serde(skip_serializing_if = "String::is_empty")]
    pub error: String,
}

#[derive(Debug, Clone, Serialize)]
pub(crate) struct HarnessHealthReport {
    #[serde(skip_serializing_if = "Option::is_none")]
    pub health_schema_version: Option<u32>,
    pub servers: Option<Vec<HarnessHealthEntry>>,
}

/// The shipped `harness list` flag set as the Go flag package prints it.
const HARNESS_LIST_FLAGS: &str = "Usage of harness list:\n  -project string\n    \tproject directory to inspect for project-local harness config\n";
const HARNESS_HEALTH_FLAGS: &str = "Usage of harness health:\n  -harness string\n    \tonly probe servers of this harness\n  -project string\n    \tproject directory to inspect for project-local harness config\n";

/// Runs `symbrain harness`.
pub fn run(
    args: &[OsString],
    stdout: &mut dyn Write,
    stderr: &mut dyn Write,
    format: OutputFormat,
) -> Option<u8> {
    if args.is_empty() {
        let _ = write!(stderr, "{HARNESS_USAGE}");
        return Some(exit::USAGE);
    }

    let verb = args[0].to_string_lossy();
    let rest = &args[1..];

    match verb.as_ref() {
        "-h" | "--help" | "help" => {
            let _ = write!(stdout, "{HARNESS_USAGE}");
            Some(exit::OK)
        }
        "list" => run_list(rest, stdout, stderr, format),
        "health" => run_health(rest, stdout, stderr, format),
        _ => {
            let _ = write!(stderr, "{HARNESS_USAGE}");
            Some(exit::USAGE)
        }
    }
}

fn run_list(
    args: &[OsString],
    stdout: &mut dyn Write,
    stderr: &mut dyn Write,
    format: OutputFormat,
) -> Option<u8> {
    let mut project_dir: Option<PathBuf> = None;
    let mut i = 0;
    while i < args.len() {
        let arg = args[i].to_string_lossy();
        let (name, inline) = arg
            .split_once('=')
            .map_or((arg.as_ref(), None), |(name, value)| (name, Some(value)));
        match name {
            "-project" | "--project" => {
                let value = if let Some(value) = inline {
                    value.to_owned()
                } else {
                    // The shipped command parses with the Go flag package,
                    // which reports a missing value and prints the flag-set
                    // usage.
                    let Some(value) = args.get(i + 1) else {
                        let _ = writeln!(stderr, "flag needs an argument: -project");
                        let _ = write!(stderr, "{HARNESS_LIST_FLAGS}");
                        return Some(exit::USAGE);
                    };
                    i += 1;
                    value.to_string_lossy().into_owned()
                };
                project_dir = Some(PathBuf::from(value));
            }
            _ if name.starts_with('-') => {
                // The flag package prints the name without its dashes.
                let _ = writeln!(
                    stderr,
                    "flag provided but not defined: -{}",
                    name.trim_start_matches('-')
                );
                let _ = write!(stderr, "{HARNESS_LIST_FLAGS}");
                return Some(exit::USAGE);
            }
            _ => {
                // A bare argument is the shipped command's own diagnostic.
                let _ = writeln!(stderr, "symbrain harness list: unexpected argument {arg:?}");
                return Some(exit::USAGE);
            }
        }
        i += 1;
    }

    let inventory = list(project_dir.as_deref());
    if inventory.harnesses.iter().any(|harness| {
        [Some(&harness.global), harness.project.as_ref()]
            .into_iter()
            .flatten()
            .filter_map(|config| config.error.as_deref())
            .any(|error| !go_json_inventory_error(error))
    }) {
        return None;
    }

    let result = match format {
        OutputFormat::Json => output::render_json(&mut *stdout, &inventory),
        OutputFormat::Table => render_inventory_table(&mut *stdout, &inventory),
    };
    if let Err(error) = result {
        let _ = writeln!(stderr, "symbrain harness list: format output: {error}");
        return Some(exit::GENERIC);
    }

    Some(exit::OK)
}

fn go_json_inventory_error(error: &str) -> bool {
    // ponytail: only this oracle-frozen JSON diagnostic is native; add other parser messages with exact Go fixture evidence.
    error.starts_with("harness: ")
        && error.contains(
            " config is not valid json; refusing to edit a config symbrain cannot parse: parse json: ",
        )
        && error.ends_with("invalid character 'n'")
}

fn render_inventory_table(
    stdout: &mut dyn Write,
    inventory: &symbrain_harness::Inventory,
) -> std::io::Result<()> {
    for harness in &inventory.harnesses {
        writeln!(
            stdout,
            "{}\t{}",
            harness.name.as_str(),
            harness.display_name
        )?;
        render_config_table(stdout, "  global", &harness.global)?;
        if let Some(project) = &harness.project {
            render_config_table(stdout, "  project", project)?;
        }
        writeln!(stdout)?;
    }
    Ok(())
}

fn render_config_table(
    stdout: &mut dyn Write,
    label: &str,
    config: &symbrain_harness::ConfigInventory,
) -> std::io::Result<()> {
    let state = if config.error.is_some() {
        "invalid"
    } else if config.parsed {
        "parsed"
    } else if config.exists {
        "unparsed"
    } else {
        "missing"
    };
    let servers = if config.servers.is_empty() {
        "(none)".to_owned()
    } else {
        config
            .servers
            .iter()
            .map(|server| format!("{}[{}]", server.name, server.transport))
            .collect::<Vec<_>>()
            .join(",")
    };
    writeln!(
        stdout,
        "{label}\t{}\t{state}\tservers={servers}",
        config.path
    )?;
    if let Some(error) = &config.error {
        writeln!(stdout, "    error: {error}")?;
    }
    Ok(())
}

#[allow(clippy::too_many_lines)]
fn run_health(
    args: &[OsString],
    stdout: &mut dyn Write,
    stderr: &mut dyn Write,
    format: OutputFormat,
) -> Option<u8> {
    let mut harness_name: Option<String> = None;
    let mut project_dir: Option<PathBuf> = None;

    let mut i = 0;
    while i < args.len() {
        let arg = args[i].to_string_lossy();
        if matches!(arg.as_ref(), "-h" | "--h" | "-help" | "--help") {
            let _ = write!(stderr, "{HARNESS_HEALTH_FLAGS}");
            return Some(exit::USAGE);
        }
        if arg == "--" {
            if let Some(value) = args.get(i + 1) {
                let value = value.to_string_lossy();
                let _ = writeln!(
                    stderr,
                    "symbrain harness health: unexpected argument {value:?}"
                );
                return Some(exit::USAGE);
            }
            break;
        }
        let (name, inline) = arg
            .split_once('=')
            .map_or((arg.as_ref(), None), |(name, value)| (name, Some(value)));
        match name {
            "-harness" | "--harness" | "-project" | "--project" => {
                let value = if let Some(value) = inline {
                    value.to_owned()
                } else {
                    let Some(value) = args.get(i + 1) else {
                        let _ = writeln!(
                            stderr,
                            "flag needs an argument: -{}",
                            name.trim_start_matches('-')
                        );
                        let _ = write!(stderr, "{HARNESS_HEALTH_FLAGS}");
                        return Some(exit::USAGE);
                    };
                    i += 1;
                    value.to_string_lossy().into_owned()
                };
                if name.ends_with("harness") {
                    harness_name = Some(value);
                } else {
                    project_dir = Some(PathBuf::from(value));
                }
            }
            _ if name.starts_with('-') => {
                let _ = writeln!(
                    stderr,
                    "flag provided but not defined: -{}",
                    name.trim_start_matches('-')
                );
                let _ = write!(stderr, "{HARNESS_HEALTH_FLAGS}");
                return Some(exit::USAGE);
            }
            _ => {
                let _ = writeln!(
                    stderr,
                    "symbrain harness health: unexpected argument {arg:?}"
                );
                return Some(exit::USAGE);
            }
        }
        i += 1;
    }

    let inventory = list(project_dir.as_deref());
    let mut probes = Vec::new();

    for h in &inventory.harnesses {
        if let Some(ref target_name) = harness_name
            && h.name.as_str() != target_name
        {
            continue;
        }
        let cfgs = std::iter::once(&h.global).chain(h.project.as_ref());
        for cfg in cfgs {
            for server in &cfg.servers {
                probes.push(HealthProbe {
                    harness: h.name.as_str().to_string(),
                    config: cfg.path.clone(),
                    server: server.clone(),
                });
            }
        }
    }

    let probe_results = std::thread::scope(|scope| {
        let handles = probes
            .into_iter()
            .map(|probe| scope.spawn(move || probe_health(probe)))
            .collect::<Vec<_>>();
        handles
            .into_iter()
            .map(|handle| handle.join().ok())
            .collect::<Option<Vec<_>>>()
    });
    let mut entries = probe_results?;

    entries.sort_by(|left, right| {
        (
            left.harness.as_str(),
            left.server.as_str(),
            left.config.as_str(),
        )
            .cmp(&(
                right.harness.as_str(),
                right.server.as_str(),
                right.config.as_str(),
            ))
    });
    let report = HarnessHealthReport {
        health_schema_version: (!entries.is_empty()).then_some(HEALTH_SCHEMA_VERSION),
        servers: (!entries.is_empty()).then_some(entries),
    };

    let result = output::render(&mut *stdout, format, &report, |w| {
        let Some(servers) = report.servers.as_ref() else {
            return writeln!(w, "no MCP servers found");
        };
        for server in servers {
            if server.healthy {
                writeln!(
                    w,
                    "  ✓  {:<12} {:<14} {} ({})",
                    server.harness, server.server, server.config, server.transport
                )?;
            } else {
                writeln!(
                    w,
                    "  ✗  {:<12} {:<14} {}: {}",
                    server.harness, server.server, server.config, server.error
                )?;
            }
        }
        Ok(())
    });
    if let Err(error) = result {
        let _ = writeln!(stderr, "symbrain harness health: format output: {error}");
        return Some(exit::GENERIC);
    }

    Some(exit::OK)
}

struct HealthProbe {
    harness: String,
    config: String,
    server: ServerInfo,
}

fn probe_health(probe: HealthProbe) -> HarnessHealthEntry {
    let result = probe_server(&probe.server);
    HarnessHealthEntry {
        harness: probe.harness,
        config: probe.config,
        server: probe.server.name,
        transport: probe.server.transport,
        healthy: result.outcome == HealthOutcome::Healthy,
        outcome: result.outcome,
        probe_method: result.probe_method,
        latency_ms: result.latency_ms,
        error: result.error,
    }
}
