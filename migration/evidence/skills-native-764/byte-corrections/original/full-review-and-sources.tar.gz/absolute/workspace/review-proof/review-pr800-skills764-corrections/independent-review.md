# Skills764 full independent source review

**REQUEST CHANGES: six P2 groups.** This is a complete source review of the integrated six CLI verbs, eleven embedded MCP tools and their shared library/SDK owners, not approval based solely on the seven prior fixes. No candidate test, product, SDK executable, compiler, target, endpoint or GitHub operation ran. The counterexamples below are deterministic source traces and retained original byte inputs, explicitly not actual Go/native process observations.

Bound candidate: `/workspace/symaira-skills764-corrections`, clean publication `128e1bfc81733e488e25f5b4935300a33009e265`, production/scripts source `625e746a9ab9e31f631458244c7f82d6e1754457`. Original reviewed publication `db9760a3d312173e8cd096d05925319a78308b48`, production `aebb98b11316c8006b6284bf5f53650411dfca63`. Frozen product Go is `dcddcef0df5789123c7c9a7ebe6e01f10e941f2c`; nine production traces used for these findings were independently checked byte-identical to that commit. Go SDK sources are 1.26.7; the current Cargo lock selects serde_json **1.0.151**, whose actual read/de/serializer sources are retained. The earlier 1.0.145 reference remains preserved and is not substituted for current dependency attribution.

## Findings

### F1 — P2: retain raw OS path bytes through Skills presentation

Owner: `rust/symbrain-cli/src/skills_cli_misc.rs:206–211` and `224–235`; shared library/target presentation has the same loss in `library.rs:223–228`, `targets_status.rs:117`, `io_contract.rs:6–7`, and metadata marker paths.

`SYMSKILLS_LIBRARY_DIR` is accepted with `var_os` and retained as `PathBuf`, but `skills_doctor_report` immediately converts it through `display().to_string()`. The unconditionally native table and JSON reports therefore cannot preserve the frozen Go string. For the raw Unix environment value `/owned/library-\xe2\x82`, Go's human report writes both original bytes; native writes one encoded U+FFFD. Go's JSON encoder emits two `\ufffd` replacements, one for each invalid byte; the native lossy projection emits one literal U+FFFD. This example needs no raw filename or directory creation, so Darwin filename admission does not exclude it. A legitimate literal U+FFFD is a separate state and must remain distinguishable. Config/default discovery and routing have no admission gate for this value.

The retained projections cover FF, E282, C0AF and literal U+FFFD. Preserve native bytes until the output boundary and use the existing Go-shaped byte/text encoder, including paths inside errors and serialized reports. Do not apply blanket lossy conversion or declare these native reports equal. The ADR correctly says raw-path serialization remains pending; this finding supplies concrete reachable source evidence for that pending contract, rather than claiming it newly regressed in the seven-fix delta.

### F2 — P2: escape U+2028/U+2029 in native CLI JSON

Owner: `rust/symbrain-cli/src/lib.rs:249–254`, called by all six Skills report owners.

The shared `go_json` helper escapes only `&`, `<`, `>`. Pinned serde_json 1.0.151 copies the UTF8 bytes of U+2028/U+2029 unchanged; Go 1.26.7 `encoding/json/encode.go:1052–1066` escapes both unconditionally. Set the valid UTF8 environment value `SYMSKILLS_LIBRARY_DIR=/owned/library-<U+2028>` and run `skills doctor --json`: frozen Go emits `\u2028`, while native emits E280A8. U+2029 is the equivalent second case. Both reports otherwise succeed, and the prepared CLI comparator requires exact stdout bytes. Neither platform filename creation nor YAML parsing is necessary for this trigger. The HTML-plus-JS and literal-U+FFFD contrasts are retained.

Add these escapes at the shared Go JSON boundary and actual paired CLI cases. Keep caller strings and table bytes unchanged. Embedded Skills compact JSON already performs both escapes, so it provides an existing local precedent.

### F3 — P2: do not reject a valid frontmatter document solely for raw Markdown body bytes

Owner: `rust/symbrain-skills/src/model_parse.rs:22–24`, reachable through `library.rs:148` and the newly native MCP inspect/validate/render/discovery owners.

The entire `SKILL.md` is checked as UTF8 before extracting its frontmatter. Frozen `parseSkillMD` normalizes CRLF as Go bytes, extracts the closed header, decodes **only that header** with YAML and retains the remaining body as a Go string. A regular bounded file containing `---\nname: demo\ndescription: valid header\n---\nbody-\xff\n` therefore has valid Go frontmatter. `skills list`/`skills_list` report the loaded skill in Go; native drops it with a `skill_load` UTF8 error. Go `skills_inspect` also accepts the bundle and its JSON boundary repairs the body string. The native decoder rejects before that owner is reached. E282 and C0AF variants and a normal UTF8 control are retained as full original document bytes.

Separate the frontmatter text requirement from raw Markdown body storage. Preserve bytes through inspection and through subsequent consumers as appropriate; strict UTF8 overlay/variant rules remain their existing separate contracts. No bounded-reader, special-file, YAML-header or traversal validation needs weakening. This is an inherited library difference exposed by the expanded unconditional native routes; it is not a claimed failure of an executed candidate test.

### F4 — P2: validate the outer tools/call struct before raw Skills execution

Owner: `rust/symbrain-mcp/src/raw_skills.rs:20–28`, reached by `frame.rs:194–199` and `symbrain-gateway/src/dispatch.rs:17–35`.

The shortcut extracts a BTreeMap's last `name` and `arguments` and ignores the typed outer `_meta` owner. Frozen CoreKit `handleToolsCall` first unmarshals an ordered anonymous struct containing `Name string`, `Arguments json.RawMessage`, `Meta map[string]any`; an outer error prevents the handler from running. The valid request with `name:"skills_install"`, `arguments:{"name":"demo","dry_run":false}`, `_meta:[]` returns Go InvalidParams without materialization. Native recognizes the tool and enters the write handler, ignoring the malformed metadata. `_meta:{"token":1e9999}` has the same issue through Go's float64 map decoder. No arbitrary ignored-argument number admission should authorize ignoring a **known outer** typed field.

BTreeMap also erases outer duplicate/type order. `"name":4,"name":"skills_list"` preserves a Go type error but selects the native tool. `"name":"skills_list","name":null` preserves the Go string but native rejects/misses the tool. All five raw request inputs are preserved in both transports, including the potential write trigger. Restore outer Go struct admission and first-error/null/duplicate semantics while retaining argument RawMessage bytes; do not recursively decode the anonymous handler arguments prematurely. Other RPC owners must retain their current admission path.

### F5 — P2: allow Go-admitted byte/string forms to reach the known Skills raw decoder

Owner: `rust/symbrain-mcp/src/frame.rs:169–175` and `194`, with `model.rs:42` / `raw_skills.rs:22`.

The correction reaches escaped surrogate **argument** keys and values, but raw byte strings still fail at the transport before that repair. Line mode converts the full request with `String::from_utf8`. Framed `Request` first deserializes `Box<RawValue>`; pinned serde_json SliceRead `end_raw_buffering` also checks the entire captured slice as UTF8. A valid known `skills_list` call whose ignored argument string contains raw FF or E282 is admitted by frozen Go (`readLineLimited` returns `string(buf)`, RawMessage retains bytes and the handler ignores its argument); native returns a parse error. Both line and exact Content-Length fixtures are retained.

Likewise, an ignored escaped lone-surrogate key in the outer params or request object fails the native String-key BTreeMap before Skills admission, whereas Go repairs/ignores that key. These are separate from the now-correct handler argument repair. Preserve the known Skills route's Go byte/string admission through all outer layers, and keep raw/framing size limits and other RPC owners intact. An unsafe general UTF8 lossy transformation would change literal U+FFFD and duplicate/error behavior and is not the requested fix.

### F6 — P2: preserve the Unix no-follow control-document contract and discovery identity

Owner: `rust/symbrain-skills/src/load_read.rs:105–131` and `discover.rs:40–51`.

For a bundle with `SKILL.md -> document.md` and a valid regular `document.md` inside the same root, frozen Unix `openRootFile` explicitly uses O_NOFOLLOW. Bundle/library loading rejects the final control-document symlink. Native `read_skill_document` passes `nofollow=false`; a confined link is successfully followed and the `symlink && Read(error)` mapping is never reached. The newly native inspect/list/render owners can consequently accept a control document Go refuses. The same applies to the ordinary `symskills.toml` control read, which also passes false. Resources have separate confined-link semantics and must not be indiscriminately prohibited.

Discovery compounds the mismatch: Go computes the source ID from `path\0` plus raw `os.ReadFile(SKILL.md)` bytes even when the bundle is invalid. Native uses a no-follow identity read, silently substitutes an empty byte vector, yet its loader can mark this same linked bundle valid. For retained path `/owned/source/demo` and the 43-byte fixture, the deterministic source IDs are Go `sha256:e08aca32db3731e7` versus native `sha256:2fb3728d1a9f2228`. Preserve the Unix control-document refusal, and derive identity for a permitted confined link using a bounded retained capability without introducing an ambient outside-root read. Prepare actual full-row discovery, library and inspect probes, with exact unchanged source bytes/state. Windows Root.Open behavior remains a separate native requirement; this finding makes no cross-platform runtime assertion.

## Seven original findings and complete-layer review

The original full seven-finding report/receipt and all 319 archive members are preserved and SHA/length verified before the new finding inputs were written. Source disposition of those seven findings:

1. All eleven tools now share frozen Go registration order, and catalog exposure remains profile-gated; descriptions/schema/annotations are retained.
2. Each of six CLI report renderers propagates writer errors with subcommand context. `run_stdio` scopes actual fd1 OS EPIPE/SIGPIPE completion to Skills; ordinary custom writers retain their error. Sync finishes its work before output, with no output-error rollback.
3. Handler argument RawMessage admission now precedes recursive Value for the known eleven tools, preserving ignored huge numbers and repaired escaped surrogate values/keys. The remaining outer/byte admission differences are F4/F5, rather than claiming universal raw transport closure.
4. Discovery uses Lstat, skips ordinary explicit files, and classifies missing/dangling/read errors instead of the former unwrap panic. Limits and sorted target-preference dedup remain. F6 is a separate control-document case.
5. Library reads use a confined per-bundle root and the relative `SKILL.md` error label. Ordinary missing/denied reads are kept separate from entry/read budgets and special-file refusals.
6. Real archive stdout is captured separately from stderr with one aggregate bound; Git diagnostic failures remain errors, and Unix argv0 preserves the selected spelling. Other combined Git operations retain their owner. Extraction rejects traversal/.git/unsafe links, bounds entries/bytes, validates restored bundles before publication, and retains forward-commit/dirty-snapshot semantics and owner locks. The fixture really delegates Git and alters its archive stream, rather than mutating comparison records.
7. Main, permission and output pairs are registered with live child rows before assertions/comparison. RPC error branches are retained. Fixture command ledgers and final failure save preserve bootstrap/process/comparison failures instead of claiming successful parity.

Also inspected complete CLI flags/normalization/output extraction/config fallback, metadata timestamps/marker fallback, six targets/evidence, defaults-only gateway registration, all eleven handler branches, ordered handler arguments/arrays/nulls, profile inheritance/specificity/merge, render profile selection/partial target errors, project legacy base identity, current capability/loader/materialization/install/status/sync/lock/transaction/restore interactions, private executable SDK discovery (Go join, ErrDot, conditional bisect, Windows PATHEXT/argv0/SameFile), dependency pins, current public ADR/inventory/matrix, original builder and six current harness owners/workflow. Source review does not substitute for compiled platform semantics or replace the prior render-drift/preflight/raw-argv gates.

## Independent evidence and limits

`verification.json` binds the entire 259-file integrated source/criteria graph, all 57 changed-file bindings, 50 source-check bindings, full 319-member tar, eight current SDK IO/signal gzip roundtrips and 24 original SDK/consumer copies. It independently checks all 1,217 current Go files against the immutable original, unchanged Cargo manifests/lock, unchanged original five generator ASTs and all 567 unique IDs. Pure case-name projections verify **638 Unix / 614 Windows prepared pairs**, four permission pairs, 36 Unix / 12 Windows sink pairs, and preservation of the original three intended actual-child input controls. All 27 changed Rust files remain under400 lines. No evidence-only publication change affects the validated source graph.

The permission fixture correctly fails if privileged Unix mode0 remains readable; it has no root exemption. Windows uses the actual SystemRoot icacls owner with tool hash, real read denial, retained pre-denial file handle/inode and unchanged-ACL assertions. This is prepared source, not proof of Windows ACL execution. The output cases require actual OS sink errors or quiet Unix SIGPIPE; their planned controls cannot pass through bootstrap failure. The comparator preserves all CLI bytes and complete MCP payload/error/catalog fields; raw MCP transport is retained separately, not called byte equal. Only verified current generated timestamps and separately validated empty SKL004 lock files have the documented treatment.

New retained evidence: 17 byte/encoder/parser/hash **projections**, five outer-parameter request plans, full document and line/framed request bytes, exact frozen production traces and locked serde/SDK source copies. These counts are not executed tests or process pairs. Initial reference to the nonexistent handoff name `source-handoff.json` was resolved to the actual tracked `source-handoff-verification.json`; no candidate defect is inferred from that task-pointer mismatch. The earlier serde1.0.145 source copy is preserved alongside the exact current locked1.0.151 sources.

Required after source corrections: clean source checkpoint and normal current-main integration, locked compiled checks/strict lint/proper-fixture full workspace tests, all original567+3 and every additive pair/control without removing cases, independent fresh Go/native process proof for these new inputs, original preflight/raw-argv/live drift gates, Linux/macOS/Windows native execution and a different-author full review. Conditional GODEBUG stack/report forms, typed TOML diagnostics, Windows native lookup/argv0/raw paths and full #764 cutover remain open. Neither prepared source nor these projections approve publication as an executed native port.

Candidate and original sources are unchanged and clean; no target was acquired or accessed. Full raw/file SHA bindings accompany this report in `independent-review-receipt.json`.
