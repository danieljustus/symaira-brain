"""Source-traced counterexamples; explicitly NOT Go/native product executions."""
import hashlib
import json
from pathlib import Path

OUT = Path(__file__).parent
ROOT = Path('/workspace/symaira-skills764-corrections')
BOUND = OUT / 'source-bindings'

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

def row(raw):
    return {'hex': raw.hex(), 'bytes': len(raw), 'sha256': sha(raw)}

def go_quote(raw):
    # Direct projection of pinned encode.go appendString, not an SDK call.
    result = bytearray(b'"')
    at = 0
    while at < len(raw):
        byte = raw[at]
        if byte < 128:
            ch = chr(byte)
            escapes = {'"': b'\\"', '\\': b'\\\\', '\n': b'\\n', '\r': b'\\r',
                       '\t': b'\\t', '\b': b'\\b', '\f': b'\\f'}
            if ch in escapes:
                result += escapes[ch]
            elif byte < 32 or ch in '&<>':
                result += f'\\u{byte:04x}'.encode()
            else:
                result.append(byte)
            at += 1
            continue
        decoded = None
        for size in range(2, 5):
            piece = raw[at:at + size]
            try:
                candidate = piece.decode('utf-8')
            except UnicodeDecodeError:
                continue
            if len(candidate) == 1:
                decoded = (candidate, piece)
                break
        if decoded is None:
            result += b'\\ufffd'
            at += 1
            continue
        ch, piece = decoded
        result += f'\\u{ord(ch):04x}'.encode() if ch in '\u2028\u2029' else piece
        at += len(piece)
    result += b'"'
    return bytes(result)

def current_json_string(text):
    return json.dumps(text, ensure_ascii=False, separators=(',', ':')).replace('&', '\\u0026').replace('<', '\\u003c').replace('>', '\\u003e').encode()

projections = {'kind': 'Independent deterministic SOURCE PROJECTIONS; no candidate tests, SDK/product execution or runtime observation',
               'head': '128e1bfc81733e488e25f5b4935300a33009e265',
               'source': '625e746a9ab9e31f631458244c7f82d6e1754457', 'cases': []}

for token in ['\u2028', '\u2029', '<&>\u2028\u2029', '\ufffd']:
    raw = token.encode()
    projections['cases'].append({'group': 'json-js-escaping', 'input': row(raw),
        'Go_appendString_projection': row(go_quote(raw)),
        'candidate_go_json_string_projection': row(current_json_string(token)),
        'equal': go_quote(raw) == current_json_string(token),
        'reachable_input': 'SYMSKILLS_LIBRARY_DIR containing this valid UTF8 token; skills doctor --json'})

for suffix in [b'\xff', b'\xe2\x82', b'\xc0\xaf', '\ufffd'.encode()]:
    raw = b'/owned/library-' + suffix
    lossy = raw.decode('utf-8', errors='replace')
    projections['cases'].append({'group': 'raw-path-reporting', 'native_env_path': row(raw),
        'Go_human_value': row(raw), 'candidate_display_human_projection': row(lossy.encode()),
        'Go_JSON_value_projection': row(go_quote(raw)),
        'candidate_display_JSON_projection': row(current_json_string(lossy)),
        'reachable_input': 'SYMSKILLS_LIBRARY_DIR raw Unix environment value; no raw filename creation required'})

for payload in [b'\xff', b'\xe2\x82', b'\xc0\xaf', b'ordinary UTF8']:
    raw = b'---\nname: demo\ndescription: valid header\n---\nbody-' + payload + b'\n'
    closing = raw.find(b'\n---', 4)
    header = raw[4:closing]
    header.decode('utf-8')
    try:
        raw.decode('utf-8')
        native_whole_utf8 = True
    except UnicodeDecodeError:
        native_whole_utf8 = False
    path = OUT / ('body-' + payload.hex() + '.SKILL.md')
    path.write_bytes(raw)
    projections['cases'].append({'group': 'raw-body-admission', 'source_fixture': str(path),
        'input': row(raw), 'Go_YAML_input': row(header), 'candidate_whole_UTF8_admitted': native_whole_utf8,
        'source_trace': 'Go parseSkillMD decodes only fmText with YAML; native checks from_utf8(raw) first',
        'reachable_input': 'ordinary readable regular SKILL.md; CLI skills list and MCP skills_inspect'})

for raw in [b'{"jsonrpc":"2.0","id":3,"method":"tools/call","params":{"name":"skills_list","arguments":{"ignored":"\xff"}}}',
            b'{"jsonrpc":"2.0","id":3,"method":"tools/call","params":{"name":"skills_list","arguments":{"ignored":"\xe2\x82"}}}',
            br'{"jsonrpc":"2.0","id":3,"method":"tools/call","params":{"name":"skills_list","\ud800":1,"arguments":{}}}',
            br'{"jsonrpc":"2.0","id":3,"method":"tools/call","\ud800":1,"params":{"name":"skills_list","arguments":{}}}']:
    path = OUT / ('request-' + sha(raw)[:12] + '.jsonl')
    path.write_bytes(raw + b'\n')
    framed = OUT / ('request-' + sha(raw)[:12] + '.framed')
    framed.write_bytes(b'Content-Length: ' + str(len(raw)).encode() + b'\r\n\r\n' + raw)
    try:
        raw.decode('utf-8')
        line_utf8 = True
    except UnicodeDecodeError:
        line_utf8 = False
    projections['cases'].append({'group': 'mcp-byte-string-admission', 'input': row(raw),
        'line_fixture': str(path), 'framed_fixture': str(framed), 'candidate_line_UTF8_admitted': line_utf8,
        'source_trace': 'Go readLineLimited returns string(buf), JSON repairs string bytes and ignored keys; native UTF8 line / String-key outer RawValue map reject before skills_list ignores args',
        'actual_response_or_child_execution': False})

path = b'/owned/source/demo'
document = b'---\nname: demo\ndescription: valid\n---\nbody\n'
prefix = path + b'\0'
projections['cases'].append({'group': 'symlink-control-document', 'path': row(path), 'SKILL_md_symlink_target': 'document.md',
    'target_content': row(document), 'Go_discovery_source_id_projection': 'sha256:' + sha(prefix + document)[:16],
    'native_discovery_source_id_projection': 'sha256:' + sha(prefix)[:16],
    'Go_Unix_load_source_trace': 'readRootFile -> root.OpenFile O_NOFOLLOW rejects final SKILL.md symlink',
    'candidate_load_source_trace': 'read_skill_document -> read_limited_inner nofollow=false accepts confined document.md; error mapping runs only on failure',
    'kernel_or_product_probe': False})

extra_source = ['internal/skills/skill/root_unix.go', 'internal/skills/skill/root_other.go',
                'internal/skills/skill/load.go', 'internal/skills/discover/discover.go',
                'rust/symbrain-skills/src/load_read.rs']
for name in extra_source:
    (BOUND / name.replace('/', '__')).write_bytes((ROOT / name).read_bytes())
locked_ser = Path('/home/agent/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/serde_json-1.0.151/src/ser.rs')
(BOUND / 'sdk-serde_json-1.0.151-ser.rs').write_bytes(locked_ser.read_bytes())
(OUT / 'source-projections.json').write_text(json.dumps(projections, indent=2) + '\n')
print(json.dumps({'kind': projections['kind'], 'counterexample_projections': len(projections['cases']),
                  'product_SDK_compiler_test_target_port_execution': 0}))
