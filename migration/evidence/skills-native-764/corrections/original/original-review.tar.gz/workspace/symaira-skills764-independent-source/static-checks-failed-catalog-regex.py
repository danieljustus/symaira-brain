"""Source-only review controls. No product, SDK, Git fixture, or child execution."""
import ast
import csv
import hashlib
import importlib.util
import json
import re
import sys
import tomllib
from pathlib import Path

ROOT = Path('/workspace/symaira-skills764-native')
OUT = Path('/workspace/symaira-skills764-independent-source')
sys.dont_write_bytecode = True
sys.path.insert(0, str(ROOT / 'scripts/skills-native-oracle'))
import cases
import compare

results = []
def passed(name, detail):
    results.append(dict(name=name, passed=True, detail=detail))

for name in ('cases', 'compare', 'fixtures', 'run'):
    ast.parse((ROOT / f'scripts/skills-native-oracle/{name}.py').read_bytes())
passed('four Python ASTs', 'parse only, no fixture invocation')

counts = dict(cli=len(cases.cli_cases()), raw_cli=len(cases.raw_cli_cases()),
              cli_config=len(cases.config_cases()), mcp=len(cases.mcp_cases(OUT / 'uncreated-root')),
              mcp_config=len(cases.mcp_config_cases(OUT / 'uncreated-root')))
assert counts == dict(cli=276, raw_cli=66, cli_config=42, mcp=162, mcp_config=21)
all_cases = cases.cli_cases() + cases.raw_cli_cases() + cases.config_cases() + cases.mcp_cases(OUT / 'uncreated-root') + cases.mcp_config_cases(OUT / 'uncreated-root')
assert len({row[0] for row in all_cases}) == sum(counts.values()) == 567
passed('567 prepared unique cases', counts)

lock = tomllib.loads((ROOT / 'Cargo.lock').read_text())
for name, version in [('serde_json', '1.0.151'), ('tar', '0.4.46'), ('same-file', '1.0.6')]:
    assert any(row['name'] == name and row['version'] == version for row in lock['package'])
for path in ['Cargo.toml', 'rust/symbrain-gateway/Cargo.toml', 'rust/symbrain-skills/Cargo.toml']:
    tomllib.loads((ROOT / path).read_text())
passed('pinned manifest grammar', 'no Cargo resolution/type/runtime claim')

checks = json.loads((ROOT / 'migration/evidence/skills-native-764/source-checks.json').read_bytes())
for row in checks['changed_rust_files_below_400']:
    raw = (ROOT / row['path']).read_bytes()
    assert hashlib.sha256(raw).hexdigest() == row['sha256']
    assert len(raw.splitlines()) == row['lines'] < 400
passed('55 Rust files under 400 lines', len(checks['changed_rust_files_below_400']))

with (ROOT / 'migration/contract-matrix.csv').open(newline='') as source:
    matrix = list(csv.DictReader(source))
key = next(key for key in matrix[0] if 'contract' in key.lower())
assert len({row[key] for row in matrix}) == len(matrix) == 88
passed('88 unique matrix contracts', 'inventory stays pending; rows are not runtime proof')

go_catalog = {}
for path in (ROOT / 'internal/skills/mcptools').glob('*.go'):
    if path.name.endswith('_test.go'):
        continue
    for match in re.finditer(r'Name:\s*"(skills_[^"]+)".*?Description:\s*"([^"]+)".*?InputSchema:\s*json.RawMessage\(`([^`]+)`\).*?Annotations:\s*&mcpserver.ToolAnnotations\{Title:\s*"([^"]+)",\s*ReadOnlyHint:\s*(true|false)(?:,\s*DestructiveHint:\s*(true|false))?', path.read_text(), re.S):
        name, desc, schema, title, read, destructive = match.groups()
        go_catalog[name] = (desc, json.loads(schema), title, read == 'true', destructive == 'true')
rust_catalog = {}
text = (ROOT / 'rust/symbrain-gateway/src/embedded/skills_catalog.rs').read_text()
for match in re.finditer(r'"(skills_[^"]+)"\s*=>\s*\(\s*"([^"]+)",\s*r#"(.*?)"#,\s*"([^"]+)",\s*(true|false),\s*(true|false)', text, re.S):
    name, desc, schema, title, read, destructive = match.groups()
    rust_catalog[name] = (desc, json.loads(schema), title, read == 'true', destructive == 'true')
assert len(go_catalog) == len(rust_catalog) == 11
assert go_catalog == rust_catalog
passed('11 full Go/Rust registration bodies', 'description/schema/title/read/destructive equal by source; no raw runtime equivalence claim')

# Compare only synthetic transport objects: this demonstrates the failure path
# of the actual comparator, not a Go/native runtime observation.
success = [dict(id=1, result={}), dict(id=2, result={'tools': [dict(name='skills_' + str(i)) for i in range(11)]}),
           dict(id=3, result={'content': [dict(type='text', text='{}')], 'isError': False})]
failure = success[:2] + [dict(id=3, error={'code': -32700, 'message': 'synthetic parse error'})]
record = lambda rows: dict(exit=0, stdout_hex=('\n'.join(json.dumps(row) for row in rows)+'\n').encode().hex(), stderr_hex='')
assert compare.mcp_view(record(success))[1][2]['result']['content'][0]['text'] == {}
try:
    compare.mcp_view(record(failure))
except KeyError as error:
    assert error.args == ('result',)
    captured = repr(error)
else:
    raise AssertionError('expected actual comparator to fail before matched returns')
tree = ast.parse((ROOT / 'scripts/skills-native-oracle/run.py').read_bytes())
main = next(node for node in tree.body if isinstance(node, ast.FunctionDef) and node.name == 'main')
matches = [node for node in ast.walk(main) if isinstance(node, ast.Assign) and isinstance(node.value, ast.Call)
           and isinstance(node.value.func, ast.Name) and node.value.func.id == 'matched']
assert len(matches) == 1
assignment_line = matches[0].lineno
append_lines = [node.lineno for node in ast.walk(main) if isinstance(node, ast.Expr)
                and isinstance(node.value, ast.Call) and isinstance(node.value.func, ast.Attribute)
                and node.value.func.attr == 'append' and any(isinstance(arg, ast.Name) and arg.id == 'pair' for arg in node.value.args)]
assert any(line == assignment_line + 1 for line in append_lines)
passed('synthetic normal/control comparator', dict(normal_passed=True, control_raised=captured,
       matched_line=assignment_line, append_lines=sorted(append_lines), actual_process_pairs=0))

report = dict(status='passed-source-checks-with-confirmed-findings', checks=results,
              actual_builds=0, actual_product_processes=0, actual_SDK_executions=0,
              synthetic_control_is_not_process_proof=True)
(OUT / 'static-checks.json').write_text(json.dumps(report, indent=2)+'\n')
print(json.dumps(report, indent=2))
