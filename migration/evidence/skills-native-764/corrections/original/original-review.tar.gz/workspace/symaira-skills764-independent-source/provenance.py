import gzip,hashlib,json,subprocess,shutil
from pathlib import Path
r=Path('/workspace/symaira-skills764-native');out=Path('/workspace/symaira-skills764-independent-source')
sha=lambda b:hashlib.sha256(b).hexdigest();base=r/'migration/evidence/skills-native-764';protected={}
for row in json.loads((base/'source-bindings.json').read_bytes())['files']:
 b=(r/row['path']).read_bytes();assert sha(b)==row['sha256'];protected[row['path']]=row['sha256']
original=json.loads((base/'original/retention.json').read_bytes());archives=[]
for file in [base/'original/retention.json',base/'original/additional-retention.json',base/'original/scope-retention.json',base/'original/dispatch.rs.json']:
 data=json.loads(file.read_bytes())
 rows=data if isinstance(data,list) else data.get('original_source',data.get('files',[]))
 if not rows and 'archive_sha256' in data:rows=[dict(data,archive=str((file.parent/'dispatch.rs.gz').relative_to(r)))]
 for row in rows:
  gz=r/row['archive'];b=gzip.decompress(gz.read_bytes());assert sha(gz.read_bytes())==row['archive_sha256'] and sha(b)==row['sha256'] and len(b)==row['bytes'];archives.append(row)
frozen=Path('/workspace/oracles/daemon772-go-source')
oracle_matches=[];retained_repo_reference_files=[]
for row in original['frozen_go']:
 assert sha((r/row['path']).read_bytes())==row['sha256'],row
 if (frozen/row['path']).is_file():
  assert sha((frozen/row['path']).read_bytes())==row['sha256'],row;oracle_matches.append(row['path'])
 else:retained_repo_reference_files.append(row['path'])
for row in json.loads((base/'inspected-go-sources.json').read_bytes())['files']:assert sha((frozen/row['path']).read_bytes())==row['sha256']
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=r).decode().strip()=='db9760a3d312173e8cd096d05925319a78308b48'
assert not subprocess.check_output(['git','status','--porcelain'],cwd=r)
for p in ['source-bindings.json','handoff.md','prepared-case-plan.json','source-checks.json','inspected-go-sources.json','binary-source-provenance.json','helper-source-provenance.json']:
 shutil.copyfile(base/p,out/p)
for p in Path('/tmp').glob('symaira-skills764-source-final-handoff.*'):shutil.copyfile(p,out/p.name)
for row in archives:
 p=r/row['archive'];q=out/'original'/p.name;q.parent.mkdir(exist_ok=True);shutil.copyfile(p,q)
for name in protected:
 p=r/name;q=out/'candidate-source'/name;q.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,q)
(out/'complete-diff.patch').write_bytes(subprocess.check_output(['git','diff','86118925','db9760a3'],cwd=r))
(out/'original-go-bindings.json').write_text(json.dumps(original['frozen_go'],indent=2)+'\n')
(out/'provenance.json').write_text(json.dumps(dict(head='db9760a3d312173e8cd096d05925319a78308b48',source='aebb98b11316c8006b6284bf5f53650411dfca63',source_bindings=len(protected),original_archives=len(archives),frozen_go=len(original['frozen_go']),immutable_DC_oracle_matches=len(oracle_matches),retained_repository_reference_files=retained_repo_reference_files,candidate_or_SDK_execution=False,source_unchanged=True),indent=2)+'\n')
print(len(protected),'source bindings /',len(archives),'original roundtrips /',len(original['frozen_go']),'frozen Go source maps verified')
