"""Freeze the source-only review and its exact non-runtime evidence."""
import hashlib
import json
import shutil
import subprocess
from pathlib import Path

ROOT = Path('/workspace/symaira-skills764-native')
OUT = Path('/workspace/symaira-skills764-independent-source')
sha = lambda raw: hashlib.sha256(raw).hexdigest()
manifest = []
paths = [ROOT / name for name in [
    'rust/symbrain-mcp/src/frame.rs', 'rust/symbrain-mcp/src/model.rs',
    'rust/symbrain-skills/src/library.rs', 'rust/symbrain-skills/src/load_read.rs',
    'internal/skills/skill/root.go', 'internal/skills/skill/frontmatter.go',
    'internal/skills/skill/library.go', 'internal/skills/vcs/extract.go',
    'internal/skills/discover/discover.go', 'internal/skills/mcptools/mcptools.go',
    'cmd/symbrain/cmd_skills.go', 'internal/gateway/server.go']]
sdk = Path('/workspace/toolchains/go1.26.7')
paths += [sdk / name for name in ['src/encoding/json/decode.go', 'src/os/exec/exec.go',
                                 'src/os/exec/lp_unix.go', 'src/os/exec/lp_windows.go']]
paths += [Path('/home/agent/go/pkg/mod/github.com/danieljustus/symaira-corekit@v0.17.0/mcpserver/mcpserver.go')]
serde = Path('/home/agent/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/serde_json-1.0.151')
paths += [serde / name for name in ['src/read.rs', 'src/de.rs', 'Cargo.toml']]
tar = Path('/home/agent/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/tar-0.4.46')
paths += [tar / name for name in ['src/archive.rs', 'src/entry.rs', 'src/entry_type.rs', 'Cargo.toml']]
for index, path in enumerate(paths):
    raw = path.read_bytes()
    retained = OUT / 'review-source' / f'{index:03}-{path.name}'
    retained.parent.mkdir(exist_ok=True)
    retained.write_bytes(raw)
    manifest.append(dict(original=str(path), retained=str(retained), sha256=sha(raw), bytes=len(raw)))

helper = json.loads((OUT / 'helper-source-provenance.json').read_bytes())
for row in helper['files']:
    raw = subprocess.check_output(['git', 'show', row['parent_head']+':'+row['original_path']], cwd=ROOT)
    assert sha(raw) == row['original_sha256']
binary = json.loads((OUT / 'binary-source-provenance.json').read_bytes())
for row in binary['files']:
    assert sha(Path(row['original_path']).read_bytes()) == row['original_sha256']
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT).decode().strip()
assert head == 'db9760a3d312173e8cd096d05925319a78308b48'
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=ROOT)
report = Path('/workspace/symaira-skills764-independent-source-review.md')
files = []
for path in sorted(OUT.rglob('*')):
    if path.is_file():
        raw = path.read_bytes()
        files.append(dict(path=str(path), sha256=sha(raw), bytes=len(raw)))
receipt = dict(verdict='REQUEST_CHANGES', findings=[dict(id=i, priority='P2', basis='source-established, no product execution') for i in range(1,8)],
    head=head, production='aebb98b11316c8006b6284bf5f53650411dfca63', worktree=str(ROOT), clean=True,
    reviewer='memory758_port', author='review_pr797', original_retention_verified_before_findings=True,
    original_provenance=json.loads((OUT/'provenance.json').read_bytes()),
    independent_static=json.loads((OUT/'static-checks.json').read_bytes()),
    actionlint=dict(path='/workspace/toolchains/bin/actionlint', exit=0, log=str(OUT/'actionlint.log')),
    diff_check=dict(exit=0, log=str(OUT/'diff-check.log')),
    original_helper_bindings_verified=len(helper['files']), original_discovery_source_bindings_verified=len(binary['files']),
    additional_source_bindings=manifest, retained_files=files,
    report=dict(path=str(report), sha256=sha(report.read_bytes())),
    target_access=False, target_owned=False, port_access=False, compiler_execution=False,
    product_execution=False, SDK_execution=False, candidate_changed=False, Github_writes=False,
    actual_process_pairs=0, prepared_process_pairs=567, prepared_real_child_controls=3,
    runtime_or_native_approval=False)
destination = Path('/workspace/symaira-skills764-independent-source-review-receipt.json')
destination.write_text(json.dumps(receipt, indent=2)+'\n')
print(json.dumps(dict(receipt=str(destination), sha256=sha(destination.read_bytes()), report_sha256=sha(report.read_bytes()),
                     files=len(files), source_bindings=len(manifest), verdict=receipt['verdict']), indent=2))
