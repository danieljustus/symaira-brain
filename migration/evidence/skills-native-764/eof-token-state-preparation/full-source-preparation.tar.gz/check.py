"""Pure source binding/projections only; no SDK/compiler/process/fixture calls."""
import ast,copy,gzip,hashlib,importlib.util,io,json,os,subprocess,sys,tarfile,types
from pathlib import Path
sys.dont_write_bytecode=True
R=Path('/workspace/symaira-skills764-eof-correction');P=Path('/workspace/symaira-skills764-json-corrections');O=Path('/workspace/review-proof/skills764-eof-correction-preparation');H='fb43004be5e89e3f489f8a3f38c1224e2a98ff0e';sha=lambda b:hashlib.sha256(b).hexdigest();git=lambda *a:subprocess.check_output(['git','-C',str(R),*a])
sys.path.insert(0,str(R/'scripts/skills-native-oracle'));import run,json_cases,json_compare,eof_cases,byte_cases,cases as case_module,output_cases,library_denied
old=git('show',H+':scripts/skills-native-oracle/run.py');new=(R/'scripts/skills-native-oracle/run.py').read_bytes();oldjson=types.ModuleType('old_json_cases');oldjson.__file__=str(P/'scripts/skills-native-oracle/json_cases.py');exec(compile(git('show',H+':scripts/skills-native-oracle/json_cases.py'),'<immutable-parent-json-cases>','exec'),vars(oldjson))
def case_only(raw,env):
 main=next(n for n in ast.parse(raw).body if isinstance(n,ast.FunctionDef)and n.name=='main');nodes=[]
 for n in ast.walk(main):
  if isinstance(n,(ast.Assign,ast.AugAssign)):
   ts=n.targets if isinstance(n,ast.Assign)else[n.target]
   if len(ts)==1 and isinstance(ts[0],ast.Name)and ts[0].id=='cases':nodes.append(n)
 exec(compile(ast.Module(body=sorted(nodes,key=lambda n:n.lineno),type_ignores=[]),'<pure-case-generation>','exec'),env);return env['cases']
modules=[run,case_module,byte_cases,output_cases,library_denied];saved=[m.os for m in modules];plans={}
try:
 for platform in ['posix','nt']:
  proxy=types.SimpleNamespace(**{k:getattr(os,k)for k in dir(os)if not k.startswith('__')});proxy.name=platform
  for m in modules:m.os=proxy
  env=vars(run).copy();env['root']=Path('/owned');oldenv=dict(env,json_cases=oldjson.cases);a=case_only(old,oldenv);b=case_only(new,env);assert b[:len(a)]==a
  total=(len(a)+len(run.denied_ids())+len(run.output_ids()),len(b)+len(run.denied_ids())+len(run.output_ids()));assert total==((926,1112)if platform=='posix'else(884,1070)),total
  assert len(b)==len({x[0]for x in b});plans[platform]=dict(original=total[0],prepared=total[1],exact_prefix=True,added=186,case_input_binding=[dict(id=n,argv=v,stdin_sha256=sha(d)if d is not None else None,variant=selected)for n,v,d,selected in b])
finally:
 for m,original in zip(modules,saved):m.os=original
for name in ['cases.py','fixtures.py','compare.py','output_cases.py','library_denied.py','byte_cases.py']:
 assert (R/'scripts/skills-native-oracle'/name).read_bytes()==git('show',H+':scripts/skills-native-oracle/'+name)
for name in ['sha','terminate','invoke','incoming','actual_control']:
 select=lambda s:next(n for n in ast.parse(s).body if isinstance(n,ast.FunctionDef)and n.name==name);assert ast.dump(select(old),include_attributes=False)==ast.dump(select(new),include_attributes=False)
for name in ['run_controls']:
 select=lambda s:next(n for n in ast.parse(s).body if isinstance(n,ast.FunctionDef)and n.name==name);assert ast.dump(select(git('show',H+':scripts/skills-native-oracle/json_cases.py')),include_attributes=False)==ast.dump(select((R/'scripts/skills-native-oracle/json_cases.py').read_bytes()),include_attributes=False)
# Every original EOF wire is unchanged at its permanent owned location.
eof=json.loads((Path('/workspace/review-proof/review-pr800-skills764-json-corrections/eof-finding/bindings.json')).read_bytes());bound=[]
for r in eof['wires']:
 q=R/'scripts/skills-native-oracle/eof-review-inputs'/Path(r['path']).name;b=q.read_bytes();assert b==Path(r['path']).read_bytes()and sha(b)==r['sha256'];bound.append(dict(id=r['id'],bytes=len(b),sha256=sha(b)))
assert len(eof_cases.PARTIAL)==23 and len(eof_cases.PARSE_IDS)==170;assert {name for name,*_ in eof_cases.cases(Path('/owned'),run.incoming)if eof_cases.is_parse_case(name)}==eof_cases.PARSE_IDS
# Synthetically labeled complete protocol records; no real input mutant has run.
names=[line.split('"')[1]for line in (R/'rust/symbrain-mcp/src/raw_skills.rs').read_text().splitlines()if line.strip().startswith('"skills_')];assert len(names)==11
responses=[{'jsonrpc':'2.0','id':1,'result':{}},{'jsonrpc':'2.0','id':2,'result':{'tools':[{'name':n}for n in names]}},{'jsonrpc':'2.0','id':None,'error':{'code':-32700,'message':"Parse error: invalid character ' ' in numeric literal"}}]
def record(resp,framed):
 rows=[json.dumps(r,separators=(',',':')).encode()for r in resp];out=b''.join(b'Content-Length: '+str(len(b)).encode()+b'\r\n\r\n'+b for b in rows)if framed else b'\n'.join(rows)+b'\n';return dict(exit=0,stdout_hex=out.hex(),stderr_hex='',filesystem=dict(files={},raw_file_hashes={},validated_skl004_locks={}))
mutants=[]
for framed in [False,True]:
 ident='json-eof-original-minus-'+('framed'if framed else'line');base=record(responses,framed);assert json_compare.json_matched(ident,base,base,Path('/owned'))
 for kind in ['id','code','generic-message','missing','duplicate','result','catalog','exit','stderr','files','raw_file_hashes','validated_locks']:
  changed=copy.deepcopy(responses);r=record(changed,framed)
  if kind=='id':changed[2]['id']=3
  elif kind=='code':changed[2]['error']['code']=-32602
  elif kind=='generic-message':changed[2]['error']['message']='Parse error: unexpected end of JSON input'
  elif kind=='missing':changed=changed[:2]
  elif kind=='duplicate':changed.append(changed[2])
  elif kind=='result':changed[2]['result']={}
  elif kind=='catalog':changed[1]['result']['tools']=[]
  if kind in ['id','code','generic-message','missing','duplicate','result','catalog']:r=record(changed,framed)
  if kind=='exit':r['exit']=1
  elif kind=='stderr':r['stderr_hex']='78'
  elif kind=='files':r['filesystem']['files']={'unexpected':{}}
  elif kind=='raw_file_hashes':r['filesystem']['raw_file_hashes']={'unexpected':'sha'}
  elif kind=='validated_locks':r['filesystem']['validated_skl004_locks']={'unexpected':{}}
  try:accepted=json_compare.json_matched(ident,base,r,Path('/owned'))
  except (AssertionError,KeyError,IndexError):accepted=False
  assert not accepted,kind;mutants.append(dict(mode='framed'if framed else'line',kind=kind,rejected=True,synthetic=True))
# The full old scanner is restored by removing exactly the new helper/five lookups.
code=(R/'rust/symbrain-mcp/src/raw_skills_syntax.rs').read_text();start=code.index('fn token_byte(');end=code.index('fn error(',start);projection=code[:start]+code[end:];projection=projection.replace('token_byte(raw, *index)','next(raw, *index)?');assert projection.encode()==git('show',H+':rust/symbrain-mcp/src/raw_skills_syntax.rs');assert code.count('token_byte(raw, *index)')==5
# Full Go source trace: terminal error contexts and EOF's synthetic-byte action.
sdk=Path('/workspace/toolchains/go1.26.7/src/encoding/json/scanner.go').read_text();assert "s.step(s, ' ')"in sdk and 'unexpected end of JSON input'in sdk
for _,_,context in eof_cases.PARTIAL:assert json.dumps(context)in sdk,context
sourcechecks=[]
changed=git('diff','--name-only',H).decode().splitlines()+git('ls-files','--others','--exclude-standard').decode().splitlines()
for name in changed:
 p=R/name
 if p.suffix=='.rs':
  assert len(p.read_text().splitlines())<400;c=['/home/agent/.cargo/bin/rustfmt','--edition','2024','--check',str(p)];r=subprocess.run(c,capture_output=True);sourcechecks.append(dict(path=name,exit=r.returncode));assert r.returncode==0,(name,r.stderr)
for p in (R/'scripts/skills-native-oracle').glob('*.py'):ast.parse(p.read_bytes())
for name,c in [('actionlint',['/workspace/toolchains/bin/actionlint','.github/workflows/ci.yml','.github/workflows/skills-native.yml']),('diff',['git','diff','--check'])]:
 r=subprocess.run(c,cwd=R,capture_output=True);(O/(name+'.stdout')).write_bytes(r.stdout);(O/(name+'.stderr')).write_bytes(r.stderr);assert r.returncode==0,(name,r.stderr)
result=dict(kind='PURE_SOURCE_PREPARATION_ZERO_PRODUCT',parent=H,plans=plans,original_review_wires=bound,active_partial_token_families=23,parse_ids=170,synthetic_comparator_mutants=mutants,original_controls_AST_unchanged=True,all_old_harness_and_process_functions_unchanged=True,exact_scanner_projection=True,direct_rustfmt=sourcechecks,Python_AST_files=len(list((R/'scripts/skills-native-oracle').glob('*.py'))),prepared_actual_input_controls=9,current_actual_product_SDK_compiler_Target_cache_SQLite_port=0)
(O/'checks.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(dict(plans={k:{n:v for n,v in p.items()if n!='case_input_binding'}for k,p in plans.items()},original_wires=18,synthetic_mutants=len(mutants),Rustfmt=len(sourcechecks),controls_prepared=9,actual_runtime=0)))
