import gzip,hashlib,io,json,os,subprocess,tarfile
from pathlib import Path
R=Path('/workspace/symaira-skills764-json-corrections');O=Path('/workspace/review-proof/skills764-eof-correction-preparation');V=Path('/workspace/review-proof/review-pr800-skills764-json-corrections');H='fb43004be5e89e3f489f8a3f38c1224e2a98ff0e';sha=lambda b:hashlib.sha256(b).hexdigest();os.umask(0o022)
def git(*a):return subprocess.check_output(['git','-C',str(R),*a])
def native(p):
 s=p.lstat();return{k:getattr(s,k)for k in ['st_mode','st_uid','st_gid','st_dev','st_ino','st_size','st_nlink','st_mtime_ns','st_ctime_ns','st_blocks']}
assert git('rev-parse','HEAD').decode().strip()==H and git('status','--porcelain')==b''
assert sha((V/'independent-review.md').read_bytes())=='591aa17c91178fb5cb6b670c13e259561a4407f44b31c5ad54854f6c8ef4991f';assert sha((V/'receipt.json').read_bytes())=='acc5cf466b6f79c621a4146e9f761f84f0d6fb3892996d325a520dfa7ac0b588';m=V/'proof-manifest.json';assert sha(m.read_bytes())=='3c3172bb034f3b19de0de2077811b39a5a5ecabb00fa77e8a43f9bc3a9d28901'
proofs=json.loads(m.read_bytes())['records'];assert len(proofs)==68
selected=[]
for r in proofs:
 p=Path(r['path']);b=p.read_bytes();s=p.lstat();assert sha(b)==r['sha256']and len(b)==r['bytes'];assert (s.st_mode,s.st_uid,s.st_gid,s.st_mtime_ns)==(r['mode'],r['uid'],r['gid'],r['mtime_ns']);selected.append(('independent/'+r['relative'],p,b))
for p in [m,V/'receipt.json']:selected.append(('independent/'+p.name,p,p.read_bytes()))
full=[];physical=[]
proc=subprocess.Popen(['git','-C',str(R),'cat-file','--batch'],stdin=subprocess.PIPE,stdout=subprocess.PIPE)
for rec in git('ls-tree','-r','-z',H).split(b'\0'):
 if not rec:continue
 header,name=rec.split(b'\t',1);mode,kind,oid=header.decode().split();name=name.decode();assert kind=='blob';proc.stdin.write((oid+'\n').encode());proc.stdin.flush();hdr=proc.stdout.readline().split();length=int(hdr[2]);body=proc.stdout.read(length);assert proc.stdout.read(1)==b'\n';row=dict(path=name,mode=mode,object=oid,bytes=length,sha256=sha(body));full.append(row)
 p=R/name
 if p.is_file():
  assert p.read_bytes()==body;row=dict(row,native=native(p));physical.append(row);selected.append(('source/'+name,p,body))
proc.stdin.close();assert proc.wait()==0
(O/'original-full-Git-map.json').write_text(json.dumps(full,indent=2)+'\n');(O/'original-full-native-map.json').write_text(json.dumps(physical,indent=2)+'\n')
# Source header/kernel references are immutable source only, never SDK executions.
ref=V/'eof-finding/bindings.json';s=json.loads(ref.read_bytes());assert len(s['wires'])==18
for r in s['source_records']:
 for key in ['original','retained']:assert sha(Path(r[key]).read_bytes())==r['sha256']
for r in s['wires']:assert sha(Path(r['path']).read_bytes())==r['sha256']
selected.append(('sdk/scanner.go',Path(s['source_records'][3]['original']),Path(s['source_records'][3]['original']).read_bytes()))
rows=[];raw=io.BytesIO()
with tarfile.open(fileobj=raw,mode='w')as t:
 for name,p,b in selected:
  st=native(p);entry=tarfile.TarInfo(name);entry.mode=st['st_mode']&0o777;entry.uid=st['st_uid'];entry.gid=st['st_gid'];entry.mtime=st['st_mtime_ns']/1e9;entry.size=len(b);t.addfile(entry,io.BytesIO(b));assert native(p)==st;rows.append(dict(member=name,original=str(p),bytes=len(b),sha256=sha(b),native=st))
b=raw.getvalue();comp=gzip.compress(b,mtime=0);q=O/'before-edit.tar.gz';q.write_bytes(comp);assert gzip.decompress(comp)==b
with tarfile.open(fileobj=io.BytesIO(comp),mode='r:gz')as t:
 assert len(t.getmembers())==len(rows)
 for r in rows:
  e=t.getmember(r['member']);assert sha(t.extractfile(e).read())==r['sha256']and e.mode==r['native']['st_mode']&0o777 and e.uid==r['native']['st_uid']and e.gid==r['native']['st_gid']
# Full parent85 preparation archive is reused, with every payload freshly bound.
prefix=R/'migration/evidence/skills-native-764/json-depth-float-preparation';ret=json.loads((prefix/'retention.json').read_bytes());archive=R/ret['archive'];cb=archive.read_bytes();assert sha(cb)==ret['archive_sha256'];assert sha(gzip.decompress(cb))==ret['payload_sha256'];assert len(ret['members'])==85
with tarfile.open(fileobj=io.BytesIO(cb),mode='r:gz')as t:
 for r in ret['members']:
  e=t.getmember(r['member']);assert sha(t.extractfile(e).read())==r['sha256']and e.mode==r['mode']&0o777 and e.uid==r['uid']and e.gid==r['gid']
receipt=dict(source=H,source_tree=git('rev-parse',H+'^{tree}').decode().strip(),all_Git_rows=len(full),all_native_source_rows=len(physical),full_review_bound_records=68,review_receipt_and_manifest=2,original_EOF_wires=18,original_SDK_source=1,members=rows,archive=str(q),archive_sha256=sha(comp),raw_payload_sha256=sha(b),reused_author_packet=dict(path=str(archive),sha256=sha(cb),members=85,retention_path=str(prefix/'retention.json'),retention_sha256=sha((prefix/'retention.json').read_bytes())),compiler_SDK_product_execution=0,available_bytes=os.statvfs(O).f_bavail*os.statvfs(O).f_frsize)
(O/'before-edit.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps({k:v for k,v in receipt.items()if k!='members'}))
