# Skills764 F10 active EOF-state correction: SOURCE-only handoff

Clean source `19efc8d5c39c7a99d82ae46b10a5300840dd4538`, branch
`issue/764-json-eof-state-correction`, worktree
`/workspace/symaira-skills764-eof-correction`. Parent publication
`fb43004be5e89e3f489f8a3f38c1224e2a98ff0e` / source `114f63fb` remains
unchanged and clean. Normal main935 and common cc3/e003 CI ancestors remain.
This handoff requests full different-author source review by800; author does
not approve publication, runtime, merge or Skills764 closure. No resource lease.

Original full final review SHA
`591aa17c91178fb5cb6b670c13e259561a4407f44b31c5ad54854f6c8ef4991f`, receipt
`acc5cf466b6f79c621a4146e9f761f84f0d6fb3892996d325a520dfa7ac0b588` and all68
bound proofs were read and preserved before edits with complete raw/native
metadata. The new before-edit archive has665 materialized original source
bodies, complete independent proof+receipt/manifest,18 exact wire observations
and the full SDK scanner source. Full original Git has3118 mode/body bindings.
The85 parent preparation members,345 older before-edit members,1919 initial
original members and27 SDK/dependency members are fully rebound/reused without
another copy of their original gzip payloads. Git-only1217 Go archive entries
retain their original synthetic mode/uid0/gid0 headers, distinct from recorded
filesystem metadata. No original evidence or prior failed observation changes.

Production changes only the scoped MCP scanner's required-token byte lookup.
Go eof() calls its active state with ASCII space, preserving its specific error
before a generic EOF fallback. A single local `token_byte` helper supplies that
byte to five existing grammar/context branches, which reject it; generic
container/value-start/ordinary-string lookups retain the old end error. The
entire old scanner is restored byte-for-byte by removing that helper and
reverting those five lookups. No token/input normalization, alternate parser,
new length/depth limit or error rewrite is added. Full syntax still precedes
typed fields and preserves null parse ID/full message/status/stderr/state.

Permanent tests cover23 partial-token states, syntax-before-type, completed
and ordinarily unclosed token/container contrasts, actual invalid-byte
contrasts and every one of the eighteen exact line/framed original fixtures.
All source changes are below400 lines (scanner240, new tests177). F1–F9,
Core's exact finite JSON converter, all Usage behavior, Skills library, CLI,
Gateway, Go production/fixtures, Cargo identities and workflow gates remain
exact parent bytes.273 package records and all3110 protected old Git bodies
are unchanged; only eight existing paths change, with21 additive source/data
files. Full final source map has3139 Git records and684 physical native records.

Prepared process cases append186 after the exact926Unix/884Windows prefix,
giving1112/1070. They retain all eighteen independent raw wires and exercise
metadata/ignored-arguments/typed-first positions, generic EOF and valid
counterparts. Exact170 new parse IDs use the strict nil-ID/full-message
comparator with full filesystem equality including raw hashes/validated locks.
Valid inputs use the unchanged original comparator; every previous parse
branch remains identical after removing only the EOF dispatch additions. The
seven old actual-input controls remain unchanged. Two new prepared genuine
EOF-input controls require full real matching valid baselines before input
mutation, and verify exact parse error/status/stderr and all filesystem fields.
All nine controls and all current product runs remain unexecuted.

Actual pure checks pass: exact corpus prefixes/ID/input bindings on Unix and
Windows source projections;18 physical/Git/reviewer wire matches;24 labeled
synthetic comparator mutations across both transports; five-lookup scanner
projection and SDK EOF/context source trace; three changed/new Rustfmt files;
ten Python AST owners; Actionlint and diff checks; full old/new sources/native
modes, before-edit and85/345/1919/27 member archive roundtrips/owners. These are
source checks, not actual Go/Native parser, TLS, SDK, Cargo, Clippy or runtime.

Prepared tools were corrected without hiding failures. The first Rust test
source used nonexistent `is_parse_error` before source inspection corrected it
to the existing `is_parse`; its full draft is retained. The first pure SDK
context projection compared a raw backslash against Go's escaped string
literal; its original failure/script remain and JSON source quoting fixes
that checker. The first archive verifier assumed native fields for1217 older
Git-only Go members; its original failure/script remain, and complete original
Git modes plus unchanged synthetic owner0 headers are now verified explicitly.
No product execution or candidate criterion changed for those helper issues.

ADR: `docs/adr/skills-native-json-eof-764.md`. The scoped contract matrix and
README state current prepared counts/limits; prior records retain historical
identities. New wire files are binary-attributed before the source commit,
retaining all literal CRLF bytes. Production/source/test criteria and old
comparators are not loosened. Original targeted branches remain immutable.

Required next: full different-author source review, separate audited resource
allocation, full affected Core/MCP/Gateway/Skills/CLI compilation and strict
checks, full original/additive actual pinned Go/native process/state gates,
all nine meaningful real-input controls, existing path/config/owner/lifecycle
and #621/#794/other independent gates, native Linux/macOS/Windows CI. Copied SDK
source is not platform proof. Full #764 and broader migration remain open.
Source tree physical size7,857,915B before evidence, proof budget<20MiB and floor
700MiB respected. No compiler/SDK/product/SQLite/Target/cache/ports/GitHub action,
no borrowed target, no publication/PR/merge/issue mutation occurred.
