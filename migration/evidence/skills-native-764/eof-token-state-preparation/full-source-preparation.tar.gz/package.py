import gzip,hashlib,io,json,os,tarfile,subprocess
from pathlib import Path
R=Path('/workspace/symaira-skills764-eof-correction');O=Path('/workspace/review-proof/skills764-eof-correction-preparation');sha=lambda b:hashlib.sha256(b).hexdigest();H=subprocess.check_output(['git','-C',str(R),'rev-parse','HEAD']).decode().strip();assert H=='19efc8d5c39c7a99d82ae46b10a5300840dd4538';assert subprocess.check_output(['git','-C',str(R),'status','--porcelain'])==b''
rows=[];raw=io.BytesIO()
with tarfile.open(fileobj=raw,mode='w')as t:
 for p in sorted(O.iterdir()):
  if not p.is_file():continue
  b=p.read_bytes();s=p.lstat();entry=tarfile.TarInfo(p.name);entry.mode=s.st_mode&0o777;entry.uid=s.st_uid;entry.gid=s.st_gid;entry.mtime=s.st_mtime_ns/1e9;entry.size=len(b);t.addfile(entry,io.BytesIO(b));rows.append(dict(original=str(p),member=p.name,bytes=len(b),sha256=sha(b),mode=s.st_mode,uid=s.st_uid,gid=s.st_gid,mtime_ns=s.st_mtime_ns,ctime_ns=s.st_ctime_ns,device=s.st_dev,inode=s.st_ino))
payload=raw.getvalue();compressed=gzip.compress(payload,mtime=0);d=R/'migration/evidence/skills-native-764/eof-token-state-preparation';d.mkdir(parents=True);archive=d/'full-source-preparation.tar.gz';archive.write_bytes(compressed);assert gzip.decompress(archive.read_bytes())==payload
with tarfile.open(fileobj=io.BytesIO(compressed),mode='r:gz')as t:
 assert len(t.getmembers())==len(rows)
 for row in rows:
  m=t.getmember(row['member']);assert sha(t.extractfile(m).read())==row['sha256'];assert m.mode==row['mode']&0o777 and m.uid==row['uid']and m.gid==row['gid']
receipt=dict(source=H,archive=str(archive.relative_to(R)),archive_sha256=sha(compressed),archive_bytes=len(compressed),payload_sha256=sha(payload),full_roundtrip=True,members=rows,reused_immutable_parent_archives=json.loads((O/'final-verification.json').read_bytes())['full_reused_roundtrips'],source_only=True,current_product_SDK_compiler_Cargo_SQLite_Target_cache_ports=0)
(d/'retention.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(dict(source=H,members=len(rows),archive_bytes=len(compressed),archive_sha256=sha(compressed))))
