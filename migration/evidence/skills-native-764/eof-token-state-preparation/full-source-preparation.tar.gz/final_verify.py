import ast,hashlib,gzip,io,json,os,subprocess,tarfile,tomllib
from pathlib import Path
R=Path('/workspace/symaira-skills764-eof-correction');P=Path('/workspace/symaira-skills764-json-corrections');O=Path('/workspace/review-proof/skills764-eof-correction-preparation');OLD='fb43004be5e89e3f489f8a3f38c1224e2a98ff0e';sha=lambda b:hashlib.sha256(b).hexdigest();git=lambda *a:subprocess.check_output(['git','-C',str(R),*a]);H=git('rev-parse','HEAD').decode().strip()
assert git('status','--porcelain')==b'' and subprocess.check_output(['git','-C',str(P),'status','--porcelain'])==b'';assert subprocess.check_output(['git','-C',str(P),'rev-parse','HEAD']).decode().strip()==OLD
source={};native={};proc=subprocess.Popen(['git','-C',str(R),'cat-file','--batch'],stdin=subprocess.PIPE,stdout=subprocess.PIPE)
for rec in git('ls-tree','-r','-z',H).split(b'\0'):
 if not rec:continue
 h,n=rec.split(b'\t',1);mode,kind,oid=h.decode().split();name=n.decode();assert kind=='blob';proc.stdin.write((oid+'\n').encode());proc.stdin.flush();hdr=proc.stdout.readline().split();size=int(hdr[2]);b=proc.stdout.read(size);assert proc.stdout.read(1)==b'\n';source[name]=dict(mode=mode,object=oid,bytes=size,sha256=sha(b));p=R/name
 if p.is_file():
  assert p.read_bytes()==b;st=p.lstat();assert bool(st.st_mode&0o111)==(mode=='100755');native[name]=dict(sha256=sha(b),bytes=size,native={k:getattr(st,k)for k in ['st_mode','st_uid','st_gid','st_size','st_mtime_ns','st_ctime_ns','st_dev','st_ino','st_nlink','st_blocks']})
proc.stdin.close();assert proc.wait()==0
before=json.loads((O/'original-full-Git-map.json').read_bytes());changed=[];protected=[]
for row in before:
 n=row['path'];assert n in source and row['mode']==source[n]['mode'];equal=all(row[k]==source[n][k]for k in ['mode','object','bytes','sha256']);(protected if equal else changed).append(n)
expected={'.gitattributes','migration/contract-matrix.csv','rust/symbrain-mcp/src/raw_skills.rs','rust/symbrain-mcp/src/raw_skills_syntax.rs','scripts/skills-native-oracle/README.md','scripts/skills-native-oracle/json_cases.py','scripts/skills-native-oracle/json_compare.py','scripts/skills-native-oracle/run.py'};assert set(changed)==expected
for root in ['rust/symbrain-core/','rust/symbrain-skills/','rust/symbrain-usage/','rust/symbrain-cli/','rust/symbrain-gateway/','.github/workflows/']:
 assert all(n in protected for n in source if n.startswith(root)),root
assert (R/'Cargo.lock').read_bytes()==git('show',OLD+':Cargo.lock')and(R/'Cargo.toml').read_bytes()==git('show',OLD+':Cargo.toml');assert len(tomllib.loads((R/'Cargo.lock').read_text())['package'])==273
for n in source:
 if n.endswith('.go')or n in ['go.mod','go.sum']:assert n in protected,n
for rev in ['114f63fb0d5b1b4b9ea97b03d2ca5d2a7f630f27','9353520a34c5819c7d0a6cd58d3bfaa2b22b045b','cc3f4e62dcb133b616c6b58c135463ad81058801','e00365333a041118dd0598157137e0ba3586013d']:assert subprocess.run(['git','-C',str(R),'merge-base','--is-ancestor',rev,H]).returncode==0
# Strip only additive wrapper lines to bind all existing source/process criteria.
for n,remove in [('rust/symbrain-mcp/src/raw_skills.rs',b'\n#[cfg(test)]\n#[path = "raw_skills_eof_tests.rs"]\nmod eof_tests;\n'),('scripts/skills-native-oracle/json_cases.py',b'from eof_cases import cases as eof_cases\n'),('scripts/skills-native-oracle/run.py',b'from eof_cases import run_controls as eof_controls\n')]:
 b=(R/n).read_bytes();assert b.count(remove)==1;b=b.replace(remove,b'')
 if n.endswith('json_cases.py'):b=b.replace(b'    rows.extend(eof_cases(root, incoming))\n',b'')
 if n.endswith('run.py'):b=b.replace(b'            eof_controls(report, lambda: output.write_text(json.dumps(report, indent=2) + "\\n"),\n                         binaries, root, retained, env, invoke, incoming)\n',b'')
 assert b==git('show',OLD+':'+n),n
n='scripts/skills-native-oracle/json_compare.py';b=(R/n).read_bytes();b=b.replace(b'from eof_cases import is_parse_case as eof_parse_case\n',b'').replace(b'    if eof_parse_case(name):\n        return True\n',b'').replace(b"    if eof_parse_case(name):\n        return parse_view(go) == parse_view(rust) and go['filesystem'] == rust['filesystem']\n",b'');assert b==git('show',OLD+':'+n)
# Complete old and new review packets, raw body hashes and native header metadata.
pres=json.loads((O/'before-edit.json').read_bytes());archives=[(Path(pres['archive']),pres['members'],pres['archive_sha256'])]
oldpres=json.loads(Path('/workspace/review-proof/skills764-json-corrections-preparation/before-edit.json').read_bytes());archives.append((Path('/workspace/review-proof/skills764-json-corrections-preparation/before-edit.tar.gz'),oldpres['members'],'118aab6923173c7438f52946d691fc3c6bdb8f6438f7090be42be4d865b27063'))
root=Path('/workspace/symaira-skills764-byte-contracts/migration/evidence/skills-native-764/byte-corrections');ret=json.loads((root/'original/retention.json').read_bytes());archives.append((root/'original/full-review-and-sources.tar.gz',ret['members'],ret['archive_sha256']));ret=json.loads((root/'checks/boundary-source-retention.json').read_bytes());archives.append((root/'checks/inspected-sdk-dependency-owners.tar.gz',ret['files'],ret['sha256']));ret=json.loads((P/'migration/evidence/skills-native-764/json-depth-float-preparation/retention.json').read_bytes());archives.append((P/ret['archive'],ret['members'],ret['archive_sha256']))
roundtrips=[]; historical_git_trees={}
for p,rows,wanted in archives:
 compressed=p.read_bytes();assert sha(compressed)==wanted
 with tarfile.open(fileobj=io.BytesIO(compressed),mode='r:gz')as t:
  assert len(t.getmembers())==len(rows)
  for r in rows:
   m=t.getmember(r['member']);body=t.extractfile(m).read();assert sha(body)==r['sha256']and len(body)==r['bytes']
   meta=r.get('native',r);mode=meta.get('st_mode',meta.get('mode'));uid=meta.get('st_uid',meta.get('uid'));gid=meta.get('st_gid',meta.get('gid'))
   if mode is None:
    ref=r['git_head']
    if ref not in historical_git_trees:
     historical_git_trees[ref]={record.split(b'\t',1)[1].decode():record.split(b' ',1)[0].decode()for record in git('ls-tree','-r','-z',ref).split(b'\0')if record}
    mode=int(historical_git_trees[ref][r['path']],8);uid=gid=0 # Original Git-only archive headers, not filesystem owners.
   assert m.mode==mode&0o777 and m.uid==uid and m.gid==gid
 roundtrips.append(dict(path=str(p),members=len(rows),sha256=wanted,all_payload_and_mode_owner_bound=True))
# Exactly eighteen original wire files, never LF-normalized or regenerated.
eof=json.loads(Path('/workspace/review-proof/review-pr800-skills764-json-corrections/eof-finding/bindings.json').read_bytes())
for r in eof['wires']:
 n='scripts/skills-native-oracle/eof-review-inputs/'+Path(r['path']).name;assert source[n]['sha256']==r['sha256'];assert(R/n).read_bytes()==Path(r['path']).read_bytes()
assert not(R/'target').exists()and not list((R/'scripts').rglob('__pycache__'))
physical=sum(p.stat().st_size for p in R.rglob('*')if p.is_file());assert physical<20*1024*1024;free=os.statvfs(O).f_bavail*os.statvfs(O).f_frsize;assert free>=734003200
(O/'full-current-source.json').write_text(json.dumps(dict(head=H,files=source,native=native,changed_existing=changed),indent=2)+'\n');result=dict(source=H,parent=OLD,full_Git_rows=len(source),full_native_rows=len(native),protected_original_bodies=len(protected),changed_existing=changed,all_Core_Usage_Skills_CLI_Gateway_workflows_Cargo_Go_unchanged=True,all_273_packages_unchanged=True,full_reused_roundtrips=roundtrips,original18wire_git_physical_equal=True,physical_bytes=physical,source_original_clean_unchanged=True,prepared_totals=[1112,1070],prepared_actual_input_controls=9,current_SDK_compiler_product_SQLite_Target_cache_ports=0,available_bytes=free)
(O/'final-verification.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items()if k!='full_reused_roundtrips'}))
