from pathlib import Path
import gzip,hashlib,json,subprocess,tarfile,io,re
repo=Path('/workspace/symaira-memory763-ui'); source='824a95e0bdbe6a25108e1dbadaaebf7d89dc8cc4'; prod='d1f4faa77dc722da59a9cea1ff000566ce033f8f'; oracle='dcddcef0df5789123c7c9a7ebe6e01f10e941f2c'
def digest(data): return hashlib.sha256(data).hexdigest()
def sha(p):return digest(p.read_bytes())
def git(*args):return subprocess.check_output(['git',*args],cwd=repo)
assert git('rev-parse','HEAD').decode().strip()==source
assert not git('status','--porcelain')
assert not git('diff',prod,source,'--','rust','Cargo.toml','Cargo.lock','.github/workflows/memory-http-native.yml')
full=Path('/tmp/symaira-memory763-final-full');receipt=json.loads((full/'receipt.json').read_text());http=json.loads((full/'http.json').read_text())
assert receipt['head']==source and not receipt['candidate_dirty']
manifest=receipt['frozen_source_sha256'];arc=git('archive',oracle)
with tarfile.open(fileobj=io.BytesIO(arc)) as tar:
 files={m.name:sha(full/'frozen-go'/m.name) for m in tar if m.isfile() and (assertion:=digest(tar.extractfile(m).read()))==sha(full/'frozen-go'/m.name)}
assert files==manifest
assert receipt['go_binary_sha256']==sha(full/'frozen-go-cli')
for p in ['http.json','wrong-secret.json','empty-state.json']:
 d=json.loads((full/p).read_text());assert d['head']==source and not d['candidate_dirty']
 for name,value in d['source_manifest'].items():assert sha(repo/name)==value,name
 for name,value in d['frozen_go_source_sha256'].items():assert sha(full/'frozen-go'/name)==value,name
 assert d['native_sha256']==sha(Path(d['native']))
for r in receipt['records']:
 path=full/((r['mode'] or 'http')+'.json');assert sha(path)==r['report_sha256']
assert len(http['records'])==52 and all(r['match'] for r in http['records'][3:])
assert len(http['limits'])==7 and all(r['state_unchanged'] and r['state_before']==r['state_after'] for r in http['limits'])
assert all(r['exit']==0 and r['listener_closed'] for r in http['shutdown'])
for r in http['limits']:assert 'sync_oplog' in r['state_before'] and 'memories_fts' in r['state_before']
origin=json.loads((full/'same-origin.json').read_text());assert len(origin['records'])==18
assert all(r['exit']==0 and r['listener_closed'] for r in origin['shutdown'])
dom=json.loads((full/'dom.json').read_text())
for r in dom['runs']:assert sha(Path(r['report']))==r['sha256'] and r['exit']==0
assert all(r['exit']==0 and r['listener_closed'] for r in dom['shutdown'])
reads=json.loads(Path('/tmp/symaira-memory763-final-cli-read.json').read_text());assert reads['candidate_revision']==source and not reads['candidate_dirty'] and reads['cases']==reads['passed']==590
writes_root=Path('/tmp/symaira-memory763-final-cli-write');writes=json.loads((writes_root/'receipt.json').read_text());assert writes['candidate_revision']==source and not writes['candidate_dirty']
for d in [reads,writes]:
 for name,value in d['candidate_source_sha256'].items():assert sha(repo/name)==value,name
 assert d['rust_binary_sha256']==sha(repo/'target/debug/symbrain')
for name,value in writes['report_sha256'].items():assert sha(writes_root/name)==value,name
assert len(writes['controls'])==3 and all(r['detected'] and r['exit']==1 for r in writes['controls'])
assert sum(map(int,re.findall(r'test result: ok\. (\d+) passed',Path('/tmp/symaira-memory763-sourceD1-tests.log').read_text())))==320
oldroot=Path('/workspace/oracles/symaira-memory763-source813-binaries');old=json.loads((oldroot/'receipt.json').read_text());by_sha={r['sha256']:r for r in old['artifacts']}
archive=Path('/workspace/oracles/symaira-memory763-final-binaries');archive.mkdir(exist_ok=False)
artifacts=[];paths=list((repo/'target').rglob('*'))+[full/'frozen-go-cli',Path('/tmp/symaira-memory763-source9b-full/frozen-go-cli'),Path('/tmp/symaira-memory763-sourceD1-full/frozen-go-cli')]
for path in sorted(paths):
 if not path.is_file():continue
 with path.open('rb') as f:kind=f.read(4)
 if kind!=b'\x7fELF':continue
 data=path.read_bytes();value=digest(data)
 if value in by_sha:dest=Path(by_sha[value]['archive'])
 else:
  dest=archive/(value+'.gz')
  if not dest.exists():dest.write_bytes(gzip.compress(data,compresslevel=6,mtime=0))
 assert gzip.decompress(dest.read_bytes())==data
 artifacts.append(dict(path=str(path),bytes=len(data),sha256=value,archive=str(dest),archive_sha256=sha(dest)))
binreceipt=dict(snapshot_head=source,production_head=prod,attribution='All current ELF artifact paths are a snapshot; source-bound test and primary executable mappings below are the executed artifacts. Stale auxiliary artifacts are not relabeled as compiled at this source.',prior_receipt=str(oldroot/'receipt.json'),prior_receipt_sha256=sha(oldroot/'receipt.json'),artifacts=artifacts)
(archive/'receipt.json').write_text(json.dumps(binreceipt,indent=2)+'\n')
evidence=repo/'migration/evidence/memory-ui-763/native-owner-824';evidence.mkdir(exist_ok=False)
preserved=[]
def retain(path,label):
 if not path.is_file():return
 data=path.read_bytes();dest=evidence/label;dest=dest.with_name(dest.name+'.gz');dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(gzip.compress(data,compresslevel=6,mtime=0))
 assert gzip.decompress(dest.read_bytes())==data
 preserved.append(dict(original=str(path),retained=dest.relative_to(repo).as_posix(),bytes=len(data),sha256=digest(data),retained_sha256=sha(dest)))
for p in sorted(Path('/tmp').glob('symaira-memory763*')):
 if p.is_file():retain(p,'original-files/'+p.name)
 elif p.is_dir() and p.name!='symaira-memory763-dom':
  for f in sorted(p.rglob('*')):
   rel=f.relative_to(p)
   if rel.parts[0] in ['frozen-go','build-home'] or f.name.startswith('frozen-go-cli'):continue
   retain(f,'original-roots/'+p.name+'/'+str(rel))
for name in ['package.json','package-lock.json']:retain(Path('/tmp/symaira-memory763-dom')/name,'dom-dependencies/'+name)
retain(archive/'receipt.json','binary-archives/final-receipt.json');retain(oldroot/'receipt.json','binary-archives/source813-receipt.json')
source_files=git('ls-files','rust/symbrain-memory','rust/symbrain-cli','scripts/memory-http-oracle','.github/workflows/memory-http-native.yml','Cargo.toml','Cargo.lock').decode().splitlines()
proof=dict(validation_source=source,production_source=prod,normal_approved_store_parent='27001b1bd6948cd7985773655f3a43bc41e947b3',base_main='e3dbda6cbb95429237d15a9b176209b7d107792c',production_unchanged_since_D1=True,production_tree_sha256={n:sha(repo/n) for n in source_files},frozen_revision=oracle,full_frozen_source_files=len(manifest),http_source_files=len(http['source_manifest']),counts=dict(http_pairs=52,refused_full_sqlite_state_boundaries=7,http_actual_failure_controls=2,same_origin_pairs=18,native_dom_checks=11,original_dom_defect_checks=5,cli_reads=590,cli_sets=60,cli_deletes=16,cli_delegated_boundaries=13,cli_failure_output_pairs=10,cli_actual_failure_controls=3,affected_ordinary_tests=320),primary_binaries=[r for r in artifacts if r['path'] in [str(repo/'target/debug/examples/http_probe'),str(repo/'target/debug/symbrain'),str(full/'frozen-go-cli')]],elf_paths=len(artifacts),elf_unique_sha256=len({r['sha256'] for r in artifacts}),final_archive_receipt_sha256=sha(archive/'receipt.json'),retained_original_files=preserved,limits=['Linux positive owner slice, not full memory serve CLI admission; native three-OS CI and independent review remain pending.','Original source007 parent controls overlapped Doctor11434; retained as historical, replaced by exclusive source813 and final824 runs.','SourceD1 and earlier HTTP snapshots covered six named domain tables; only final824 includes every SQLite table/column/blob including sync/FTS/association state.','DOM is actual jsdom JS/network runtime with explicit browser-equivalent write Origin injection, not graphical browser/CSP/pixel proof.','All production/Cargo/workflow bytes equal tested D1; final824 strengthens scripts only. Ordinary320 and strict D1 receipts are retained unchanged, not relabeled.'])
(evidence/'validation.json').write_text(json.dumps(proof,indent=2)+'\n')
print(json.dumps(dict(retained=len(preserved),elf_paths=len(artifacts),elf_unique=proof['elf_unique_sha256'],source_files=len(source_files),frozen_source_files=len(manifest),validation_sha256=sha(evidence/'validation.json'))))
