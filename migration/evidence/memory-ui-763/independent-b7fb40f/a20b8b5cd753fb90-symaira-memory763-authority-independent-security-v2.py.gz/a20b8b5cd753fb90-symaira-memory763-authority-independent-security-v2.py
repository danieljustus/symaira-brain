import sys,json,sqlite3,base64,hmac,hashlib,socket,time,subprocess
from pathlib import Path
sys.path.insert(0,'/workspace/symaira-memory763-authority/scripts/memory-http-oracle')
import support as s
from replay import semantic
ROOT=Path('/tmp/symaira-memory763-authority-independent-security-v2');ROOT.mkdir(exist_ok=False)
NATIVE=Path('/tmp/symaira-memory763-authority-independent-owner')
records=[];shutdown=[];peers=[];emb=s.Embeddings()
def signed(claims,header=b'{"alg":"HS256","typ":"JWT"}'):
 enc=lambda b:base64.urlsafe_b64encode(b).rstrip(b'=')
 unsigned=enc(header)+b'.'+enc(json.dumps(claims,separators=(',',':')).encode())
 return (unsigned+b'.'+enc(hmac.new(s.SECRET.encode(),unsigned,hashlib.sha256).digest())).decode()
def group(label, required=False):
 root=ROOT/label;root.mkdir();seedroot=root/'seed';env=s.owned_env(seedroot,emb.url);db,seed=s.seed(seedroot,env)
 result=[]
 for native,name,binary in [(False,'go',s.GO),(True,'native',NATIVE)]:
  owned=root/name;env=s.owned_env(owned,emb.url);target=owned/'current.db'
  if required:
   with (owned/'config/symmemory/config.toml').open('a') as f:f.write('[security]\nrequire_profile = true\n')
  with sqlite3.connect(db) as original,sqlite3.connect(target) as current:original.backup(current)
  peer=s.Peer(binary,owned,env,native,target,{'SYMMEMORY_SECURITY_REQUIRE_PROFILE':'true'} if required else None)
  result.append(peer);peers.append(peer)
 return result
def pair(ps,name,path='/api/list',method='GET',body=None,headers=None,status=200,readonly=True,parity=True):
 headers={'Authorization':'Bearer '+s.token()} if headers is None else headers
 observations=[]
 for p in ps:
  before=s.snapshot(p.database);raw=p.request(name,path,method,body,headers);after=s.snapshot(p.database)
  observations.append(dict(raw=raw,before=before,after=after,unchanged=before==after))
 row=dict(name=name,observations=observations,semantic_match=semantic(observations[0]['raw'])==semantic(observations[1]['raw']))
 records.append(row)
 assert all(o['raw']['status']==status for o in observations),row
 if readonly:assert all(o['unchanged'] for o in observations),name
 if parity:assert row['semantic_match'],row
 return row
try:
 ps=group('jwt');claims=dict(jti='owned-jwt-extra',iss='symaira-memory',sub='owned-human',iat=1,exp=4102444800)
 for name,token,expected in [('valid',signed(claims),200),('tampered-signature',signed(claims)[:-2]+'AA',401),('padded-signature',signed(claims)+'=',401),('four-segments',signed(claims)+'.x',401),('future-issued',signed(dict(claims,iat=4102444700)),200),('wrong-issuer',signed(dict(claims,iss='untrusted')),401),('empty-subject',signed(dict(claims,sub='')),401),('whitespace-subject',signed(dict(claims,sub='\t\n')),401),('signed-arbitrary-header',signed(claims,b'opaque-header'),200),('expired',signed(dict(claims,exp=1)),401)]:
  pair(ps,name,headers={'Authorization':'Bearer '+token},status=expected)
 for p in ps:shutdown.append(p.close());peers.remove(p)
 ps=group('roles')
 for subject in ['reader','unknown-role']:
  pair(ps,'delete-denied-'+subject,'/api/delete?id=owned-seed','DELETE',headers={'Authorization':'Bearer '+s.token(subject)},status=403)
 for p in ps:
  with sqlite3.connect(p.database) as c:c.execute('DROP TABLE profiles')
 pair(ps,'profile-lookup-error-fails-closed','/api/set','POST',{'content':'Amber fox'},status=403)
 for p in ps:shutdown.append(p.close());peers.remove(p)
 ps=group('required-profile',True)
 pair(ps,'required-profile-missing-write','/api/set','POST',{'content':'Amber fox'},headers={'Authorization':'Bearer '+s.token('missing-owned-subject')},status=403)
 pair(ps,'required-profile-missing-delete','/api/delete?id=owned-seed','DELETE',headers={'Authorization':'Bearer '+s.token('missing-owned-subject')},status=403)
 for p in ps:shutdown.append(p.close());peers.remove(p)
 ps=group('persistent-revoke')
 pair(ps,'revoke-other-owned-jti','/api/token/revoke','POST',{'jti':' owned-reader '},readonly=False)
 pair(ps,'revoked-reader-denied',headers={'Authorization':'Bearer '+s.token('reader')},status=401)
 pair(ps,'other-admin-still-valid',headers={'Authorization':'Bearer '+s.token('administrator')})
 for i,p in enumerate(ps):
  shutdown.append(p.close());peers.remove(p)
  replacement=s.Peer(s.GO if i==0 else NATIVE,p.root,p.env,i==1,p.database);ps[i]=replacement;peers.append(replacement)
 pair(ps,'persistent-revoke-after-restart',headers={'Authorization':'Bearer '+s.token('reader')},status=401)
 for p in ps:shutdown.append(p.close());peers.remove(p)
 ps=group('revoke-failure')
 for p in ps:
  with sqlite3.connect(p.database) as c:c.execute('DROP TABLE jwt_revocations')
 pair(ps,'persist-revoke-failure-reported','/api/token/revoke','POST',{'jti':'owned-owned-human'},status=500)
 pair(ps,'in-memory-revoke-still-denies',status=401)
 for p in ps:shutdown.append(p.close());peers.remove(p)
 ps=group('body-errors')
 for name,body in [('invalid-metadata-type',b'{"content":"Amber fox","metadata":{"x":2}}'),('invalid-entities-type',b'{"content":"Amber fox","entities":[2]}'),('invalid-working-type',b'{"content":"Amber fox","working":"true"}'),('trailing-nonspace',b'{"content":"Amber fox"} false')]:
  pair(ps,name,'/api/set','POST',body,status=400)
 # Safe admission must occur before Get/retrieval history on unsupported content.
 for p in ps:
  with sqlite3.connect(p.database) as c:c.execute("UPDATE memories SET metadata='{\"x\":\"alice@example.invalid\"}' WHERE id='owned-seed'")
 for name,path,method,body in [('unsafe-metadata-get','/api/get?id=owned-seed','GET',None),('unsafe-metadata-search','/api/search','POST',{'query':'Blue fox sample'})]:
  p=ps[1];before=s.snapshot(p.database);row=p.request(name,path,method,body,{'Authorization':'Bearer '+s.token()});after=s.snapshot(p.database)
  records.append(dict(name=name,native_only=True,raw=row,before=before,after=after,unchanged=before==after));assert row['status']==501 and before==after
 for p in ps:shutdown.append(p.close());peers.remove(p)
finally:
 for p in peers:shutdown.append(p.close())
 emb.close()
 Path(str(ROOT)+'.json').write_text(json.dumps(dict(native_sha256=s.digest(NATIVE),go_sha256=s.digest(s.GO),records=records,shutdown=shutdown,embedding_requests=emb.requests),indent=2)+'\n')
print(json.dumps(dict(records=len(records),all_pass=True)))
