from pathlib import Path
import gzip, hashlib, json, os, re, shutil, subprocess

source = Path('/workspace/symaira-memory763-ui/target')
destination = Path('/workspace/symaira-memory649-doctor/target')
publication = Path('/workspace/symaira-memory763-authority')
assert source.is_dir() and not source.is_symlink() and not destination.exists()
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=publication, text=True).strip() == '2c7d1c243b17fd4e85f78c26267a371a25472669'
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=publication)

def users():
    found = []
    for proc in Path('/proc').iterdir():
        if not proc.name.isdigit() or int(proc.name) == os.getpid():
            continue
        try:
            values = [os.readlink(proc/'exe'), os.readlink(proc/'cwd'), (proc/'maps').read_text()]
            for fd in (proc/'fd').iterdir():
                try:
                    values.append(os.readlink(fd))
                except OSError:
                    pass
            if any(str(source) == value or str(source)+'/' in value for value in values):
                found.append(proc.name)
        except (OSError, ProcessLookupError):
            pass
    return found

assert not users(), users()
known = {}
for directory in Path('/workspace/oracles').glob('symaira-memory763*'):
    for packed in directory.rglob('*.gz'):
        if re.fullmatch('[0-9a-f]{64}', packed.stem):
            known.setdefault(packed.stem, packed)
archive = Path('/workspace/oracles/symaira-memory763-authority-root-idle-binaries')
archive.mkdir(exist_ok=True)
assert not (archive/'receipt.json').exists()
records, verified, new = [], set(), []
for parent, _, names in os.walk(source):
    for name in names:
        path = Path(parent)/name
        if path.is_symlink() or not path.is_file():
            continue
        with path.open('rb') as raw:
            if raw.read(4) != b'\x7fELF':
                continue
        with path.open('rb') as raw:
            digest = hashlib.file_digest(raw, 'sha256').hexdigest()
        if digest not in known:
            packed = archive/(digest+'.gz')
            with path.open('rb') as raw, packed.open('wb') as encoded:
                with gzip.GzipFile(fileobj=encoded, mode='wb', mtime=0) as stream:
                    shutil.copyfileobj(raw, stream, 1 << 20)
            known[digest] = packed
            new.append(digest)
        if digest not in verified:
            with gzip.open(known[digest], 'rb') as decoded:
                assert hashlib.file_digest(decoded, 'sha256').hexdigest() == digest
            verified.add(digest)
        records.append({'path': str(path), 'bytes': path.stat().st_size, 'sha256': digest, 'archive': str(known[digest])})
assert records and not users()
receipt = {'publication': '2c7d1c243b17fd4e85f78c26267a371a25472669', 'tested_source': 'b7fb40fda3ec68526ad5b4eb5e05b285d3f00935', 'previous_target': str(source), 'next_target': str(destination), 'users': [], 'ELF_paths': len(records), 'unique': len(verified), 'new_archives': len(new), 'roundtrip_verified': True, 'current_artifacts': records, 'actual_executions_receipt': '/workspace/oracles/symaira-memory763-authority-independent-2c7-binaries/receipt.json', 'scope': 'Inactive cache reuse only; cached ELF files are not all current-source executions.', 'transferred': False}
(archive/'receipt.json').write_text(json.dumps(receipt, indent=2)+'\n')
source.rename(destination)
receipt['transferred'] = True
(archive/'receipt.json').write_text(json.dumps(receipt, indent=2)+'\n')
Path('/tmp/symaira-memory763-to-doctor649-cache-transfer.json').write_text(json.dumps(receipt, indent=2)+'\n')
print(json.dumps({key: value for key, value in receipt.items() if key != 'current_artifacts'}))
