from pathlib import Path
import json,subprocess,datetime
repo='danieljustus/symaira-brain'
def api(path):return json.loads(subprocess.check_output(['gh','api',path],text=True))
census=json.loads(Path('/tmp/symaira-obsolete-queued-actions-census.json').read_text())
records=[];out=Path('/tmp/symaira-obsolete-queued-actions-decisions.json')
for candidate in census['obsolete_candidates']:
 current=api(f'repos/{repo}/pulls?state=open&per_page=100')
 by={p['head']['ref']:p for p in current}
 branch=candidate['head_branch'];record={'candidate':candidate};records.append(record)
 if branch not in by or by[branch]['head']['sha']==candidate['head_sha']:
  record['decision']='skip: not an obsolete head of an existing open PR';continue
 run=api(f"repos/{repo}/actions/runs/{candidate['id']}")
 record['run_before']=run
 assert run['head_sha']==candidate['head_sha'] and run['head_branch']==branch
 if run['status']!='queued':record['decision']='skip: no longer queued';continue
 jobs=api(f"repos/{repo}/actions/runs/{candidate['id']}/jobs?per_page=100")
 record['jobs_before']=jobs
 record['current_pr']={'number':by[branch]['number'],'head':by[branch]['head']['sha']}
 if any(job['status']=='in_progress' for job in jobs['jobs']):
  record['decision']='skip: an actual job is already running';continue
 record['decision']='cancel obsolete queued run only; all completed proof/artifacts retained; current-head checks unchanged'
 out.write_text(json.dumps({'repository':repo,'time':datetime.datetime.now(datetime.timezone.utc).isoformat(),'records':records},indent=2)+'\n')
 result=subprocess.run(['gh','api',f"repos/{repo}/actions/runs/{candidate['id']}/cancel",'-X','POST','--silent'],capture_output=True,text=True)
 record['cancel_exit']=result.returncode;record['cancel_stderr']=result.stderr
 assert result.returncode==0,record
 record['run_after']=api(f"repos/{repo}/actions/runs/{candidate['id']}")
 out.write_text(json.dumps({'repository':repo,'time':datetime.datetime.now(datetime.timezone.utc).isoformat(),'records':records},indent=2)+'\n')
 print(candidate['id'],branch,record['decision'],flush=True)
out.write_text(json.dumps({'repository':repo,'time':datetime.datetime.now(datetime.timezone.utc).isoformat(),'records':records},indent=2)+'\n')
print('Recorded',len(records),'decisions; current heads and running jobs preserved',flush=True)
