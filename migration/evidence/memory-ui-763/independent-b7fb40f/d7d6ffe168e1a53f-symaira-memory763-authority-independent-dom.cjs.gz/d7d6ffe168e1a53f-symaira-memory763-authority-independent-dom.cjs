const fs=require('node:fs'),assert=require('node:assert/strict');
const {JSDOM,ResourceLoader,VirtualConsole}=require('/tmp/symaira-memory763-dom/node_modules/jsdom');
const [base,token,out]=process.argv.slice(2),records=[],resources=[],checks=[],errors=[];
class Owned extends ResourceLoader{fetch(url,opts){assert.equal(new URL(url).origin,base);resources.push(url);return super.fetch(url,opts);}}
const console=new VirtualConsole();console.on('jsdomError',e=>errors.push(String(e)));
const wait=async(p,name)=>{const end=Date.now()+5000;while(Date.now()<end){if(p()){checks.push(name);return;}await new Promise(r=>setTimeout(r,20));}throw Error(name);};
(async()=>{const dom=await JSDOM.fromURL(base+'/',{runScripts:'dangerously',resources:new Owned(),virtualConsole:console,beforeParse(w){w.fetch=async(url,opts)=>{assert.equal(new URL(url).origin,base);if(opts&&opts.method==='POST')opts.headers={...opts.headers,Origin:base};const r=await fetch(url,opts);records.push({url,options:opts,status:r.status,body_hex:Buffer.from(await r.clone().arrayBuffer()).toString('hex')});return r;};}});
 const d=dom.window.document,click=s=>d.querySelector(s).click();await wait(()=>d.readyState==='complete','assets-loaded');
 d.querySelector('#token-input').value=token;click('#auth-btn');await wait(()=>d.querySelector('#memories-body').textContent.includes('<img'),'list-literal-untrusted-html');
 assert.equal(d.querySelector('#memories-body img'),null);assert.equal(d.querySelector('#memories-body .content-cell').getAttribute('title'),d.querySelector('#memories-body .content-cell').textContent);checks.push('list-attribute-text-roundtrip');
 d.querySelector('#search-query').value='Blue fox sample';click('#search-btn');await wait(()=>d.querySelector('#search-body').textContent.includes('<img'),'search-literal-untrusted-html');assert.equal(d.querySelector('#search-body img'),null);
 click('[data-tab="rules"]');await wait(()=>d.querySelector('#rules-body').textContent.includes('<img'),'rules-literal-untrusted-html');assert.equal(d.querySelector('#rules-body img'),null);
 click('[data-tab="entities"]');await wait(()=>d.querySelector('#entities-body').textContent.includes('<img'),'entities-literal-untrusted-html');assert.equal(d.querySelector('#entities-body img'),null);
 assert.equal(dom.window.__owned_xss,undefined);assert(resources.every(r=>!r.includes('owned-xss')));assert.equal(errors.length,0);checks.push('no-execution-no-injected-resource');
 fs.writeFileSync(out,JSON.stringify({checks,records,resources,errors,limits:'Actual shipped JS/DOM and private native HTTP, not graphical browser/CSP enforcement'},null,2)+'\n');dom.window.close();
})().catch(e=>{fs.writeFileSync(out,JSON.stringify({checks,records,resources,errors,failure:String(e)},null,2)+'\n');process.exitCode=1;});
