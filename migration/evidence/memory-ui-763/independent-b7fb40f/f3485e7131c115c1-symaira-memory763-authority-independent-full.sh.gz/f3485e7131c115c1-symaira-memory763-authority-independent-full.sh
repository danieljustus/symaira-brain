set -euo pipefail
umask 022
. /home/agent/.cargo/env
export PATH=/workspace/toolchains/go1.26.7/bin:$PATH
export CARGO_TARGET_DIR=/workspace/symaira-memory763-ui/target CARGO_INCREMENTAL=0 CARGO_PROFILE_DEV_DEBUG=0 CARGO_PROFILE_TEST_DEBUG=0 CARGO_BUILD_JOBS=2
export PYTHONDONTWRITEBYTECODE=1
check_disk() { python3 - <<'PY'
import shutil
x=shutil.disk_usage('/workspace');assert x.free>=700*1024*1024,x
PY
}
check_disk
cargo build -p symbrain-memory --example http_probe --offline --locked > /tmp/symaira-memory763-authority-independent-build.log 2>&1
check_disk
cargo test -p symbrain-memory -p symbrain-cli --all-targets --all-features --offline --locked > /tmp/symaira-memory763-authority-independent-tests.log 2>&1
check_disk
cargo build -p symbrain-cli --bin symbrain --offline --locked > /tmp/symaira-memory763-authority-independent-cli-build.log 2>&1
cargo clippy -p symbrain-memory -p symbrain-cli --all-targets --all-features --offline --locked -- -D warnings > /tmp/symaira-memory763-authority-independent-clippy.log 2>&1
cargo fmt --all -- --check > /tmp/symaira-memory763-authority-independent-fmt.log 2>&1
/workspace/toolchains/bin/actionlint > /tmp/symaira-memory763-authority-independent-actionlint.log 2>&1
check_disk
python3 scripts/memory-http-oracle/run.py --native "$CARGO_TARGET_DIR/debug/examples/http_probe" --node /opt/codex/runtimes/codex-primary-runtime/dependencies/node/bin/node --jsdom /tmp/symaira-memory763-dom/node_modules/jsdom --report-dir /tmp/symaira-memory763-authority-independent-full-http > /tmp/symaira-memory763-authority-independent-full-http.log 2>&1
check_disk
python3 scripts/memory-cli-oracle/replay.py --go /workspace/oracles/symbrain-go-dcddcef0 --rust "$CARGO_TARGET_DIR/debug/symbrain" --report /tmp/symaira-memory763-authority-independent-read.json > /tmp/symaira-memory763-authority-independent-read.log 2>&1
python3 scripts/memory-cli-oracle/controls.py --go /workspace/oracles/symbrain-go-dcddcef0 --rust "$CARGO_TARGET_DIR/debug/symbrain" --report /tmp/symaira-memory763-authority-independent-read-controls.json > /tmp/symaira-memory763-authority-independent-read-controls.log 2>&1
check_disk
ss -ltn '( sport = :11434 )' > /tmp/symaira-memory763-authority-independent-11434-before.log
python3 scripts/memory-cli-oracle/write_gate.py --go /workspace/oracles/symbrain-go-dcddcef0 --rust "$CARGO_TARGET_DIR/debug/symbrain" --report-dir /tmp/symaira-memory763-authority-independent-write > /tmp/symaira-memory763-authority-independent-write.log 2>&1
ss -ltn '( sport = :11434 )' > /tmp/symaira-memory763-authority-independent-11434-after.log
