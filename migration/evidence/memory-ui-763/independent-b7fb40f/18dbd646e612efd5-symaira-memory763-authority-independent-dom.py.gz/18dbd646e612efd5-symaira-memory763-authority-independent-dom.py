import sys,json,sqlite3,subprocess
from pathlib import Path
sys.path.insert(0,'/workspace/symaira-memory763-authority/scripts/memory-http-oracle')
import support as s
root=Path('/tmp/symaira-memory763-authority-independent-dom');root.mkdir(exist_ok=False)
emb=s.Embeddings();peer=None;report={}
try:
 seedroot=root/'seed';env=s.owned_env(seedroot,emb.url);db,seed=s.seed(seedroot,env)
 text='<img src="/owned-xss" onerror="window.__owned_xss=1"> & "quote"'
 with sqlite3.connect(db) as c:
  c.execute('UPDATE memories SET content=? WHERE id=?',(text,'owned-seed'))
  c.execute('UPDATE rules SET content=?',(text,))
  c.execute('UPDATE entities SET name=?,description=?',(text,text))
 owned=root/'native';env=s.owned_env(owned,emb.url);target=owned/'current.db'
 with sqlite3.connect(db) as original,sqlite3.connect(target) as current:original.backup(current)
 native=Path('/tmp/symaira-memory763-authority-independent-owner');peer=s.Peer(native,owned,env,True,target)
 before=s.snapshot(target);command=['/opt/codex/runtimes/codex-primary-runtime/dependencies/node/bin/node','/tmp/symaira-memory763-authority-independent-dom.cjs','http://127.0.0.1:'+str(peer.port),s.token(),str(root/'dom.json')]
 r=subprocess.run(command,capture_output=True,timeout=25);report=dict(command=command,exit=r.returncode,stdout_hex=r.stdout.hex(),stderr_hex=r.stderr.hex(),native_sha256=s.digest(native),seed=seed,before=before,after=s.snapshot(target));assert r.returncode==0
finally:
 if peer:report['shutdown']=peer.close()
 emb.close();Path(str(root)+'.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(dict(checks=len(json.loads((root/'dom.json').read_text())['checks']),exit=report['exit'])))
