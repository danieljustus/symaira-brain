from pathlib import Path
import subprocess,json,re,hashlib,os,gzip
ROOT=Path('/workspace/symaira-memory763-authority');HEAD='2c7d1c243b17fd4e85f78c26267a371a25472669';SOURCE='b7fb40fda3ec68526ad5b4eb5e05b285d3f00935';ORACLE='dcddcef0df5789123c7c9a7ebe6e01f10e941f2c';P=Path('/tmp/symaira-memory763-authority-independent-full-http');sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def load(p):return json.loads(Path(p).read_bytes())
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()==HEAD
assert not subprocess.check_output(['git','status','--porcelain'],cwd=ROOT)
manifest_union={};go_union={}
def manifests(values,candidate=True):
 for name,digest in values.items():
  value=sha(ROOT/name)if candidate else hashlib.sha256(subprocess.check_output(['git','show',ORACLE+':'+name],cwd=ROOT)).hexdigest()
  assert digest==value,(name,digest,value)
  u=manifest_union if candidate else go_union
  assert name not in u or u[name]==digest
  u[name]=digest
http=load(P/'http.json');assert http['head']==HEAD and not http['candidate_dirty'] and len(http['records'])==52 and all(r['match']for r in http['records']if 'match'in r) and [r['id']for r in http['records']if 'match'not in r]==['root','css','js'] and [r['intentional_asset_delta']for r in http['records']if 'match'not in r]==[False,True,True];assert len(http['limits'])==7 and all(r['state_unchanged']and r['actual_native']['status']==501 and r['state_before']==r['state_after']for r in http['limits']);manifests(http['source_manifest'])
for record,asset in zip(http['records'][:3],['index.html','style.css','app.js']):
 assert bytes.fromhex(record['rust']['body_hex'])==(ROOT/'rust/symbrain-memory/assets/web'/asset).read_bytes() and record['go']['status']==record['rust']['status']==200
 if asset=='index.html':assert record['go']['body_hex']==record['rust']['body_hex']
 if asset=='style.css':assert b''.join(bytes.fromhex(record['go']['body_hex']).split())==b''.join(bytes.fromhex(record['rust']['body_hex']).split())
full=load(P/'receipt.json');assert full['head']==HEAD and not full['candidate_dirty']and full['go_version'].startswith('go version go1.26.7 ')and full['jsdom_version']=='26.1.0';manifests(full['frozen_source_sha256'],False)
for mode in ['wrong-secret','empty-state']:
 x=load(P/(mode+'.json'));assert not x['records'][-1]['match']and x['records'][-1]['id']=='cors-extension'
auth=load(P/'authority-http.json');assert len(auth['records'])==15 and all(r['match']for r in auth['records'])
for r in auth['records']:
 if r['pair'][0]['raw']['status']!=200 or r['pair'][0]['raw']['request_hex'].startswith('474554'):assert all(p['unchanged']for p in r['pair'])
 if 'compared_primary_row'in r['pair'][0]:assert r['pair'][0]['compared_primary_row']==r['pair'][1]['compared_primary_row']and all(p['fts_integrity']=='pass'for p in r['pair'])
for mode,case in [('omit-duplicate','duplicate-host-local-first-read'),('foreign-to-local','absolute-foreign-target-read')]:
 x=load(P/('authority-'+mode+'.json'));assert x['records'][-1]['name']==case and not x['records'][-1]['match']
transport=load(P/'transport.json');assert len(transport['records'])==8 and all(p['unchanged']for r in transport['records']for p in r['pair'])
origin=load(P/'same-origin.json');assert len(origin['records'])==18 and origin['head']==HEAD and not origin['candidate_dirty']
dom=load(P/'dom.json');assert len(dom['runs'])==2 and all(r['exit']==0 for r in dom['runs'])
checks=[len(load(r['report'])['checks'])for r in dom['runs']];assert checks==[11,5],checks
read=load('/tmp/symaira-memory763-authority-independent-read.json');assert read['candidate_revision']==HEAD and not read['candidate_dirty']and read['cases']==read['passed']==590 and not read['operator_home_used']and not read['fallback_available'];manifests(read['candidate_source_sha256']);manifests(read['immutable_go_cli_source_sha256'],False)
controls=load('/tmp/symaira-memory763-authority-independent-read-controls.json');assert len(controls['controls'])==2 and all(r['exit']==1 and r['cases']==r['rejected_cases']==32 for r in controls['controls'])
write=load('/tmp/symaira-memory763-authority-independent-write/receipt.json');assert write['candidate_revision']==HEAD and not write['candidate_dirty']and not write['operator_home_used']and not write['operator_credentials_in_runtime']and not write['paid_endpoints_used']and write['embedding_endpoints_owned'];manifests(write['candidate_source_sha256']);manifests(write['frozen_go_source_sha256'],False);assert len(write['controls'])==3 and all(r['exit']==1 and r['detected']for r in write['controls'])
for name,n in [('writes',60),('deletes',16),('fallback-boundaries',13),('write-failures',10)]:
 x=load('/tmp/symaira-memory763-authority-independent-write/'+name+'.json');assert x['passed']==x['total']==len(x['cases'])==n
log=Path('/tmp/symaira-memory763-authority-independent-tests.log').read_bytes();results=[tuple(map(int,m))for m in re.findall(rb'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;',log)];assert len(results)==33 and tuple(map(sum,zip(*results)))==(325,0,0)
assert b'Finished'in Path('/tmp/symaira-memory763-authority-independent-clippy.log').read_bytes()
for n in ['fmt','actionlint']:assert not Path('/tmp/symaira-memory763-authority-independent-'+n+'.log').read_bytes()
exe={p:sha(p)for p in re.findall(r'Running [^\n]+ \(([^\n]+)\)',log.decode())}
for p in ['/workspace/symaira-memory763-ui/target/debug/symbrain','/workspace/symaira-memory763-ui/target/debug/examples/http_probe',str(P/'frozen-go-cli'),'/tmp/symaira-memory763-authority-independent-owner','/tmp/symaira-memory763-authority-independent-cli','/tmp/symaira-memory763-authority-independent-824-owner']:exe[p]=sha(p)
assert exe['/workspace/symaira-memory763-ui/target/debug/examples/http_probe']==http['native_sha256']==full['native_binary_sha256']=='94f699d51aab08d7e865c2b9015bf99a479cdfc486e94d45c7c128fdd5ba2102'
assert exe['/workspace/symaira-memory763-ui/target/debug/symbrain']==read['rust_binary_sha256']==write['rust_binary_sha256']=='255d248e0bf951126bd1a28381889ec82618380586b1906d27a982f29f66cc5f'
old=load(ROOT/'migration/evidence/memory-ui-763/independent-review-824/preservation.json');oldhost=next(r for r in old['retained_files']if r['original']=='/tmp/symaira-memory763-independent-host.json');original= json.loads(gzip.decompress((ROOT/'migration/evidence/memory-ui-763/independent-review-824'/oldhost['retained']).read_bytes()));canonical=lambda text:re.sub(rb'127\.0\.0\.1:[0-9]+',b'127.0.0.1:<owned-port>',bytes.fromhex(text))
for earlier,current in zip(original['records'],auth['records'][:12]):
 assert earlier['name']==current['name']
 for a,b in zip(earlier['pair'],current['pair']):assert canonical(a['request_hex'])==canonical(b['raw']['request_hex']),earlier['name']
extra=load('/tmp/symaira-memory763-authority-independent-extra.json');assert len(extra['records'])==20 and sum(r['semantic_equal']for r in extra['records'])==18 and all(r['status_reason_equal']and all(p['unchanged']for p in r['pair'])for r in extra['records'])
valid=load('/tmp/symaira-memory763-authority-independent-head-valid.json');assert len(valid['records'])==3 and all(r['semantic_equal']and all(p['unchanged']for p in r['pair'])for r in valid['records'])
security=load('/tmp/symaira-memory763-authority-independent-security-v2.json');assert len(security['records'])==27 and all(r.get('semantic_match',True)for r in security['records'])
x=load('/tmp/symaira-memory763-authority-independent-dom.json');assert x['exit']==0 and len(load('/tmp/symaira-memory763-authority-independent-dom/dom.json')['checks'])==7
r={'publication':HEAD,'source':SOURCE,'tests':[325,0,0],'summaries':33,'http':[52,7,2],'authority':[15,2],'transport':8,'origin':18,'DOM':checks,'read':[590,2,32],'write':[60,16,13,10,3],'novel':[20,18,2],'validHEAD':3,'security':[25,2],'hostileDOM':7,'original12_request_bytes_verified_only_owned_port_substitution':True,'source_manifest_union':len(manifest_union),'frozen_manifest_union':len(go_union),'fresh_executable_bindings':exe,'remaining_boundary':'HEAD early400 literal body omitted by nativeHyper; status/reason/auth/no-write preserved. Root explicitly accepts standards-compliant omission, documentation must narrow body parity. Native3/full763 gated.'}
Path('/tmp/symaira-memory763-authority-independent-verification.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({k:v for k,v in r.items()if k!='fresh_executable_bindings'},indent=2))
