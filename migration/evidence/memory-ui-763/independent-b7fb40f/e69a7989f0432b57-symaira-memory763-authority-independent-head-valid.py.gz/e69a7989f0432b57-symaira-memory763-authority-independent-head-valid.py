"""Read-only prepared probe; execute only after immutable target/endpoint handoff."""
from pathlib import Path
import os,sys,json,socket,http.client,sqlite3,time,subprocess,hashlib
repo=Path('/workspace/symaira-memory763-authority')
sys.path.insert(0,str(repo/'scripts/memory-http-oracle'))
import support as s
from replay import semantic
NATIVE=Path(os.environ['REVIEW_MEMORY_NATIVE'])
ROOT=Path(os.environ['REVIEW_MEMORY_REPORT']).with_suffix('.evidence');ROOT.mkdir(exist_ok=False)
emb=s.Embeddings();peers=[];records=[];shutdown=[]
# Literal malformed/supported authority inputs. HTTP version and method parser
# gaps, if observed, are classified separately rather than hidden by filtering.
cases=[
 ('malformed-host-at',b'GET',b'/api/list',[b'foreign@host'],b'HTTP/1.1'),
 ('malformed-host-hash',b'GET',b'/api/list',[b'localhost#anchor'],b'HTTP/1.1'),
 ('malformed-host-question',b'GET',b'/api/list',[b'localhost?x'],b'HTTP/1.1'),
 ('malformed-host-inner-space',b'GET',b'/api/list',[b'local host'],b'HTTP/1.1'),
 ('malformed-host-inner-tab',b'GET',b'/api/list',[b'local\thost'],b'HTTP/1.1'),
 ('malformed-host-raw-nonutf8',b'GET',b'/api/list',[b'localhost\xff\xe2\x82'],b'HTTP/1.1'),
 ('empty-host-relative',b'GET',b'/api/list',[b''],b'HTTP/1.1'),
 ('empty-host-absolute',b'GET',b'http://{OWN}/api/list',[b''],b'HTTP/1.1'),
 ('absolute-local-malformed-header',b'GET',b'http://{OWN}/api/list',[b'foreign@host'],b'HTTP/1.1'),
 ('absolute-local-userinfo',b'GET',b'http://owned:synthetic@{OWN}/api/list',[b'untrusted.invalid'],b'HTTP/1.1'),
 ('absolute-foreign-userinfo',b'GET',b'http://owned:synthetic@untrusted.invalid/api/list',[b'{OWN}'],b'HTTP/1.1'),
 ('absolute-https-local',b'GET',b'https://{OWN}/api/list',[b'untrusted.invalid'],b'HTTP/1.1'),
 ('http10-no-host-relative',b'GET',b'/api/list',[],b'HTTP/1.0'),
 ('http10-no-host-absolute',b'GET',b'http://{OWN}/api/list',[],b'HTTP/1.0'),
 ('http10-duplicate-host',b'GET',b'/api/list',[b'{OWN}',b'{OWN}'],b'HTTP/1.0'),
 ('head-malformed-host',b'HEAD',b'/api/list',[b'foreign@host'],b'HTTP/1.1'),
 ('head-duplicate-host',b'HEAD',b'/api/list',[b'{OWN}',b'{OWN}'],b'HTTP/1.1'),
 ('post-malformed-absolute-before-body',b'POST',b'http://{OWN}/api/set',[b'foreign@host'],b'HTTP/1.1'),
 ('post-duplicate-before-body',b'POST',b'/api/set',[b'{OWN}',b'untrusted.invalid'],b'HTTP/1.1'),
 ('post-missing-before-body',b'POST',b'http://{OWN}/api/set',[],b'HTTP/1.1'),
]
cases=[('head-local-positive',b'HEAD',b'/api/list',[b'{OWN}'],b'HTTP/1.1'),('head-absolute-local-positive',b'HEAD',b'http://{OWN}/api/list',[b'untrusted.invalid'],b'HTTP/1.1'),('head-set-method-denial',b'HEAD',b'/api/set',[b'{OWN}'],b'HTTP/1.1')]
def actual(peer,case):
 name,method,target,hosts,version=case;own=('127.0.0.1:'+str(peer.port)).encode();wire=method+b' '+target.replace(b'{OWN}',own)+b' '+version+b'\r\n'
 wire+=b''.join(b'Host: '+h.replace(b'{OWN}',own)+b'\r\n'for h in hosts)
 wire+=b'Authorization: Bearer '+s.token().encode()+b'\r\nConnection: close\r\n'
 if method==b'POST':wire+=b'Content-Length: 1000000000\r\n'
 wire+=b'\r\n';before=s.snapshot(peer.database);start=time.monotonic();response=b''
 with socket.create_connection(('127.0.0.1',peer.port),timeout=8)as sock:
  sock.settimeout(8);sock.sendall(wire)
  while True:
   try:part=sock.recv(65536)
   except ConnectionResetError:break
   if not part:break
   response+=part
 after=s.snapshot(peer.database);head,_,body=response.partition(b'\r\n\r\n');lines=head.split(b'\r\n');status=int(lines[0].split(b' ',2)[1]);reason=lines[0].split(b' ',2)[2].decode('latin1');headers=[tuple(t.decode('latin1').split(': ',1))for t in lines[1:]if b': 'in t]
 row=dict(id=name,status=status,reason=reason,headers=headers,body_hex=body.hex());return dict(raw=row,request_hex=wire.hex(),response_hex=response.hex(),before=before,after=after,unchanged=before==after,elapsed=time.monotonic()-start)
try:
 seedroot=ROOT/'seed';env=s.owned_env(seedroot,emb.url);database,seed=s.seed(seedroot,env)
 for native,name,binary in [(False,'go',s.GO),(True,'native',NATIVE)]:
  owned=ROOT/name;env=s.owned_env(owned,emb.url);db=owned/'current.db'
  with sqlite3.connect(database)as orig,sqlite3.connect(db)as copy:orig.backup(copy)
  peers.append(s.Peer(binary,owned,env,native,db))
 for case in cases:
  time.sleep(.61);pair=[actual(p,case)for p in peers];records.append(dict(name=case[0],pair=pair,semantic_equal=semantic(pair[0]['raw'])==semantic(pair[1]['raw']),status_reason_equal=(pair[0]['raw']['status'],pair[0]['raw']['reason'])==(pair[1]['raw']['status'],pair[1]['raw']['reason'])))
  assert all(p['unchanged']for p in pair),case[0]
finally:
 for p in peers:shutdown.append(p.close())
 emb.close();Path(os.environ['REVIEW_MEMORY_REPORT']).write_text(json.dumps(dict(head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip(),candidate_dirty=bool(subprocess.check_output(['git','status','--porcelain'],cwd=repo)),native_sha256=s.digest(NATIVE),go_sha256=s.digest(s.GO),records=records,shutdown=shutdown,embedding_requests=emb.requests,scope='Actual three valid HEAD supported/method-denial authority controls, literal request/response and allSQLite before/after. Whole-wire framing/Date differences classified explicitly; no assumed full parser/Go serialization parity.'),indent=2)+'\n')
print([(r['name'],r['semantic_equal'],r['status_reason_equal'])for r in records])
