# Current Doctor806 native Windows Source lifecycle observations

Read-only collection of run37184966738, completed Windows job111384880074.
Publication is44354141e73b5ff4287ec3b1b767c2d0a8e99e6b. The full checkout log
confirms CI mergefb39903f721f0958de9ab6119a0ab094e13e50a2 into main5e232700.
All ten recorded Source input hashes and all five diagnostic input hashes match
the publication files exactly. The diagnostic reports a clean merge checkout.

The complete decoded job log is retained byte-for-byte as the MCP-returned
UTF-8 text, including BOM/CRLF, at
/tmp/symaira-doctor806-443-windows-original.log (719385bytes,
SHA878e72f3ee49a4a3e3c400bebaff3618a7b3fb41f03b0d71ad173dd795d6b4cd).
The complete tool response is retained separately. All downloaded raw ZIPs match
their GitHub SHA-256 digests; every member is extracted unchanged with a length,
SHA and original ZIP metadata map. The complete archive receipt is
/tmp/symaira-doctor806-443-artifacts/original-archive-receipt.json.

## Actual gate and Source phases

Setup repair passed177cases. Doctor repair passed269/269 and all three original
genuine input controls. Source selected95Windows cases, completed the first
explicit-browse-json Go/native pair, then failed in explicit-browse-human:
Go returned0 with its normal install line; Rust exceeded the unchanged25second
outer process budget with empty captured stdout/stderr. The original progress
journal retains the full inputs, environment, outputs and live-state snapshot.
Source negative controls were not reached. Later usage/vault/MCP gates were
skipped; their missing-artifact upload failures do not establish a second
production defect. Linux Source/Setup/Doctor output gates passed separately.

The failed Rust fixture recorded git rev-parse, Go version and Go build calls,
and contained a3350016byte staged symbrowse plus an empty capture file. This
proves the fixture builder created its payload. It does not prove the original
builder's exit or the original CLI's exact blocking frame, CPU use or cleanup.
The original timeout remains a real failed acceptance gate.

## Actual isolated Windows JobObject diagnosis

Artifact11297098945 retains the full report, Cargo output and24raw members.
The historical mode observed wrapper-created, parent-exited,16cached-status
post-exit polls, historical-drop-enter and historical-kill-enter. No kill
return or wrapper-drop-return was observed before the separate12second
watchdog. The watchdog terminated only its recorded owned parent/tree.

The inner-wait comparison observed whole-job termination success, cached
top-level wait success and wrapper-drop return, exit0 without forced cleanup.
The descendant comparison likewise returned0 without forced cleanup after
terminating the owned job; a recorded owned descendant PID was confirmed
inactive by native tasklist. All three intended observations matched. The
report explicitly records production_acceptance=false and
original_cli_timeout_cause_proved=false, and those limits remain in force.

The locked process-wrap10.0.1 crate archive matches Cargo's checksum
1f21b97672d2dc848e7b25701ab4535618b92f4861c13cc3f7f7bed52ad3c8da.
Its reviewed std/tokio JobObject and core/Windows source bytes match that actual
archive. Std JobObject try_wait consumes completion notifications and returns
the inner status without updating its own wait cache. Default kill calls
start_kill followed by wrapper wait; the latter can block on an already consumed
completion notification. The historical diagnosis proves this reachable
post-exit ownership defect, independently of the original CLI's exact frame.

## Binary provenance gap and concrete successor

The original uploads omit executable bytes. They record native Source CLI
SHA336e218cf9babe5ef5ec13f4e65430add1116b0c0fce0f43d0cb709b91e20fbe,
Go SHA4b45e3e068984bade85019a41ae8ff973e61adadfa55198eab94283ae1488eea,
and actual diagnostic test SHA878a2b5f82ec3fb3b53c537ff1a21612e1cf83021d191e95eea45b7abc2cdd94,
with source/Cargo-artifact bindings. There is no original native PE-byte archive
claim. A successor should upload the actual current CLI, Go and executed test
PE bytes plus a manifest alongside all original reports.

Proceed with a source-only isolated successor for the concrete demonstrated
cleanup defect: terminate the full owned Windows job, await/reap the actual
top-level process without re-entering a consumed completion-port wait, and
retain descendant termination checks. Audit both Source std and Broker Tokio
ownership paths before choosing a focused helper. Preserve Unix ownership,
all original budgets/controls and the historical failing diagnostic. Do not
disable waiting globally or use unowned taskkill. Require different-author
review, fresh exact-head native Windows diagnostic and the complete Source
process gate, followed by native-three-OS acceptance. No compile, target,
port, process replay, rerun, push or product source edit occurred in collection.
