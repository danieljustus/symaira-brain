use std::ffi::OsString;
use std::io::{self, Write};
use std::process::ExitCode;
struct Partial { mode: String, remaining: usize }
impl Write for Partial {
 fn write(&mut self, bytes: &[u8]) -> io::Result<usize> {
  if self.remaining > 0 {
   let count=bytes.len().min(self.remaining);
   io::stdout().write_all(&bytes[..count])?;
   self.remaining-=count;
   return Ok(count);
  }
  Err(match self.mode.as_str() {
   "raw-pipe" => io::Error::from_raw_os_error(32),
   "raw-full" => io::Error::from_raw_os_error(28),
   _ => io::Error::other("owned partial callback"),
  })
 }
 fn flush(&mut self) -> io::Result<()> { Ok(()) }
}
fn main() -> ExitCode {
 let args=std::env::args_os().skip(1).collect::<Vec<OsString>>();
 let mut writer=Partial {mode:std::env::var("SETUP_EMBEDDED_MODE").unwrap(),remaining:7};
 ExitCode::from(symbrain_cli::run(&args,&mut writer,&mut io::stderr()))
}
