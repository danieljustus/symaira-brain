from pathlib import Path
import base64,gzip,hashlib,json,os,re,subprocess
ROOT=Path('/workspace/symaira-doctor765-stdout');HEAD='58fe50b9d275f0cc8a7ab6a8252a6595a58e52ab';ORACLE='dcddcef0df5789123c7c9a7ebe6e01f10e941f2c';P='/tmp/symaira-doctor-source-sixth-full-';E='/tmp/symaira-doctor-source-sixth-extra-';sha=lambda b:hashlib.sha256(b).hexdigest()
def load(path):return json.loads(Path(path).read_bytes())
def state(r):assert r.get('candidate_head',r.get('candidate_revision',r.get('head')))==HEAD and not r.get('candidate_dirty',r.get('dirty',False)),r.keys()
cache={}
def gitbytes(ref,name):
 key=(ref,name)
 if key not in cache:cache[key]=subprocess.check_output(['git','show',ref+':'+name],cwd=ROOT)
 return cache[key]
def manifests(r):
 counts={}
 for key in ['candidate_source_sha256','candidate_manifest_sha256','go_source_sha256','immutable_go_cli_source_sha256','frozen_go_source_sha256']:
  if key not in r:continue
  counts[key]=len(r[key])
  for name,digest in r[key].items():assert sha((ROOT/name).read_bytes()if key.startswith('candidate')else gitbytes(ORACLE,name))==digest,(key,name)
 return counts
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()==HEAD and not subprocess.check_output(['git','status','--porcelain'],cwd=ROOT)
gates={};counts={};controls=[]
for name,total in [('source',111),('doctor',285),('setup',201)]:
 r=load(P+name+'.json');state(r);assert r['total']==total and r['exit']==0
 if name=='setup':assert r['matches']and len(r['cases'])==total and len(r['observations'])==total*2
 else:assert r['matched']==r['complete_observations']==total and not r['failures']
 counts[name]=manifests(r);gates[name]={'total':total,'go_sha256':r['go_binary_sha256'],'rust_sha256':r['rust_binary_sha256']}
 for mode in (['wrong-exit','wrong-source']if name=='source'else['wrong-exit','missing-header','missing-core-event']if name=='doctor'else[]):
  q=load(P+name+'.json.'+mode+'.json');field={'wrong-exit':'exit','wrong-source':'stdout_base64','missing-header':'stdout_base64','missing-core-event':'logs'}[mode];assert q['total']==q['complete_observations']==1 and q['matched']==0 and q['exit']==1 and q['failures']==[{'case':'explicit-browse-json'if name=='source'else'correct','fields':[field]}];controls.append({'family':name,'mode':mode,'field':field})
original=0
for name in ['findings','lookup','raw-signals','eight-extra','eight-home','boundaries','symlink']:
 r=load(E+name+'.json');state(r)
 for value in r.values():
  if isinstance(value,list):
   for row in value:
    if isinstance(row,dict)and('mismatched_fields'in row or'differences'in row):assert not row.get('mismatched_fields',row.get('differences'));original+=1
 if name=='raw-signals':assert len(r['actual_cancellation'])==2 and all(not x['descendant_active']and x['actual_cli_exit']==1 for x in r['actual_cancellation'])
assert original==35
for name in ['consumers','fix-consumers']:
 r=load(E+name+'-setup.json');state(r);assert r['total']==8 and r['matches']and r['exit']==0 and len(r['observations'])==16
for family,n in [('source',4),('doctor',3)]:
 r=load(E+'consumers-'+family+'.json');state(r);assert len(r['cases'])==n and all(not x['differences']for x in r['cases'])
log=Path(P+'tests.log').read_bytes();results=[tuple(map(int,x))for x in re.findall(rb'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;',log)];assert len(results)==54 and tuple(map(sum,zip(*results)))==(501,0,0)
assert b'Finished'in Path(P+'clippy.log').read_bytes()
for name in ['fmt','actionlint']:assert not Path(P+name+'.log').read_bytes()
bins={name:sha(Path(name).read_bytes())for name in re.findall(r'Running [^\n]+ \(([^\n]+)\)',log.decode())}
for name in ['/workspace/symaira-setup765-source/target/debug/symbrain','/workspace/symaira-setup765-source/target/debug/symguard','/workspace/symaira-setup765-source/target/debug/examples/setup_embedded_output','/workspace/symaira-setup765-source/target/debug/examples/doctor_embedded_output','/tmp/symaira-doctor-source-sixth-extra-partial-writer-budget','/tmp/symaira-doctor765-sixth-58fe-cli']:bins[name]=sha(Path(name).read_bytes())
cli='/workspace/symaira-setup765-source/target/debug/symbrain';assert bins[cli]==bins['/tmp/symaira-doctor765-sixth-58fe-cli']
guard=load(P+'guard.json');state(guard);assert guard['total']==124 and guard['matched']==121 and len(guard['remaining_native_diagnostic_states'])==3 and not guard['audit_diagnostic_deviations'];counts['guard']=manifests(guard)
raw=load(P+'guard-raw-paths.json');gc=load(P+'guard-controls.json');assert raw['total']==raw['matched']==63 and len(raw['controls'])==2 and all(x['rejected']for x in raw['controls']);assert gc['rejected']==3 and all(x['rejected']for x in gc['controls'])
for name,n in [('output-probes',4),('source-output',2),('pipe-probes',6),('human-pipe-probes',6),('embedded',24)]:
 r=load(P+'output/'+name+'.json');state(r);assert len(r['cases'])==n and all(not x['differences']for x in r['cases'])
 if name!='embedded':assert r['rust_sha256']==bins[cli]
r=load(P+'output/controls.json');assert r['rejected_groups']==4 and sum(x['exact_rejected_cases']for x in r['groups'])==15 and sum(x['preserved_matching_cases']for x in r['groups'])==3
partial=load(E+'partial-writer-budget.json');state(partial);assert len(partial['cases'])==18 and all(not x['differences']for x in partial['cases'])
for row in partial['cases']:
 assert len(base64.b64decode(row['go']['stdout_base64']))==len(base64.b64decode(row['rust']['stdout_base64']))==7
 assert row['go']['exit']==row['rust']['exit']==(0 if row['case'].endswith('human')else 1)
read=load(P+'memory-read.json');state(read);assert read['passed']==read['cases']==590 and not read['operator_home_used']and not read['fallback_available'];counts['memory-read']=manifests(read)
r=load(P+'memory-read-controls.json');assert len(r['controls'])==2 and all(x['exit']==1 and x['cases']==x['rejected_cases']==32 for x in r['controls'])
write=load(P+'memory-write/receipt.json');state(write);assert not write['operator_home_used']and not write['operator_credentials_in_runtime']and not write['paid_endpoints_used']and write['embedding_endpoints_owned'];assert len(write['controls'])==3 and all(x['exit']==1 and x['detected']for x in write['controls']);counts['memory-write']=manifests(write)
for name,n in [('writes',60),('deletes',16),('fallback-boundaries',13),('write-failures',10)]:
 r=load(P+'memory-write/'+name+'.json');assert r['passed']==r['total']==len(r['cases'])==n
for name,n in [('process',9),('fix',4),('embedded',27)]:
 r=load(P+'doctor-output/'+name+'.json');state(r);assert len(r['cases'])==n and all(not x['differences']for x in r['cases']);counts['doctor-output-'+name]=manifests(r)
r=load(P+'doctor-output/controls.json');state(r);assert r['rejected_groups']==len(r['groups'])==3 and sum(x['actual_rejected_cases']for x in r['groups'])==6 and sum(x['preserved_cases']for x in r['groups'])==21;counts['doctor-output-controls']=manifests(r)
for name,n,oldfail in [('bounded18',18,6),('fix8',8,2)]:
 r=load('/tmp/symaira-doctor765-sixth-original-'+name+'.json');state(r);assert len(r['cases'])==n and r['baseline_sha256']=='a2f9be69dbf324e12a20b5ed3e573f06bb9c66750fec2c3a2a16bd4716bdfc52';assert all(not x['differences']for x in r['cases']if not x['baseline']);assert sum(bool(x['differences'])for x in r['cases']if x['baseline'])==oldfail
 for row in r['cases']:
  if row['case'].endswith('partial-reader'):assert len(base64.b64decode(row['go']['raw_stdout_prefix_base64']))==len(base64.b64decode(row['rust']['raw_stdout_prefix_base64']))==128 and row['go']['pipe_capacity']==row['rust']['pipe_capacity']==4096
retention=load(ROOT/'migration/evidence/doctor-stdout-765/original-fifth/preservation.json');assert len(retention['independent_artifacts'])==146 and len(retention['actually_executed'])==56 and len(retention['all_target_elf_including_proc_macro_and_build_scripts'])==661
for row in retention['independent_artifacts']:
 with gzip.open(ROOT/row['tracked_archive'],'rb')as f:assert hashlib.file_digest(f,'sha256').hexdigest()==row['sha256']
prior=load(ROOT/'migration/evidence/doctor-output-765/final-e6e96a2/validation.json')
for name,digest in prior['full_affected_source_sha256'].items():assert sha(gitbytes('e6e96a227410a293d240f33f4fb6f88ccd829298',name))==digest,(name,digest)
assert not subprocess.check_output(['git','diff','e6e96a227410a293d240f33f4fb6f88ccd829298',HEAD,'--','cmd','internal','guard','go.mod','go.sum','Cargo.toml','Cargo.lock','rust/symbrain-core','rust/symbrain-managed','rust/symbrain-memory'],cwd=ROOT)
assert subprocess.check_output(['git','status','--porcelain'],cwd='/workspace/symaira-doctor765-output')==b''
users=[];target='/workspace/symaira-setup765-source/target'
for p in Path('/proc').iterdir():
 if not p.name.isdigit()or int(p.name)==os.getpid():continue
 for item in [p/'exe',p/'cwd']+list((p/'fd').glob('*')):
  try:
   actual=os.readlink(item)
   if actual.startswith(target):users.append({'pid':p.name,'path':actual})
  except OSError:pass
assert not users,users
r={'source_head':HEAD,'main_ancestor':'2b6d49f250a81650eda1b93cec7d859a171873bb','tests':{'passed':501,'failed':0,'ignored':0,'summaries':54,'previous_actual500_retained':True},'gates':gates,'manifests':counts,'source_doctor_controls':controls,'original35_and_actual_cancel2':True,'original23_consumers':True,'guard124_121full_3retained_raw63_controls5':True,'memory590_60_16_13_10_controls5':True,'setup_source_output18_embedded24_controls4_15reject3preserve':True,'doctor_output13_embedded27_controls3_6reject21preserve':True,'novel18_setup_cumulative_writer_pairs':True,'original_doctor_current9_a66_9_and_currentfix4_a66_4':True,'original_a66_two_groups_failures_preserved':{'nonfix':6,'fix':2},'fifth_independent_artifacts_retained':145,'fifth_actual_binaries_retained':56,'fifth_all_ELF_paths_retained':661,'prior299_source_hashes_verified_immutable':True,'Go_Core_Managed_Memory_Cargo_unchanged':True,'actual_binary_sha256':bins,'target_users':users,'target_released':False,'native_platforms':{'Linux':'executed','Windows':'pending','macOS':'pending'},'disposition':'Author validation only; two inherited Doctor output findings corrected on actual input; independent full review and native gates still required. No GitHub write/full765 closure.'}
Path('/tmp/symaira-doctor765-sixth-verification.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({k:r[k]for k in ['source_head','tests','gates','manifests','target_users','disposition']},indent=2))
