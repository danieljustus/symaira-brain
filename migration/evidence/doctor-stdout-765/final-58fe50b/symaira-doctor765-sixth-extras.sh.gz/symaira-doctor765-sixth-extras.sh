#!/usr/bin/env bash
set -euo pipefail
umask 022
. /home/agent/.cargo/env
export PATH=/workspace/toolchains/go1.26.7/bin:$PATH
export PYTHONDONTWRITEBYTECODE=1
python3 /tmp/symaira-doctor-source-sixth-extra-findings.py > /tmp/symaira-doctor-source-sixth-extra-findings.log 2>&1
python3 /tmp/symaira-doctor-source-sixth-extra-lookup.py > /tmp/symaira-doctor-source-sixth-extra-lookup.log 2>&1
python3 /tmp/symaira-doctor-source-sixth-extra-raw-signals.py > /tmp/symaira-doctor-source-sixth-extra-raw-signals.log 2>&1
python3 /tmp/symaira-doctor-source-sixth-extra-eight-extra.py > /tmp/symaira-doctor-source-sixth-extra-eight-extra.log 2>&1
python3 /tmp/symaira-doctor-source-sixth-extra-eight-home.py > /tmp/symaira-doctor-source-sixth-extra-eight-home.log 2>&1
python3 /tmp/symaira-doctor-source-sixth-extra-boundaries.py > /tmp/symaira-doctor-source-sixth-extra-boundaries.log 2>&1
python3 /tmp/symaira-doctor-source-sixth-extra-symlink.py > /tmp/symaira-doctor-source-sixth-extra-symlink.log 2>&1
python3 /tmp/symaira-doctor-source-sixth-extra-consumers.py > /tmp/symaira-doctor-source-sixth-extra-consumers.log 2>&1
python3 /tmp/symaira-doctor-source-sixth-extra-fix-consumers.py > /tmp/symaira-doctor-source-sixth-extra-fix-consumers.log 2>&1
