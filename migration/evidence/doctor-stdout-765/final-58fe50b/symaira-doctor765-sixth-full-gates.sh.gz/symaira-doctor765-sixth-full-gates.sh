#!/usr/bin/env bash
set -euo pipefail
umask 022
. /home/agent/.cargo/env
export PATH=/workspace/toolchains/go1.26.7/bin:$PATH
export CARGO_TARGET_DIR=/workspace/symaira-setup765-source/target
export CARGO_INCREMENTAL=0 CARGO_PROFILE_DEV_DEBUG=0 CARGO_PROFILE_TEST_DEBUG=0 CARGO_BUILD_JOBS=2 PYTHONDONTWRITEBYTECODE=1
cargo test --locked --all-targets --all-features -p symbrain-cli -p symbrain-managed -p symbrain-core -p symbrain-guard-core -p symguard-cli -p symbrain-memory > /tmp/symaira-doctor-source-sixth-full-tests.log 2>&1
cargo clippy --locked --all-targets --all-features -p symbrain-cli -p symbrain-managed -p symbrain-core -p symbrain-guard-core -p symguard-cli -p symbrain-memory -- -D warnings > /tmp/symaira-doctor-source-sixth-full-clippy.log 2>&1
cargo fmt --all -- --check > /tmp/symaira-doctor-source-sixth-full-fmt.log 2>&1
/workspace/toolchains/bin/actionlint > /tmp/symaira-doctor-source-sixth-full-actionlint.log 2>&1
scripts/setup-source-oracle/run.sh /tmp/symaira-doctor-source-sixth-full-source.json > /tmp/symaira-doctor-source-sixth-full-source.log 2>&1
scripts/doctor-repair-oracle/run.sh /tmp/symaira-doctor-source-sixth-full-doctor.json > /tmp/symaira-doctor-source-sixth-full-doctor.log 2>&1
scripts/setup-repair-oracle/run.sh /tmp/symaira-doctor-source-sixth-full-setup.json > /tmp/symaira-doctor-source-sixth-full-setup.log 2>&1
scripts/guard-standalone-oracle/run.sh /tmp/symaira-doctor-source-sixth-full-guard.json > /tmp/symaira-doctor-source-sixth-full-guard.log 2>&1
scripts/setup-output-oracle/run.sh /tmp/symaira-doctor-source-sixth-full-output > /tmp/symaira-doctor-source-sixth-full-output.log 2>&1
scripts/doctor-stdout-oracle/run.sh /tmp/symaira-doctor-source-sixth-full-doctor-output > /tmp/symaira-doctor-source-sixth-full-doctor-output.log 2>&1
python3 scripts/memory-cli-oracle/replay.py --rust "$CARGO_TARGET_DIR/debug/symbrain" --report /tmp/symaira-doctor-source-sixth-full-memory-read.json > /tmp/symaira-doctor-source-sixth-full-memory-read.log 2>&1
python3 scripts/memory-cli-oracle/controls.py --rust "$CARGO_TARGET_DIR/debug/symbrain" --go /workspace/oracles/symbrain-go-dcddcef0 --report /tmp/symaira-doctor-source-sixth-full-memory-read-controls.json > /tmp/symaira-doctor-source-sixth-full-memory-read-controls.log 2>&1
python3 scripts/memory-cli-oracle/write_gate.py --rust "$CARGO_TARGET_DIR/debug/symbrain" --report-dir /tmp/symaira-doctor-source-sixth-full-memory-write > /tmp/symaira-doctor-source-sixth-full-memory-write.log 2>&1
