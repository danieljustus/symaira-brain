import base64,gzip,hashlib,importlib.util,json,os,shutil,subprocess,sys,tempfile,time
from pathlib import Path
ROOT=Path('/workspace/symaira-doctor765-stdout');TARGET=Path('/workspace/symaira-setup765-source/target')
sys.path.insert(0,str(ROOT/'scripts/doctor-repair-oracle'));spec=importlib.util.spec_from_file_location('sixthwriter',ROOT/'scripts/doctor-repair-oracle/replay.py');m=importlib.util.module_from_spec(spec);sys.modules[spec.name]=m;spec.loader.exec_module(m)
GO=Path('/workspace/oracles/symbrain-go-dcddcef0');prefix=Path('/tmp/symaira-doctor765-sixth-independent-writer');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();rows=[]
rlib=TARGET/'debug/deps/libsymbrain_cli-aa8b4f9701bbbd35.rlib';assert rlib.exists()
rust_binary=Path(str(prefix)+'-native');go_binary=Path(str(prefix)+'-go')
subprocess.run(['rustc','--edition=2024','-C','debuginfo=0','--extern','symbrain_cli='+str(rlib),'-L','dependency='+str(TARGET/'debug/deps'),str(prefix)+'.rs','-o',str(rust_binary)],check=True)
with tempfile.TemporaryDirectory(prefix='doctor-sixth-writer-owned-')as temporary:
 source=Path(temporary)/'source';source.mkdir();archive=subprocess.Popen(['git','archive',m.ORACLE],cwd=ROOT,stdout=subprocess.PIPE)
 subprocess.run(['tar','-xf','-','-C',str(source)],stdin=archive.stdout,check=True);archive.stdout.close();assert archive.wait()==0
 driver=source/'cmd/symbrain/owned_sixth_writer.go';shutil.copyfile(str(prefix)+'.go.txt',driver)
 subprocess.run(['go','build','-trimpath','-mod=readonly','-o',str(go_binary),'./cmd/symbrain'],cwd=source,check=True)
 for mode in ['raw-eintr','custom-interrupted','raw-eio','raw-full','raw-pipe','custom','zero-success','short-success']:
  for route,args in [('json',['doctor','--json']),('human',['doctor'])]:
   row=dict(mode=mode,route=route,go_writer_contract='violated short nil-error'if mode in ['zero-success','short-success']else'valid')
   for label,binary in [('go',go_binary),('rust',rust_binary)]:
    with tempfile.TemporaryDirectory(prefix='doctor-sixth-writer-state-')as fixture:
     root=Path(fixture);env=m.legacy.prepare_root(root,GO);(root/'bin').mkdir();env.update(PATH=str(root/'bin'),SYMBRAIN_GO_BINARY=str(root/'absent'),SYMBRAIN_RELEASE_BASE_URL='http://127.0.0.1:1',OWNED_WRITER_MODE=mode,OWNED_WRITER_TRACE=str(root/'trace'))
     start=time.time();before=m.filesystem(root,{},start,start);run=subprocess.run([str(binary),*args],cwd=env['PROJECT'],env=env,capture_output=True,timeout=30);end=time.time();after=m.filesystem(root,{},start,end);after.pop('trace',None)
     normal=lambda b:base64.b64encode(b.replace(os.fsencode(root),b'<root>')).decode()
     row[label]=dict(exit=run.returncode,stdout_base64=normal(run.stdout),stderr_base64=normal(run.stderr),raw_stdout_base64=base64.b64encode(run.stdout).decode(),raw_stderr_base64=base64.b64encode(run.stderr).decode(),submitted_calls_hex=(root/'trace').read_text().splitlines(),before=before,after=after)
   row['differences']=[k for k in ['exit','stdout_base64','stderr_base64','before','after']if row['go'][k]!=row['rust'][k]];rows.append(row)
 record=dict(candidate_head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),candidate_source='58fe50b9d275f0cc8a7ab6a8252a6595a58e52ab',go_source=m.ORACLE,go_sdk=subprocess.check_output(['go','version'],text=True).strip(),actual_inputs={str(p):sha(p)for p in [Path(str(prefix)+'.rs'),Path(str(prefix)+'.go.txt'),rlib,rust_binary,go_binary]},cases=rows,scope='Actual frozen Go/public Rust caller, six valid zero-byte error responses plus two explicitly invalid-Go short-success robustness controls. Complete submitted call bytes, stdout/stderr/exit and owned read-only state. Rust Write EINTR retry semantics classified separately; no blanket Go callback equality or native non-Linux claim. No repair/operator/provider network.')
 Path(str(prefix)+'.json').write_text(json.dumps(record,indent=2)+'\n');print([(r['mode'],r['route'],r['go']['exit'],r['rust']['exit'],r['differences'])for r in rows])
