set -euo pipefail
umask 022
. /home/agent/.cargo/env
export PATH=/workspace/toolchains/go1.26.7/bin:$PATH
export PYTHONDONTWRITEBYTECODE=1
export DOCTOR_STDOUT_GO=/workspace/oracles/symbrain-go-dcddcef0 DOCTOR_STDOUT_RUST=/tmp/symaira-doctor765-sixth-58fe-cli DOCTOR_STDOUT_BASELINE=/tmp/symaira-doctor765-owner-a66-cli DOCTOR_STDOUT_BASELINE_PROBE=1
DOCTOR_STDOUT_REPORT=/tmp/symaira-doctor765-sixth-independent-bounded18.json python3 scripts/doctor-stdout-oracle/process.py > /tmp/symaira-doctor765-sixth-independent-bounded18.log 2>&1
DOCTOR_STDOUT_REPORT=/tmp/symaira-doctor765-sixth-independent-fix8.json python3 scripts/doctor-stdout-oracle/fix.py > /tmp/symaira-doctor765-sixth-independent-fix8.log 2>&1
rustc --edition=2024 -C debuginfo=0 --extern symbrain_cli=/workspace/symaira-setup765-source/target/debug/deps/libsymbrain_cli-aa8b4f9701bbbd35.rlib -L dependency=/workspace/symaira-setup765-source/target/debug/deps /tmp/symaira-doctor765-sixth-independent-cumulative.rs -o /tmp/symaira-doctor765-sixth-independent-cumulative-native
SETUP_OUTPUT_GO=/workspace/oracles/symbrain-go-dcddcef0 SETUP_OUTPUT_EMBEDDED_RUST=/tmp/symaira-doctor765-sixth-independent-cumulative-native SETUP_OUTPUT_REPORT=/tmp/symaira-doctor765-sixth-independent-cumulative.json python3 /tmp/symaira-doctor765-sixth-independent-cumulative.py > /tmp/symaira-doctor765-sixth-independent-cumulative.log 2>&1
