set -euo pipefail
umask 022
. /home/agent/.cargo/env
export PATH=/workspace/toolchains/go1.26.7/bin:/workspace/toolchains/bin:$PATH
export GOTOOLCHAIN=local CARGO_TARGET_DIR=/workspace/symaira-memory803-open/target CARGO_INCREMENTAL=0 CARGO_PROFILE_DEV_DEBUG=0 CARGO_PROFILE_TEST_DEBUG=0 CARGO_BUILD_JOBS=2 PYTHONDONTWRITEBYTECODE=1
check_disk() { python3 -c 'import shutil; d=shutil.disk_usage("/workspace"); assert d.free>=700*1024*1024,d'; }
test "$(git rev-parse HEAD)" = 2fe09ea78f1beb0225b9c325d76a054c183a9e42
test -z "$(git status --porcelain)"
check_disk
cargo test -p symbrain-memory -p symbrain-cli --all-targets --all-features --offline --locked > /tmp/symaira-memory803-root-tests.log 2>&1
check_disk
cargo build -p symbrain-cli --bin symbrain --offline --locked > /tmp/symaira-memory803-root-build.log 2>&1
cargo clippy -p symbrain-memory -p symbrain-cli --all-targets --all-features --offline --locked -- -D warnings > /tmp/symaira-memory803-root-clippy.log 2>&1
cargo fmt --all -- --check > /tmp/symaira-memory803-root-fmt.log 2>&1
actionlint > /tmp/symaira-memory803-root-actionlint.log 2>&1
check_disk
python3 scripts/memory-cli-oracle/replay.py --go /workspace/oracles/symbrain-go-dcddcef0 --rust "$CARGO_TARGET_DIR/debug/symbrain" --report /tmp/symaira-memory803-root-read.json > /tmp/symaira-memory803-root-read.log 2>&1
python3 scripts/memory-cli-oracle/controls.py --go /workspace/oracles/symbrain-go-dcddcef0 --rust "$CARGO_TARGET_DIR/debug/symbrain" --report /tmp/symaira-memory803-root-read-controls.json > /tmp/symaira-memory803-root-read-controls.log 2>&1
check_disk
python3 -c 'import subprocess; x=subprocess.check_output(["ss","-H","-ltn","( sport = :11434 )"]); assert not x,x'
ss -ltn '( sport = :11434 )' > /tmp/symaira-memory803-root-11434-before.log
python3 scripts/memory-cli-oracle/write_gate.py --go /workspace/oracles/symbrain-go-dcddcef0 --rust "$CARGO_TARGET_DIR/debug/symbrain" --report-dir /tmp/symaira-memory803-root-write > /tmp/symaira-memory803-root-write.log 2>&1
ss -ltn '( sport = :11434 )' > /tmp/symaira-memory803-root-11434-after.log
python3 -c 'import subprocess; x=subprocess.check_output(["ss","-H","-ltn","( sport = :11434 )"]); assert not x,x'
test -z "$(git status --porcelain)"
