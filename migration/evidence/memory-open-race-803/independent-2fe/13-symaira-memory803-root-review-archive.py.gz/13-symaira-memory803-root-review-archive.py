import json,hashlib,gzip,subprocess,re,os,time
from pathlib import Path
root=Path('/workspace/symaira-memory803-open');target=root/'target';sha=lambda b:hashlib.sha256(b).hexdigest()
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()=='2fe09ea78f1beb0225b9c325d76a054c183a9e42'
assert not subprocess.check_output(['git','status','--porcelain'],cwd=root)
h=json.loads(Path('/tmp/symaira-memory803-open-final-handoff.json').read_text());v=json.loads((root/'migration/evidence/memory-open-race-803/final-4c62355/validation.json').read_text())
for name,d in h['evidence_files'].items():assert sha((root/name).read_bytes())==d,name
for name,d in v['source_files'].items():assert sha((root/name).read_bytes())==d,name
archives={}
for path,d in h['prior_actual_archive_receipts'].items():assert sha(Path(path).read_bytes())==d,path
original=json.loads(Path(h['archive_receipt']).read_text());assert sha(Path(h['archive_receipt']).read_bytes())==h['archive_receipt_sha256']
for row in original['ELFs']:
 a=row['archive'];archives[row['sha256']]=a
for d,a in archives.items():
 p=Path(a['gzip']);assert sha(p.read_bytes())==a['gzip_sha256']
 with gzip.open(p,'rb') as f:assert hashlib.file_digest(f,'sha256').hexdigest()==d
read=json.loads(Path('/tmp/symaira-memory803-root-read.json').read_text());write=json.loads(Path('/tmp/symaira-memory803-root-write/receipt.json').read_text());control=json.loads(Path('/tmp/symaira-memory803-root-read-controls.json').read_text())
assert read['candidate_revision']==write['candidate_revision']==h['publication_head'] and not read['candidate_dirty'] and not write['candidate_dirty'] and read['passed']==read['cases']==590
for a in (read,write):
 for name,d in a['candidate_source_sha256'].items():assert sha((root/name).read_bytes())==d,name
for name,d in write['frozen_go_source_sha256'].items():assert sha(subprocess.check_output(['git','show',write['go_revision']+':'+name],cwd=root))==d,name
for name,d in write['report_sha256'].items():assert sha((Path('/tmp/symaira-memory803-root-write')/name).read_bytes())==d,name
assert len(control['controls'])==2 and all(x['exit']==1 and x['cases']==x['rejected_cases']==32 for x in control['controls'])
assert len(write['controls'])==3 and all(x['exit']==1 and x['detected'] for x in write['controls'])
cli=target/'debug/symbrain';assert sha(cli.read_bytes())==read['rust_binary_sha256']==write['rust_binary_sha256']
assert sha(Path('/workspace/oracles/symbrain-go-dcddcef0').read_bytes())==read['go_binary_sha256']==write['go_binary_sha256']
log=Path('/tmp/symaira-memory803-root-tests.log').read_text();results=re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;',log);assert len(results)==32 and sum(int(x[0]) for x in results)==327 and not any(int(x[1])+int(x[2]) for x in results)
# Preserve all compiled payloads; cached objects are not represented as executions.
dest=Path('/workspace/oracles/symaira-memory803-root-2fe-binaries');dest.mkdir(exist_ok=False);rows=[];unique={};roles=[]
for raw in re.findall(r'Running .*?\((target/[^)]+)\)',log):
 p=root/raw;assert p.is_file(),p;roles.append({'role':'actual cargo test executable','path':str(p),'sha256':sha(p.read_bytes())})
roles.append({'role':'actual CLI oracle and controls owner','path':str(cli),'sha256':sha(cli.read_bytes())})
for p in sorted(target.rglob('*')):
 if not p.is_file():continue
 with p.open('rb') as stream:
  if stream.read(4)!=b'\x7fELF':continue
 b=p.read_bytes();d=sha(b)
 if d not in unique:
  a=archives.get(d)
  if a is None:
   q=dest/(d+'.gz');z=gzip.compress(b,mtime=0);q.write_bytes(z);assert gzip.decompress(z)==b;a={'gzip':str(q),'gzip_sha256':sha(z),'bytes':len(b)}
  unique[d]=a
 rows.append({'path':str(p),'sha256':d,'archive':unique[d]})
assert all(x['sha256'] in unique for x in roles)
receipt={'source':h['publication_head'],'ELFs':rows,'unique':unique,'actual_executed_roles':roles,'roundtrip_verified':True,'scope':'All compiled ELF/object/procmacro payloads retained. Only explicitly attributed Cargo/CLI roles assert execution. Transient removed Go helper ELFs have source/hash/raw reports, no payload retention claim.'}
(dest/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
review={'reviewer':'Root different author','source':h['publication_head'],'result':'BOUNDED APPROVE pre-migration plain BUSY5 WAL setup retry','tests_passed':327,'tests_failed':0,'tests_ignored':0,'test_summaries':32,'read_pairs':590,'read_mutants':64,'set_pairs':60,'delete_pairs':16,'actual_delegated_boundaries':13,'output_pairs':10,'actual_write_mutants':3,'source_hashes_verified':len(write['candidate_source_sha256']),'frozen_go_hashes_verified':len(write['frozen_go_source_sha256']),'author_full_raw_proofs_verified':len(h['evidence_files']),'author_archived_unique_payloads_verified':len(archives),'root_archived_ELF_paths':len(rows),'root_archived_unique_payloads':len(unique),'actual_executed_role_count':len(roles),'actual_native_cli_sha256':read['rust_binary_sha256'],'actual_go_cli_sha256':read['go_binary_sha256'],'archive_receipt':str(dest/'receipt.json'),'strict_clippy_fmt_actionlint':True,'reviewed_policy':'Only autocommit pre-migration journal_mode=WAL with exact primaryBUSY5 retries, one5s monotonic budget inclSQLite waiting/yields; original error/transaction/data preserved; restore5000ms; unchanged IMMEDIATE migrations/33tests/FTS and caller operations','original_windows_phase':'full raw BUSY5 public-open panic retained; internal failing phase not established by CI log','native_platform_requirement':'fresh exact-head Windows/macOS/Linux MemoryCLI/Evidence and protected checks mandatory','historical649':'full37migration repair/default successor remains uncompiled separate scope'}
Path('/tmp/symaira-memory803-root-review.json').write_text(json.dumps(review,indent=2)+'\n');print(json.dumps(review,indent=2))
