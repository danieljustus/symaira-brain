import hashlib,json,os,pathlib,subprocess,shutil
OUT=pathlib.Path(__file__).parent;OLD=OUT/'miniature';OWN=OUT/'initial-full-fixture';OWN.mkdir()
assert shutil.disk_usage(OUT).free>=700*1024**2
remote=OLD/'remote';pin=subprocess.check_output(['git','rev-parse','master'],cwd=remote).decode().strip()
env={k:v for k,v in os.environ.items() if not k.startswith('GIT_')}
env.update(HOME=str(OLD/'home'),USERPROFILE=str(OLD/'home'),GIT_CONFIG_GLOBAL=os.devnull,GIT_CONFIG_NOSYSTEM='1',GIT_TEMPLATE_DIR=str(OLD/'template'),GIT_TERMINAL_PROMPT='0')
rows=[]
def run(label,args,cwd=OWN,exit=0):
 p=subprocess.run(args,cwd=cwd,env=env,capture_output=True,timeout=20)
 (OUT/('full-'+label+'.stdout')).write_bytes(p.stdout);(OUT/('full-'+label+'.stderr')).write_bytes(p.stderr)
 rows.append(dict(label=label,argv=[str(x) for x in args],cwd=str(cwd),exit=p.returncode,stdout_hex=p.stdout.hex(),stderr_hex=p.stderr.hex()))
 assert p.returncode==exit,(label,p.returncode,p.stderr)
 return p.stdout
checkout=OWN/'full-history-checkout'
run('initial-full-clone',['git','-c','protocol.file.allow=always','clone','--single-branch','--branch','current',remote.as_uri(),str(checkout)])
assert run('initial-not-shallow',['git','rev-parse','--is-shallow-repository'],checkout)==b'false\n'
run('initial-pin-missing',['git','cat-file','-t',pin],checkout,128)
before=OWN/'shared-before';run('before-shared-clone',['git','-c','protocol.allow=never','-c','protocol.file.allow=always','clone','--shared','--no-checkout','--',str(checkout),str(before)])
run('before-pinned-checkout',['git','checkout','--detach',pin],before,128)
run('depth1-pinned-fetch',['git','-c','protocol.file.allow=always','fetch','--no-tags','--depth=1','origin',pin],checkout)
assert run('source-pin-present',['git','cat-file','-t',pin],checkout)==b'commit\n'
assert run('source-now-shallow',['git','rev-parse','--is-shallow-repository'],checkout)==b'true\n'
after=OWN/'shared-after';run('after-shared-clone',['git','-c','protocol.allow=never','-c','protocol.file.allow=always','clone','--shared','--no-checkout','--',str(checkout),str(after)])
assert not (after/'.git/objects/info/alternates').exists()
run('after-pin-still-missing',['git','cat-file','-t',pin],after,128)
run('after-pinned-checkout-fails',['git','checkout','--detach',pin],after,128)
assert ('fatal: unable to read tree ('+pin+')\n').encode() in bytes.fromhex(rows[-1]['stderr_hex'])
control=OWN/'no-depth-control'
run('control-full-clone',['git','-c','protocol.file.allow=always','clone','--single-branch','--branch','current',remote.as_uri(),str(control)])
run('control-exact-pinned-fetch',['git','-c','protocol.file.allow=always','fetch','--no-tags','origin',pin],control)
assert run('control-stays-full',['git','rev-parse','--is-shallow-repository'],control)==b'false\n'
clone=OWN/'no-depth-shared';run('control-shared-clone',['git','-c','protocol.allow=never','-c','protocol.file.allow=always','clone','--shared','--no-checkout','--',str(control),str(clone)])
assert (clone/'.git/objects/info/alternates').is_file()
run('control-pinned-checkout-passes',['git','checkout','--detach',pin],clone)
assert (clone/'file').read_bytes()==b'old immutable parent\n'
receipt=dict(actual_source_only_owned_Git_mechanics=True,actual_candidate_or_SDK_execution=False,git_version=subprocess.check_output(['git','--version']).decode().strip(),initial_checkout_complete_current_branch_history=True,actual_CI_checkout_fetch_depth=0,synthetic_pinned_oid=pin,pinned_current_candidate_reference='01f41906e2e021db3c693ec97617bb701e4dad8a',current_source_not_mutated=True,successful_fetch_depth1_still_fails_shared_clone_checkout=True,nondepth_exact_pin_control_passes=True,commands=rows)
(OUT/'exact-initial-full-verification.json').write_text(json.dumps(receipt,indent=2)+'\n')
print('REQUEST CHANGES: depth1 acquisition makes full checkout shallow; shared clone still loses exact pinned object. Non-depth exact-pin control passes.')
