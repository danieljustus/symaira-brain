import hashlib, io, json, os, pathlib, shutil, subprocess, tarfile, zipfile
import yaml
ROOT=pathlib.Path('/workspace/symaira-skills621');OUT=pathlib.Path(__file__).parent
H='cc3f4e62dcb133b616c6b58c135463ad81058801';P='e605cc4b2a3509ccbbf5e1a2704413b25474789a';PIN='01f41906e2e021db3c693ec97617bb701e4dad8a'
def digest(data):return hashlib.sha256(data).hexdigest()
def git(*args):return subprocess.check_output(['git','-C',str(ROOT),*args])
def blob(ref,path):return git('show',ref+':'+path)
def save(name,value):(OUT/name).write_text(json.dumps(value,indent=2)+'\n')
assert shutil.disk_usage(OUT).free>=700*1024**2
assert git('rev-list','--parents','-n1',H).decode().split()==[H,P]
assert not git('status','--porcelain')
delta=git('diff','--name-only',P,H).decode().splitlines()
assert set(delta)=={'.github/workflows/ci.yml','docs/adr/skills-ci-immutable-parent-acquisition.md','migration/evidence/skills-render-drift-621/ci-parent-object-e605/full-original-failure.tar.gz','migration/evidence/skills-render-drift-621/ci-parent-object-e605/retention.json'}
before=yaml.safe_load(blob(P,'.github/workflows/ci.yml'));after=yaml.safe_load(blob(H,'.github/workflows/ci.yml'))
found=[]
for job,body in after['jobs'].items():
    for index,step in enumerate(body.get('steps',[])):
        if step.get('name')=='Fetch the immutable native Skills comparison parent':
            assert job=='rust-migration-windows'
            assert step==dict(name='Fetch the immutable native Skills comparison parent',shell='bash',run='git fetch --no-tags --depth=1 origin '+PIN)
            assert body['steps'][index+1]['name']=='Frozen Go and native Windows wide Skills argv acceptance'
            found.append((job,index));body['steps'].pop(index);break
assert len(found)==1 and after==before
rows=[]
for path in git('ls-tree','-r','--name-only',P).decode().splitlines():
    if path in delta:continue
    left=git('ls-tree',P,'--',path);right=git('ls-tree',H,'--',path);assert left==right,path
    rows.append(dict(path=path,entire_Git_body_and_mode_equal=True,tree_identity=left.decode().strip()))
save('whole-unchanged-parent-bindings.json',rows)
builder='scripts/skills-argv-oracle/build_parent.py'
assert digest(blob(H,builder))=='6a864a01aa8f3e9e74934ada473906d6cb27a339b6e57fe03bc8f606d4ea01bc'
assert blob(H,builder)==blob(P,builder)==blob('9353520a34c5819c7d0a6cd58d3bfaa2b22b045b',builder)
assert ('WINDOWS_PARENT = "'+PIN+'"').encode() in blob(H,'scripts/skills-argv-oracle/novel.py')
retention=json.loads(blob(H,'migration/evidence/skills-render-drift-621/ci-parent-object-e605/retention.json'))
archive=blob(H,'migration/evidence/skills-render-drift-621/ci-parent-object-e605/full-original-failure.tar.gz')
assert digest(archive)==retention['archive_sha256']
tar_records=[];payloads={}
with tarfile.open(fileobj=io.BytesIO(archive),mode='r:gz') as tf:
    for member in tf.getmembers():
        if not member.isfile():continue
        data=tf.extractfile(member).read();payloads[member.name]=data
        tar_records.append(dict(member=member.name,bytes=len(data),sha256=digest(data),mode=member.mode))
    for row in retention['files']:
        data=payloads[row['member']];assert digest(data)==row['sha256'] and len(data)==row['bytes']
        if row['member'].endswith('ci.yml'):assert data==blob(P,'.github/workflows/ci.yml')
        else:assert pathlib.Path(row['path']).read_bytes()==data
        # The archived metadata describes the original file before the workflow edit.
        assert tf.getmember(row['member']).mode==row['mode']
log=payloads['000-original-job.log'];assert len(log)==375691 and digest(log)=='a164916daac5de474d0e24c8dc93b36d00d98619024ef54fab4eaf2826180e29'
(OUT/'original-job.log').write_bytes(log)
for token in [b'build_parent.py',b'12/12 live native CLI reports',b'RuntimeError: command failed with exit 128']:
    assert token.lower() in log.lower(),token
zip_path=pathlib.Path(retention['original_ZIP_bytes_retained_external']);raw=zip_path.read_bytes();assert digest(raw)==retention['original_zip_sha256']
zip_rows=[];parent_report=None
with zipfile.ZipFile(io.BytesIO(raw)) as z:
    assert z.testzip() is None
    for row in retention['original_zip_members']:
        data=z.read(row['path']);assert len(data)==row['bytes'] and digest(data)==row['sha256']
        assert z.getinfo(row['path']).CRC==row['CRC'] and z.getinfo(row['path']).external_attr>>16==row['native_zip_mode']
        assert any(value==data for value in payloads.values()),row['path']
        if row['path']=='parent-build.json':parent_report=json.loads(data);(OUT/'original-parent-build.json').write_bytes(data)
        if row['path'].endswith('.exe'):assert data[:2]==b'MZ'
        zip_rows.append(row)
assert len(zip_rows)==8
assert parent_report['status']=='failed' and parent_report['source_ref']==PIN and parent_report['restored_current']
assert len(parent_report['commands'])==6
assert parent_report['commands'][-1]['exit']==128
assert parent_report['commands'][-1]['argv'][-3:]==['checkout','--detach',PIN]
assert bytes.fromhex(parent_report['commands'][-1]['stderr_hex'])==('fatal: unable to read tree ('+PIN+')\n').encode()
assert all(row['exit']==0 for row in parent_report['commands'][:-1])
assert not any('build' in row['argv'] for row in parent_report['commands'])
save('retention-verification.json',dict(full_archive_sha256=digest(archive),full_archive_bytes=len(archive),tar_members=tar_records,original_ZIP_path=str(zip_path),original_ZIP_sha256=digest(raw),ZIP_members=zip_rows,parent_report=parent_report))
commands=[]
def run(label,args,cwd=ROOT,env=None,expected=0):
    p=subprocess.run(args,cwd=cwd,env=env,capture_output=True,timeout=30)
    (OUT/(label+'.stdout')).write_bytes(p.stdout);(OUT/(label+'.stderr')).write_bytes(p.stderr)
    commands.append(dict(label=label,argv=[str(x) for x in args],cwd=str(cwd),exit=p.returncode,stdout_sha256=digest(p.stdout),stderr_sha256=digest(p.stderr)))
    assert p.returncode==expected,(label,p.returncode,p.stderr)
    return p.stdout
CI=OUT/'ci-current.yml';CI.write_bytes(blob(H,'.github/workflows/ci.yml'))
run('actionlint',['/workspace/toolchains/bin/actionlint',str(CI)])
run('diffcheck',['git','diff','--check',P,H])
local=OUT/'miniature';local.mkdir(exist_ok=True);home=local/'home';home.mkdir(exist_ok=True);template=local/'template';template.mkdir(exist_ok=True)
env=dict(os.environ,HOME=str(home),USERPROFILE=str(home),GIT_CONFIG_GLOBAL=os.devnull,GIT_CONFIG_NOSYSTEM='1',GIT_TEMPLATE_DIR=str(template),GIT_TERMINAL_PROMPT='0',GIT_AUTHOR_DATE='2026-10-04T00:00:00Z',GIT_COMMITTER_DATE='2026-10-04T00:00:00Z')
env={k:v for k,v in env.items() if not k.startswith('GIT_') or k in ['GIT_CONFIG_GLOBAL','GIT_CONFIG_NOSYSTEM','GIT_TEMPLATE_DIR','GIT_TERMINAL_PROMPT','GIT_AUTHOR_DATE','GIT_COMMITTER_DATE']}
remote=local/'remote';remote.mkdir();run('mini-init',['git','init','--quiet',str(remote)],env=env)
(remote/'file').write_text('old immutable parent\n');run('mini-add-parent',['git','add','file'],remote,env)
run('mini-commit-parent',['git','-c','user.name=Owned Source Review','-c','user.email=source-review@example.invalid','commit','--quiet','-m','pinned parent'],remote,env)
pin=run('mini-parent-head',['git','rev-parse','HEAD'],remote,env).decode().strip()
run('mini-orphan-current',['git','checkout','--quiet','--orphan','current'],remote,env)
(remote/'file').write_text('squash current unrelated ancestry\n');run('mini-add-current',['git','add','file'],remote,env)
run('mini-commit-current',['git','-c','user.name=Owned Source Review','-c','user.email=source-review@example.invalid','commit','--quiet','-m','current squash'],remote,env)
checkout=local/'checkout';run('mini-depth1-checkout',['git','-c','protocol.file.allow=always','clone','--depth=1','--branch','current',remote.as_uri(),str(checkout)],env=env)
pre=local/'shared-before';run('mini-shared-before',['git','-c','protocol.allow=never','-c','protocol.file.allow=always','clone','--shared','--no-checkout','--',str(checkout),str(pre)],env=env)
run('mini-original-checkout-fails',['git','checkout','--detach',pin],pre,env,128)
run('mini-exact-depth1-fetch',['git','-c','protocol.file.allow=always','fetch','--no-tags','--depth=1','origin',pin],checkout,env)
post=local/'shared-after';run('mini-shared-after',['git','-c','protocol.allow=never','-c','protocol.file.allow=always','clone','--shared','--no-checkout','--',str(checkout),str(post)],env=env)
run('mini-corrected-checkout',['git','checkout','--detach',pin],post,env)
assert run('mini-corrected-head',['git','rev-parse','HEAD'],post,env).decode().strip()==pin
assert (post/'file').read_bytes()==b'old immutable parent\n'
save('verification.json',dict(head=H,parent=P,changed_paths=delta,complete_unchanged_parent_bodies=len(rows),entire_previous_workflow_preserved_after_one_Windows_step=True,actual_portable_localGit_miniature=True,miniature_is_synthetic_not_actual_01f_CI_acceptance=True,owned_miniature_pin=pin,before_checkout_exit=128,after_checkout_exit=0,actual_SDK_compiler_product_Target_port=0,commands=commands,workspace_free_bytes=shutil.disk_usage(OUT).free))
assert not git('status','--porcelain');print('PASS source/workflow/retention and owned local Git acquisition mechanics; native acceptance pending')
