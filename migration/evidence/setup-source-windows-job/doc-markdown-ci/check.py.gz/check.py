from pathlib import Path
import gzip,hashlib,json,subprocess,tarfile
root=Path('/workspace/symaira-source806-job-doc-markdown');out=Path(__file__).parent;parent='d0b58ab03f77e847cd92862f0332f5ebc4952b44';sha=lambda b:hashlib.sha256(b).hexdigest()
def git(*args):return subprocess.check_output(['git',*args],cwd=root)
head=git('rev-parse','HEAD').decode().strip();assert not git('status','--porcelain')
path='rust/symbrain-cli/src/setup_source_windows_job.rs';old=git('show',parent+':'+path);current=(root/path).read_bytes();expected=old.replace(b'//! Preserve owned JobObject completion',b'//! Preserve owned `JobObject` completion',1);assert current==expected;assert old.split(b'\n',1)[1]==current.split(b'\n',1)[1]
map=[]
for entry in git('ls-tree','-rz',head).split(b'\0'):
 if not entry:continue
 meta,name=entry.split(b'\t');mode,kind,oid=meta.decode().split()
 if kind=='blob':map.append(dict(path=name.decode(),mode=mode,blob=oid))
byname={r['path']:r for r in map};original=json.loads(gzip.decompress((root/'migration/evidence/setup-source-windows-job/doc-markdown-ci/whole-original-parent-modes-blobs.json.gz').read_bytes()))
for row in original['whole_tree']:
 if row['path']==path:assert byname[path]['mode']==row['mode']
 else:assert byname[row['path']]==row,row['path']
ret=json.loads((root/'migration/evidence/setup-source-windows-job/doc-markdown-ci/retention.json').read_text())
with tarfile.open(root/'migration/evidence/setup-source-windows-job/doc-markdown-ci/complete-original-source-and-native-logs.tar.gz') as tar:
 for row in ret['records']:assert sha(tar.extractfile(row['member']).read())==row['sha256']
checks={}
for name,argv in [('rustfmt',['/home/agent/.rustup/toolchains/1.98.0-x86_64-unknown-linux-gnu/bin/rustfmt','--edition','2024','--check',path]),('diff',['git','diff','--check',parent,head])]:
 p=subprocess.run(argv,cwd=root,stdout=subprocess.PIPE,stderr=subprocess.PIPE);(out/(name+'.stdout')).write_bytes(p.stdout);(out/(name+'.stderr')).write_bytes(p.stderr);assert p.returncode==0;(checks.update({name:p.returncode}))
result=dict(head=head,parent=parent,old_source_sha256=sha(old),new_source_sha256=sha(current),sole_header_comment_change=True,whole_remaining_helper_body_exact=True,unchanged_whole_parent_blobs_except_header=len(original['whole_tree'])-1,all_original_modes_exact=True,full_raw_archive_roundtrip=True,checks=checks,compiler_Cargo_SDK_product_target_cache_ports_GitHub=0)
(out/'checks.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
