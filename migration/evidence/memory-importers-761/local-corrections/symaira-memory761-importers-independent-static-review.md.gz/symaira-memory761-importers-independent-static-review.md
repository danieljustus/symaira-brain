# Independent source-only Memory761 review

Disposition: **REQUEST CHANGES — three P2 source findings**. This is a full
source review of the five-adapter/marker/retention checkpoint, not a compiled
candidate or native three-OS acceptance. No source, fixture, provider, target,
compiler, SDK executable, product, socket or GitHub resource was mutated or run.

Reviewed immutable publication `2946cf2b959ed71ed58dcf44d36c515aab60328e`,
production `734d2705f6b9312599644700c845db04f07d685c`, normal prerequisite merge
`f7a761d3ef77ad55c1727293be50abf301c6e2a2`, approved Store parent
`a30bba8bbd52323fa5e000207f1c391d576ac86c`, and frozen Go
`dcddcef0df5789123c7c9a7ebe6e01f10e941f2c`.

## Findings

1. **P2: Retention loses nanoseconds before SQL deletion admission.**
   `rust/symbrain-memory/src/activity_retention.rs:39` and `:60` bind the
   inherited `gotime::format`, whose `timestamp_subsec_micros` at
   `gotime.rs:16` truncates submicrosecond precision. Frozen Expire and
   ClearTimeRange bind UTC `time.Time` directly. Pinned modernc1.59
   `conn.go:236` defaults to `t.String()`; sqlitekit0.17's DSN supplies no
   time-format override; SDK `time/format.go:547` renders nine fractional
   digits. A valid Go-saved expiry `.000000500` with supplied instant
   `.000000600` is deleted by Go but retained by the new native operation,
   whose bound becomes a whole second. An interval ending `.000000500` with
   supplied range start `.000000600` is conversely deleted by native despite
   no Go overlap. These are changes to deleted rows/counts, not just output
   wording. Go Segment validation permits these increasing nanosecond windows
   and SaveSegment preserves the explicit expiry. Fix the new consumer's
   timestamp contract and prove exact rows/counts/state with actual Go/native
   pairs, including equal boundary and whole-second controls. The inherited
   formatter does not make this new deletion consumer correct. Avoid changing
   unrelated Store/provider policies without their existing gates.

2. **P2: Invalid source bytes lose the Go JSON escape distinction in metadata.**
   `rust/symbrain-memory/src/importer/bytes.rs:96` first decodes invalid bytes
   into valid U+FFFD. `gojson::quote` then uses locked serde_json1.0.151, which
   copies that valid UTF-8 fragment as EF BF BD. Pinned Go
   `encoding/json/encode.go`'s `appendString` branch for RuneError/size1 instead
   writes the six ASCII bytes `\ufffd`. Curated frontmatter `name: <FF>` thus
   yields metadata bytes `{"name":"\ufffd"}` in Go versus a literal replacement
   character in native; `[[<FF>]]` similarly changes the `links` value. Codex
   and Obsidian use the same primitive. The metadata value is an embedded JSON
   string retained as bytes, so parsing the inner JSON into an object to hide
   this difference would weaken the actual contract and full hex comparator.
   The prepared `go_json_escapes_html_and_each_bad_byte` test currently encodes
   the wrong literal expectation. Preserve raw-byte distinction until the
   encoder: valid literal U+FFFD is a necessary positive control and must stay
   literal; global U+FFFD replacement would also be wrong. Retain HTML/JS and
   invalid-key/order tests while adding actual package differential pairs.

3. **P2: Basename performs an extra Clean on caller input.**
   `rust/symbrain-memory/src/importer/files.rs:129` cleans the full path before
   selecting its final segment. SDK `filepathlite/path.go:224` Base strips
   trailing separators, then returns the final segment without Clean.
   Obsidian's explicit root is not generated/cleaned: `/owned/vault/.` has
   Go vault metadata `.` but native `vault` in discovery and import
   (`obsidian.rs:76`, `:156`). `/owned/vault/..` likewise changes `..` to
   `owned`. The shell importer calls the same helper on the first command
   token (`shell.rs:101`); `npm/. install` gets a native package-manager tag
   where Go Base is `.` and no tag exists. A legitimate `npm/ install` is the
   positive trailing-separator control. Implement Base independently of
   Clean; retain explicit Clean/Join/Rel behavior and symlink ownership proofs.
   This changes public library results; no hypothetical CLI is needed.

All examples above are **source-derived counterexamples**, preserved bytewise
in `findings.json`, not observations of an executed Go/Rust/SQLite binary.
The frozen sources, pinned SDK, dependency source and candidate hashes are
bound by the receipt. Runtime allocation remains required for actual pairs.

## Complete production and evidence review

Reviewed every production delta: public raw DTO/optional trait presence and
checked shared evidence conversion; Aider role/heading/byte threshold/ignored
Scanner error behavior; Shell defaults/filters/exclusions/epochs/duplicate IDs/
tags; Codex policy deny-first, root/stat/read order, bounded read, parent-window
coverage, cursor and provenance/evidence metadata; Curated two source trees,
index exclusions, delimiter/scanner/YAML/link parsing, postparse stat and byte
truncation; Obsidian constructor/defaults, folder/tag filtering, H1/filename
title, raw link behavior and metadata; shared Unicode/JSON/file/scanner helpers;
all four import-marker methods; all three retention methods, transaction
ordering, zero/error counts, unconditional explicit-clear cleanup and
postcommit count retention; existing Store and migration prerequisite seams.
All new production files and tests stay below 400 lines. Dependency manifests
and lock remain byte-identical. Existing CLI/MCP routes and fallback predicates
are unchanged. No new Core/Guard/credential dependency or provider operation
appears.

The nonempty `MAX(imported_at)` error is accurately source-derived: expression
columns have no DATETIME declaration, modernc's `_texttotime` is off, the
sqlitekit DSN does not enable it, and SDK NullTime.Scan calls convertAssign
into `*time.Time`. Native maps Null to absent and string/int64/float64/[]uint8
to the corresponding unsupported-Scan error. This is not a successful cursor;
the Registry checks this error before discovery. It still needs actual Store
process proof, exactly as the author documents. No issue found by treating
this error as an accidental feature to repair.

Reviewed the actual frozen importer interfaces, Registry, discovery and
application references: no importer/Registry production constructor call or
Memory import CLI exists. Activity Store construction is live in Go CLI/MCP;
the new mutations are additive native library methods, not admitted commands.
Presence of TranscriptImporter is preserved separately from its bool value.
No automatic source capture or phantom import command was introduced. The
canonical byte DTO and checked evidence bridge are consistent with #760's
separate ownership; no Engine implementation was reviewed or approved here.

The ten other importer families, Registry governance/extraction/sanitizer/
staging/embedding/store/marker partial-commit orchestration and remaining
Activity mutations/rollups/promotion/typed reads are clearly pending. Windows
paths explicitly refuse; raw typed I/O diagnostics, configured-path versus
SQLite filename WAL inspection, rename/busy peers, local-zone/cache and chrono
epoch limits are explicit future gates. Those acknowledgments are not native
three-OS evidence or a waiver for acceptance. Constructor default/clock/API
surfaces and live shared Store/MCP prerequisites need full later proof.

Reviewed both real-function oracle callers, all 70 fixture recipes, complete
report comparator, state snapshots, three prepared input mutants, allocation
shell driver, source binding checker, all 24 prepared unit functions, ADR,
ledger/matrix deltas and original editing-correction preservation. The oracle
calls real public frozen constructors; no private algorithm was copied into
an expected-data generator. Arrays, raw hex, nil/allocated-empty, complete
errors and evidence spans remain literal; only metadata map ordering is made
explicit in both actual callers. The comparator checks ordered complete IDs,
positive bootstrap per family and entire reports. All three real-process
mutants remain unexecuted. The prepared driver requires four allocation
variables but timeout/floor checks and final executable/source receipts are
external allocation requirements, not yet a self-contained runtime gate.

## Independent checks actually performed

- Six source gates passed: independent complete bindings/protection/archive/
  AST/plan checks; author's read-only binding verifier; standalone Rustfmt;
  shell syntax; Actionlint; git diff hygiene. No Cargo/Clippy/compiler/SDK
  executable was invoked.
- Verified 577 native, 1231 frozen, 25 SDK and six module source hashes; 33
  prepared inputs; all 1515 approved parent Memory proofs. Independently
  checked **4185 protected baseline paths** unchanged and all 57 changed
  paths. Original 14 importer fixtures and the historical editing patch
  roundtrip hash are exact.
- Archived all 57 original changed-path bytes plus three final handoff/
  manifest files, **60 lossless gzip records**, before any correction. The
  candidate stayed clean at the identical HEAD; no target exists.
- Materialized all **70 prepared** recipes only in the owned reviewer
  workspace, validated unique IDs/order against the unchanged plan and
  full readonly snapshot consistency; generated the three planned altered
  packets and verified one-packet changes without touching originals.
- Six **synthetic comparator machinery** boundaries behaved correctly:
  identical fabricated reports accepted; empty, missing, reordered, duplicate
  and changed-content fabricated reports rejected. These deliberately labeled
  harness checks are not the three real-process corruption controls and not
  actual Go/native importer reports.

**Actual compiled candidate tests, Go SDK probes and product processes: zero.**
Prepared 70 cases/24 unit functions/three process controls remain unexecuted.
Native three-OS acceptance remains pending. Runtime/parent gates must retain
complete original input/output/state/exit and actual executable/source binding,
then add the three finding groups above before admission or issue closure.

Original candidate/source is unchanged and no target/compiler/socket lease was
held. Root decides an isolated author successor after this complete review;
this report does not authorize edits or self-approval.
