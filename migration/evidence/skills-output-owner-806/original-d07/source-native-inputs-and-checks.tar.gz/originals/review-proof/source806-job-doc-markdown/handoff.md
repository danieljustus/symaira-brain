Source806 Windows documentation-lint correction is ready for independent focused review.

Clean immutable HEAD `d07c5daae8b68f053f9c215434ed8e5bc64c6baa`, validated source
`9fb91e9517e942c3372b1290aba83cc5b7cdb034`, new worktree
`/workspace/symaira-source806-job-doc-markdown`, branch
`fix/806-windows-job-doc-markdown`, parent `d0b58ab03f77e847cd92862f0332f5ebc4952b44`.

Only source change: the first doc comment in setup_source_windows_job.rs places
JobObject in backticks, exactly matching the actual Clippy doc_markdown suggestion.
The complete remaining helper is byte-identical. All other 4,866 original Git file
bodies/modes are exact, including functional code, corpora, controls, CI, dependencies
and Go. No lint allowance or runtime behavior was changed.

Before editing, preservation commit 9d401919 retained complete original helper,
whole-parent modes/blob map, both full native job logs (111449738122 / 111449738205),
original CRLF and native metadata. Both supplied full-log SHA values matched and
all archive payloads round-trip exactly. Their actual checkout identities remain
in the logs; no unavailable merge source is claimed locally equivalent. The primary
strict lint failure is identified before subsequent missing-artifact errors; those
later errors do not demonstrate a separate process/ownership regression.

Pure source checks pass: exact one-line delta, whole suffix and parent identities,
lossless native/source retention, standalone Rustfmt and diff whitespace. Eight
complete source-check outputs/programs are retained in tracked gzip evidence. Local
Cargo/compiler/SDK/product/target/cache/provider/ports/GitHub count is zero.

ADR: docs/adr/source-windows-job-doc-markdown-806.md. Full immutable receipt and
proof paths/hashes: handoff.json. Source/Brain78f/Doctorca originals and targets
remain unchanged. No cross-integration before their reviews finish; fresh required
native strict/runtime CI remains mandatory. This is an author source handoff,
not independent approval, native acceptance or issue completion.
