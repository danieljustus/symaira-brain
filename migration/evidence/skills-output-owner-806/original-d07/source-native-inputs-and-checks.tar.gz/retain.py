from pathlib import Path
import hashlib
import json
import tarfile

O=Path('/workspace/review-proof/source806-output-owner-successor');R=Path('/workspace/symaira-source806-output-owner');D=R/'migration/evidence/skills-output-owner-806/original-d07';D.mkdir(parents=True,exist_ok=True);files=sorted(p for p in O.rglob('*') if p.is_file());rows=[];archive=D/'source-native-inputs-and-checks.tar.gz'
with tarfile.open(archive,'w:gz',format=tarfile.PAX_FORMAT,compresslevel=6) as t:
    for p in files:
        raw=p.read_bytes();s=p.stat();name=str(p.relative_to(O));info=t.gettarinfo(str(p),arcname=name);info.pax_headers['mtime']=f'{s.st_mtime_ns//10**9}.{s.st_mtime_ns%10**9:09d}'
        with p.open('rb') as f:t.addfile(info,f)
        rows.append({'member':name,'original':str(p),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'mode':s.st_mode,'uid':s.st_uid,'gid':s.st_gid,'mtime_ns':s.st_mtime_ns})
with tarfile.open(archive,'r:gz') as t:
    assert set(t.getnames())=={x['member'] for x in rows}
    for x in rows:
        m=t.getmember(x['member']);raw=t.extractfile(m).read();assert len(raw)==x['bytes'] and hashlib.sha256(raw).hexdigest()==x['sha256'];assert (m.mode,m.uid,m.gid)==(x['mode']&0o7777,x['uid'],x['gid']);assert m.pax_headers['mtime']==f"{x['mtime_ns']//10**9}.{x['mtime_ns']%10**9:09d}"
(D/'retention.json').write_text(json.dumps({'source':'d4e65c2df053f5fc92f7f067c4d3f80da66e352e','parent':'d07c5daae8b68f053f9c215434ed8e5bc64c6baa','archive':archive.name,'archive_bytes':archive.stat().st_size,'archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'all_member_bytes_mode_uid_gid_nsmtime_roundtrip_exact':True,'members':rows,'actual_native_PE_ZIP_preserved_external':'/workspace/review-proof/root-source806-d07-windows-wide-originals/receipt.json','own_SDK_compiler_SQL_product_Target_cache_ports':0},indent=2)+'\n');print('membercount',len(rows),'archive',archive.stat().st_size,'sha256',hashlib.sha256(archive.read_bytes()).hexdigest(),'bodybudget',sum(p.stat().st_size for root in [R,O] for p in root.rglob('*') if p.is_file()))
