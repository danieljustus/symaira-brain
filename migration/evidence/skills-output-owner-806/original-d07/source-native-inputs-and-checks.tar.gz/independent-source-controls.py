"""Additional source-data controls; no SDK, binary receipt, SQL or product."""
from pathlib import Path
import importlib.util
import json
import hashlib
import subprocess

R=Path('/workspace/symaira-source806-output-owner');O=Path('/workspace/review-proof/source806-output-owner-successor')
p=R/'scripts/skills-argv-oracle/inherited_output.py';spec=importlib.util.spec_from_file_location('source_output_controls',p);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
parent={n:subprocess.check_output(['git','-C',str(R),'show',m.PARENT_REFS[0]+':'+n]) for n in m.OWNER_PATHS}
current={n:(R/n).read_bytes() for n in m.OWNER_PATHS};accepted=[];rejected=[]
for ref in m.PARENT_REFS:
    result=m.qualify(ref,parent,current);assert result['qualification']=='source806-d07' and not result['go_parity_claim'];accepted.append(ref)
for context in ['parent','current']:
    original=parent if context=='parent' else current
    for name in m.OWNER_PATHS:
        altered={**original,name:original[name]+b'\n// independent source mutation\n'}
        try:m.qualify(m.PARENT_REFS[0],altered if context=='parent' else parent,altered if context=='current' else current)
        except ValueError as error:rejected.append({'context':context,'path':name,'error':str(error)})
        else:raise AssertionError('unknown source accepted')
# All prior four profiles keep their old branch selector outcome; Source is the
# sole additive whole profile. Equal entrypoint bytes never become a new policy.
for name,profile in m.PROFILES.items():
    if name!='source806-d07':assert (profile[m.CLI] in (m.MEMORY_HASHES[m.CLI],m.SOURCE_HASHES[m.CLI]))==(profile[m.CLI]==m.MEMORY_HASHES[m.CLI])
(O/'independent-source-controls.json').write_text(json.dumps({'real_current_source_profile_accepted_refs':accepted,'changed_source_owners_refused':rejected,'prior_four_selectors_unchanged':True,'SDK_compiler_SQL_product_Target_cache_ports':0},indent=2)+'\n');print('2 Source reference selections accepted;10 whole-source mutations refused;4 old selector outcomes identical')
