from pathlib import Path
import ast
import hashlib
import json
import subprocess

R=Path('/workspace/symaira-source806-output-owner')
O=Path('/workspace/review-proof/source806-output-owner-successor')
A='d07c5daae8b68f053f9c215434ed8e5bc64c6baa'
M='a111084cfc34f03b1f58f934cd2420c603e017c3'

def blob(ref,name):
    return subprocess.check_output(['git','-C',str(R),'show',ref+':'+name])

def funcs(raw):
    return {n.name:n for n in ast.parse(raw).body if isinstance(n,ast.FunctionDef)}

def dump(n):
    return ast.dump(n,include_attributes=False)

name='scripts/skills-argv-oracle/inherited_output.py'
reviewed=blob(M,name).decode();new=(R/name).read_text()
removed=new.replace('SOURCE_HASHES = {\n    **MEMORY_HASHES,\n    CLI: "b4fa7a9df8312bb72cca213bb26b867537f8f916fa30ea6c140e446a57c3f2e2",\n    CORE: GUARD_CORE_HASH,\n}\n','',1).replace('    "source806-d07": SOURCE_HASHES,\n','',1).replace('current_hashes[CLI] in (MEMORY_HASHES[CLI], SOURCE_HASHES[CLI])','current_hashes[CLI] == MEMORY_HASHES[CLI]',1)
assert removed==reviewed
novel='scripts/skills-argv-oracle/novel.py';p=funcs(blob(A,novel));c=funcs((R/novel).read_bytes());assert p.keys()==c.keys()
for name in p:
    if name!='parent_provenance':assert dump(p[name])==dump(c[name]),name
old=p['parent_provenance'].body;newnodes=c['parent_provenance'].body
idx=next(i for i,n in enumerate(old) if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='owners' for t in n.targets))
assert [dump(n) for n in old[:idx]]==[dump(n) for n in newnodes[:idx]]
assert (R/novel).read_bytes()==blob(M,novel)
test='scripts/skills-argv-oracle/test_novel.py';old=next(n for n in ast.parse(blob(A,test)).body if isinstance(n,ast.ClassDef));cur=next(n for n in ast.parse((R/test).read_bytes()).body if isinstance(n,ast.ClassDef) and n.name==old.name);assert dump(old)==dump(cur)
# The eight original source-control methods retain their complete criteria;
# only setUpClass's pure source-data provider changes in the Source checkout.
old_class=next(n for n in ast.parse(blob(M,test)).body if isinstance(n,ast.ClassDef) and n.name=='InheritedOutputSource');new_class=next(n for n in ast.parse((R/test).read_bytes()).body if isinstance(n,ast.ClassDef) and n.name==old_class.name)
old_methods={n.name:dump(n) for n in old_class.body if isinstance(n,ast.FunctionDef) and n.name!='setUpClass'};new_methods={n.name:dump(n) for n in new_class.body if isinstance(n,ast.FunctionDef) and n.name!='setUpClass'};assert old_methods==new_methods and len(old_methods)==8
unchanged=['.github/workflows/ci.yml','Cargo.toml','Cargo.lock','scripts/skills-argv-oracle/build_parent.py','scripts/skills-argv-oracle/build_go.py','scripts/skills-argv-oracle/compare.py','scripts/skills-argv-oracle/verify_control.py','scripts/skills-argv-oracle/verify_novel_control.py']
for name in unchanged:assert (R/name).read_bytes()==blob(A,name),name
plan='migration/evidence/skills-preflight-793/windows-wide-argv/original-70b-static/symaira-skills794-wide-argv-independent-novel-plan.json';assert blob(A,plan)==(R/plan).read_bytes();assert hashlib.sha256((R/plan).read_bytes()).hexdigest()=='5478c095a73d0332baa987dfae3dea6d3c3863104841be7b4d689edfba762bce'
index=subprocess.check_output(['git','-C',str(R),'ls-files','-sz']);rows=[]
for row in index.split(b'\0'):
    if row:
        meta,path=row.split(b'\t');mode,oid,stage=meta.split();assert stage==b'0';rows.append((path.decode(),mode.decode(),oid.decode()))
proc=subprocess.Popen(['git','-C',str(R),'cat-file','--batch'],stdin=subprocess.PIPE,stdout=subprocess.PIPE)
sources=[]
for path,mode,oid in rows:
    proc.stdin.write((oid+'\n').encode());proc.stdin.flush();header=proc.stdout.readline().split();assert header[0].decode()==oid and header[1]==b'blob';raw=proc.stdout.read(int(header[2]));assert proc.stdout.read(1)==b'\n';assert hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()==oid
    physical=R/path
    if physical.exists():assert physical.read_bytes()==raw,path
    sources.append({'path':path,'mode':mode,'blob':oid,'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'materialized':physical.exists()})
proc.stdin.close();assert proc.wait()==0
(O/'complete-current-source-map.json').write_text(json.dumps(sources,separators=(',',':'))+'\n')
original={}
for row in subprocess.check_output(['git','-C',str(R),'ls-tree','-rz',A]).split(b'\0'):
    if row:
        m,n=row.split(b'\t');mode,kind,oid=m.split();original[n.decode()]=(mode.decode(),oid.decode())
changed=[]
for row in sources:
    if row['path'] in original and original[row['path']]!=(row['mode'],row['blob']):changed.append(row['path'])
assert set(changed)=={'scripts/skills-argv-oracle/novel.py','scripts/skills-argv-oracle/test_novel.py','MIGRATION-RUST.md','migration/contract-matrix.csv'},changed
assert all(not n.startswith('rust/') for n in changed)
# Every prior source entry remains, with only the four declared harness/ledger changes.
assert set(original)<=set(n['path'] for n in sources)
fixtures=json.loads((R/'migration/evidence/skills-output-owner-806/reviewed-profile-sources/source-bindings.json').read_bytes())
for row in fixtures['files']:
    raw=(R/'migration/evidence/skills-output-owner-806/reviewed-profile-sources'/row['fixture']).read_bytes();assert raw==blob(row['reference'],row['path']);assert hashlib.sha256(raw).hexdigest()==row['sha256'];assert subprocess.check_output(['git','-C',str(R),'rev-parse',row['reference']+':'+row['path']],text=True).strip()==row['blob']
(O/'source-verification.json').write_text(json.dumps({'original_entries':len(original),'current_entries':len(sources),'materialized_checked':sum(x['materialized'] for x in sources),'four_declared_old_harness_ledger_deltas':changed,'all_original_Rust_Cargo_lock_workflow_Go_and_other_entries_exact':True,'all_original_process_corpus_functions_and_parent_admission_prefix_AST_equal':True,'helper_reverse_exact_reviewed_source':True,'all_original_four_preparation_methods_and_eight_owner_methods_AST_equal':True,'pure_source_snapshot_bodies_exact_Git':len(fixtures['files']),'SDK_compiler_SQL_product_Target_cache_port_runs':0},indent=2)+'\n')
print('source rows',len(sources),'all old entries',len(original),'declared changes',changed)
