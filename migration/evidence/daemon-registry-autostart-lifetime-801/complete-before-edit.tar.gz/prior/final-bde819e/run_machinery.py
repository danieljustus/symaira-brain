"""Bounded subreaper for Python-only actual selftests; file-backed raw output."""
from pathlib import Path
import ctypes,hashlib,json,os,signal,subprocess,sys,time
ROOT=Path('/workspace/symaira-daemon801-progress-observer');OUT=Path(__file__).parent
libc=ctypes.CDLL(None,use_errno=True)
assert libc.prctl(36,1,0,0,0)==0
sha=lambda b:hashlib.sha256(b).hexdigest()
(OUT/'private-tmp').mkdir(exist_ok=True)
owned_env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',TMPDIR=str(OUT/'private-tmp'),TMP=str(OUT/'private-tmp'),TEMP=str(OUT/'private-tmp'))
commands=[('original-five',[sys.executable,'/workspace/symaira-daemon801-client-deadlines/browse/port/harness/test_registry_progress.py'],1),('corrected-five',[sys.executable,str(ROOT/'browse/port/harness/test_registry_progress.py')],0),('actual-controls',[sys.executable,str(ROOT/'migration/evidence/daemon-registry-progress-observer-801/observer_controls.py'),'--source',str(ROOT),'--out',str(OUT/'actual-controls')],0)]
records=[]
for name,argv,expected in commands:
 paths=[OUT/(name+'.stdout'),OUT/(name+'.stderr')]
 began=time.monotonic();forced=False
 with paths[0].open('wb') as stdout,paths[1].open('wb') as stderr:
  child=subprocess.Popen(argv,cwd=ROOT,env=owned_env,stdin=subprocess.DEVNULL,stdout=stdout,stderr=stderr,start_new_session=True)
  try:code=child.wait(timeout=30)
  except subprocess.TimeoutExpired:
   forced=True;os.killpg(child.pid,signal.SIGKILL);code=child.wait(timeout=3)
 # Only this subprocess process group belongs to this harness.
 try:os.killpg(child.pid,signal.SIGKILL)
 except ProcessLookupError:pass
 reaped=[]
 deadline=time.monotonic()+3
 while True:
  try:pid,status=os.waitpid(-1,os.WNOHANG)
  except ChildProcessError:break
  if pid:reaped.append(dict(pid=pid,status=status));continue
  assert time.monotonic()<deadline,'adopted Python child failed to reap'
  time.sleep(.005)
 streams=[]
 for p in paths:
  b=p.read_bytes();assert len(b)<=4*1024*1024;streams.append(dict(path=str(p),bytes=len(b),sha256=sha(b)))
 records.append(dict(name=name,argv=argv,exit=code,expected_exit=expected,forced_cleanup=forced,duration=time.monotonic()-began,streams=streams,reaped_adopted=reaped))
 (OUT/'machinery-progress.json').write_text(json.dumps(records,indent=2)+'\n')
 assert not forced and code==expected
(OUT/'machinery.json').write_text(json.dumps(dict(rows=records,subreaper=True,outer_timeout_seconds=30,file_backed=True,SDK_product_compiler_Target_ports=0),indent=2)+'\n')
print(json.dumps(records))
