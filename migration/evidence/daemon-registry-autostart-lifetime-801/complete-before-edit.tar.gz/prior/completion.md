The four complete original CI logs and all linked original observer/capture
source were preserved before changes. Eight captures produce four events each
plus binding:33. The original observer expects17 and reproduces exactly that
failure in an owned Linux Python-only run.

Source bde819e23689a846271f6cc489d46a310ec0fbe9 changes only the existing
concurrency observer method and adds its direct CLI_TIMEOUT import. All other
3693 original tracked paths retain complete Git body/mode identity. The five
test names and four other method ASTs are unchanged. Production event/capture,
comparators, workflows, Rust/Go/dependencies, fixtures and budgets are unchanged.

Fresh source-bound Python-only checks under a bounded subreaper: original five
exit1 with the intended17/33 assertion; corrected five exit0; one retained
ordinary eight-child run passes33 records; missing-launch mutation runs8 actual
children and rejects25 records; wrong-case mutation runs8 actual children and
rejects33 records with corrupt links. Actual journals, result receipts and both
raw stream files are retained. Actionlint, Python AST and full diff check pass.

These checks are Linux Python machinery only. No SDK/compiler/product/Target/
cache/provider/endpoint/port or GitHub mutation ran. Native six-platform and
protected acceptance, old failed jobs and full #772 contracts remain open.
Author evidence is not independent approval. The source is frozen for Root's
focused different-author review.
