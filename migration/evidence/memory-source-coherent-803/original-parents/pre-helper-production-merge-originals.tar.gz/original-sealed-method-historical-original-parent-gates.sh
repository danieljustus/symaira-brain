#!/usr/bin/env bash
set -euo pipefail
umask 022
cd /workspace/symaira-memory649-doctor
. /home/agent/.cargo/env
export PATH=/workspace/toolchains/go1.26.7/bin:/workspace/toolchains/bin:$PATH
export CARGO_TARGET_DIR=/workspace/symaira-memory649-doctor/target
export CARGO_INCREMENTAL=0 CARGO_PROFILE_DEV_DEBUG=0 CARGO_PROFILE_TEST_DEBUG=0 CARGO_BUILD_JOBS=2 PYTHONDONTWRITEBYTECODE=1
task_source=$(git rev-parse HEAD)
test "$task_source" = 64b2c6aceaa0d1f7d1550d1398a5a70ec81aa7a0
test -z "$(git status --porcelain)"
task_prefix=/tmp/symaira-memory649-current-parent
stage() {
  python3 - "$task_prefix-space.jsonl" "$1" <<'PY'
import json,shutil,sys,time
free=shutil.disk_usage('/workspace').free
with open(sys.argv[1],'a') as out:
    out.write(json.dumps({'stage':sys.argv[2],'free_bytes':free,'time':time.time()})+'\n')
assert free >= 700*1024*1024, 'Insufficient headroom before new stage'
PY
  local task_log=$1
  shift
  "$@" > "$task_log" 2>&1
}
stage "$task_prefix-tests.log" cargo test --locked --all-targets --all-features -p symbrain-cli -p symbrain-managed -p symbrain-core -p symbrain-guard-core -p symguard-cli -p symbrain-memory
stage "$task_prefix-clippy.log" cargo clippy --locked --all-targets --all-features -p symbrain-cli -p symbrain-managed -p symbrain-core -p symbrain-guard-core -p symguard-cli -p symbrain-memory -- -D warnings
stage "$task_prefix-fmt.log" cargo fmt --all -- --check
stage "$task_prefix-actionlint.log" /workspace/toolchains/bin/actionlint
stage "$task_prefix-schema.log" bash scripts/memory-schema-oracle/run.sh "$task_prefix-schema.json"
stage "$task_prefix-source.log" bash scripts/setup-source-oracle/run.sh "$task_prefix-source.json"
stage "$task_prefix-doctor.log" bash scripts/doctor-repair-oracle/run.sh "$task_prefix-doctor.json"
stage "$task_prefix-setup.log" bash scripts/setup-repair-oracle/run.sh "$task_prefix-setup.json"
stage "$task_prefix-guard.log" bash scripts/guard-standalone-oracle/run.sh "$task_prefix-guard.json"
stage "$task_prefix-output.log" bash scripts/setup-output-oracle/run.sh "$task_prefix-output"
stage "$task_prefix-doctor-output.log" bash scripts/doctor-stdout-oracle/run.sh "$task_prefix-doctor-output"
test "$(git rev-parse HEAD)" = "$task_source"
test -z "$(git status --porcelain)"
