flags = [x for p in PACKAGES for x in ['-p', p]]
stage('whole-build', ['cargo', 'build', '--locked', '--offline', '--all-targets', '--all-features', '--message-format=json', *flags])
stage('whole-tests', ['cargo', 'test', '--locked', '--offline', '--all-targets', '--all-features', *flags])
stage('whole-strict', ['cargo', 'clippy', '--locked', '--offline', '--all-targets', '--all-features', *flags, '--', '-D', 'warnings'])
stage('whole-fmt', ['cargo', 'fmt', '--all', '--', '--check'])
stage('actionlint', ['/workspace/toolchains/bin/actionlint'])
go = output / 'bin/symbrain-go'
rust = target / 'debug/symbrain'
stage('actual-frozen-go', ['bash', 'scripts/run-go-oracle.sh', FROZEN, 'build', '-o', str(go), './cmd/symbrain'])
for name, script in [('source', 'setup-source-oracle'), ('doctor', 'doctor-repair-oracle'), ('setup', 'setup-repair-oracle'), ('guard', 'guard-standalone-oracle'), ('activity', 'activity-validation-oracle')]:
    stage(name, ['bash', 'scripts/' + script + '/run.sh', str(output / 'reports' / (name + '.json'))])
for name, total in [('source', 111), ('doctor', 285), ('setup', 201)]:
    r = json.loads((output / 'reports' / (name + '.json')).read_bytes())
    assert r['candidate_head'] == SOURCE and (not r['candidate_dirty']) and (r['total'] == total) and (r['exit'] == 0)
    if name == 'setup':
        assert r['matches'] is True
    else:
        assert r['matched'] == r['complete_observations'] == total and (not r['failures'])
stage('setup-output', ['bash', 'scripts/setup-output-oracle/run.sh', str(output / 'reports/setup-output')])
stage('doctor-output', ['bash', 'scripts/doctor-stdout-oracle/run.sh', str(output / 'reports/doctor-output')])
stage('memory-read', ['python3', 'scripts/memory-cli-oracle/replay.py', '--rust', str(rust), '--go', str(go), '--report', str(output / 'reports/memory-read.json')])
stage('memory-read-controls', ['python3', 'scripts/memory-cli-oracle/controls.py', '--rust', str(rust), '--go', str(go), '--report', str(output / 'reports/memory-read-controls.json')])
assert lease['port11434_authorized'] is True, 'Root must allocate exclusive default Ollama port before write gate'
stage('memory-writes', ['python3', 'scripts/memory-cli-oracle/write_gate.py', '--rust', str(rust), '--go', str(go), '--report-dir', str(output / 'reports/memory-write')])
stage('frozen-db-memory-fixture', ['bash', 'scripts/run-go-oracle.sh', FROZEN, 'run', './scripts/db-memory-oracle', '-check'])
stage('evidence', ['bash', 'scripts/memory-evidence-oracle/run.sh', '--report', str(output / 'reports/evidence.json')])
stage('evidence-controls', ['python3', 'scripts/memory-evidence-oracle/controls.py', '--report', str(output / 'reports/evidence-controls.json')])
stage('novel-owned-process-boundaries', ['python3', str(PREP / 'novel.py'), str(ROOT), str(go), str(rust), str(output / 'reports/novel.json')])
stage('mcp-full-differential', ['python3', 'scripts/mcp-differential.py', str(go), str(rust)])
adapters = output / 'parent-supplements'
adapters.mkdir()
original_map = json.loads((PREP / 'original-parent-driver-map.json').read_bytes())
adapter_map = {}
for old, item in original_map.items():
    old = Path(old)
    if not old.name.startswith('symaira-doctor-source-sixth-extra-'):
        continue
    assert sha(old) == item['sha256']
    new = adapters / old.name
    text = old.read_text()
    if old.suffix == '.py':
        tree = ast.parse(text)
        changes = []

        class Paths(ast.NodeTransformer):

            def visit_Constant(self, node):
                if not isinstance(node.value, str):
                    return node
                value = node.value
                replacements = {'/workspace/symaira-doctor765-stdout': str(ROOT), '/workspace/oracles/symbrain-go-dcddcef0': str(go), '/tmp/symaira-setup765-source-independent-go': str(go), '/workspace/symaira-setup765-source/target/debug/symbrain': str(rust)}
                updated = replacements.get(value, value)
                if value.startswith('/tmp/symaira-doctor-source-sixth-extra-'):
                    updated = str(adapters / Path(value).name)
                if updated != value:
                    changes.append({'original': value, 'replacement': updated})
                    return ast.copy_location(ast.Constant(updated), node)
                return node
        old_bytes = [n.value.hex() for n in ast.walk(tree) if isinstance(n, ast.Constant) and isinstance(n.value, bytes)]
        tree = Paths().visit(tree)
        text = ast.unparse(ast.fix_missing_locations(tree)) + '\n'
        reparsed = ast.parse(text)
        assert ast.dump(tree) == ast.dump(reparsed), 'Supplement adapter altered AST structure'
        assert old_bytes == [n.value.hex() for n in ast.walk(reparsed) if isinstance(n, ast.Constant) and isinstance(n.value, bytes)], 'Raw byte corpus changed'
        adapter_map[new.name] = {'original_sha256': item['sha256'], 'path_literals_only': changes}
    new.write_text(text)
(output / 'parent-adapter-map.json').write_text(json.dumps(adapter_map, indent=2) + '\n')
for name in ['findings', 'lookup', 'raw-signals', 'eight-extra', 'eight-home', 'boundaries', 'symlink', 'consumers', 'fix-consumers']:
    stage('original-extra-' + name, ['python3', str(adapters / ('symaira-doctor-source-sixth-extra-' + name + '.py'))])
artifacts = []
for line in (output / 'logs/whole-build.stdout').read_text().splitlines():
    try:
        row = json.loads(line)
    except json.JSONDecodeError:
        continue
    t = row.get('target', {})
    if row.get('reason') == 'compiler-artifact' and t.get('name') == 'symbrain_cli' and (t.get('kind') == ['lib']):
        assert Path(t['src_path']).resolve() == ROOT / 'rust/symbrain-cli/src/lib.rs'
        artifacts.extend((Path(p) for p in row['filenames'] if p.endswith('.rlib')))
assert len(set(artifacts)) == 1, 'Exact current-source CLI rlib required'
partial = output / 'bin/partial-writer'
stage('partial-caller-build', ['rustc', '--edition=2024', str(adapters / 'symaira-doctor-source-sixth-extra-partial-writer-budget.rs'), '-L', 'dependency=' + str(target / 'debug/deps'), '--extern', 'symbrain_cli=' + str(artifacts[0]), '-o', str(partial)])
stage('original-extra-partial-writer', ['python3', str(adapters / 'symaira-doctor-source-sixth-extra-partial-writer-budget.py')], {'SETUP_OUTPUT_GO': str(go), 'SETUP_OUTPUT_EMBEDDED_RUST': str(partial), 'SETUP_OUTPUT_REPORT': str(output / 'reports/partial-writer18.json')})
supplements = lease.get('additional_source_bound_supplements', [])
for item in supplements:
    assert sha(item['driver']) == item['sha256']
    stage(item['name'], item['argv'])
assert git('rev-parse', 'HEAD') == SOURCE and (not git('status', '--porcelain'))
for rel, digest in bind['candidate'].items():
    assert sha(ROOT / rel) == digest
(output / 'runtime-status.json').write_text(json.dumps({'source': SOURCE, 'status': 'GATES_FINISHED_NOT_SELF_APPROVED', 'native_Windows_executed': False, 'native_Windows_five_modes_and_95_cases': 'pending native CI', 'native_three_os': 'pending', 'full_issue765_closed': False, 'stages': len(stages)}, indent=2) + '\n')
