#!/usr/bin/env python3
"""PREPARED only: additional full actual Source/Doctor reports, never normalized."""
import importlib.util,json,os,subprocess,sys,tempfile
from pathlib import Path
ROOT,GO,RUST,REPORT=map(Path,sys.argv[1:])
def load(name,path):
 spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);sys.modules[name]=m;spec.loader.exec_module(m);return m
sys.path.insert(0,str(ROOT/'scripts/doctor-repair-oracle'))
s=load('source765_independent_novel_source',ROOT/'scripts/setup-source-oracle/replay.py')
d=load('source765_independent_novel_doctor',ROOT/'scripts/doctor-repair-oracle/replay.py')
records=[]
with tempfile.TemporaryDirectory(prefix='s765-novel-tools-') as owned:
 temp=Path(owned);source=temp/'main.go';source.write_bytes((ROOT/'scripts/setup-source-oracle/tool_fixture.go.txt').read_bytes());tool=temp/'tool'
 subprocess.run(['go','build','-trimpath','-o',str(tool),str(source)],check=True)
 for human in (False,True):
  for name,config,extra in [
    ('unknown-healthy','[future_settings]\nunknown = "<>&"\n',{}),
    ('flag-syntax-before-builder',None,{'invalid_flag':'--=owned-invalid'}),
    ('boolean-parse-before-builder',None,{'invalid_flag':'--json=owned-invalid'}),
    ('lexical-home-parent',None,{'home_lexical':'parent'}),
    ('raw-temporary-capture',None,{'raw_tmp':'valid'}),
    ('temporary-read-error',None,{'raw_tmp':'file'})]:
   args=['setup','--from-source','<source>','--modules','browse']+([] if human else ['--json'])
   extra=dict(extra)
   if 'invalid_flag' in extra:args.append(extra.pop('invalid_flag'))
   case=dict(s.cases()[0],name='independent-'+name+('-human' if human else '-json'),args=args,**extra)
   if config is not None:case['config']=config
   row={'family':'source','case':case['name']}
   for label,binary in [('go',GO),('rust',RUST)]:
    with tempfile.TemporaryDirectory(prefix='s765-novel-owned-') as fixture:row[label]=s.observe(binary,case,Path(fixture),GO,tool)
   row['differences']=[key for key in row['go']['contract'] if row['go']['contract'][key]!=row['rust']['contract'][key]];records.append(row)
 probe=d.build_probe(temp)
 with d.legacy.ReleaseFixtureServer() as url:
  d.legacy.RELEASE_BASE_URL=url
  for human in (False,True):
   for name,config,extra in [('unknown-healthy','[future_settings]\nunknown = "<>&"\n',()),('flag-syntax-before-builder',None,('--=owned-invalid',)),('boolean-parse-before-builder',None,('--json=owned-invalid',))]:
    case=d.cases()[0].__class__('independent-'+name+('-human' if human else '-json'),args=('doctor','--fix')+(() if human else ('--json',))+extra,config=config)
    row={'family':'doctor','case':case.name}
    for label,binary in [('go',GO),('rust',RUST)]:
     with tempfile.TemporaryDirectory(prefix='d765-novel-owned-') as fixture:row[label]=d.observe(binary,case,Path(fixture),probe,GO)
    row['differences']=[key for key in row['go']['contract'] if row['go']['contract'][key]!=row['rust']['contract'][key]];records.append(row)
receipt={'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),
 'dirty':bool(subprocess.check_output(['git','status','--porcelain'],cwd=ROOT)),
 'go_sha256':s.digest(GO),'rust_sha256':s.digest(RUST),'records':records,'count':len(records),
 'normalization':'Only unchanged actual inherited observe function contracts; full raw/state observations retained; no new error/output waiver'}
REPORT.write_text(json.dumps(receipt,indent=2)+'\n')
assert len(records)==18 and all(not row['differences'] for row in records),[(r['case'],r['differences']) for r in records]
