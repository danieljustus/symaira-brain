def stage(name, args, extra=None):
    assert shutil.disk_usage('/workspace').free >= 700 * 1024 ** 2, 'Stop below700MiB'
    assert git('rev-parse', 'HEAD') == SOURCE and (not git('status', '--porcelain'))
    row = {'name': name, 'argv': args, 'cwd': str(ROOT), 'free_before': shutil.disk_usage('/workspace').free, 'started': time.time()}
    run_env = dict(env, SOURCE765_STAGE=name)
    run_env.update(extra or {})
    stdout = output / 'logs' / (name + '.stdout')
    stderr = output / 'logs' / (name + '.stderr')
    with stdout.open('wb') as out, stderr.open('wb') as err:
        child = subprocess.Popen(args, cwd=ROOT, env=run_env, stdout=out, stderr=err, start_new_session=True)
        while child.poll() is None:
            if shutil.disk_usage('/workspace').free < 700 * 1024 ** 2:
                row['space_abort'] = True
                break
            if time.time() - row['started'] > 3600:
                row['outer_timeout'] = True
                break
            try:
                child.wait(timeout=1)
            except subprocess.TimeoutExpired:
                pass
        if child.poll() is None:
            os.killpg(child.pid, signal.SIGTERM)
            try:
                child.wait(timeout=5)
            except subprocess.TimeoutExpired:
                os.killpg(child.pid, signal.SIGKILL)
                child.wait()
        code = child.returncode
    row.update(exit=code, finished=time.time(), free_after=shutil.disk_usage('/workspace').free, stdout_sha256=sha(stdout), stderr_sha256=sha(stderr))
    stages.append(row)
    (output / 'stages.json').write_text(json.dumps(stages, indent=2) + '\n')
    assert code == 0 and (not row.get('outer_timeout')) and (not row.get('space_abort')), f'Full stage failed: {name}; preserve raw outputs'
    if name.startswith('whole-') or name in ['actual-frozen-go', 'source', 'doctor', 'setup', 'guard', 'activity', 'setup-output', 'doctor-output', 'partial-caller-build']:
        assert shutil.disk_usage('/workspace').free >= 700 * 1024 ** 2
        subprocess.run([sys.executable, str(PREP / 'archive-stage.py'), str(output), str(target), name], check=True, env=run_env)
