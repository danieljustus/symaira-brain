# Independent full source review: lexical startup discovery successor

REQUEST CHANGES: one concrete source-backed P2. Reviewed immutable clean
publication381e324852e70fd7c647dce9bbffccb4c2731484 and production source
718125743c58a8a6d6f1ab0f7444f2475342d39e in
/workspace/symaira-daemon772-state-key-discovery-clean. No production, fixture,
original proof, worktree, target or GitHub mutation occurred. This is different-
author source/SDK/provenance review, not compiler or native acceptance. Python
source projections and archive decoding are not actual Go/Rust/provider tests.

## P2: retain impossible zero-mask rules instead of admitting a relative owner

Location: browse/crates/symbrowse-core/src/key_sources/startup_discovery/godebug.rs:83-86
and167-170. Concrete input: GODEBUG=execerrdot=0#qxyf with an executable bare
symvault found through PATH=dot or another relative entry.

Pinned internal/bisect.New accepts the hex token yf: x chooses width4, y resets
bits to0, then f adds15. At flush, the first token byte y changes the width to0
without clearing those bits. The SDK stores cond{mask:0,bits:15,result:true}.
matchResult tests id&mask==bits; no uint64 id can satisfy0==15. The matcher is
valid and nonnil, quiet, and disables all changes without printing. Therefore
Setting.Value returns empty, exec.LookPath returns ErrDot, and frozen
LookupVault treats this provider as unavailable. No guessed stack ID or Go
reporting behavior is required to establish this case.

Native parse preserves bits15 but calls Tree::assign(bits15,width0,true).
That method ignores bits at width0 and writes Leaf(true), so allow_relative
returns true and the startup owner invokes the relative provider. This defeats
the newly scoped Go discovery boundary and can choose a different key provider
even if the final CLI output matches. It is new trie-classification behavior;
it is not the prior unported conditional/reporting case or invalid-suffix
nil-matcher compatibility. Invalidating the accepted SDK token would also
produce the wrong result, because Go ignores parse errors and then admits text0.

The same group includes qxya and qxyF (bits10/15), q!xyf (Go quiet all-enable
versus native refusal), and q-xyf (the impossible subtraction must leave the
initial universal set intact). Positive controls qxy, qy, qn and q0+1 still
classify as their expected universal sets. qxy0 is actually invalid because y
is immediately followed by0; its nil-matcher opt-in is a distinct control.
Later-rule and negation order must remain intact when the impossible rule is
ignored. Preserve the SDK mask/bits semantics at the trie boundary and add
these accepted-hex cases to real Go/native typed, default-CLI owner and mutation
controls before admission. Do not widen stack/report exceptions or call the
refusal an accepted parity divergence.

The retained source projection has17 focused inputs and5600 finite grammar
patterns, with14 mismatches in this same family. It transliterates actual SDK
New/condition evaluation separately from native trie assignment, binds both
source hashes, and keeps all results. It never runs the SDK, Rust or a provider;
these counts are source projections, not differential process results.

## Full-layer assessment and prior findings

Inspected the complete scoped resolver, Unix/Windows discovery, new lexical
helper and full trie/parser, pinned SDK Join/Clean/volume/postClean and
GODEBUG New/Value/Stack/match/printing control flow, extension lowercase data,
SystemKeySources, KeyResolver ordering, startup supervisor validation/envelopes,
standalone and owned group/job lifecycle, CLI/default daemon wiring, frozen
LookupVault/RunVaultCommand and all six owned Go fixtures/new harness/workflow.
Only Ownership::Provider uses discovery. Explicit native separator/volume paths
bypass candidate normalization; the standalone file is byte-identical. Unix
argv0 stays original. Supervisor failure remains an error; only explicit
provider absence allows ordinary key-source fallback. Bounded stdout/key
transport, input lifetime pipe, cancellation waits and descendant ownership
retain the previously reviewed scoped architecture.

The two48fc source findings are corrected in principle: PATH candidates pass
through lexical Go-style normalization before Stat/access/execution, and empty,
invalid and supported quiet-universal suffixes follow the first-# / last-setting
contract. Unix effective-X_OK uses only the SDK ENOSYS/EPERM fallback. The
missing-directory and symlink-dotdot cases have actual process/query/owner
plans and a real prepared traversal mutant; no filesystem canonicalization
was introduced. Native units remain separate from PATHEXT's Go text projection.

Windows source preserves drive-relative joins, rooted/UNC/device volumes,
postClean protection, extension/default/order rules, implicit-cwd opt-out
presence and selected spelling separately from the owned absolute executable.
All187 simple Unicode15 lowercase ranges match the pinned SDK; raw native
PATH units are retained. The safe same-file1.0.6 chain is Windows-only and
acyclic, with exact cached archive checksums. Source inspection does not certify
all Windows raw/invalid namespace semantics or GetFullPathName behavior.
The already documented argv0/GetCommandLine, Lstat desired-access/sharing/
retained-ID and unpaired-unit ownership gaps remain open. No additional native
Windows runtime finding is claimed here.

Conditional/reporting patterns are explicitly unported and produce a failed
provider instead of quietly falling through to an environment key. Nonzero
settings' Go reporting side effects are also unproved. full_discovery_compatibility
remains false. This restriction cannot waive a full discovery cutover, and it
does not cover the new qxyf bug because that input has an exact nonprinting,
stack-independent SDK result.

## Harness, proof retention and approval scope

The new harness retains raw process/query/native-unit vectors before pair
assertions, identifies/stops/waits each autostart daemon before fixture teardown,
and preserves both run and cleanup failures. Actual output/status/query count
and executable owner are compared; Unix argv0 is asserted and Windows raw argv0/
command line remains separately unresolved. Typed SDK fixtures import copied
SDK bisect bytes, not a replacement matcher, and distinguish13 supported cases
from eight unported stack/report cases. Prepared26 Unix/35 Windows CLI pairs,
optional five historical pairs, six Windows BAT/CMD full-cause/no-shell vectors
and three Unix/two Windows actual child mutants remain unexecuted. Original
209+16/310, key31, process63, Registry510, MCP13 and raw-path/lifetime controls
are prior-source obligations, not results for718.

Independently verified17 author source maps and177 current inspected Rust/TOML/
harness/workflow maps; all14 immutable48fc source maps;1219 clean frozen Go
files;17 inspected SDK source/license hashes; all57 original Root proofs plus
seven original independent proof gzip/raw SHA/length pairs; two exact dependency
archive checksums and all187 Unicode rows. Also freshly decoded/hashed187
archived ELF payloads representing247 retained paths and61 actual old-CCC
build/run bindings. Those ELF bytes remain historical, not candidate718 binaries.
Publication381 changes only four source-preparation evidence files after718.
Fresh rustfmt, six Go fixture formatting checks, Python AST parsing and
workflow actionlint passed. No Cargo/Go builder, native product/provider process,
port or target execution occurred. Candidate and original sources stay clean.

Retain this source finding and projections before correction. After a scoped
repair, require clean-source compilation/strict full original gates, actual
new owner/setting/script/error controls, different-author immutable review,
real native six-platform workflows and full772/release acceptance. No approval
for merge or full discovery/argv0/cutover follows from this source review.

Artifacts: /tmp/symaira-discovery718-independent-sdk-projection.py/.json/.log,
/tmp/symaira-discovery718-independent-provenance.py/.json/.log and companion
independent-review-receipt.json. Reviewer tooling's initial source-script syntax
and archive-reference mistakes were corrected; their original script/log remain
retained and are not counted as product failures or substantive controls.
