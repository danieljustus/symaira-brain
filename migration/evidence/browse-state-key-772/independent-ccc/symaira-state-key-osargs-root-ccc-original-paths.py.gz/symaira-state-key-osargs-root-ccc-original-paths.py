from pathlib import Path
import tempfile,os,subprocess,json,hashlib,base64,shutil
cli=Path('/workspace/symaira-daemon772-state-key-osargs/target/debug/symbrowse')
probe=Path('/workspace/symaira-daemon772-state-key-osargs/target/debug/examples/startup_key_source_probe')
fixture=Path('/workspace/oracles/symaira-state-key-4cd-owned-provider')
key='ab'*32
records=[]
with tempfile.TemporaryDirectory(prefix='statekey-root-path-') as temp:
 root=os.fsencode(temp)
 for name in [b'ascii', 'unicode-ä'.encode(), b'raw-\xff']:
  d=root+b'/'+name;os.mkdir(d);provider=d+b'/symvault';shutil.copyfile(os.fsencode(fixture),provider);os.chmod(provider,0o700)
  env={b'HOME':root,b'XDG_CONFIG_HOME':root+b'/config',b'XDG_DATA_HOME':root+b'/data',b'XDG_STATE_HOME':root+b'/state',b'XDG_RUNTIME_DIR':root+b'/runtime',b'PATH':d,b'SYMBROWSE_KEY_PROBE_MODE':b'ab',b'SYMBROWSE_KEY_PROBE_LEDGER':d+b'/queries.jsonl',b'SYMBROWSE_ENCRYPTION_KEY':key.encode()}
  p=subprocess.run([os.fsencode(probe),provider,os.fsencode(cli)],capture_output=True,env=env,cwd=root,timeout=5)
  records.append({'case':base64.b64encode(name).decode(),'provider_arg_base64':base64.b64encode(provider).decode(),'probe_exit':p.returncode,'probe_stdout_base64':base64.b64encode(p.stdout).decode(),'probe_stderr_base64':base64.b64encode(p.stderr).decode(),'observation':json.loads(p.stdout),'provider_invoked':os.path.exists(d+b'/queries.jsonl')})
  # The exact same raw-path program is supported by the helper's OsString route.
  q=subprocess.Popen([os.fsencode(cli),b'--internal-startup-key-provider',provider,b'1000',b'get',b'symbrowse/encryption-key'],stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE,env=env,cwd=root,start_new_session=True)
  q.wait(timeout=5);out,err=q.communicate(timeout=2)
  records[-1]['direct_owned_route']={'exit':q.returncode,'stdout_base64':base64.b64encode(out).decode(),'stderr_base64':base64.b64encode(err).decode()}
receipt={'source':'ccc5c87eb3bf69cf4adbf054b60d5e5342af3891','publication':'ccc5c87eb3bf69cf4adbf054b60d5e5342af3891','binaries_sha256':{str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in [cli,probe,fixture]},'records':records,'scope':'actual publicSystemKeySources with_programs+with_startup_owner vs same actual internal route; no GoCLI parity claim'}
Path('/tmp/symaira-state-key-osargs-root-ccc-original-paths.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps([(r['case'],r['observation'],r['direct_owned_route']['exit']) for r in records]))
