import sys,os,json,time,tempfile,subprocess,shutil
from pathlib import Path
root=Path('/workspace/symaira-daemon772-state-key-osargs');sys.path.insert(0,str(root/'browse/port/harness'));import daemon_state_key as gate
provider=Path('/workspace/oracles/symaira-state-key-4cd-owned-provider');rows=[]
for path in ['', '.', './bin', 'bin', '/ABSOLUTE']:
 for label,binary in [('go',Path('/tmp/symaira-pr801-go-1.26.7')),('rust',root/'target/debug/symbrowse')]:
  with tempfile.TemporaryDirectory(prefix='bk-discover-') as folder:
   owned=Path(folder);env=gate.registry.environment(owned);(owned/'bin').mkdir();shutil.copyfile(provider,owned/'symvault');(owned/'symvault').chmod(0o700);shutil.copyfile(provider,owned/'bin/symvault');(owned/'bin/symvault').chmod(0o700)
   ledger=owned/'queries.jsonl';env.update(PATH=str(owned/'bin') if path=='/ABSOLUTE' else path,SYMBROWSE_KEY_PROBE_MODE='ab',SYMBROWSE_KEY_PROBE_LEDGER=str(ledger),SYMBROWSE_ENCRYPTION_KEY=gate.KEY)
   begin=time.monotonic();p=subprocess.run([str(binary),'state','list','--session','nd'+str(os.getpid()),'--json'],cwd=owned,env=env,capture_output=True,timeout=12)
   row={'path':path,'binary_kind':label,'binary_sha256':gate.registry.process.digest(binary),'exit':p.returncode,'stdout':p.stdout.decode(errors='backslashreplace'),'stderr':p.stderr.decode(errors='backslashreplace'),'elapsed':time.monotonic()-begin,'queries':[json.loads(x) for x in ledger.read_text().splitlines()] if ledger.exists() else []};rows.append(row);print(json.dumps(row),flush=True)
   Path('/tmp/symaira-state-key-osargs-root-ccc-path-discovery.json').write_text(json.dumps({'source':'2b2755231b4ec5ce79de6fb2f022ac423abb44bd','provider_sha256':gate.registry.process.digest(provider),'cases':rows,'scope':'actual owned Linux CLI processes; no native Windows/macOS claim'},indent=2)+'\n')
