# Independent full static review: startup provider discovery

**REQUEST CHANGES: two source-backed P2 findings.** Reviewed clean publication `48fc3639e2265756f3bf8f9c4c914afa971ea5da`, source `64a76183d0d556b4b979af9cdf31b5028c1e76bf`, original State parent `2b2755231b4ec5ce79de6fb2f022ac423abb44bd`, retained Root review `4798e5d099343e89d7a48dac916816df8a421510`, and normal main `5e232700bb9031fc34d4995465a4037837540abb`. Worktree `/workspace/symaira-daemon772-state-key-discovery` stayed clean and unchanged.

This is full different-author **static** review. No compiler/Cargo/Go builder, product/provider/API invocation, target access, port or GitHub mutation was performed. The supplementary owned file-stat/access and Python projections below are not compiled Go/Rust observations or native Windows proof.

## P2: clean discovered PATH candidates before checking/executing their owner

Location: `browse/crates/symbrowse-core/src/key_sources/startup_discovery.rs:45–47`.

Pinned Go `lp_unix.go` computes each candidate with `filepath.Join(dir,file)`; `path_unix.go:join` calls lexical `Clean` before Stat and Eaccess. Rust uses `directory.join(program)` and hands the resulting unclean native path to metadata/access and then execution. PathBuf preserves `..`.

The difference is reachable through the newly native default bare symvault startup path. For absolute PATH `/owned/missing/../bin`, Go checks `/owned/bin/symvault` even when missing does not exist; native stat on `/owned/missing/../bin/symvault` fails. More seriously, if `/owned/link` points to `/owned/other/nested`, PATH `/owned/link/../bin` selects `/owned/bin/symvault` in Go but `/owned/other/bin/symvault` through native filesystem traversal. The latter is a different executable owner, not merely a harmless spelling difference. Both paths are absolute, so ErrDot or GODEBUG refusal does not cover it.

Independent `/tmp/symaira-state-key-discovery-independent-path-projection.py` creates only inert owned placeholders, never executes them, and records actual stat/effective-X_OK/device/inode/content-SHA results for an absolute positive control plus both examples. The control chooses one inode; missing/../bin gives present-vs-ENOENT; symlink/../bin gives two different executable inodes/content hashes. The policy projection is transparently pinned to the inspected SDK join and candidate source, not called actual Go/Rust runtime.

Repair the private discovered-candidate join/clean boundary before lookup and invocation. Do not canonicalize through the filesystem, rewrite explicit caller paths or change standalone semantics. Add actual frozen-Go/native owner/query/argv comparisons for missing and symlink dot-dot PATH candidates, alongside the original first-relative refusal. The Windows join also lacks Go lexical normalization; inspect native Windows volume/root rules independently rather than reusing an unqualified Unix normalizer.

## P2: preserve the SDK's GODEBUG value-suffix contract for opt-in

Location: `browse/crates/symbrowse-core/src/key_sources/startup_discovery.rs:15–21`.

The last `execerrdot=` operand is compared literally to `0`. Pinned Go `internal/godebug.parse` separates an optional `#pattern` from the setting text; `Setting.Value` returns the text when the matcher permits it. A concrete unambiguous case is `GODEBUG=execerrdot=0#`: parse stores text `0`, `bisect.New("")` returns nil, and Value therefore returns `0`. Go allows the relative provider. Native compares `0#` to `0` and treats it as absent. `execerrdot=0#qy` is another SDK-proven quiet-all matcher case; the new code rejects it too. Last-setting precedence still applies.

The independent receipt contains five source-derived settings: plain opt-in, both repeated-setting orders, empty suffix and quiet-all suffix. These are source projections, not actual SDK executions. The empty-suffix finding does not depend on guessing a call-stack hash or inventing arbitrary pattern acceptance.

Preserve the private setting/value contract, including the exact supported modifier behavior and negative controls. Do not globally inject GODEBUG or simply accept every string beginning with `0`. Add real provider-owner comparisons for these concrete settings after runtime allocation; stack-selective bisect modes require explicit evidence/remaining-boundary treatment.

## Full-layer inspection and original finding status

The original Root CCC owner defect is corrected in principle for the prepared simple PATH forms: empty Unix PATH has zero entries, nonempty empty entries map to cwd, the first executable relative candidate is refused before a later absolute program, and the explicit plain opt-in restores relative discovery. Effective X_OK uses existing rustix EACCESS with only ENOSYS/EPERM mode-bit fallback, matching the inspected SDK. Directories/non-executable candidates do not win. The two findings above prevent certification of full corrected discovery semantics.

Read the entire production resolver, Unix/Windows lookup and lowercase module, opt-in startup owner validation, supervisor/result envelopes, SystemKeySources routing, standalone/scoped process lifecycle and owned job/group wrapper; inspected transitive daemon startup/default resolver and frozen Go LookupVault/runner. Only Ownership::Provider applies new discovery. Explicit separator/volume paths and the standalone file remain byte-identical contracts. Unix arg0 is set to the original program; provider arguments remain the fixed public get/reference vectors, and key bytes remain on bounded captured stdout. Lease cancellation, bounded output, cancellation-aware waits, exit status, invalid/missing-owner failures and descendant cleanup retain the scoped owner boundary. No new credential exposure or broad global lookup was added.

The Windows branch mirrors extension order/default/empty-list behavior, implicit cwd opt-out presence, relative-candidate tracking and Lstat/SameFile identity at source level; native runtime is still unproved. UTF16 PATH/program values avoid lossy text conversion. PATHEXT alone uses one replacement per invalid byte and the pinned simple Unicode15 lowercase data. All187 rows match the actual SDK table, including alternating cases and U+0130 rather than Rust full expansion/newer Unicode behavior. The complete Go notice is present.

The new same-file dependency is exact Windows-only1.0.6, with locked winapi-util0.1.11 and existing windows-sys0.61.2; both new cached crate payload hashes match lock checksums. The introduced chain is acyclic and does not add a reverse dependency on product packages. A manual/source lock audit is not fresh Cargo --locked acceptance.

Important unexecuted Windows boundaries: actual hardlink/symlink/reparse identity; native PATH/PATHEXT unpaired units; quoted PATH fields/volume rules; original argv0 versus the absolute selected program and raw GetCommandLine units; BAT/CMD full failure path/cause/no-shell marker across relative opt-in as well as absolute paths. The new BAT/CMD tests prepare two absolute PATH script vectors, not every relative/raw cause. `same_file` requests FILE_READ_ATTRIBUTES and Rust default sharing, whereas pinned Go's lazy file-ID opener uses desired-access0/share0 with the same reparse/backups flags. Do not describe all ACL/sharing cases as byte-identical Lstat behavior without native owned controls. These are precise source differences/test boundaries; no additional hypothetical native-runtime P2 is claimed here.

## Harness, provenance and acceptance

Read all264 lines of the new default-CLI gate and five Go fixtures, existing owner lease/probe interaction, workflow, source-check recipe and ADR. It compares complete output/status/query count and executable owner; Unix argv0 is asserted, Windows argv0/raw command line is retained as a separate unresolved observation. The gate stops and waits for each verified owner, preserves cleanup failures, writes incremental raw events before equality/vector parsing, and only sets complete after all pairs/control. Original Linux inputs remain exact; Darwin's owned security path is honestly a platform-adjusted input. The false-owner child is real prepared behavior, not a status-only fake. There is no current execution result.

Independently verified14 prepared source maps against immutable64a/current bytes; all57 original Root proof gzip/raw SHA/length maps; unchanged standalone bytes; SDK source hashes and187 case ranges; exact dependency cache hashes; and1219 frozen Go .go/mod/sum files against the immutable clean dcddcef0 Git checkout. Publication48fc adds only three preparation evidence files to64a. Original REQUEST CHANGES, ten actual CCC owner observations, failed archive guard and cleanup/executable history remain unchanged. Existing Skills/MCP/Memory-default receipts were not edited.

Python AST/source auditing and actionlint are static checks only. Prepared16 Unix/25 Windows pairs, optional five original pairs, two Windows SDK/script pairs and one true false-owner child are not passing observations. Still required: compile and strict affected/workspace gates, all original209+16/310 suites and key31/process63/Registry510/MCP13 controls, original raw API paths/lifetime cleanup, both new finding reproductions, native six-platform acceptance and full772/release cutover. No target/port resource is held by this review.

Artifacts: `/tmp/symaira-state-key-discovery-independent-static-provenance.json`, `...-independent-path-projection.py`, `...-independent-path-projection/receipt.json`, its log, actionlint log and final review receipt. No source mutation or issue closure follows from this report.
