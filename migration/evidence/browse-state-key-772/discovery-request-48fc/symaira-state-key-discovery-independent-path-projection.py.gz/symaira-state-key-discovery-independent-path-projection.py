"""Owned filesystem + source-policy projections; no Go/Rust/provider execution."""
import hashlib,json,os,pathlib,posixpath,subprocess,tempfile
R=pathlib.Path('/workspace/symaira-daemon772-state-key-discovery');O=pathlib.Path('/tmp/symaira-state-key-discovery-independent-path-projection');O.mkdir()
with tempfile.TemporaryDirectory(prefix='state-path-source-review-') as folder:
 root=pathlib.Path(folder);(root/'bin').mkdir();(root/'other').mkdir();(root/'other'/'nested').mkdir();(root/'other'/'bin').mkdir()
 for p,text in [(root/'bin'/'symvault',b'owned lexically chosen placeholder, never executed'),(root/'other'/'bin'/'symvault',b'owned filesystem-traversed placeholder, never executed')]:p.write_bytes(text);p.chmod(0o700)
 (root/'link').symlink_to(root/'other'/'nested',target_is_directory=True)
 def observation(path):
  try:
   st=os.stat(path);return {'stat_ok':True,'effective_x_ok':os.access(path,os.X_OK,effective_ids=True),'device':st.st_dev,'inode':st.st_ino,'sha256':hashlib.sha256(pathlib.Path(path).read_bytes()).hexdigest()}
  except OSError as e:return {'stat_ok':False,'errno':e.errno,'text':str(e)}
 rows=[]
 for name,directory in [('absolute-control',str(root/'bin')),('missing-dotdot',str(root/'missing')+'/../bin'),('symlink-dotdot',str(root/'link')+'/../bin')]:
  native=directory+'/symvault';go=posixpath.normpath(native);left=observation(go);right=observation(native);rows.append({'case':name,'PATH':directory,'bare_program':'symvault','Go_filepathJoin_projection':go,'native_PathBufJoin_projection':native,'actual_filesystem_Go_clean_candidate':left,'actual_filesystem_native_unclean_candidate':right,'same_selected_inode':left.get('stat_ok') and right.get('stat_ok') and (left['device'],left['inode'])==(right['device'],right['inode']),'compiler_provider_API_execution':False})
 assert rows[0]['same_selected_inode'];assert rows[1]['actual_filesystem_Go_clean_candidate']['stat_ok'] and not rows[1]['actual_filesystem_native_unclean_candidate']['stat_ok'];assert not rows[2]['same_selected_inode'] and rows[2]['actual_filesystem_native_unclean_candidate']['stat_ok']
 settings=[]
 for value in ['execerrdot=0','execerrdot=1,execerrdot=0','execerrdot=0,execerrdot=1','execerrdot=0#','execerrdot=0#qy']:
  last=[part[len('execerrdot='):] for part in value.split(',') if part.startswith('execerrdot=')][-1];native=last=='0';text=last.split('#',1)[0];pattern=last.split('#',1)[1] if '#' in last else None
  # Only SDK-provable empty matcher and quiet-all pattern, never stack-specific emulation.
  assert pattern in (None,'','qy');sdk=text=='0';settings.append({'GODEBUG':value,'native_literal_tail_allows':native,'pinnedSDK_text_empty_or_quietall_projection_allows':sdk,'Go_internal_godebug_bisect_actual_execution':False})
 result={'scope':'SOURCE/FILESYSTEM PROJECTION ONLY; actual owned stat/access observations, no candidate/Go/provider/API runtime','publication':subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip(),'candidate_source':'64a76183d0d556b4b979af9cdf31b5028c1e76bf','rows':rows,'godebug_projection':settings,'SDK_sources':{n:hashlib.sha256((pathlib.Path('/workspace/toolchains/go1.26.7')/n).read_bytes()).hexdigest() for n in ['src/os/exec/lp_unix.go','src/path/filepath/path_unix.go','src/internal/godebug/godebug.go','src/internal/bisect/bisect.go']},'candidate_sha256':hashlib.sha256((R/'browse/crates/symbrowse-core/src/key_sources/startup_discovery.rs').read_bytes()).hexdigest()}
 (O/'receipt.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'filesystem_cases':3,'lexical_policy_mismatches':2,'GODEBUG_source_projections':len(settings),'product_or_compiler_exec':False}))
