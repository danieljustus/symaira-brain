import gzip,hashlib,json,os,re,shutil,subprocess,time
from pathlib import Path
ROOT=Path('/workspace/symaira-daemon772-discovery-runtime');TARGET=ROOT/'target';OUT=Path('/workspace/symaira-discovery772-port-owned-308');FULL=OUT/'full'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
source=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT).decode().strip()
assert source=='308f3049f83fdc26c5b81f843b0160644d8ca0c3' and not subprocess.check_output(['git','status','--porcelain'],cwd=ROOT)
nonpath=Path('/tmp/symaira-discovery-runtime-308-nonport-handoff.json');non=json.loads(nonpath.read_bytes())
port=json.loads((FULL/'validation.json').read_bytes());assert port['complete'] and all(r['exit']==0 for r in port['stages'])
for name,digest in non['source_sha256'].items():assert sha(ROOT/name)==digest,name
for name,digest in port['source_sha256'].items():assert sha(ROOT/name)==digest,name
assert sha(Path('/tmp/symaira-discovery-runtime-308-nonport/validation.json'))==non['validation_sha256']
for name,digest in non['logs_sha256'].items():assert sha(Path('/tmp/symaira-discovery-runtime-308-nonport')/name)==digest
ret=json.loads((ROOT/'migration/evidence/browse-state-key-772/discovery-runtime-prepared/retention.json').read_bytes())
for name,digest in ret['SDK_source_sha256'].items():assert sha(Path('/workspace/toolchains/go1.26.7')/name)==digest,name
for row in ret['original_review_files']:assert sha(ROOT/row['retained'])==row['sha256']
roles=dict(non['current_executed_test_or_explicit_build_roles'])
log=(FULL/'mcp.json.tests.log').read_text();counts=re.findall(r'test result: \w+\. (\d+) passed; (\d+) failed; (\d+) ignored;',log)
for name in re.findall(r'Running [^\n]*\(([^)]+)\)',log):
 p=Path(name);assert p.is_file() and p.is_relative_to(TARGET)
 record=roles.setdefault(str(p),dict(sha256=sha(p),bytes=p.stat().st_size,bound_execution_stages=[]))
 assert record['sha256']==sha(p);record['bound_execution_stages'].append('mcp-actual-workspace')
roles[str(FULL/'retained-provider')]=dict(sha256=sha(FULL/'retained-provider'),bytes=(FULL/'retained-provider').stat().st_size,bound_execution_stages=['build-original-provider','discovery-original-retained-provider'])
roles['/tmp/symaira-pr801-go-1.26.7']=dict(sha256=sha(Path('/tmp/symaira-pr801-go-1.26.7')),bytes=Path('/tmp/symaira-pr801-go-1.26.7').stat().st_size,bound_execution_stages=['key','process','registry','discovery','mcp'])
roles['/tmp/symaira-pr801-go-mcp-v0.8.0']=dict(sha256=sha(Path('/tmp/symaira-pr801-go-mcp-v0.8.0')),bytes=Path('/tmp/symaira-pr801-go-mcp-v0.8.0').stat().st_size,bound_execution_stages=['mcp'])
archive=Path('/workspace/oracles/symaira-discovery772-308-current-binaries');archive.mkdir(exist_ok=False)
reuse=json.loads(Path('/tmp/symaira-discovery-runtime-verified-archive-reuse.json').read_bytes())['unique'];unique={};rows=[]
def bind(p,kind):
 h=sha(p)
 if h not in unique:
  assert shutil.disk_usage('/workspace').free>=700*1024**2
  prior=reuse.get(h)
  if prior: gz=Path(prior['archive']);assert sha(gz)==prior['gzip_sha256']
  else:
   gz=archive/(h+'.gz')
   with p.open('rb') as src,gz.open('wb') as dst:
    with gzip.GzipFile(fileobj=dst,mode='wb',mtime=0) as zipped:shutil.copyfileobj(src,zipped)
  hashed=hashlib.sha256();size=0
  with gzip.open(gz,'rb') as stream:
   while b:=stream.read(1024*1024):hashed.update(b);size+=len(b)
  assert hashed.hexdigest()==h and size==p.stat().st_size
  unique[h]=dict(archive=str(gz),gzip_sha256=sha(gz),bytes=size,reused=bool(prior))
 rows.append(dict(path=str(p),sha256=h,bytes=p.stat().st_size,role=kind))
for p in sorted(TARGET.rglob('*')):
 if not p.is_file():continue
 with p.open('rb') as f:magic=f.read(4)
 if magic==b'\x7fELF':bind(p,'current-target-cache-not-all-executed')
for name,record in roles.items():
 p=Path(name);assert sha(p)==record['sha256'] and p.stat().st_size==record['bytes'];bind(p,'actually-executed-or-explicitly-built')
# Cache binaries must also remain recoverable before any separately authorized retirement.
cachefiles=[]
for p in sorted((OUT/'go-build').rglob('*')):
 if not p.is_file():continue
 with p.open('rb') as f:magic=f.read(4)
 cachefiles.append(dict(path=str(p),bytes=p.stat().st_size,sha256=sha(p),ELF_PE=magic==b'\x7fELF' or magic[:2]==b'MZ'))
 if cachefiles[-1]['ELF_PE']:bind(p,'Go-cache-binary-not-an-execution-claim')
(archive/'receipt.json').write_text(json.dumps(dict(source=source,rows=rows,unique=unique,actual_roles=roles,all_roundtrips_verified=True),indent=2)+'\n')
(OUT/'go-cache-manifest.json').write_text(json.dumps(cachefiles,indent=2)+'\n')
frozen=Path('/workspace/oracles/daemon772-go-source');assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=frozen).decode().strip()=='dcddcef0df5789123c7c9a7ebe6e01f10e941f2c'
assert not subprocess.check_output(['git','status','--porcelain'],cwd=frozen)
names=subprocess.check_output(['git','ls-files','*.go','go.mod','go.sum','browse/go.mod','browse/go.sum','guard/go.mod','guard/go.sum'],cwd=frozen).decode().splitlines()
(OUT/'frozen-go-source.json').write_text(json.dumps({n:sha(frozen/n) for n in names},indent=2)+'\n')
proofs={str(p.relative_to(OUT)):{'sha256':sha(p),'bytes':p.stat().st_size} for p in OUT.rglob('*') if p.is_file() and not p.is_relative_to(OUT/'go-build') and not p.is_relative_to(OUT/'home') and not p.is_relative_to(OUT/'temp')}
(OUT/'proof-map.json').write_text(json.dumps(proofs,indent=2)+'\n')
summary=dict(source=source,upstream_static_review='7e5c4561c82803403b579d011fb687bbe254d32a',all_original_commands_retained=True,nonport_handoff_sha256=sha(nonpath),port_validation_sha256=sha(FULL/'validation.json'),full_workspace_counts=dict(passed=sum(int(r[0]) for r in counts),failed=sum(int(r[1]) for r in counts),ignored=sum(int(r[2]) for r in counts),summaries=len(counts)),actual_roles=len(roles),target_ELF_paths=sum(r['role']=='current-target-cache-not-all-executed' for r in rows),all_unique_archived=len(unique),binary_receipt=str(archive/'receipt.json'),binary_receipt_sha256=sha(archive/'receipt.json'),frozen_Go_source_files=len(names),SDK_source_files=len(ret['SDK_source_sha256']),original_review_files=len(ret['original_review_files']),proof_files=len(proofs),Go_cache_files=len(cachefiles),Go_cache_ELF_PE=sum(r['ELF_PE'] for r in cachefiles),complete=True,author_runtime_verification_not_independent_approval=True,native_Windows_or_Darwin_runtime=False,full_discovery_compatibility=False,explicitly_unported_Go_stack_report_patterns=8,mandatory_remaining=['Different-author full runtime/source review','Native six-OS CI and protected current required checks','Full Go stack/report compatibility before discovery cutover'],free_workspace_bytes=shutil.disk_usage('/workspace').free)
(OUT/'summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary,indent=2))
