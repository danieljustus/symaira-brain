#!/usr/bin/env bash
set -euo pipefail
umask 022
source /home/agent/.cargo/env
cd /workspace/symaira-daemon772-discovery-runtime
export PATH=/workspace/toolchains/go1.26.7/bin:/workspace/toolchains/bin:$PATH
export CARGO_TARGET_DIR=/workspace/symaira-daemon772-discovery-runtime/target
export CARGO_BUILD_JOBS=2 CARGO_INCREMENTAL=0 CARGO_PROFILE_DEV_DEBUG=0 CARGO_PROFILE_TEST_DEBUG=0 CARGO_NET_OFFLINE=true
export CARGO_HOME=/home/agent/.cargo RUSTUP_HOME=/home/agent/.rustup
export GOENV=off GOTOOLCHAIN=local GOPROXY=off CGO_ENABLED=0 GOMODCACHE=/home/agent/go/pkg/mod
export GOCACHE=/workspace/symaira-discovery772-port-owned-308/go-build GOMAXPROCS=2 GOFLAGS=-p=2
exec env HOME=/workspace/symaira-discovery772-port-owned-308/home USERPROFILE=/workspace/symaira-discovery772-port-owned-308/home XDG_CONFIG_HOME=/workspace/symaira-discovery772-port-owned-308/config XDG_DATA_HOME=/workspace/symaira-discovery772-port-owned-308/data XDG_CACHE_HOME=/workspace/symaira-discovery772-port-owned-308/cache XDG_STATE_HOME=/workspace/symaira-discovery772-port-owned-308/state XDG_RUNTIME_DIR=/workspace/symaira-discovery772-port-owned-308/runtime TMPDIR=/workspace/symaira-discovery772-port-owned-308/temp TMP=/workspace/symaira-discovery772-port-owned-308/temp TEMP=/workspace/symaira-discovery772-port-owned-308/temp PYTHONDONTWRITEBYTECODE=1 python3 migration/evidence/browse-state-key-772/discovery-runtime-prepared/run.py --phase port --allocation-receipt /workspace/review-proof/discovery772-308-port-allocation.json --port-release-receipt /workspace/symaira-discovery772-port-owned-308/port-receipt.json --out /workspace/symaira-discovery772-port-owned-308/full --archive-reuse-receipt /tmp/symaira-discovery-runtime-verified-archive-reuse.json
