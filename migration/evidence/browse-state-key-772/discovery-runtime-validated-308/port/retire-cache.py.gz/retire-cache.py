from pathlib import Path
import hashlib,json,os,shutil,subprocess,time
OUT=Path('/workspace/symaira-discovery772-port-owned-308');CACHE=OUT/'go-build';TARGET=Path('/workspace/symaira-daemon772-discovery-runtime/target')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
manifest=OUT/'go-cache-manifest.json';rows=json.loads(manifest.read_bytes());assert rows and not any(r['ELF_PE'] for r in rows)
summary=json.loads((OUT/'summary.json').read_bytes());binary=Path(summary['binary_receipt']);assert sha(binary)==summary['binary_receipt_sha256']
assert json.loads(binary.read_bytes())['all_roundtrips_verified']
for row in rows:
 p=Path(row['path']);assert p.is_relative_to(CACHE) and p.is_file() and not p.is_symlink() and sha(p)==row['sha256'] and p.stat().st_size==row['bytes']
 with p.open('rb') as f:magic=f.read(4)
 assert magic!=b'\x7fELF' and magic[:2]!=b'MZ'
assert {str(p) for p in CACHE.rglob('*') if p.is_file()}=={r['path'] for r in rows}
def users():
 result=[];unreadable=[]
 for p in Path('/proc').iterdir():
  if not p.name.isdigit() or p.name==str(os.getpid()):continue
  for name in ['exe','cwd','environ']:
   try:v=(p/name).read_bytes() if name=='environ' else os.fsencode(os.readlink(p/name))
   except (FileNotFoundError,ProcessLookupError):continue
   except PermissionError:unreadable.append(dict(pid=p.name,field=name));continue
   if os.fsencode(str(CACHE)) in v:result.append(dict(pid=p.name,field=name))
  try:
   for fd in (p/'fd').iterdir():
    try:v=os.readlink(fd)
    except (FileNotFoundError,ProcessLookupError,PermissionError):continue
    if v==str(CACHE) or v.startswith(str(CACHE)+'/'):result.append(dict(pid=p.name,field=str(fd)))
  except (FileNotFoundError,ProcessLookupError,PermissionError):pass
 return result,unreadable
visible,unknown=users();assert not visible
before=shutil.disk_usage('/workspace').free;assert before>=700*1024**2
receipt=dict(authorized_by='Root explicit only-owned GOCACHE derivative retirement after all current native/Go archives and raw proof binding',root=str(CACHE),source=summary['source'],manifest_sha256=sha(manifest),files=len(rows),bytes=sum(r['bytes'] for r in rows),ELF_PE=0,binary_receipt_sha256=sha(binary),visible_consumers_before=visible,unreadable_process_fields=unknown,free_before_bytes=before,started=time.time(),retired=False)
p=OUT/'cache-retirement.json';p.write_text(json.dumps(receipt,indent=2)+'\n')
shutil.rmtree(CACHE)
receipt.update(retired=True,free_after_bytes=shutil.disk_usage('/workspace').free,visible_consumers_after=users()[0],only_owned_cache_removed=True,target_current_native_Go_archives_SDK_raw_unchanged=True)
receipt['actual_free_delta_bytes']=receipt['free_after_bytes']-before;receipt['two_GiB_start_reserve_established']=receipt['free_after_bytes']>=2*1024**3
assert sha(binary)==summary['binary_receipt_sha256']
p.write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({k:receipt[k] for k in ['free_before_bytes','free_after_bytes','actual_free_delta_bytes','two_GiB_start_reserve_established','visible_consumers_after','ELF_PE']},indent=2))
