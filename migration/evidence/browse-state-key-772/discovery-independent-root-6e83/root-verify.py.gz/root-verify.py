import ast, gzip, hashlib, json, subprocess
from pathlib import Path

ROOT = Path('/workspace/symaira-daemon772-discovery-runtime')
REVIEW = Path('/workspace/review-artifacts/discovery772-6e83-review-doctor')
OUT = Path(__file__).parent
def digest(path):
    h = hashlib.sha256()
    with open(path, 'rb') as stream:
        while data := stream.read(1024 * 1024):
            h.update(data)
    return h.hexdigest()

assert subprocess.check_output(['git', '-C', str(ROOT), 'rev-parse', 'HEAD']).decode().strip() == '6e83b875afc31e4688b61371daf76e655c9082ec'
assert not subprocess.check_output(['git', '-C', str(ROOT), 'status', '--porcelain'])
receipt = json.loads((REVIEW / 'independent-review-receipt.json').read_bytes())
assert digest(REVIEW / 'independent-review-receipt.json') == 'f653cd9762111f89c5a57d8162cc0f90764b0ff81b08030b5938149d5cfd880f'
assert digest(REVIEW / 'independent-review.md') == '81d21c1b9189eeb5b8eb7b505f1a47186b67a4e75f0f1a0f808b1e43f72304d7'
for path, expected in receipt['proof_files_sha256'].items():
    assert '/target/' not in path
    assert digest(path) == expected, path
provenance = json.loads((REVIEW / 'provenance.json').read_bytes())
for row in provenance['archive_payloads']:
    h = hashlib.sha256(); length = 0
    with gzip.open(row['archive'], 'rb') as stream:
        while data := stream.read(1024 * 1024):
            length += len(data); h.update(data)
    assert h.hexdigest() == row['sha256'] and length == row['bytes'], row['archive']
retention = json.loads((ROOT / 'migration/evidence/browse-state-key-772/discovery-runtime-validated-308/retention.json').read_bytes())
completed = next(row for row in retention['records'] if row['original'].endswith('/finalize-corrected.log'))
assert completed['sha256'] == '696594dde5ad20683871a657c2179f01ebde6c1b6897ce4049ab16a1e56d0067' and completed['bytes'] == 2256
assert digest(completed['original']) == completed['sha256']
source = (REVIEW / 'comparisons.py').read_text()
tree = ast.parse(source)
# Preserve all comparator statements, changing only its private output directory.
matches = 0
for node in ast.walk(tree):
    if isinstance(node, ast.Constant) and node.value == str(REVIEW):
        node.value = str(OUT); matches += 1
assert matches == 1
(OUT / 'pure-comparator-original.py').write_text(source)
try:
    exec(compile(tree, str(REVIEW / 'comparisons.py'), 'exec'), {'__name__': '__main__'})
except SystemExit as result:
    assert result.code == 0, result.code
(OUT / 'verification.json').write_text(json.dumps(dict(
    publication='6e83b875afc31e4688b61371daf76e655c9082ec',
    full_bound_files=len(receipt['proof_files_sha256']), archive_roundtrips=len(provenance['archive_payloads']),
    actual_recorded_comparisons_recomputed=True, original_review_complete=True,
    original_self_log_disagreement_retained=True, completed_log_independently_bound=True,
    ephemeral_go_helper_bytes_absent_from_595_archive=True,
    no_product_sdk_compiler_target_port=True, native6_pending=True, full772_open=True), indent=2)+'\n')
