# Discovery772 independent source, retained runtime and provenance review

Disposition: **APPROVE the bounded Linux candidate for the next protected/native review stage.** No new confirmed production blocker. This is a different-author review of the complete source and already recorded actual runtime evidence; resource restrictions prohibited new product execution. It is not native-six-platform acceptance, approval of the full Go discovery contract, or closure of #772.

Reviewed clean publication `6e83b875afc31e4688b61371daf76e655c9082ec`, tested source `308f3049f83fdc26c5b81f843b0160644d8ca0c3`, worktree `/workspace/symaira-daemon772-discovery-runtime`. Actual CLI SHA256 `f2171f2bf56159a37fdd80caca500ac4c38035a22983d12ec21d0cc1b69d6cea`. The publication adds only 66 evidence files; production and harness bytes remain those tested at 308f. No candidate files, Go sources, executables, archives, ports, targets or GitHub objects were modified.

## Complete source review

I read the prior complete independent mask/ownership review and its original evidence, revalidated all 177 upstream source identities and independently inspected the live provider call graph and contracts: CLI admission/private route, ServerOptions startup owner, runtime store initialization, KeyResolver precedence/failure behavior, SystemKeySources lookup versus standalone provisioning, supervised argv/status envelope, stdin lifetime cancellation, bounded readers, process groups and Windows job ownership, executable lookup/path helpers, PATHEXT decoding/casing, last-setting GODEBUG parsing, mask grammar/trie and supported/unported decisions, fixtures, comparison projections and all 21-stage driver commands.

Of the 177 source identities, 175 remain byte-identical to independently reviewed upstream 7e5c4561. The complete runtime production delta is one ASCII prefix comparison rewritten from uppercase equality to `u8::eq_ignore_ascii_case`; the `unit <= 127` guard remains. The only runtime test delta prints the actual existing Guard error and makes the descendant-pipe fixture consume its stdin request before exiting. Its 20/50ms budgets and timeout assertions are unchanged. Retained initial b17/a147/df16 failures support the narrow fixture and lint changes. No dependency, frozen Go, standalone key provisioning or provider fallback policy changed in this runtime successor.

Unix bare-name selection follows the pinned SDK: empty PATH has zero entries; each candidate uses lexical Join/Clean; the first executable relative candidate refuses by default rather than skipping to a later owner; explicit opt-in preserves argv0 and selects an owned absolute invocation path. Effective-access fallback matches the SDK. Windows source handles implicit CWD, relative-to-absolute same-file preference, PATHEXT ordering, lstat identity and batch CreateProcess failure instead of silently invoking cmd.exe. Windows execution/ACL/wide-path cleanup remains unproved here. The wrapper API and drop behavior alone do not prove inactive Windows descendants; fresh native evidence remains mandatory.

The trie ignores conditions with bits outside their mask, preserving earlier/later rules and inversion. Its width-zero/64 semantics agree with pinned `bisect.New` source and the preserved actual SDK-only original proof. The current real SDK helper records its own Stack result separately and never substitutes that result for the frozen CLI's distinct stack owner.

## Actual evidence independently verified and recomputed

All 14 nonport stages and seven port stages report successful exit zero, exact tested source and verified log hashes. I parsed the original full logs rather than accepting summary counts.

| Actual author gate | Verified result |
| --- | --- |
| Affected original tests | 215 passed, 0 failed, 3 intentional ignores, 34 summaries |
| Affected all-target tests | 214 passed, 0 failed, 3 intentional ignores, 33 summaries |
| MCP library | 16 passed, 0 failed |
| Whole workspace with real Go MCP fixtures | 316 passed, 0 failed, 3 intentional ignores, 67 summaries |
| Startup key/store | 31 pairs; stored API observations match; 3 actual mutants rejected |
| Daemon process | 63 responses; 3 comparator controls rejected |
| Registry | 510 CLI observations, 20 raw frames, 8 concurrent clients per binary; 8 controls rejected |
| MCP | All 13 original actual Go/native frames match; 3 genuine fixture/endpoint failures rejected |
| Provider ownership | 8 lifecycle cases, 9 invalid admissions, 3 raw/native path cases; unrelated provider survives |
| Discovery | 40 pairs plus 5 original-provider pairs; Unix argv0 and selected executable paths match; 4 actual discovery mutants rejected |
| Typed SDK settings | 30 supported decisions verified against actual copied SDK results; 8 explicit fail-closed unported patterns |

The independent `comparisons.py` executes only the audited pure comparator functions over retained data. It rechecks all bytes, exits, paths, validated owner/PID/time projections, store observations, process ordering, real mutant divergence, complete raw pair retention and cleanup facts. It does not launch any product, SDK, compiler or transport. 3,055 report source-map entries match current Rust/harness and frozen Go files. The initial two reviewer-only extraction mistakes (missing pure helper, ninth refusal's intentionally smaller recorded shape) are preserved as separate logs; neither was a candidate failure.

Literal invalid CLI bytes, selected-output failures and implemented help are checked before registry projections. Only the precise unimplemented session-id help row is removed under the already documented bounded contract. Paths and PID/time projection rules remain scoped to independently validated owned process observations. Existing Go warning/Rust shutdown diagnostics are checked explicitly rather than broadly discarded.

## Provenance and preservation

Verified every one of 1,219 frozen Go file hashes at clean `dcddcef0df5789123c7c9a7ebe6e01f10e941f2c`, 17 pinned SDK source hashes, 14 original review files, 80 original lossless raw archives, 187 historical ELF payloads, 22 SDK retained files and all 64 final lossless raw files. In total the archive verifier streamed 948 archive records and checked both compressed and decompressed hashes/lengths without restoring or running any executable.

The current binary receipt contains **712 path/role records, 595 unique payloads, 646 target-cache paths and 66 test/explicit-build/product-oracle roles**. Every unique current payload round-trips. All 31 affected-original, 33 all-target and 57 workspace `Running` executable paths map to the recorded stages and archived identities. The current CLI and reports bind the original probe bytes correctly. Later workspace aliases are distinct retained artifacts:

- Store probe executed earlier: `7c72b2cff21ef8580d6119274046d27acbfb124b2300b540e3fcc3b2ec715c92`; later alias `479b9fe0959584697efe21a82c08034774a8b54a7db8f883887c8f3fd6efd863`.
- Startup probe executed earlier: `823d21100cde17605c7bf715523e1a3ae8fd65415dcc02d6a4b831c1ba99c4ba`; later alias `5766d577295e861229dd772c193f5c48e5281e448d13b97febd413228709569f`.

Neither later alias is relabeled as an earlier execution. Root's independent transfer receipt `44ad8e415b5fb3f86092a3cc88ae9a5459fd66ea65dda60c2dea20e51a96f494` agrees on these sources, payload preservation and target ownership. This reviewer never inspected the moved target.

Two precise, nonblocking preservation qualifications:

1. The 40-entry port proof map captured its own `finalize-corrected.log` before the final stdout print, recording the empty snapshot. The completed 2,256-byte log is correctly and independently bound in the tracked 64-record retention at SHA `696594dde5ad20683871a657c2179f01ebde6c1b6897ce4049ab16a1e56d0067`. The verifier preserves the two original map disagreements instead of rewriting either original. No process result/log differs. Future finalization should exclude or explicitly label the in-flight self-log and bind the completed log after its writer closes.
2. The 595 archive is not an archive of every ephemeral Go test helper. The discovery provider (`a1d8c6e4…`), discovery mutant (`bbee67b4…`) and current typed SDK helper (`b45e0f24…`) have retained build sources, actual reported hashes and raw outputs, but their temporary executable bytes are absent from that archive. This limits independent executable-byte replay of those temporary helpers; it does not alter the preserved product/oracle/actual test executable roles. Future actual native runs should archive these helpers before temporary fixture teardown if complete executable retention is claimed.

## Required remaining acceptance

The eight exact unresolved patterns are `q0`, `q1`, `qxf`, `y`, `n`, `qy-0`, `qvy`, `!y`. Their actual current native results remain a terminal failure with no Vault query or environment downgrade. They are supported by Go's real stack/report identity and are **not accepted as native parity**. Other stack/report forms must not inherit a blanket waiver from this finite inventory.

Windows script SDK vectors executed on this Linux host: **zero**. Windows GNU Clippy and Darwin checks in the logs are compilation/source checks, not native OS execution. Current native six-platform/protected checks, genuine Windows/Darwin ownership/cleanup/path behavior and complete remaining Go stack/report contracts are mandatory before full discovery cutover or #772 closure. This bounded review does not dispose of those gates.

Review outputs are confined to `/workspace/review-artifacts/discovery772-6e83-review-doctor`. No compiler, SDK invocation, new cache, target access, runtime replay, listener or resource lease was used. The candidate remains clean and immutable; Root/Usage retain exclusive ownership of the moved target.
