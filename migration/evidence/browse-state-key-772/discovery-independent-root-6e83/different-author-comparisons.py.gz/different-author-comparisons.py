import ast,base64,copy,hashlib,json,os,pathlib,re,types
from datetime import datetime
R=pathlib.Path('/workspace/symaira-daemon772-discovery-runtime');H=R/'browse/port/harness';O=pathlib.Path('/workspace/review-artifacts/discovery772-6e83-review-doctor');P=pathlib.Path('/workspace/symaira-discovery772-port-owned-308/full')
errors=[];checked={}
def ck(v,m):
 if not v:errors.append(m)
def pure(path,names,extra={}):
 tree=ast.parse(path.read_text());nodes=[x for x in tree.body if isinstance(x,ast.FunctionDef) and x.name in names];assert len(nodes)==len(names)
 ns=dict(copy=copy,json=json,base64=base64,os=os,re=re,datetime=datetime,**extra)
 exec(compile(ast.Module(body=nodes,type_ignores=[]),str(path),'exec'),ns);return ns
def data(n):return json.load(open(P/(n+'.json')))
k=data('key');ns=pure(H/'daemon_state_key.py',['normalized']); norm=ns['normalized']
for x in k['cases']:ck(norm(x['go'])==norm(x['rust']),'key '+x['input']['name'])
for x in k['negative_controls']:
 ref=next(a for a in k['cases'] if a['input']['name']==x['input']['name']);ck(norm(x['actual'])!=norm(ref['go']),'key control '+x['name'])
ck(k['oracle_api']['observations']==k['rust_store_probe']['observations'],'key store API');ck(k['startup_pairs']==len(k['cases'])==31,'key31');checked['key_pairs']=31;checked['key_actual_mutants']=3
p=data('process');ns=pure(H/'daemon_process.py',['normalized','compare','controls'],{'COMMANDS':['daemon.ping','daemon.status','daemon.info','daemon.sessions','daemon.session','daemon.invalid','daemon.stop']})
# Read the literal list from the immutable comparator source rather than invent it.
tree=ast.parse((H/'daemon_process.py').read_text());ns['COMMANDS']=ast.literal_eval(next(x.value for x in tree.body if isinstance(x,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='COMMANDS' for t in x.targets)))
for x in p['cases']:ck(ns['compare'](x),'process '+x['session'])
ck(ns['controls'](p['cases'])==p['negative_controls'],'process controls');ck(p['total']==63,'process63');checked['process_observations']=63;checked['process_comparator_controls']=3
cli=pure(H/'daemon_registry_cli.py',['comparable_help','compare'],{'UNSUPPORTED_ID_ROW':b'  id          Derive a stable, collision-free session id from the local repository layout\n'})
reg=pure(H/'registry_compare.py',['normalize','compare','controls'],{'cli_edges':types.SimpleNamespace(compare=cli['compare'])});d=data('registry');ck(reg['compare'](d['case']),'registry');ck(reg['controls'](d['case'])==d['negative_controls'],'registry controls');checked['registry']=d['counts_per_binary'];checked['registry_controls']=8
m=data('mcp');ck(len(m['observations'])==13 and m['test_exit']==0,'mcp13');
for x in m['observations']:ck(x['rust_exit']==0 and not x['rust_stderr_base64'] and x['rust_stdout_base64']==x['go_stdout_base64'],'mcp '+x['name'])
ck(len(m['negative_controls'])==3 and all(x['exit']!=0 and x['rejected'] for x in m['negative_controls']),'mcp genuine controls');checked['mcp']=13;checked['mcp_actual_controls']=3
D=data('discovery');raw=json.load(open(P/'discovery.raw.json'));ck(raw['complete'],'raw complete');pair_events=[x for x in raw['events'] if x['phase']=='pair.observed'];ck(len(pair_events)==45,'all raw pairs');
for i,x in enumerate(D['cases']+D['original_retained_provider_pairs']):
 l=x['go'];r=x['rust'];fields=['exit','stdout_base64','stderr_base64','vault_query_count'];
 if i<40:fields+=['owner_paths']
 ck(all(l[f]==r[f] for f in fields),'discovery '+x['case']);ck(l['exit']==r['exit']==0 and not l['stderr_base64'] and not r['stderr_base64'],'discovery clean');
 for obs in [l,r]:ck(obs['cleanup']['gone_before_teardown'],'owned cleanup');
 if i<40:ck([v['argv0_base64'] for v in l['vectors']]==[v['argv0_base64'] for v in r['vectors']],'Unix argv0 '+x['case'])
 ck(any(e['case']==x['case'] and e['go']==l and e['rust']==r for e in pair_events),'raw pair exact '+x['case'])
settings=D['typed_sdk_setting_vectors'];ck(len(settings)==38,'38 SDKsettings');unsupported=[]
for x in settings:
 ck(json.loads(base64.b64decode(x['go_stdout_base64']))==x['go'],'rawSDKjson');ck(json.loads(base64.b64decode(x['rust_stdout_base64']))==x['rust'],'rawnativeSetting')
 ck(x['go_exit']==x['rust_exit']==0 and not x['go_stderr_base64'] and not x['rust_stderr_base64'],'SDK streams')
 if x['expected_allow'] is None:
  unsupported.append(x['pattern']);ck(not x['rust']['configured'] and 'requires Go runtime stack/report identity' in x['rust']['error'] and x['vault_queries']==0,'unportedfailclosed '+x['pattern'])
 else:ck(all(v['enabled']==x['expected_allow'] and not v['print'] for v in x['go']['typed_ids']) and x['rust']['configured'] and not x['rust']['error'] and x['vault_queries']==int(x['expected_allow']),'SDK allow '+x['pattern'])
ck(unsupported==D['unported_stack_report_patterns']==['q0','q1','qxf','y','n','qy-0','qvy','!y'],'exact8unported')
for x in D['negative_controls']:
 orig=next(z for z in D['cases'] if z['case']==x['observed']['case']);ck(x['observed']['vault_query_count']!=orig['go']['vault_query_count'] and x['observed']['cleanup']['gone_before_teardown'],'realmutant '+x['mode'])
checked.update(discovery_pairs=len(D['cases']),original_pairs=5,supported_settings=30,unported_patterns=unsupported,discovery_actual_mutants=len(D['negative_controls']),windows_script_vectors=0)
W=data('ownership');ck(len(W['cases'])==8,'8ownershipcases')
for x in W['cases']:ck(x['provider_and_descendants_gone'] and x['unrelated_provider_survived'],'ownership '+x['mode']+' '+x['trigger'])
for x in W['refusals']:
 ck(x['exit']==1 and x['provider_not_queried'],'ownedrefusal')
 if x.get('name')!='refuse-inherited-unix-group':ck(not x['stdout'] and not x['stderr'],'ownedrefusal streams')
for x in W['native_paths']['cases']:ck(x['public']['exit']==x['internal']['exit']==0 and len(x['public_queries'])==len(x['internal_queries'])==1,'ownedrawpaths')
ck(W['native_paths']['negative_control']['rejected'],'rawpathmutant');checked.update(ownership_cases=8,ownership_refusals=9,owned_native_path_cases=3)
# Bind every current report source and every reported Go source; never touch target aliases.
maps=0
for n in ['key','process','registry','ownership','discovery']:
 d=data(n)
 for p,h in d['candidate_source_sha256'].items():ck(hashlib.sha256((R/p).read_bytes()).hexdigest()==h,n+' currentSource '+p);maps+=1
 for p,h in d.get('go_source_sha256',{}).items():ck(hashlib.sha256((pathlib.Path('/workspace/oracles/daemon772-go-source')/p).read_bytes()).hexdigest()==h,n+' GoSource '+p);maps+=1
checked['source_map_comparisons']=maps
(O/'comparisons.json').write_text(json.dumps({'source':'308f3049f83fdc26c5b81f843b0160644d8ca0c3','checked':checked,'errors':errors,'scope':'pure recorded-data assertions only; zero product/runtime/Cargo/SDK/target execution'},indent=2)+'\n');print(json.dumps({'checked':checked,'errors':errors}));raise SystemExit(bool(errors))
