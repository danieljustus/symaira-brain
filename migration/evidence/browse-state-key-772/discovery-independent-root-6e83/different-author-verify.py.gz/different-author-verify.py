import gzip,hashlib,json,pathlib,subprocess,re,time
R=pathlib.Path('/workspace/symaira-daemon772-discovery-runtime'); O=pathlib.Path('/workspace/review-artifacts/discovery772-6e83-review-doctor'); P=pathlib.Path('/workspace/symaira-discovery772-port-owned-308')
errors=[]; stats={}; bound={}; payloads={}
def digest(p):
 h=hashlib.sha256()
 with open(p,'rb') as f:
  while b:=f.read(1024*1024): h.update(b)
 return h.hexdigest()
def ck(v,msg):
 if not v: errors.append(msg)
def file(p,sha,n=None):
 p=pathlib.Path(p); ck('/target/' not in str(p),'forbidden target path '+str(p))
 if '/target/' in str(p): return
 try:
  got=digest(p); ck(got==sha,'SHA '+str(p)); ck(n is None or p.stat().st_size==n,'length '+str(p)); bound[str(p)]=got
 except Exception as e: errors.append(str(p)+': '+str(e))
def archive(p,compressed,raw,n):
 p=pathlib.Path(p); file(p,compressed)
 if (str(p),raw,n) in payloads:return
 try:
  h=hashlib.sha256(); size=0
  with gzip.open(p,'rb') as f:
   while b:=f.read(1024*1024): h.update(b); size+=len(b)
  ck(h.hexdigest()==raw,'raw SHA '+str(p));ck(size==n,'raw length '+str(p));payloads[(str(p),raw,n)]=True
 except Exception as e:errors.append(str(p)+': '+str(e))
def load(p):
 p=pathlib.Path(p);bound[str(p)]=digest(p);return json.load(open(p))
def git(*a):return subprocess.check_output(['git',*a],cwd=R,text=True).strip()
ck(git('rev-parse','HEAD')=='6e83b875afc31e4688b61371daf76e655c9082ec','publication');ck(not git('status','--porcelain'),'clean')
H=load('/workspace/symaira-discovery772-runtime-final-handoff.json')
for k in ('complete_port_receipt','binary_receipt'):file(H[k],H[k+'_sha256'])
A=load(R/'migration/evidence/browse-state-key-772/discovery-runtime-prepared/retention.json')
for a in A['frozen_Go_files']:file(pathlib.Path('/workspace/oracles/daemon772-go-source')/a['path'],a['sha256'])
for p,h in A['SDK_source_sha256'].items():file(pathlib.Path('/workspace/toolchains/go1.26.7')/p,h)
for a in A['original_review_files']:file(R/a['retained'],a['sha256'],a['bytes'])
for p,h in A['source_maps'].items():
 b=subprocess.check_output(['git','show','7e5c4561:'+p],cwd=R);ck(hashlib.sha256(b).hexdigest()==h,'upstream map '+p)
for a in A['original_raw_proofs']:archive(R/a['path'],a['gzip_sha256'],a['raw_sha256'],a['raw_bytes'])
for a in A['historical_ELF_payloads']:archive(a['archive'],a['gzip_sha256'],a['sha256'],a['bytes'])
S=load(R/'migration/evidence/browse-state-key-772/discovery-mask-prepared/actual-sdk-only/retention.json')
for a in S['files']:archive(R/'migration/evidence/browse-state-key-772/discovery-mask-prepared/actual-sdk-only'/a['retained'],a['gzip_sha256'],a['sha256'],a['bytes'])
T=load(R/'migration/evidence/browse-state-key-772/discovery-runtime-validated-308/retention.json')
for a in T['records']:archive(R/a['retained'],a['gzip_sha256'],a['sha256'],a['bytes']);file(a['original'],a['sha256'],a['bytes'])
B=load(H['binary_receipt']);ck(len(B['rows'])==712,'712 roles');ck(len(B['unique'])==595,'595 unique');ck(len(B['actual_roles'])==66,'66 actual')
for i,(h,a) in enumerate(B['unique'].items()):
 archive(a['archive'],a['gzip_sha256'],h,a['bytes'])
 if i%100==0:print('archives',i,'errors',len(errors),flush=True)
for a in B['rows']:ck(a['sha256'] in B['unique'],'row archive')
for p,a in B['actual_roles'].items():ck(a['sha256'] in B['unique'],'executed role archive '+p)
for a in B['workspace_example_alias_relinks']:
 ck(a['earlier_executed_sha256']!=a['current_post_workspace_sha256'],'distinct alias');ck(a['earlier_executed_sha256'] in B['unique'] and a['current_post_workspace_sha256'] in B['unique'],'alias archived')
M=load(P/'proof-map.json')
for p,a in M.items():file(P/p,a['sha256'],a['bytes'])
for folder,receipt in [(pathlib.Path('/tmp/symaira-discovery-runtime-308-nonport'),'nonport'),(P/'full','port')]:
 d=load(folder/'validation.json');ck(d['complete'],'complete '+receipt);ck(d['source']==H['tested_source'],'stage source '+receipt)
 for p,h in d['source_sha256'].items():file(R/p,h)
 for stage in d['stages']:ck(stage['status']=='passed' and stage['exit']==0,'stage '+stage['name']);file(folder/(stage['name']+'.log'),stage['log_sha256'])
 stats[receipt+'_stages']=len(d['stages'])
log=(P/'full/mcp.json.tests.log').read_text(); summaries=re.findall(r'test result: \w+\. (\d+) passed; (\d+) failed; (\d+) ignored;',log)
stats['workspace_summaries']=len(summaries);stats['workspace_counts']=[sum(int(x[i]) for x in summaries) for i in range(3)];ck(stats['workspace_counts']==[316,0,3] and len(summaries)==67,'workspace count')
for name in ['affected-original','affected-all-targets','mcp-lib']:
 log=(pathlib.Path('/tmp/symaira-discovery-runtime-308-nonport')/(name+'.log')).read_text();a=re.findall(r'test result: \w+\. (\d+) passed; (\d+) failed; (\d+) ignored;',log);stats[name]={'counts':[sum(int(x[i]) for x in a) for i in range(3)],'summaries':len(a)}
stats.update(original_Go=len(A['frozen_Go_files']),SDK=len(A['SDK_source_sha256']),original_reviews=len(A['original_review_files']),original_raw=len(A['original_raw_proofs']),historical_ELFs=len(A['historical_ELF_payloads']),SDK_retained=len(S['files']),new_raw=len(T['records']),current_binary_roles=len(B['rows']),actual_roles=len(B['actual_roles']),unique_current=len(B['unique']),roundtrips=len(payloads),proof_map=len(M))
(O/'provenance.json').write_text(json.dumps({'source':H['tested_source'],'publication':H['publication'],'stats':stats,'errors':errors,'files':bound,'archive_payloads':[{'archive':p,'sha256':h,'bytes':n} for p,h,n in payloads],'target_access':False,'product_execution':False},indent=2)+'\n');print(json.dumps({'stats':stats,'errors':errors}),flush=True)
raise SystemExit(bool(errors))
