import pathlib,json,gzip,tarfile,hashlib,subprocess,ast,os
R=pathlib.Path('/workspace/symaira-skills794-mtime-resolution');O=pathlib.Path('/workspace/review-proof/root-skills794-508');head='5081205bbc27264bc0c701b92330410fcbe56c02';base='04e2bd5c9850abc0870dfa0b35017f6a32297cdb';sha=lambda b:hashlib.sha256(b).hexdigest();git=lambda ref,n:subprocess.check_output(['git','-C',str(R),'show',ref+':'+n])
assert subprocess.check_output(['git','-C',str(R),'rev-parse','HEAD'],text=True).strip()==head;assert not subprocess.check_output(['git','-C',str(R),'status','--porcelain'])
n='scripts/skills-argv-oracle/test_novel.py';before=git(base,n).decode();after=(R/n).read_text();assert before.replace('            os.utime(owned, ns=(10**18 + 1, 10**18 + 1))','            # A one-second delta is representable by native Windows FILETIME.\n            os.utime(owned, ns=(10**18 + 10**9, 10**18 + 10**9))')==after
h=json.loads(pathlib.Path('/workspace/review-proof/review-pr800-ci794-803-current/skills-mtime-final-handoff.json').read_bytes())
for row in h['all_changed_files']:assert len(git(head,row['path']))==row['bytes'] and sha(git(head,row['path']))==row['sha256'],row['path']
p=R/'migration/evidence/skills-preflight-793/windows-mtime-resolution';protected=json.loads((p/'protected-file-map.json').read_bytes())
for row in protected:assert sha(git(head,row['path']))==row['sha256'] and git(base,row['path'])==git(head,row['path'])
raw=json.loads((p/'raw-bindings.json').read_bytes())
for row in raw:
 c=(R/row['retained']).read_bytes();b=gzip.decompress(c);assert sha(c)==row['gzip_sha256'];assert sha(b)==row['sha256'] and len(b)==row['bytes'];assert pathlib.Path(row['original']).read_bytes()==b
resources=R/'migration/evidence/resource-retirement-2026-10-04';manifest=json.loads((resources/'archive-manifest.json').read_bytes());archive=resources/'full-audit.tar.gz';assert sha(archive.read_bytes())==manifest['gzip_sha256']
with tarfile.open(archive,'r:gz')as t:
 members={m.name:m for m in t.getmembers()if m.isfile()};assert len(members)==len(manifest['all_files'])
 for row in manifest['all_files']:
  b=t.extractfile(members[row['path']]).read();assert len(b)==row['bytes'] and sha(b)==row['sha256'];assert b==(pathlib.Path(manifest['source'])/row['path']).read_bytes(),row['path']
for path in ['docs/adr/skills-native-mtime-resolution-794.md','docs/adr/verified-idle-worktree-retirement.md']:(O/pathlib.Path(path).name).write_bytes((R/path).read_bytes())
tmp=O/'owned-temp';tmp.mkdir(exist_ok=False);env={**os.environ,'TMPDIR':str(tmp),'PYTHONDONTWRITEBYTECODE':'1'}
commands=[('portable',['python3','-m','unittest','discover','-s','scripts/skills-argv-oracle','-p','test_novel.py','-v']),('actionlint',['/workspace/toolchains/bin/actionlint']),('whitespace',['git','diff','--check',base,head])];results=[]
for label,command in commands:
 run=subprocess.run(command,cwd=R,env=env,capture_output=True);(O/(label+'.stdout')).write_bytes(run.stdout);(O/(label+'.stderr')).write_bytes(run.stderr);results.append({'label':label,'command':command,'exit_code':run.returncode});assert run.returncode==0,label
receipt={'disposition':'APPROVE_SOURCE_READY_CURRENT_NATIVE_CI','head':head,'base':base,'only_code_change':'one-second observable mtime mutation instead of1ns, same full snapshot assertion','protected_files':len(protected),'complete_original_raw_bindings':len(raw),'resource_archive_all_files':len(manifest['all_files']),'actual_independent_portable_tests':4,'original_Windows312_pass_before_own_unit_failure':True,'actual_Windows112_and_Parent_not_executed':True,'product_Go_Rust_or_compiler_executions':0,'commands':results,'resource_decisions_bounded_visibility_and_measured_delta_accepted':True}
(O/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt,indent=2))
