from pathlib import Path
import gzip,hashlib,json
ROOT=Path('/workspace/symaira-skills794-novel-plan');BASE=ROOT/'migration/evidence/skills-preflight-793/windows-wide-argv'
sha=lambda b:hashlib.sha256(b).hexdigest()
run=json.loads((BASE/'runtime-integration/author-linux-result.json').read_bytes())
builder=json.loads((BASE/'owned-go-builder/retention.json').read_bytes())
refs=[('/workspace/oracles/symaira-pr794-faa8f12f6c77-idle-binaries/receipt.json',None), (run['actual_executable_archive']['path'],run['actual_executable_archive']['sha256']),(builder['archive'],builder['archive_sha256'])]
results=[]
for path,expected in refs:
 p=Path(path);r=json.loads(p.read_bytes())
 if expected:assert sha(p.read_bytes())==expected
 records=r.get('all_ELF_files',r.get('roles',r.get('executables',r.get('records',[]))))
 unique=r.get('unique',{row['sha256']:row for row in records});payloads=[]
 assert unique and records,(path,'empty archive mapping')
 for h,row in unique.items():
  compressed=Path(row['archive']).read_bytes()
  expectedzip=row.get('archive_sha256',row.get('gzip_sha256'))
  if expectedzip:assert sha(compressed)==expectedzip
  digest=hashlib.sha256();length=0
  with gzip.open(row['archive'],'rb') as stream:
   while chunk:=stream.read(1024*1024):digest.update(chunk);length+=len(chunk)
  assert digest.hexdigest()==h
  expectedlen=row.get('bytes',row.get('size'))
  if expectedlen is not None:assert length==expectedlen
  payloads.append(dict(sha256=h,bytes=length,archive=row['archive'],archive_sha256=sha(compressed)))
 results.append(dict(receipt=path,receipt_sha256=sha(p.read_bytes()),unique_payloads=payloads,record_count=len(records),keys=list(r)))
Path('/tmp/symaira-skills794-novel-independent-archives.json').write_text(json.dumps(results,indent=2)+'\n')
print(json.dumps([dict(receipt=x['receipt'],unique=len(x['unique_payloads']),paths=x['record_count']) for x in results]))
