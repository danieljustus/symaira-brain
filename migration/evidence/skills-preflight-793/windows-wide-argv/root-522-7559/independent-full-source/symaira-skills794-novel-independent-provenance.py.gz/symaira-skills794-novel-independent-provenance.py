from pathlib import Path
import ast,gzip,hashlib,json,subprocess
ROOT=Path('/workspace/symaira-skills794-novel-plan')
SHA=lambda b:hashlib.sha256(b).hexdigest()
git=lambda *a:subprocess.check_output(['git',*a],cwd=ROOT)
head=git('rev-parse','HEAD').decode().strip();assert head=='7559ba0a4aec8e7baf999c0df3b4e9f330001367' and not git('status','--porcelain')
handoff=json.loads(Path('/tmp/symaira-skills794-novel-plan-final-handoff.json').read_bytes())
for row in handoff['changed_files']:assert SHA((ROOT/row['path']).read_bytes())==row['sha256'] and (ROOT/row['path']).stat().st_size==row['bytes']
evidence=ROOT/'migration/evidence/skills-preflight-793/windows-wide-argv';prep=json.loads((evidence/'novel-runner-preparation/source-preparation.json').read_bytes())
for row in prep['unchanged_original_sources']:
 current=(ROOT/row['path']).read_bytes();assert SHA(current)==row['sha256']
 assert current==git('show','a9493030ee454b2dbf3f244862c35c855e608163:'+row['path'])
archives=[]
for folder,key,mode in [('novel-runner-preparation','files','initial'),('runtime-integration/author-linux-51e42','files','runtime'),('owned-go-builder','originals','builder'),('original-70b-static','files','static')]:
 receipt=json.loads((evidence/folder/('initial-retention.json' if mode=='initial' else 'retention.json')).read_bytes())
 for row in receipt[key]:
  retained=row.get('tracked',row.get('retained'));p=ROOT/retained if retained.startswith('migration/') else evidence/folder/retained
  raw=gzip.decompress(p.read_bytes()) if p.suffix=='.gz' else p.read_bytes()
  expected=row.get('sha256',row.get('original_sha256'));length=row.get('bytes',row.get('original_size'))
  assert SHA(raw)==expected and len(raw)==length,(folder,p)
  if 'gzip_sha256' in row:assert SHA(p.read_bytes())==row['gzip_sha256']
  archives.append({'path':str(p),'sha256':expected,'bytes':len(raw),'scope':mode})
# Verify the exact declared native parent owners for both platforms without executing a binary.
owner_maps={}
for ref in ['faa8f12f6c77aad694003c9fa8c5e66d94919ba0','01f41906e2e021db3c693ec97617bb701e4dad8a']:
 owner_maps[ref]={}
 for name in ['rust/symbrain-cli/src/lib.rs','rust/symbrain-core/src/output.rs','rust-toolchain.toml']:
  current=(ROOT/name).read_bytes();assert current==git('show',ref+':'+name),(ref,name)
  owner_maps[ref][name]=SHA(current)
p=Path('/workspace/oracles/symaira-pr794-faa8f12f6c77-idle-binaries/receipt.json');faa=json.loads(p.read_bytes())
assert faa['head']=='faa8f12f6c77aad694003c9fa8c5e66d94919ba0' and faa['roundtrip_verified']
role=next(x for x in faa['executables'] if x['original_path'].endswith('/target/debug/symbrain'))
payload=faa['unique'][role['sha256']];compressed=Path(payload['archive']).read_bytes();raw=gzip.decompress(compressed)
assert SHA(raw)==role['sha256'] and SHA(compressed)==payload['gzip_sha256'] if 'gzip_sha256' in payload else SHA(raw)==role['sha256']
assert SHA(Path(handoff['unix']['parent_copy']).read_bytes())==role['sha256']
# Original comparator and its 315 historical vectors are unchanged; Windows prepares312, never interpreted as runtime.
for path in ['scripts/skills-argv-oracle/compare.py','scripts/skills-argv-oracle/build_go.py','scripts/skills-argv-oracle/verify_control.py','scripts/skills-argv-oracle/test_build_go.py']:
 assert (ROOT/path).read_bytes()==git('show','a9493030:'+path)
records=json.loads((ROOT/'migration/evidence/skills-preflight-793/maine3-integration/symaira-pr794-main31-raw-flag-process.json').read_bytes())['results'];assert len(records)==315
assert all(x['raw_args_hex'] for x in records)
for p in (ROOT/'scripts/skills-argv-oracle').glob('*.py'):ast.parse(p.read_text(),str(p))
# All current candidate source maps, including complete Rust owners, are retained.
paths=git('ls-files','rust','Cargo.toml','Cargo.lock','rust-toolchain.toml','scripts/skills-argv-oracle','.github/workflows/ci.yml').decode().splitlines()
maps={p:SHA((ROOT/p).read_bytes()) for p in paths}
assert not (ROOT/'target').exists()
result=dict(head=head,parent=handoff['parent'],clean=True,source_only=True,compiler_or_target_or_product_or_ports_used=False,changed_handoff_maps=len(handoff['changed_files']),unchanged_original_source_maps=len(prep['unchanged_original_sources']),retained_payloads=archives,parent_owners=owner_maps,actual_archived_faa_CLI_sha256=role['sha256'],parent_copy_matches_archive=True,original_comparator_builder_control_unchanged=True,original315_vectors_preserved=True,current_source_maps=maps)
Path('/tmp/symaira-skills794-novel-independent-provenance.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k not in ['retained_payloads','parent_owners','current_source_maps']}))
