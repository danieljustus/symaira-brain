import ast,hashlib,importlib.util,json,os,sys,tempfile
from pathlib import Path
from unittest.mock import patch
ROOT=Path('/workspace/symaira-skills794-novel-plan');FOLDER=ROOT/'scripts/skills-argv-oracle'
sys.path.insert(0,str(FOLDER))
import novel,build_parent,compare
sha=lambda b:hashlib.sha256(b).hexdigest()
plan=json.loads(novel.PLAN.read_bytes());assert sha(novel.PLAN.read_bytes())==novel.PLAN_SHA
scopes={}
for windows in [False,True]:
 cases=novel.selected_cases(windows);ids=[c['id'] for c in cases];assert len(ids)==len(set(ids))
 for case in cases:
  args=novel.arguments(case,windows)
  assert all(('\0' not in a) if windows else b'\0' not in a for a in args)
  if 'args_utf16le_hex' in case and windows:assert [a.encode('utf-16-le','surrogatepass').hex() for a in args]==case['args_utf16le_hex']
 scopes['Windows' if windows else 'Unix']=dict(total=len(cases),required=sum(not i.startswith('inherited-global') for i in ids),actual_parent=sum(i.startswith('inherited-global') for i in ids),ids=ids)
with patch.object(compare.os,'name','nt'):
 baseline=compare.cases();assert len(baseline)==312 and len({i for i,a in baseline})==312
 with patch.object(compare.os,'name','posix'):assert len(compare.cases())==315
# No native CLI or target: test Python finally/restoration on dummy ordinary
# byte files with the build function replaced explicitly. Never invoke Cargo.
restoration=[]
for fail in [False,True]:
 with tempfile.TemporaryDirectory(prefix='skills-parent-source-projection-') as temp:
  d=Path(temp);current=d/'current';current.write_bytes(b'original-current-owned-dummy');saved=d/'saved';parent=d/'parent';receipt=d/'receipt.json'
  def owned_dummy_build(args,current,saved,parent,report):
   report['current_sha256']=sha(current.read_bytes());saved.write_bytes(current.read_bytes());current.write_bytes(b'dummy-parent-cache-output');parent.write_bytes(current.read_bytes());report['parent_sha256']=sha(parent.read_bytes());report['source_before']=report['source_after']=[]
   if fail:raise RuntimeError('intentional dummy source-only build failure')
  argv=['build_parent.py','--current',str(current),'--target','/not-allocated-not-accessed','--saved-current',str(saved),'--parent',str(parent),'--receipt',str(receipt)]
  with patch.object(sys,'argv',argv),patch.object(build_parent,'build',owned_dummy_build):code=build_parent.main()
  r=json.loads(receipt.read_bytes());assert code==int(fail) and r['restored_current'] and current.read_bytes()==b'original-current-owned-dummy'
  restoration.append(dict(intentional_failure=fail,exit=code,restored=True,actual_parent_or_current_or_Cargo_execution=False))
# Full frozen source maps bind the exact committed object payloads, not HEAD alone.
p=ROOT/'migration/evidence/skills-preflight-793/windows-wide-argv/owned-go-builder/02-build.json.gz'
import gzip,subprocess
build=json.loads(gzip.decompress(p.read_bytes()));assert build['source_before']==build['source_after'] and len(build['source_before'])==2438
rows=build['source_before'];blob_ids=[r['blob'] for r in rows]
raw=subprocess.check_output(['git','cat-file','--batch'],input=('\n'.join(blob_ids)+'\n').encode(),cwd=ROOT)
position=0
for row in rows:
 end=raw.index(b'\n',position);header=raw[position:end].split();size=int(header[2]);payload=raw[end+1:end+1+size];position=end+size+2
 assert header[0].decode()==row['blob'] and header[1]==b'blob'
 assert sha(payload)==row['sha256'] and len(payload)==row['bytes']
assert position==len(raw)
assert f"vcs.revision={novel.GO_REF}" in build['go_build_info'] and 'vcs.modified=false' in build['go_build_info']
out=dict(source_only=True,fresh_product_or_Cargo_or_SDK_execution=False,immutable_plan_sha256=novel.PLAN_SHA,native_prepared_scopes=scopes,original315_312_preserved=True,source_only_dummy_restoration=restoration,archived_actual_frozen_Go2438_maps_match_Git_blobs=True,archived_actual_SDK_builder_status=build['status'],archived_actual_SDK_binary_sha256=build['output_sha256'])
Path('/tmp/symaira-skills794-novel-independent-plan.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({k:v for k,v in out.items() if k!='native_prepared_scopes'}))
