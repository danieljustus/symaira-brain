from pathlib import Path
import hashlib,json
ROOT=Path('/workspace/symaira-skills794-novel-plan');sha=lambda b:hashlib.sha256(b).hexdigest()
paths=[]
p=Path('/tmp/symaira-skills794-root-tracked-novel-pinned/report.json');r=json.loads(p.read_bytes());assert r['candidate_head']=='7559ba0a4aec8e7baf999c0df3b4e9f330001367' and not r['candidate_dirty'] and not r['native_windows']
for path,h in r['candidate_sources_sha256'].items():assert sha((ROOT/path).read_bytes())==h,path
assert len(r['cases'])==53
for row in r['cases']:
 for name in ['go','rust','parent']:
  v=row[name];assert not v['timed_out'] and v['readonly'] and v['before']==v['after']
 left,right=('rust','parent') if row['scope']=='actual-parent' else ('go','rust')
 assert all(row[left][key]==row[right][key] for key in ['exit','stdout_hex','stderr_hex'])
 assert row['accepted'] and row['readonly']
 if row['scope']=='actual-parent':assert all(row[n]['exit']==2 and row[n]['stdout_hex']=='' and bytes.fromhex(row[n]['stderr_hex']).startswith(b'symbrain: ') for n in ['rust','parent'])
assert r['summary']==dict(total=53,accepted=53,required=51,inherited=2,readonly=True)
paths.append(dict(path=str(p),sha256=sha(p.read_bytes()),existing_process_owner='Root',fresh_reviewer_execution=False,total=53,accepted=53))
for control in ['flag-input','parent-input']:
 p=Path('/tmp/symaira-skills794-root-tracked-novel-pinned/control-'+control+'.json');v=json.loads(p.read_bytes());row=v['cases'][0]
 assert v['negative_control']==control and v['summary']['total']==1 and v['summary']['accepted']==0 and v['summary']['readonly']
 left,right=('go','rust') if control=='flag-input' else ('rust','parent')
 assert all(row[n]['exit']==2 and row[n]['stdout_hex']=='' and row[n]['before']==row[n]['after'] and not row[n]['timed_out'] for n in [left,right])
 a,b=bytes.fromhex(row[left]['stderr_hex']),bytes.fromhex(row[right]['stderr_hex']);assert a!=b
 assert (b'actual-native-input-control' in b) if control=='flag-input' else (b'actual-parent-input-control' in b)
 paths.append(dict(path=str(p),sha256=sha(p.read_bytes()),existing_process_owner='Root',fresh_reviewer_execution=False,intended_changed_input_mismatch=True,stdout_empty=True,exit2=True,readonly=True))
p=Path('/tmp/symaira-skills794-wide-root-go/process.json');v=json.loads(p.read_bytes());assert len(v['results'])==315 and v['matched']==315 and v['historical_go_preserved']
for row in v['results']:assert row['matched'] and row['readonly'] and row['historical_go_preserved'] and row['go']==row['rust'] and row['go']['state_before']==row['go']['state_after']
paths.append(dict(path=str(p),sha256=sha(p.read_bytes()),existing_process_owner='Root',fresh_reviewer_execution=False,original315_exact=True))
for control in ['flag-input','quoted-value','normalization']:
 p=Path('/tmp/symaira-skills794-wide-root-go/control-'+control+'.json');v=json.loads(p.read_bytes());assert v['total']==1 and v['matched']==0 and v['readonly']
 row=v['results'][0];assert row['go']['exit_code']==row['rust']['exit_code']==2 and row['go']['stdout_hex']==row['rust']['stdout_hex']=='' and row['go']['stderr_hex']!=row['rust']['stderr_hex']
 paths.append(dict(path=str(p),sha256=sha(p.read_bytes()),existing_process_owner='Root',fresh_reviewer_execution=False,original_control_rejected=True))
Path('/tmp/symaira-skills794-novel-independent-existing-process.json').write_text(json.dumps(dict(scope='independent read/recalculation of existing Root Linux process bytes; no new product execution or Windows claim',proofs=paths),indent=2)+'\n')
print(json.dumps(dict(existing_Root_Linux53_recomputed=True,existing_Root_controls2_intended=True,existing_Root_original315_and3_controls=True,fresh_reviewer_product_executions=0)))
