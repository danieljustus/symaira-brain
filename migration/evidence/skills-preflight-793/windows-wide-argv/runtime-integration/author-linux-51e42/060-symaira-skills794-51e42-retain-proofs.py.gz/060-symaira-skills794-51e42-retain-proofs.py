import gzip,hashlib,json
from pathlib import Path
repo=Path('/workspace/symaira-skills794-wide-runtime');out=repo/'migration/evidence/skills-preflight-793/windows-wide-argv/runtime-integration/author-linux-51e42'
files=[]
for root in ['/tmp/symaira-skills794-wide-runtime-53711-author','/tmp/symaira-skills794-wide-runtime-53711-modes-author','/tmp/symaira-skills794-wide-runtime-51e42-author','/tmp/symaira-skills794-wide-runtime-51e42-complete-author','/tmp/symaira-skills794-wide-runtime-51e42-vcs-author']:
 for p in sorted(Path(root).iterdir()):
  if p.is_file() and p.read_bytes()[:4]!=b'\x7fELF':files.append(p)
files.append(Path('/tmp/symaira-skills794-wide-runtime-51e42-novel-author/receipt.json'))
files += [Path('/tmp')/n for n in ['symaira-skills794-53711-checkout-mode-correction.json','symaira-skills794-51e42-source-validation.json','symaira-skills794-51e42-original-route-maps.json','symaira-skills794-51e42-original-full-rust-map.json','symaira-skills794-51e42-go-full-source-map.json','symaira-skills794-51e42-vcs-diagnosis.json','symaira-skills794-51e42-vcs-dryrun.log','symaira-skills794-51e42-novel-author.py','symaira-skills794-51e42-novel-author.log','symaira-skills794-51e42-owned-go-build.sh','symaira-skills794-53711-initial-preserve.py','symaira-skills794-53711-initial-preserve.log','symaira-skills794-53711-modes-preserve.py','symaira-skills794-53711-modes-preserve.log','symaira-skills794-51e42-preflight-preserve.py','symaira-skills794-51e42-preflight-preserve.log','symaira-skills794-51e42-final-preserve.py','symaira-skills794-51e42-final-preserve.log','symaira-memory803-to-skills794-cache-transfer.json','symaira-memory803-to-skills794-cache-transfer.py','symaira-memory803-to-skills794-cache-transfer.log','symaira-shared-go-cache-retirement.json','symaira-shared-go-cache-retire.py','symaira-shared-go-cache-retire.log','symaira-shared-go-cache-inventory.json','symaira-shared-go-cache-clean.stdout','symaira-shared-go-cache-clean.stderr','symaira-skills794-51e42-retain-proofs.py']]
files += [Path('/workspace/oracles')/n/'receipt.json' for n in ['symaira-skills794-53711-initial-binaries','symaira-skills794-53711-modes-binaries','symaira-skills794-51e42-preflight-binaries','symaira-skills794-51e42-final-binaries','symaira-memory803-root-2fe-binaries','symaira-pr794-faa8f12f6c77-idle-binaries']]
rows=[];sha=lambda b:hashlib.sha256(b).hexdigest()
for i,p in enumerate(files):
 assert p.is_file(),p
 b=p.read_bytes();dest=out/(f'{i:03}-'+p.name+'.gz');z=gzip.compress(b,mtime=0)
 if dest.exists():assert dest.read_bytes()==z
 else:dest.write_bytes(z)
 assert gzip.decompress(dest.read_bytes())==b
 rows.append({'original':str(p),'original_sha256':sha(b),'original_size':len(b),'retained':str(dest.relative_to(repo)),'gzip_sha256':sha(z)})
ret={'source':'51e42aa959fbec416f20221db6fa41e8c91b5862','scope':'lossless original attempts/permissions/API-doc/PATH/VCS failure preservation + actual final Linux gates; original bytes unchanged; executable archives separate','files':rows}
(out/'retention.json').write_text(json.dumps(ret,indent=2)+'\n');print('retained actual original files',len(rows),'gzip bytes',sum((repo/r['retained']).stat().st_size for r in rows))
