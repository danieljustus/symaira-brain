import gzip,hashlib,json,os,re,stat,subprocess,time
from pathlib import Path
repo=Path('/workspace/symaira-skills794-wide-runtime');target=repo/'target';out=Path('/workspace/oracles/symaira-skills794-51e42-final-binaries');out.mkdir()
sha=lambda b:hashlib.sha256(b).hexdigest()
roots=[Path('/workspace/oracles')/name for name in ['symaira-skills794-51e42-preflight-binaries','symaira-skills794-53711-modes-binaries','symaira-skills794-53711-initial-binaries','symaira-memory803-root-2fe-binaries']]
proof=Path('/tmp/symaira-skills794-wide-runtime-51e42-complete-author');vcs=Path('/tmp/symaira-skills794-wide-runtime-51e42-vcs-author');novel=Path('/tmp/symaira-skills794-wide-runtime-51e42-novel-author');rows=[];unique={}
parents=sorted({repo/p for p in re.findall(r'\((target/[^)]+)\)',(proof/'affected-tests.log').read_text()+(proof/'core-tests.log').read_text())})
roles={str(p):'actual fresh Rust Cargo parent' for p in parents};roles.update({str(vcs/'symbrain'):'actual native CLI 315+3controls+53novel',str(vcs/'symbrain-go'):'actual frozen Go CLI 315+3controls+53novel',str(novel/'parent-faa8'):'actual archived parent53 supplemental cases'})
paths=[p for p in sorted(target.rglob('*')) if p.is_file() and not p.is_symlink()]+[Path(p) for p in roles if not Path(p).is_relative_to(target)]
for p in paths:
 with p.open('rb') as stream:
  if stream.read(4)!=b'\x7fELF':continue
 b=p.read_bytes();h=sha(b)
 if h not in unique:
  archive=next((r/(h+'.gz') for r in roots if (r/(h+'.gz')).exists()),out/(h+'.gz'))
  if not archive.exists():archive.write_bytes(gzip.compress(b,mtime=0))
  z=archive.read_bytes();assert gzip.decompress(z)==b
  unique[h]={'archive':str(archive),'archive_sha256':sha(z)}
 rows.append({'path':str(p),'sha256':h,'bytes':len(b),'mode':stat.S_IMODE(p.stat().st_mode),'role':roles.get(str(p),'present target artifact; source association retained by prior archive lineage, not claimed newly executed'),**unique[h]})
actual=[r for r in rows if r['path'] in roles];assert len(actual)==61 and len(parents)==58
users=[]
for p in Path('/proc').iterdir():
 if not p.name.isdigit():continue
 probes=[p/'exe',p/'cwd']
 try:probes+=list((p/'fd').iterdir())
 except OSError:pass
 for probe in probes:
  try:s=os.readlink(probe)
  except OSError:continue
  if s.startswith(str(target)):users.append({'pid':p.name,'link':str(probe),'path':s})
assert not users
receipt={'source_head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo).decode().strip(),'source_dirty':subprocess.check_output(['git','status','--porcelain'],cwd=repo).decode(),'scope':'actual Linux author tests/strict+Go/native argv; no independent approval/native Windows runtime claim','unix_time':time.time(),'target':str(target),'target_users':users,'all_ELF_files':rows,'unique_payloads':len(unique),'actual_executed_roles':actual,'actual_test_parents':58,'actual_CLI_roles':3,'prior_archive_receipts':[{ 'path':str(r/'receipt.json'),'sha256':sha((r/'receipt.json').read_bytes())} for r in roots],'original_parent_receipt':'/workspace/oracles/symaira-pr794-faa8f12f6c77-idle-binaries/receipt.json','proof_files':[{ 'path':str(p),'sha256':sha(p.read_bytes()),'bytes':p.stat().st_size} for r in [proof,vcs] for p in sorted(r.iterdir()) if p.is_file() and p.read_bytes()[:4]!=b'\x7fELF']+[{'path':str(novel/'receipt.json'),'sha256':sha((novel/'receipt.json').read_bytes())}]}
(out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({'ELF_paths':len(rows),'unique_payloads':len(unique),'actual_roles':len(actual),'receipt_sha256':sha((out/'receipt.json').read_bytes()),'target_users':users}))
