from pathlib import Path
import json,hashlib,gzip,os,subprocess,shutil,time
src=Path('/workspace/symaira-memory803-open');dst=Path('/workspace/symaira-skills794-wide-runtime');target=src/'target';new=dst/'target';rp=Path('/workspace/oracles/symaira-memory803-root-2fe-binaries/receipt.json');raw=rp.read_bytes();r=json.loads(raw)
assert r['source']=='2fe09ea78f1beb0225b9c325d76a054c183a9e42' and r['roundtrip_verified'] and not new.exists()
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=src,text=True).strip()==r['source']
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=dst,text=True).strip()=='53711fb08ddd51b149554e02bf97531f54d18d10'
for root in [src,dst]:assert not subprocess.check_output(['git','status','--porcelain'],cwd=root)
users=[]
for p in Path('/proc').iterdir():
 if not p.name.isdigit() or int(p.name)==os.getpid():continue
 try:
  values=[os.readlink(p/'exe'),os.readlink(p/'cwd'),(p/'maps').read_text()]
  for fd in (p/'fd').iterdir():
   try:values.append(os.readlink(fd))
   except OSError:pass
  if any(str(target)+'/' in x for x in values):users.append(p.name)
 except OSError:pass
assert not users,users
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
for x in r['ELFs']:assert sha(x['path'])==x['sha256']
for d,a in r['unique'].items():
 assert sha(a['gzip'])==a['gzip_sha256']
 with gzip.open(a['gzip'],'rb') as f:assert hashlib.file_digest(f,'sha256').hexdigest()==d
shutil.move(target,new);assert new.exists() and not target.exists() and rp.read_bytes()==raw
receipt={'source':r['source'],'destination_source':'53711fb08ddd51b149554e02bf97531f54d18d10','old_target':str(target),'new_target':str(new),'exclusive_compiler_owner':'/root/doctor765_port Skills794 author runtime','target_users':users,'retained_ELF_paths':len(r['ELFs']),'retained_unique_payloads':len(r['unique']),'actual_executed_roles':len(r['actual_executed_roles']),'archive_receipt':str(rp),'archive_receipt_sha256':hashlib.sha256(raw).hexdigest(),'all_original_payloads_roundtrip_verified':True,'free_bytes':shutil.disk_usage('/workspace').free,'stage_floor_bytes':700*1024*1024,'unix_time':time.time(),'reason':'Reuse only idle fully archived derived cache; originalmain target/toolchain/source/raw failures remain untouched. No previous author compile/result is silently attributed to new source.'}
Path('/tmp/symaira-memory803-to-skills794-cache-transfer.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt))
