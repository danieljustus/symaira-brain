"""Actual Unix supplement of preserved plan; Windows cases are not executed."""
import gzip,hashlib,json,os,stat,subprocess,time
from pathlib import Path
repo=Path('/workspace/symaira-skills794-wide-runtime')
proof=Path('/tmp/symaira-skills794-wide-runtime-51e42-vcs-author')
out=Path('/tmp/symaira-skills794-wide-runtime-51e42-novel-author')
plan=repo/'migration/evidence/skills-preflight-793/windows-wide-argv/original-70b-static/symaira-skills794-wide-argv-independent-novel-plan.json'
sha=lambda b:hashlib.sha256(b).hexdigest()
assert subprocess.check_output(['git','status','--porcelain'],cwd=repo)==b''
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo).decode().strip()=='51e42aa959fbec416f20221db6fa41e8c91b5862'
out.mkdir()
p=Path('/workspace/oracles/symaira-pr794-faa8f12f6c77-idle-binaries/receipt.json');prior=json.loads(p.read_bytes());h='06f8f43d4710de9fcc7d629711a079b83e723f559f75fff312d5a14dde8140cb';original=prior['unique'][h];z=Path(original['archive']).read_bytes();raw=gzip.decompress(z);assert sha(raw)==h and len(raw)==original['original_size'];parent=out/'parent-faa8';parent.write_bytes(raw);parent.chmod(0o755)
# Parent attribution requires the actual diagnostic/dispatch sources too.
parent_sources={}
for name in ['rust/symbrain-core/src/output.rs','rust/symbrain-cli/src/lib.rs']:
 current=(repo/name).read_bytes();old=subprocess.check_output(['git','show',prior['head']+':'+name],cwd=repo);assert old==current;parent_sources[name]=sha(current)
binaries={'go':proof/'symbrain-go','native':proof/'symbrain','parent':parent}
d=json.loads(plan.read_bytes());cases=[c for c in d['novel_cases'] if c['platform']!='native-Windows']
receipt={'scope':'actual Linux raw-byte+portable preflight; native Windows99 novel cases NOT executed','source_head':'51e42aa959fbec416f20221db6fa41e8c91b5862','plan_sha256':sha(plan.read_bytes()),'binary_sha256':{k:sha(v.read_bytes()) for k,v in binaries.items()},'parent_source':prior['head'],'parent_receipt':str(p),'parent_receipt_sha256':sha(p.read_bytes()),'parent_unchanged_dispatch_sources':parent_sources,'cases':[]}
def snapshot(root):
 result={}
 for f in [root,*sorted(root.rglob('*'))]:
  info=f.lstat();row={'mode':stat.S_IMODE(info.st_mode),'kind':stat.S_IFMT(info.st_mode),'size':info.st_size,'mtime_ns':info.st_mtime_ns}
  if f.is_symlink():row['link']=os.readlink(f)
  elif f.is_file():row['sha256']=sha(f.read_bytes())
  result[str(f.relative_to(root))]=row
 return result
for i,c in enumerate(cases):
 args=c.get('args')
 if 'args_bytes_hex' in c:argv=[bytes.fromhex(a) for a in c['args_bytes_hex']]
 elif args is not None:argv=[a.encode() for a in args]
 else:argv=[bytes.fromhex(a).decode('utf-16le','surrogatepass').encode('utf-8','surrogatepass') for a in c['args_utf16le_hex']]
 row={'id':c['id'],'raw_args_hex':[a.hex() for a in argv],'expected_scope':c['expect']}
 for label,binary in binaries.items():
  root=out/(str(i)+'-'+label);root.mkdir()
  for directory in ['home','config','data','cache','project','empty-bin','config/symbrain','config/symskills','data/symbrain/skills/library/broken','home/.claude/skills/owned']:(root/directory).mkdir(parents=True,exist_ok=True)
  for name,raw in [('config/symbrain/config.toml',b'[malformed Brain'),('config/symskills/config.toml',b'[malformed Skills'),('project/.symbrain.toml',b'[malformed project'),('data/symbrain/skills/library/broken/SKILL.md',b'---\nnot valid: [\n---\nowned malformed skill'),('home/.claude/skills/owned/.symskills.json',b'{owned-malformed-marker'),('project/owned.txt',b'unchanged\x00raw\xff')]:
   f=root/name;f.write_bytes(raw);f.chmod(0o640);os.utime(f,ns=(1_000_000_000_000_000_000,1_000_000_000_000_000_000))
  for directory in [root,*root.rglob('*')]:
   if directory.is_dir():os.utime(directory,ns=(1_000_000_000_000_000_000,1_000_000_000_000_000_000))
  env={'HOME':str(root/'home'),'USERPROFILE':str(root/'home'),'XDG_CONFIG_HOME':str(root/'config'),'XDG_DATA_HOME':str(root/'data'),'XDG_CACHE_HOME':str(root/'cache'),'PATH':str(root/'empty-bin'),'SYMBRAIN_GO_BINARY':str(root/'absent-fallback'),'LANG':'C.UTF-8','TZ':'UTC'}
  before=snapshot(root);start=time.time();p=subprocess.run([os.fsencode(binary),b'skills',b'sync',b'--json',*argv],cwd=root/'project',env=env,capture_output=True,timeout=5,check=False);after=snapshot(root)
  row[label]={'exit':p.returncode,'stdout_hex':p.stdout.hex(),'stderr_hex':p.stderr.hex(),'before':before,'after':after,'start':start,'end':time.time(),'environment':env}
  row[label]['readonly']=before==after
 compared=lambda a,b:all(a[key]==b[key] for key in ['exit','stdout_hex','stderr_hex'])
 row['Go_native_matched']=compared(row['go'],row['native']);row['native_parent_matched']=compared(row['native'],row['parent']);row['readonly']=all(row[k]['readonly'] for k in binaries)
 receipt['cases'].append(row)
 (out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
required=[r for r in receipt['cases'] if not r['id'].startswith('inherited-global')];inherited=[r for r in receipt['cases'] if r['id'].startswith('inherited-global')]
assert len(required)==51 and len(inherited)==2
receipt['summary']={'actual_pairs':len(receipt['cases']),'Go_native_required':sum(r['Go_native_matched'] for r in required),'native_parent_inherited':sum(r['native_parent_matched'] for r in inherited),'all_readonly':all(r['readonly'] for r in receipt['cases']),'raw_Unix_cases':40,'portable_required':11,'portable_inherited':2,'native_Windows_executed':0}
(out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt['summary']));print('differences',[(r['id'],r['Go_native_matched'],r['native_parent_matched'],r['readonly']) for r in receipt['cases'] if not r['Go_native_matched'] or not r['readonly']])
assert all(r['Go_native_matched'] and r['readonly'] for r in required)
assert all(r['native_parent_matched'] and r['readonly'] for r in inherited)
