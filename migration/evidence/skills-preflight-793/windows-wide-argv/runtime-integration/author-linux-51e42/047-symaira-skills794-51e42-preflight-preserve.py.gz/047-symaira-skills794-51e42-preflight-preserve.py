import gzip,hashlib,json,os,re,stat,subprocess,time
from pathlib import Path
repo=Path('/workspace/symaira-skills794-wide-runtime');target=repo/'target';out=Path('/workspace/oracles/symaira-skills794-51e42-preflight-binaries');out.mkdir()
proof=Path('/tmp/symaira-skills794-wide-runtime-51e42-author');(proof/'preflight-driver.exit').write_text('1\n')
sha=lambda b:hashlib.sha256(b).hexdigest(); rows=[];unique={};metadata=[]
for record in subprocess.check_output(['git','ls-files','-s','-z'],cwd=repo).split(b'\0'):
 if not record:continue
 header,name=record.split(b'\t',1);p=repo/os.fsdecode(name);s=p.lstat();metadata.append({'path':os.fsdecode(name),'git_mode':header.split()[0].decode(),'actual_mode':stat.S_IMODE(s.st_mode),'kind':stat.S_IFMT(s.st_mode),'size':s.st_size,'mtime_ns':s.st_mtime_ns,'sha256':sha(p.read_bytes()) if p.is_file() and not p.is_symlink() else None})
for p in sorted(target.rglob('*')):
 if not p.is_file() or p.is_symlink():continue
 with p.open('rb') as stream:
  if stream.read(4)!=b'\x7fELF':continue
 raw=p.read_bytes();h=sha(raw)
 if h not in unique:
  prior=Path('/workspace/oracles/symaira-skills794-53711-initial-binaries')/(h+'.gz')
  if not prior.exists():prior=Path('/workspace/oracles/symaira-skills794-53711-modes-binaries')/(h+'.gz')
  if not prior.exists():prior=Path('/workspace/oracles/symaira-memory803-root-2fe-binaries')/(h+'.gz')
  archive=prior if prior.exists() else out/(h+'.gz')
  if not archive.exists():archive.write_bytes(gzip.compress(raw,mtime=0))
  zipped=archive.read_bytes();assert gzip.decompress(zipped)==raw
  unique[h]={'archive':str(archive),'archive_sha256':sha(zipped)}
 rows.append({'path':str(p),'sha256':h,'bytes':len(raw),'mode':stat.S_IMODE(p.stat().st_mode),**unique[h]})
log=(proof/'affected-tests.log').read_text()+(proof/'core-tests.log').read_text();parents=sorted({str(repo/relative) for relative in re.findall(r'\((target/[^)]+)\)',log)})
receipt={'source_head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo).decode().strip(),'source_dirty':subprocess.check_output(['git','status','--porcelain'],cwd=repo).decode(),'scope':'actual affected/Core/strict/fmt passing; missing actionlint PATH failure; source51e42 unchanged before full rerun','unix_time':time.time(),'actual_test_parents':parents,'files':rows,'unique_payloads':len(unique),'tracked_checkout_metadata':metadata,'proof_files':{str(p):sha(p.read_bytes()) for p in proof.iterdir() if p.is_file()},'original_cache_archive_receipt':'/workspace/oracles/symaira-memory803-root-2fe-binaries/receipt.json'}
(out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({'ELF_paths':len(rows),'unique_payloads':len(unique),'actual_parents':len(parents),'tracked_modes':{mode:sum(m['actual_mode']==mode for m in metadata) for mode in sorted({m['actual_mode'] for m in metadata})},'receipt_sha256':sha((out/'receipt.json').read_bytes())}))
