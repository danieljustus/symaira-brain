#!/usr/bin/env bash
set -euo pipefail
umask 022
source_repo=/workspace/symaira-skills794-wide-runtime
oracle_root=/tmp/symaira-skills794-51e42-owned-go-source
proof_root=/tmp/symaira-skills794-wide-runtime-51e42-vcs-author
frozen_revision=dcddcef0df5789123c7c9a7ebe6e01f10e941f2c
[[ ! -e "$oracle_root" && ! -e "$proof_root" ]]
python3 - <<'PY'
import shutil
assert shutil.disk_usage('/workspace').free >= 850*1024*1024, 'STOP: need clone/build headroom above 700MiB floor'
PY
mkdir "$proof_root"
git clone --quiet --shared --no-checkout "$source_repo" "$oracle_root" > "$proof_root/clone.log" 2>&1
git -C "$oracle_root" checkout --quiet --detach "$frozen_revision" >> "$proof_root/clone.log" 2>&1
[[ -d "$oracle_root/.git" && "$(git -C "$oracle_root" rev-parse HEAD)" == "$frozen_revision" ]]
[[ -z "$(git -C "$oracle_root" status --porcelain)" ]]
export PATH=/workspace/toolchains/go1.26.7/bin:$PATH
python3 /tmp/symaira-subreaper.py env CGO_ENABLED=0 GOTOOLCHAIN=go1.26.7 go -C "$oracle_root" build -buildvcs=true -o "$proof_root/symbrain-go" ./cmd/symbrain > "$proof_root/go-build.log" 2>&1
go version -m "$proof_root/symbrain-go" > "$proof_root/go-build-info.log"
rg -F "vcs.revision=$frozen_revision" "$proof_root/go-build-info.log"
rg -F 'vcs.modified=false' "$proof_root/go-build-info.log"
[[ -z "$(git -C "$oracle_root" status --porcelain)" ]]
