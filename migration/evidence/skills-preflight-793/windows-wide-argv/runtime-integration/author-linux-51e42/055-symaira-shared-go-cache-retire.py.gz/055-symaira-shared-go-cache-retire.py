import json,os,subprocess,shutil,time,hashlib
from pathlib import Path
cache=Path('/home/agent/.cache/go-build');inv=Path('/tmp/symaira-shared-go-cache-inventory.json');original=inv.read_bytes();r=json.loads(original);assert r['cache']==str(cache) and r['elf_entries']==0
users=[]
for p in Path('/proc').iterdir():
 if not p.name.isdigit() or int(p.name)==os.getpid():continue
 try:
  exe=os.readlink(p/'exe');cwd=os.readlink(p/'cwd');cmd=(p/'cmdline').read_bytes().split(b'\0');values=[exe,cwd,(p/'maps').read_text()]
  for fd in (p/'fd').iterdir():
   try:values.append(os.readlink(fd))
   except OSError:pass
  compiler=('/workspace/toolchains/go1.26.7/' in exe and Path(exe).name in ['go','compile','link'])
  if compiler or any(str(cache)+'/' in x for x in values):users.append({'pid':int(p.name),'exe':exe,'cwd':cwd})
 except OSError:pass
assert not users,users
fuzz=cache/'fuzz';fuzz_before=[]
if fuzz.exists():
 for p in fuzz.rglob('*'):
  if p.is_file():fuzz_before.append((str(p),hashlib.sha256(p.read_bytes()).hexdigest()))
before=shutil.disk_usage('/workspace').free
result=subprocess.run(['python3','/tmp/symaira-subreaper.py','/workspace/toolchains/go1.26.7/bin/go','clean','-cache'],env={**os.environ,'GOCACHE':str(cache),'GOTOOLCHAIN':'local'},capture_output=True)
Path('/tmp/symaira-shared-go-cache-clean.stdout').write_bytes(result.stdout);Path('/tmp/symaira-shared-go-cache-clean.stderr').write_bytes(result.stderr);assert result.returncode==0,(result.returncode,result.stderr)
for name,d in fuzz_before:assert hashlib.sha256(Path(name).read_bytes()).hexdigest()==d
record={'reason':'Restore build headroom by retiring only inactive derived shared Go compiler object cache; allownersexclusivegrowthhold, no cache executables found. SDK source/binaries, module downloads, fuzzy corpus, originalmain Cargo target and actual separatelyretained executed binaries/reports remain intact. Rebuild from fixed source/SDK when required. No cache object is called acceptance evidence.','cache':str(cache),'inventory_sha256':hashlib.sha256(original).hexdigest(),'old_entries':r['entries'],'old_bytes':r['bytes'],'old_ELF_entries':r['elf_entries'],'users':users,'argv':['go','clean','-cache'],'exit':result.returncode,'fuzz_files_preserved':len(fuzz_before),'free_before':before,'free_after':shutil.disk_usage('/workspace').free,'unix_time':time.time()}
Path('/tmp/symaira-shared-go-cache-retirement.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record))
