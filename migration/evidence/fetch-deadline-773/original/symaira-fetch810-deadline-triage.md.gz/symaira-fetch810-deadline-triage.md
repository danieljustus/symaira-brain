# PR810 Linux deadline fixture triage — read only

The two retained native Linux failures establish a test-fixture phase error,
not a leaked connection in the failing observation. The proxy task receives
`UnexpectedEof` while still reading the request headers. That is evidence that
the accepted peer ended before the test called `client.close()`. The fixture
panics, drops its completion sender, and the test then receives `RecvError`.
The preceding `FetchError::Timeout` assertion passed in both logs. The failure
is real and must be repaired and rerun; it is not an acceptance waiver.

## Exact evidence

- Original CI job111324721353 full log SHA
  `93e3a5b76a77548b56750a73ef8864ccc23f9df535f665b58ca72f2dbe87c21c`.
- Original daemon/MCP Linux all-workspace test log SHA
  `a3e960002abdd8a6b6d112e12274e600605ff9dd852ae26854aaa6b027d0936b`.
- Original downloaded daemon ZIP SHA
  `ce5bebe29185a5d16768a390fdc1ac4bfa9ac4c0bbe5de4a4e857251cdb87843`.
- Both report the same proxy_uri.rs header-read panic at20 and completion
  receiver panic at63. Cancellation and body-limit siblings pass in both.
- Local published source9b4ca887 is clean; Fetch files are byte-identical to
  productionc7beb3a. The logs identify CI merge5c0f4a3 of9b4 intoe3db.
  e3db is already an ancestor of9b4. The exact merge object is unavailable
  locally, so this report does not claim a directly checked CI merge blob.
- The original archived proxy_uri test ELF was decoded and roundtrip checked:
  `ec10c9250682e5b635c6f608c89c6ee0c4aae21e7adff8c3c2b6cdc93a0a4fb2`.
  It was not executed. No builds, targets, source edits or new runtime replays.

The companion receipt binds every inspected source file and original artifact.
The Doctor sourcee6/publicationb3 and its reviewer-owned target are untouched.

## Why the phase can differ

The public Fetch timeout covers the whole transport attempt: honest.rs creates
its deadline before redirect::send. That path builds/caches the reqwest client,
then dials the selected proxy, performs Hyper handshake, sends the request,
and receives response headers. The30ms test budget is therefore not a30ms
body-stall budget. Cold initialization or ordinary scheduling can exhaust it
before a complete request header reaches the fixture. The logs do not identify
which cold initialization or scheduling event consumed the budget; that cause
must not be invented from EOF alone.

The existing deadline test discards the `started` receiver. Its helper only
sends `closed` after a complete header and partial response. `read_exact().unwrap()`
on a valid earlier timeout creates the secondary test failure. Increasing a
sleep/retrying CI would leave that admission mistake and would not prove a
particular ownership stage.

## Complete owner trace

Before spawning Hyper, proxy_io::connect returns an owned boxed TCP/TLS stream
inside the send future. Dropping that future releases its socket. Handshake
returns a connection future; ConnectionTask immediately owns the spawned task.
While send_request is pending, that guard stays in the send future. Its Drop
aborts the connection task. Once response headers arrive, the guard transfers
into OwnedBody inside the actual reqwest Response. Deadline, body-limit or
caller cancellation drops that response/body future and aborts the task.
Raw connections are not stored in the FetchClient HTTP-client cache. The client
can remain alive throughout the socket close assertion.

There is no source path in this examined owner chain that explains a leaked
accepted peer in the reported early-EOF failure. This is source reasoning plus
the actual CI observation, not a new exhaustive runtime ownership certification.

## Recommended narrow successor

Change tests and a dev-only Tokio feature, not transport policy or deadline
values. Preserve the original failed logs/ZIP/archive as immutable evidence.

1. Make fixture observations explicit: accepted, complete request headers,
   response headers/partial body, and peer EOF/reset. Bound header bytes and
   join/observe the fixture task. A legitimate early EOF must produce its exact
   phase and bytes rather than panicking and dropping a channel. Tests that
   require a later phase must assert that phase; do not accept it as a skip.
   Bind closure to the accepted socket and observe it before client teardown.

2. Deterministically test public transport deadline ownership. Use the same
   raw080 request and owned proxy. The fixture receives and validates the full
   absolute-form request but deliberately withholds response headers. Start
   Fetch with a comfortably bounded setup budget such as the shipped30s;
   require its complete-header handshake under a separate real-time setup
   watchdog. Only then pause Tokio time and advance beyond that already armed
   transport deadline. Assert the actual Fetch result is Timeout. Resume Tokio
   time before awaiting real OS EOF/reset under a real-time watchdog. Keep the
   client alive until after the close result. Withheld headers guarantee that
   the transport future remains pending when time advances; the test cannot
   accidentally pass by completing a response at the timer boundary.

3. Preserve deadline-after-partial-body proof separately in an internal unit
   test of the actual owners. Obtain the actual raw Response through
   redirect::send (including proxy_uri::send and OwnedBody), with validated
   response headers and one of eight body bytes. Start the same Tokio timeout
   over the production read_response, explicitly poll it to Pending, then
   advance controlled time beyond its armed deadline. Await the timeout by
   value so the inner response future is dropped at the same boundary as the
   production caller. Resume real time and require real peer EOF/reset while
   the original client is still alive. Keep cancellation and body-limit
   siblings and their complete wire/close assertions.

4. Use dev-only `tokio` workspace dependency features=["test-util"] at the
   existing pinned1.53.1 version. Do not replace production std::Instant or
   the shared deadline clock to make a test pass. Blindly pausing the current
   partial-response integration test is wrong: production recomputes remaining
   budget with std::Instant. A response completing during virtual advancement
   could arm a new body timer using real elapsed time. The separate pending
   transport and pending body tests above avoid crossing that clock boundary.

Useful negative control for the body owner is to poll the actual timed reader
by reference through its timeout result and deliberately retain that still-owned
future/response until the bounded peer-close assertion. It must reject the
missing EOF, then explicitly clean up. This executes real socket ownership,
not an invented Fetch result. Verify the control's actual intended failure
before counting it; do not assume a hypothetical Drop mutant is effective.
Also keep a complete short body positive control so closure observations cannot
be produced solely by every operation failing.

## Concrete validation after authorization

Implement in a new isolated successor of approved9b4, with an explicitly owned
existing target allocated by Root; do not recreate the retired target or borrow
the Doctor target. Run focused tests across both failure phases and meaningful
negative controls, then existing full Fetch/CLI/Daemon/MCP tests and Go/native
process/control proofs, strict checks, and source/binary binding. Keep current
value/wire evidence and package identity honest; a test-only correction does
not erase raw30native/1Go pooling cost or other incomplete Fetch semantics.
Fresh exact-head native Linux, macOS and Windows workflow evidence and a full
independent review are required. No new passing test or native platform proof
is claimed by this read-only triage.
