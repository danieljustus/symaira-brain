from pathlib import Path
import gzip,hashlib,json,re,subprocess,shutil,platform
repo=Path('/workspace/symaira-fetch773-deadline'); out=repo/'migration/evidence/fetch-deadline-773/final-6eb3cde';out.mkdir(exist_ok=True)
sha=lambda b:hashlib.sha256(b).hexdigest()
load=lambda name:json.loads(Path('/tmp/symaira-fetch773-deadline-final-'+name+'.json').read_text())
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip();assert head=='6eb3cde9db6160d099a29670c4ba287f2faa5891'
# These raw gates were all run before adding evidence files.
assert load('process')['matched']==251
assert load('process-controls')['rejected']==5
assert load('process-raw-proxy-controls')['rejected']==3
assert load('process-proxy-auth-controls')['rejected']==3
raw=load('process-raw-proxy');assert (raw['proxy_matched'],raw['referer_equal'],raw['referer_authorized_divergence'],raw['tls_matched'],raw['native_named_jar_assertions'])==(32,7,1,4,4)
auth=load('process-proxy-auth');assert (auth['echo_matched'],auth['enforced_matched'])==(114,8)
assert load('mcp')['matches'] and load('mcp')['test_exit']==0 and len(load('mcp')['negative_controls'])==3
assert load('daemon-process')['matches'] and load('daemon-process')['total']==63
controls=load('controls');assert len(controls['observations'])==6
assert all(r['exact_rejection'] if r['mutant'] else r['accepted'] for r in controls['observations'])
assert load('auth-required')['passed']==8 and load('original5')['passed']==5
assert load('boundaries')['matched']==140
for name,key,flag in [('auth-extra','pairs','matched'),('original8','observations','equal')]:
 old=json.loads((repo/'browse/port/evidence/fetch-control-773/proxy-auth-c7'/(name+'.json')).read_text());new=load(name)
 ident=lambda r:r.get('case',{}).get('id',r.get('id'))
 assert [ident(r)for r in old[key]if not r[flag]]==[ident(r)for r in new[key]if not r[flag]]
assert load('auth-extra')['total']==38 and load('auth-extra')['passed']==34
assert load('original8')['passed']==7 and load('original8')['failed']==1
log=Path('/tmp/symaira-fetch773-deadline-final-mcp.json.tests.log').read_text()
rows=re.findall(r'test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored;',log)
counts=dict(summaries=len(rows),passed=sum(int(r[1])for r in rows),failed=sum(int(r[2])for r in rows),ignored=sum(int(r[3])for r in rows))
assert counts==dict(summaries=66,passed=303,failed=0,ignored=1)
archive=Path('/workspace/oracles/symaira-fetch773-deadline-6eb3cde-binaries/receipt.json');a=json.loads(archive.read_text());assert (a['artifact_count'],a['unique_count'])==(152,121)
paths=sorted(Path('/tmp').glob('symaira-fetch773-deadline-final-*'))+sorted(Path('/tmp').glob('symaira-fetch773-deadline-initial-*'))+sorted(Path('/tmp').glob('symaira-fetch773-deadline-rerun-*'))
paths += [Path('/tmp')/n for n in ['symaira-fetch773-deadline-remaining-gates.sh','symaira-fetch773-deadline-retained-process.py','symaira-fetch773-deadline-final-archive.py','symaira-fetch773-deadline-final-retention-check.py','symaira-fetch773-deadline-final-evidence.py']]
paths += [archive]
records=[]
for p in sorted(set(paths)):
 if not p.is_file() or p.name.endswith('go-probe'):continue
 b=p.read_bytes(); dest=out/(p.name+'.gz')
 with dest.open('wb')as f:
  with gzip.GzipFile(filename='',mode='wb',fileobj=f,mtime=0,compresslevel=6)as z:z.write(b)
 assert sha(gzip.decompress(dest.read_bytes()))==sha(b)
 records.append(dict(original=str(p),original_sha256=sha(b),bytes=len(b),retained=dest.name,retained_sha256=sha(dest.read_bytes())))
receipt=dict(validated_source=head,parent='9b4ca8875f23b6668a2814ff73632354afcad777',normal_main_ancestor='e3dbda6cbb95429237d15a9b176209b7d107792c',worktree=str(repo),target=str(repo/'target'),platform=platform.platform(),workspace=counts,strict_workspace_all_targets_all_features=True,original_full_workspace_attempt=dict(passed=297,failed=4,ignored=1,summaries=56,cause='Direct Cargo lacked generated MCP output/daemon prerequisites; full original log retained, proper daemon_mcp workspace above passed'),deadline_controls=dict(positive=3,precise_actual_mutant_rejections=3),fetch_process=dict(total=251,matched=251,controls=5),raw_proxy=dict(exact=32,referer_exact=7,original_E011=1,tls_linux=4,named_jars=4,controls=3),proxy_auth=dict(exact_ordered_pairs=114,enforcing_peers=8,controls=3),daemon=dict(actual_pairs=63,controls=3,exit_tests=2,race_rounds=50,starters_each=50),mcp=dict(actual_pairs=13,controls=3),supplements=dict(original38=dict(exact=34,inherited_origin_byte_gaps=4),original5_exact=5,original8=dict(exact=7,original_E011=1),enforcing8_exact=8,reviewer_boundaries140_exact=140),frozen_Go_packages=10,fixture_checks=dict(static=28,profiles=11,robots=15),matrix=dict(contracts=88,acyclic_work_items=17),benchmark_harness=dict(tests=7,platform_skips=2),identity_tests=4,all_new_actual_ELF_archive=dict(paths=152,unique=121,receipt=str(archive),receipt_sha256=sha(archive.read_bytes()),roundtrip_sha256=True,includes_macros_not_relabelled_executed_tests=True),primary_binaries=dict(native_cli=load('daemon-process')['rust_binary_sha256'],native_control_probe=load('process-controls')['native_binary_sha256'],actual_fresh_Go_probe=load('process-controls')['go_binary_sha256'],reused_pinned_Go_release=load('daemon-process')['go_binary_sha256'],reused_pinned_Go_v080_fixture=load('mcp')['binaries_sha256']['go_fixture']),raw_evidence=records,remaining=dict(native_six_platform_CI_required=True,different_author_full_review_required=True,value='Parent240 value samples/120 wirecost pairs retained; no new-source benchmark or size claim',full_773_772_default_cutover=False,full_765_closed=False),failed_attempt_preserved=True,original_169_113_archive_roundtrip_verified=True)
(out/'validation.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(len(records),'raw source/env/harness/artifact/log/report files retained with roundtripSHA; source',head)
