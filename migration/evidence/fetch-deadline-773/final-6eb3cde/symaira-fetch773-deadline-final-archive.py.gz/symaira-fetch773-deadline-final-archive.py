#!/usr/bin/env python3
"""Roundtrip archive the exclusively owned final executable proof, without retirement."""
from pathlib import Path
import gzip,hashlib,json,subprocess,os
repo=Path('/workspace/symaira-fetch773-deadline'); target=repo/'target'
archive=Path('/workspace/oracles/symaira-fetch773-deadline-6eb3cde-binaries');archive.mkdir(exist_ok=True)
sha=lambda b:hashlib.sha256(b).hexdigest()
items=[]; unique={}
paths=list(target.rglob('*'))+[Path(p)for p in ['/tmp/symaira-fetch773-deadline-final-go-probe','/tmp/symaira-fetch773-proxy-auth-clean-go-release','/tmp/symaira-browse-mcp-go']]
for p in paths:
 if not p.is_file():continue
 with p.open('rb')as f:magic=f.read(4)
 if magic!=b'\x7fELF':continue
 data=p.read_bytes();h=sha(data); dest=archive/(h+'.elf.gz')
 if h not in unique:
  if not dest.exists():
   with dest.open('wb')as f:
    with gzip.GzipFile(filename='',mode='wb',fileobj=f,mtime=0,compresslevel=6)as z:z.write(data)
  assert sha(gzip.decompress(dest.read_bytes()))==h
  unique[h]=dict(archive=str(dest),bytes=len(data),gzip_bytes=dest.stat().st_size,gzip_sha256=sha(dest.read_bytes()),decoded_sha256=h)
 items.append(dict(path=str(p),sha256=h,bytes=len(data),mode=oct(p.stat().st_mode&0o777),archive=str(dest)))
receipt=dict(source_head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip(),source_dirty=bool(subprocess.check_output(['git','status','--porcelain'],cwd=repo)),target=str(target),retired=False,artifacts=items,unique=unique,artifact_count=len(items),unique_count=len(unique),decoded_bytes=sum(x['bytes']for x in unique.values()),gzip_bytes=sum(x['gzip_bytes']for x in unique.values()))
(archive/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(len(items),'ELF paths;',len(unique),'unique, all roundtrip SHA256 verified; target retained')
