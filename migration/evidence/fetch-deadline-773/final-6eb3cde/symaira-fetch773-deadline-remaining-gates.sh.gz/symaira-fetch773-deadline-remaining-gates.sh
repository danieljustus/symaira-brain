#!/usr/bin/env bash
set -euo pipefail
umask 022
source /home/agent/.cargo/env
export PATH=/workspace/toolchains/go1.26.7/bin:$PATH
export CARGO_TARGET_DIR=/workspace/symaira-fetch773-deadline/target
export CARGO_PROFILE_DEV_DEBUG=0 CARGO_PROFILE_TEST_DEBUG=0 CARGO_INCREMENTAL=0 CARGO_BUILD_JOBS=2
check_capacity() {
  python3 - <<'PY'
import shutil
free=shutil.disk_usage('/workspace').free
assert free>=700*1024*1024, f'No new compile below700MiB: {free} free'
PY
}
cd /workspace/symaira-fetch773-deadline/browse
check_capacity
cargo clippy --workspace --all-targets --all-features --locked -- -D warnings > /tmp/symaira-fetch773-deadline-final-workspace-clippy.log 2>&1
check_capacity
cargo test -p symbrowse-fetch --all-targets --locked --no-run --message-format=json > /tmp/symaira-fetch773-deadline-final-artifacts.jsonl 2> /tmp/symaira-fetch773-deadline-final-artifacts.log
python3 port/harness/fetch_deadline_controls.py --artifacts /tmp/symaira-fetch773-deadline-final-artifacts.jsonl --output /tmp/symaira-fetch773-deadline-final-controls.json > /tmp/symaira-fetch773-deadline-final-controls.log 2>&1
check_capacity
python3 port/harness/daemon_mcp.py --go /tmp/symaira-fetch773-proxy-auth-clean-go-release --go-fixture /tmp/symaira-browse-mcp-go --rust "$CARGO_TARGET_DIR/debug/symbrowse" --go-source /workspace/oracles/daemon772-go-source --workspace --out /tmp/symaira-fetch773-deadline-final-mcp.json > /tmp/symaira-fetch773-deadline-final-mcp.log 2>&1
check_capacity
go run ./scripts/rust-port/fetch_fixture_gen.go --check > /tmp/symaira-fetch773-deadline-final-go-fixtures.log 2>&1
go run -tags rustport ./scripts/rust-port/cmd/fetchcontrolgen --check > /tmp/symaira-fetch773-deadline-final-go-controls.log 2>&1
check_capacity
GOTOOLCHAIN=go1.26.7 CGO_ENABLED=0 go -C /workspace/oracles/daemon772-go-source/browse test -count=1 ./internal/fetch/... > /tmp/symaira-fetch773-deadline-final-go-tests.log 2>&1
