from pathlib import Path
import gzip,hashlib,json
repo=Path('/workspace/symaira-fetch773-deadline');root=repo/'migration/evidence/fetch-deadline-773/original'
sha=lambda b:hashlib.sha256(b).hexdigest()
d=json.loads((root/'retention.json').read_text()); records=[]
for orig,r in d['original_files'].items():
 z=root/r['retained'];b=gzip.decompress(z.read_bytes())
 assert sha(b)==r['sha256'] and sha(z.read_bytes())==r['retained_sha256']
 assert sha(Path(orig).read_bytes())==r['sha256']
 records.append(dict(original=orig,sha256=r['sha256'],roundtrip=True))
r=d['original_test_binary'];assert sha(gzip.decompress((root/r['retained']).read_bytes()))==r['sha256']
assert sha(gzip.decompress((root/'original-proxy_uri.rs.gz').read_bytes()))==d['original_input_sha256']
archive=Path(d['all169_executables113_unique_original_archive']);old=json.loads(archive.read_text())
assert len(old['executables'])==169 and len(old['unique'])==113
for h,r in old['unique'].items():
 digest=hashlib.sha256()
 with gzip.open(r['archive'],'rb')as f:
  for b in iter(lambda:f.read(1024*1024),b''):digest.update(b)
 assert digest.hexdigest()==h
print('Original fullCI logs/ZIP/triage/input/ec10test and all169ELF/113unique retained exact')
Path('/tmp/symaira-fetch773-deadline-final-original-retention.json').write_text(json.dumps(dict(original_files=records,original_test_sha256=d['original_test_binary']['sha256'],original_archive_sha256=sha(archive.read_bytes()),original169_paths_verified=True,all113_roundtrip_verified=True),indent=2)+'\n')
