from pathlib import Path
import json,re,hashlib,subprocess
repo=Path('/workspace/symaira-fetch773-deadline');a=json.loads(Path('/workspace/oracles/symaira-fetch773-deadline-6eb3cde-binaries/receipt.json').read_text());mapped={r['path']:r for r in a['artifacts']};seen={}
logs=[Path('/tmp/symaira-fetch773-deadline-final-workspace-tests.log'),Path('/tmp/symaira-fetch773-deadline-final-mcp.json.tests.log'),Path('/tmp/symaira-fetch773-deadline-initial-focused.log')]
for p in logs:
 for binary in re.findall(r'Running .*?\((/workspace/symaira-fetch773-deadline/target/[^)]+)\)',p.read_text()):
  seen.setdefault(binary,[]).append(str(p))
for p in [Path('/tmp/symaira-fetch773-deadline-final-controls.json'),Path('/tmp/symaira-fetch773-deadline-final-controls-retained-artifacts.json')]:
 for r in json.loads(p.read_text())['observations']:seen.setdefault(r['binary'],[]).append(str(p))
seen[str(repo/'target/debug/examples/control_probe')]=['actual Fetch process/raw/auth/supplement reports']
seen[str(repo/'target/debug/symbrowse')]=['actual daemon/MCP/lifecycle/races reports']
for p in ['/tmp/symaira-fetch773-deadline-final-go-probe','/tmp/symaira-fetch773-proxy-auth-clean-go-release','/tmp/symaira-browse-mcp-go']:seen[p]=['actual Go process reports (fresh probe retained before cleanup; reused immutable Go fixtures separately bound)']
records=[]
for p,inputs in sorted(seen.items()):
 assert p in mapped,p
 actual=hashlib.sha256(Path(p).read_bytes()).hexdigest();assert actual==mapped[p]['sha256']
 records.append(dict(path=p,sha256=actual,archive=mapped[p]['archive'],execution_evidence=sorted(set(inputs))))
Path('/tmp/symaira-fetch773-deadline-final-executed-provenance.json').write_text(json.dumps(dict(source='6eb3cde9db6160d099a29670c4ba287f2faa5891',actual_execution_bound_paths=len(records),artifacts=records,all_archive_paths=152,unique_archive_objects=121,macro_shared_artifacts_not_relabelled_executed_tests=True),indent=2)+'\n')
print(len(records),'actual executed test/probe/CLI/Go paths verified against final roundtrip archive')
