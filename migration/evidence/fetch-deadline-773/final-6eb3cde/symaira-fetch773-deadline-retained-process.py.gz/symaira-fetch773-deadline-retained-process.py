#!/usr/bin/env python3
"""Run unchanged Fetch process gate and retain its owned oracle before cleanup."""
import hashlib,json,os,shutil,subprocess,threading,time
from pathlib import Path
root=Path('/tmp/symaira-fetch773-deadline-process-owned');root.mkdir(exist_ok=True)
retained=Path('/tmp/symaira-fetch773-deadline-final-go-probe')
report=Path('/tmp/symaira-fetch773-deadline-final-process-retention.json')
stop=threading.Event();observations=[]
def watch():
 while not stop.wait(.05):
  for p in root.glob('fetch773-source.*/go-probe'):
   if p.exists() and p.stat().st_mode&0o111 and p.stat().st_size>1000000:
    # Wait for linker publication; actual subsequent runner receipt must match.
    try:
     b=p.read_bytes();h=hashlib.sha256(b).hexdigest()
     if observations and observations[-1]['sha256']==h:continue
     retained.write_bytes(b);retained.chmod(0o755)
     observations.append(dict(actual_owned_path=str(p),retained_path=str(retained),sha256=h,bytes=len(b)))
     report.write_text(json.dumps(dict(observations=observations),indent=2)+'\n')
    except FileNotFoundError: pass
observer=threading.Thread(target=watch);observer.start()
env=dict(os.environ,RUNNER_TEMP=str(root))
try:
 with Path('/tmp/symaira-fetch773-deadline-final-process.log').open('wb') as log:
  completed=subprocess.run(['port/harness/run_fetch_control_773.sh','/tmp/symaira-fetch773-deadline-final-process.json'],cwd='/workspace/symaira-fetch773-deadline/browse',env=env,stdout=log,stderr=subprocess.STDOUT)
finally:
 stop.set();observer.join()
assert observations,'Owned actual Go binary was not retained'
assert hashlib.sha256(retained.read_bytes()).hexdigest()==observations[-1]['sha256']
if completed.returncode==0:
 actual=json.loads(Path('/tmp/symaira-fetch773-deadline-final-process.json').read_text())
 assert actual['binaries_sha256']['go']==observations[-1]['sha256'], 'Retained oracle differs from actually executed Go bytes'
raise SystemExit(completed.returncode)
