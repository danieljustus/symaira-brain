import base64,hashlib,json,os,subprocess,time
from pathlib import Path
repo=Path('/workspace/symaira-fetch773-deadline')
h=json.load(open('/tmp/symaira-fetch773-deadline-final-handoff.json'))
records=[]
binaries=h['deadline_test_binaries']
for path,digest in binaries.items():
 assert hashlib.file_digest(open(path,'rb'),'sha256').hexdigest()==digest
env=dict(os.environ);env.pop('FETCH_PROXY_FIXTURE_CONTROL',None)
for repeat in range(16):
 for path in binaries:
  cmd=[path,'--nocapture']
  if 'symbrowse_fetch-' in Path(path).name:cmd.insert(1,'honest::proxy_uri::tests::')
  start=time.monotonic()
  p=subprocess.run(cmd,cwd=repo,env=env,capture_output=True,timeout=20)
  record={'repeat':repeat,'command':cmd,'sha256':binaries[path],'exit':p.returncode,'elapsed_seconds':time.monotonic()-start,'stdout_base64':base64.b64encode(p.stdout).decode(),'stderr_base64':base64.b64encode(p.stderr).decode()}
  records.append(record)
  Path('/tmp/symaira-fetch773-deadline-root-repeated-phases.json').write_text(json.dumps({'source':h['source'],'publication':h['publication'],'scope':'32 real phase/close/task/body/earlyEOF test-ELF executions, original assertions unchanged, no builds','observations':records},indent=2)+'\n')
  assert p.returncode==0,(repeat,path,p.stdout,p.stderr)
print('32 actual test-ELF runs pass; each runs 3 library or 5 proxy phase cases')

