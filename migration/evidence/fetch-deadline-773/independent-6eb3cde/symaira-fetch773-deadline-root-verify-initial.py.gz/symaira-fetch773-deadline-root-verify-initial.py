from pathlib import Path
import json,gzip,hashlib,subprocess
r=Path('/workspace/symaira-fetch773-deadline');src='6eb3cde9db6160d099a29670c4ba287f2faa5891';parent='9b4ca8875f23b6668a2814ff73632354afcad777'
sha=lambda p:hashlib.file_digest(Path(p).open('rb'),'sha256').hexdigest()
v=r/'migration/evidence/fetch-deadline-773/final-6eb3cde/validation.json';d=json.loads(v.read_text());assert sha(v)=='ecc69d216bd126f2920948289b40c4ed5de71d4b2def7447567c882e59780437'
assert not subprocess.check_output(['git','status','--porcelain'],cwd=r)
proof=[]
for x in d['raw_evidence']:
 p=v.parent/x['retained'];assert sha(p)==x['retained_sha256']
 with gzip.open(p,'rb') as f:assert hashlib.file_digest(f,'sha256').hexdigest()==x['original_sha256']
 proof.append(x['original'])
p=json.load(open('/tmp/symaira-fetch773-deadline-final-production-provenance.json'))
for x in p['production_checks']:
 current=(r/x['path']).read_bytes();old=subprocess.check_output(['git','show',parent+':'+x['path']],cwd=r)
 if x['kind']=='byte-identical':assert current==old,x['path']
 else:
  suffix=b'\n#[cfg(test)]\n#[path = "proxy_uri_tests.rs"]\nmod tests;\n'
  assert current==old+suffix,x['path']
assert subprocess.check_output(['git','show',parent+':browse/Cargo.lock'],cwd=r)==(r/'browse/Cargo.lock').read_bytes()
maps=[]
for name in ['process','daemon']:
 p=json.load(open('/tmp/symaira-fetch773-deadline-root-'+name+'.json'))
 for k,ref in [('candidate_source_sha256',src),('go_source_sha256','dcddcef0df5789123c7c9a7ebe6e01f10e941f2c')]:
  entries=p.get(k,{})
  for file,digest in entries.items():
   if k.startswith('candidate'):assert sha(r/file)==digest,(name,file)
   assert hashlib.sha256(subprocess.check_output(['git','show',ref+':'+file],cwd=r)).hexdigest()==digest,(name,file)
  maps.append({'report':name,'kind':k,'count':len(entries)})
a=json.load(open(d['all_new_actual_ELF_archive']['receipt']))
for digest,rec in a['unique'].items():
 assert sha(rec['archive'])==rec['gzip_sha256'],digest
 with gzip.open(rec['archive'],'rb') as f:assert hashlib.file_digest(f,'sha256').hexdigest()==digest
e=json.load(open('/tmp/symaira-fetch773-deadline-final-executed-provenance.json'))
for rec in e['artifacts']:
 assert sha(rec['path'])==rec['sha256'],rec['path']
 with gzip.open(rec['archive'],'rb') as f:assert hashlib.file_digest(f,'sha256').hexdigest()==rec['sha256']
for file in subprocess.check_output(['git','diff','--name-only',src,'HEAD'],cwd=r,text=True).splitlines():assert file.startswith('migration/evidence/fetch-deadline-773/final-6eb3cde/'),file
out={'source':src,'publication':subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip(),'verified_author_evidence_files':len(proof),'verified_production_files':len(p['production_checks']),'lock_unchanged':True,'maps':maps,'archive_paths':a['artifact_count'],'unique_archive_roundtrips':len(a['unique']),'executed_source_bound_paths':len(e['artifacts']),'source_successor_evidence_only':True}
Path('/tmp/symaira-fetch773-deadline-root-verification.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))

