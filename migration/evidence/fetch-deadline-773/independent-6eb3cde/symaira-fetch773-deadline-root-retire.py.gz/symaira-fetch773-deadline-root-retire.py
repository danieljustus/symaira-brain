from pathlib import Path
import os,json,gzip,hashlib,shutil,subprocess
r=Path('/workspace/symaira-fetch773-deadline');t=r/'target'
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip();assert head=='6e19b2bdc847915ee645ffe79af0b79d6e726fe7'
assert not subprocess.check_output(['git','status','--porcelain'],cwd=r)
sha=lambda p:hashlib.file_digest(Path(p).open('rb'),'sha256').hexdigest()
users=[]
for proc in Path('/proc').iterdir():
 if not proc.name.isdigit() or int(proc.name)==os.getpid():continue
 try:
  vals=[os.readlink(proc/'exe'),os.readlink(proc/'cwd'),(proc/'maps').read_text()]
  for fd in (proc/'fd').iterdir():
   try:vals.append(os.readlink(fd))
   except OSError:pass
  if any(str(t)+'/' in x or str(t)==x for x in vals):users.append(proc.name)
 except (OSError,ProcessLookupError):pass
assert not users,users
old=json.load(open('/workspace/oracles/symaira-fetch773-deadline-6eb3cde-binaries/receipt.json'));unique=dict(old['unique'])
archive=Path('/workspace/oracles/symaira-fetch773-deadline-root-idle-binaries');archive.mkdir(exist_ok=True)
assert not (archive/'receipt.json').exists()
records=[];new=[]
for parent,_,names in os.walk(t):
 for name in names:
  p=Path(parent)/name
  if p.is_symlink() or not p.is_file():continue
  with p.open('rb') as f:
   if f.read(4)!=b'\x7fELF':continue
  digest=sha(p)
  if digest not in unique:
   out=archive/(digest+'.gz')
   with p.open('rb') as f,out.open('wb') as raw:
    with gzip.GzipFile(fileobj=raw,mode='wb',mtime=0) as z:shutil.copyfileobj(f,z,1<<20)
   with gzip.open(out,'rb') as f:assert hashlib.file_digest(f,'sha256').hexdigest()==digest
   unique[digest]={'archive':str(out),'sha256':digest,'original_size':p.stat().st_size,'compressed_size':out.stat().st_size}
   new.append(digest)
  records.append({'path':str(p),'sha256':digest,'archive':unique[digest]['archive']})
doc={'head':head,'tested_source':'6eb3cde9db6160d099a29670c4ba287f2faa5891','target':str(t),'current_ELF_payload_paths':len(records),'new_archive_objects':len(new),'all_ELF_payloads_roundtrip_verified':True,'original_execution_identity_archive':str('/workspace/oracles/symaira-fetch773-deadline-6eb3cde-binaries/receipt.json'),'users':users,'current_artifacts':records,'retired':False}
(archive/'receipt.json').write_text(json.dumps(doc,indent=2)+'\n')
shutil.rmtree(t);doc['retired']=True
(archive/'receipt.json').write_text(json.dumps(doc,indent=2)+'\n')
print(len(records),'current ELF payload paths verified; new',len(new),'archive objects; only Root-owned cache retired')

