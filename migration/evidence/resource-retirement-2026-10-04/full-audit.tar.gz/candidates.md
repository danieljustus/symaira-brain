# Read-only completed worktree resource audit

91 registered worktrees examined. 57 source-eligible old worktrees are clean, contain no target/cache/ignored runtime except verified Python derivatives, are strict ancestors of an allowed published/prepared checkpoint, and retain matching branch refs in the preserved /workspace/symaira-brain/.git. Every tracked byte, blob/type/executable bit was checked against its HEAD, including source and all tracked raw proofs. 8,770 unique referenced Git blob objects exist locally with exact byte lengths and lazy fetching disabled. Native permissions (including prior0600/0700 from umask077) are retained per file; they do not change Git executable semantics and can be restored from these manifests. No worktree/branch/cache/source was deleted.

Visible agent exe/cwd/FD/environment scans at start and end found zero references to these candidates. Values of environment variables were not retained. 641 exited zombie records carry no live address space/file table. Root-owned dockerdPID198/containerdPID249 remain **UNVERIFIED** for their privileged exe/cwd/FD/environment fields: no global zero-user claim is made. Authorized read-only Docker ps returned success with zero running containers, so there were no running-container mount references to inspect. Root can decide the explicit host-service boundary; no user-approval flow is inferred.

The following15 published ancestors are prioritized: your five named old review trees, then nine old Doctor source generations and the superseded Usage argv tree. All protected/latest prepared heads and explicit active paths are kept. No frozen Go oracle worktree is included.

| Worktree | MiB¹ | HEAD | Checkpoint PR | Exact files |
|---|---:|---|---|---:|
| symaira-memory649-root | 120.0 | ec57961f | 803 | 4129 |
| symaira-skills794-wide-root | 70.3 | cec81cfc | 794 | 2767 |
| symaira-memory803-deadline | 105.6 | a0ec18b8 | 803 | 3008 |
| symaira-memory649-integrated | 115.2 | 63fbd320 | 803 | 3802 |
| symaira-decisions | 64.4 | 6c6881db | 794 | 2537 |
| symaira-doctor806-journal-import | 294.6 | 74dd7aea | 806 | 4395 |
| symaira-doctor806-windows-job-diagnostic | 294.6 | e7541a33 | 806 | 4418 |
| symaira-doctor806-source-progress-fix | 294.1 | 7ea3cfb9 | 806 | 4355 |
| symaira-doctor806-source-progress | 293.9 | 9faee8b0 | 806 | 4331 |
| symaira-doctor806-owned-paths | 293.7 | c6723ab2 | 806 | 4299 |
| symaira-doctor765-stdout | 282.2 | fb6d68b3 | 806,prepared-Brain | 4042 |
| symaira-doctor765-output | 256.9 | b3ad77a8 | 806,prepared-Brain | 3771 |
| symaira-doctor765-json | 205.9 | 3f92a768 | 806,prepared-Brain | 3156 |
| symaira-doctor765-windows | 176.7 | 34394496 | 806,prepared-Brain | 2861 |
| symaira-usage768-argv | 156.6 | eea73b74 | 804 | 3314 |

¹ Allocated source-directory blocks, excluding target/cache/.git: selected total3024.7MiB (2.95GiB). Across all57 candidates the upper estimate is6,969MiB. Lower-overlay files can reclaim less or nothing; actual headroom must be measured after each Root-authorized retirement. This audit does not promise2GiB of actual gain.

Full manifest: manifest.json. Per-worktree tracked-file manifests record every raw path, Gitblob, SHA256, length, native permission and Git mode; these cover all tracked source/proofs, not just production. Root must recheck branch/HEAD/status/ignored/runtime and visible process references immediately before removal, preserve every branch/ref/Git object, and then measure real free space. Initial short-prefix resolver failures and the overly strict0644-only first classification remain retained; no candidate data changed.
