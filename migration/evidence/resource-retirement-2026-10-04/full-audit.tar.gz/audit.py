from pathlib import Path
import hashlib
import json
import os
import stat
import subprocess
from datetime import datetime, timezone

REPO = Path('/workspace/symaira-brain')
OUT = Path(__file__).resolve().parent
KEEP = {'symaira-brain','symaira-pr794','symaira-memory758-cli-fixes','symaira-guard770',
        'symaira-source765-windows-job-cleanup','symaira-managed803-timeout-diagnostic',
        'symaira-memory762-sync-backend-fixes','symaira-usage768-retry-after-decimal',
        'symaira-daemon772-discovery-runtime','symaira-brain765-runtime',
        'symaira-skills764-native','symaira-memory761-importers','symaira-memory760-engine'}
PUBLISHED = {'794':'04e2','803':'a30bba8b','805':'a1a29878','806':'44354141','797':'4f3c0032',
             '801':'c31b557b','804':'b8621bc2','809':'ab4','810':'86698a96','811':'3ce87f52','812':'9647ee73',
             'prepared-Brain':'43f7d6e8','prepared-Discovery':'308f3049'}


def git(*args, cwd=REPO, check=True):
    p = subprocess.run(['git', *args], cwd=cwd, capture_output=True, check=False)
    if check and p.returncode:
        raise RuntimeError((args, p.returncode, p.stderr.decode(errors='replace')))
    return p


def proc_users(paths):
    users = {str(p): [] for p in paths}
    inaccessible = []
    def match(value, p):
        needle = os.fsencode(str(p))
        start = 0
        while (at := value.find(needle, start)) >= 0:
            end = at + len(needle)
            if end == len(value) or value[end:end+1] in (b'/', b'\0', b':', b' ', b'\n'):
                return True
            start = end
        return False
    for proc in Path('/proc').iterdir():
        if not proc.name.isdigit() or int(proc.name) == os.getpid():
            continue
        refs = []
        try:
            for name in ('exe', 'cwd'):
                try:
                    refs.append((name, os.fsencode(os.readlink(proc / name))))
                except FileNotFoundError:
                    pass
            for fd in (proc / 'fd').iterdir():
                try:
                    refs.append(('fd:' + fd.name, os.fsencode(os.readlink(fd))))
                except FileNotFoundError:
                    pass
            for entry in (proc / 'environ').read_bytes().split(b'\0'):
                if b'=' in entry:
                    key, value = entry.split(b'=', 1)
                    refs.append(('env:' + key.decode(errors='replace'), value))
        except FileNotFoundError:
            continue
        except PermissionError:
            inaccessible.append(int(proc.name))
            continue
        for p in paths:
            kinds = sorted({kind for kind, value in refs if match(value, p)})
            if kinds:
                # Environment VALUES are deliberately never retained or printed.
                users[str(p)].append({'pid': int(proc.name), 'references': kinds})
    return users, inaccessible


raw = git('worktree', 'list', '--porcelain').stdout
(OUT / 'registered-worktrees.original.txt').write_bytes(raw)
worktrees = []
for paragraph in raw.decode().strip().split('\n\n'):
    row = {}
    for line in paragraph.splitlines():
        key, _, value = line.partition(' ')
        row[key] = value
    worktrees.append(row)
checkpoints = {}
all_commits = git('rev-list', '--all').stdout.decode().splitlines()
for label, prefix in PUBLISHED.items():
    matches = [sha for sha in all_commits if sha.startswith(prefix)]
    if len(matches) != 1:
        raise RuntimeError(('ambiguous or absent published checkpoint', label, prefix, matches))
    checkpoints[label] = matches[0]
paths = [Path(w['worktree']) for w in worktrees if w['worktree'].startswith('/workspace/')]
start_users, start_inaccessible = proc_users(paths)
rows = []
for w in worktrees:
    path = Path(w['worktree'])
    if not str(path).startswith('/workspace/'):
        rows.append(dict(w, disposition='KEEP_OUTSIDE_WORKSPACE'))
        continue
    reasons = []
    if path.name in KEEP:
        reasons.append('EXPLICIT_ACTIVE_KEEP')
    if w['HEAD'] in checkpoints.values():
        reasons.append('EXACT_PUBLISHED_OR_LATEST_PREPARED_HEAD')
    status = git('status', '--porcelain=v1', '-z', '--ignored', '--untracked-files=normal', cwd=path).stdout
    ignored, dirty = [], []
    for entry in status.split(b'\0'):
        if entry:
            if entry.startswith(b'!! '):
                ignored.append(os.fsdecode(entry[3:]))
            else:
                dirty.append(os.fsdecode(entry))
    forbidden = [p for p in ignored if '__pycache__' not in Path(p).parts]
    if dirty:
        reasons.append('DIRTY_OR_UNTRACKED')
    if forbidden:
        reasons.append('IGNORED_RUNTIME_OR_CACHE')
    if (path / 'target').exists() or (path / 'target').is_symlink():
        reasons.append('TARGET_PRESENT')
    if start_users[str(path)]:
        reasons.append('PROCESS_USERS')
    ancestors = [label for label, sha in checkpoints.items() if sha != w['HEAD'] and
                 git('merge-base', '--is-ancestor', w['HEAD'], sha, check=False).returncode == 0]
    if not ancestors:
        reasons.append('NOT_STRICT_ANCESTOR_OF_ALLOWED_CHECKPOINT')
    branch = w.get('branch')
    if not branch or git('rev-parse', '--verify', branch, check=False).stdout.decode().strip() != w['HEAD']:
        reasons.append('NO_PERSISTENT_MATCHING_BRANCH_REF')
    # Never descend into targets or ignored SDK caches to obtain their sizes.
    size = subprocess.run(['du', '-s', '-B1', '--exclude=target', '--exclude=.git',
                           '--exclude=node_modules', '--exclude=.cache', '--', str(path)],
                          capture_output=True, check=False)
    base_size = int(size.stdout.split()[0]) if size.returncode == 0 else None
    row = dict(w, reasons=reasons, clean=not dirty, dirty_entries=dirty,
               ignored_entries=ignored, forbidden_ignored_entries=forbidden,
               allowed_python_derivatives=[p for p in ignored if p not in forbidden],
               strict_ancestor_checkpoints=ancestors, proc_users_start=start_users[str(path)],
               allocated_bytes_excluding_targets_caches_and_git=base_size)
    if not reasons:
        records = []
        for entry in git('ls-tree', '-r', '-z', w['HEAD']).stdout.split(b'\0'):
            if not entry:
                continue
            meta, name = entry.split(b'\t', 1)
            mode, kind, blob = meta.split()
            file = path / os.fsdecode(name)
            info = file.lstat()
            if kind != b'blob':
                reasons.append('NON_BLOB_ENTRY')
                continue
            data = os.fsencode(os.readlink(file)) if mode == b'120000' else file.read_bytes()
            actual = hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()
            if actual != blob.decode():
                reasons.append('TRACKED_BYTES_NOT_GIT_BLOB_IDENTICAL')
            if mode in (b'100644', b'100755') and (not stat.S_ISREG(info.st_mode) or
                    bool(info.st_mode & 0o111) != (mode == b'100755')):
                reasons.append('TRACKED_TYPE_OR_MODE_NOT_RECREATABLE')
            records.append({'path_bytes_hex':name.hex(), 'mode':mode.decode(), 'blob':blob.decode(),
                            'native_mode':stat.S_IMODE(info.st_mode),
                            'sha256':hashlib.sha256(data).hexdigest(), 'bytes':len(data)})
        manifest_name = path.name + '-tracked-files.json'
        (OUT / manifest_name).write_text(json.dumps(records, indent=2) + '\n')
        row.update(tracked_files=len(records), tracked_source_proof_bytes=sum(x['bytes'] for x in records),
                   tracked_file_manifest=manifest_name, full_blob_byte_verification=not reasons)
    row['reasons'] = sorted(set(reasons))
    row['disposition'] = 'CANDIDATE_ROOT_REVIEW_ONLY' if not reasons else 'KEEP'
    rows.append(row)
    (OUT / 'progress.json').write_text(json.dumps(rows, indent=2) + '\n')
end_users, end_inaccessible = proc_users(paths)
for row in rows:
    if row['worktree'] in end_users:
        row['proc_users_end'] = end_users[row['worktree']]
        if end_users[row['worktree']] and row['disposition'] == 'CANDIDATE_ROOT_REVIEW_ONLY':
            row['disposition'] = 'KEEP'
            row['reasons'].append('PROCESS_USERS_AT_FINAL_SCAN')
report = dict(completed=datetime.now(timezone.utc).isoformat(), checkpoints=checkpoints,
              persistent_git_directory=git('rev-parse', '--git-common-dir').stdout.decode().strip(),
              proc_permission_failures_start=start_inaccessible, proc_permission_failures_end=end_inaccessible,
              deletion_performed=False, targets_compilers_ports_used=False,
              size_limit='allocated source-directory bytes are an upper estimate; lower overlay reclaim may be zero',
              recheck_required_before_root_removal=True, worktrees=rows)
(OUT / 'manifest.json').write_text(json.dumps(report, indent=2) + '\n')
candidates = [r for r in rows if r['disposition'] == 'CANDIDATE_ROOT_REVIEW_ONLY']
print(json.dumps({'registered':len(rows), 'candidates':len(candidates),
                  'allocated_source_candidate_MiB':round(sum(r['allocated_bytes_excluding_targets_caches_and_git'] for r in candidates)/2**20, 2),
                  'candidate_paths':[r['worktree'] for r in candidates],
                  'inaccessible_proc_PIDs':sorted(set(start_inaccessible+end_inaccessible))}, indent=2))
