"""Independent source projection only. Never imports/builds/runs Rust or Go.

Fast/Eisel control flow follows inspected Rust/SDK source. Decimal shifts use
exact integer arithmetic, independently of either digit-loop implementation.
This verifies retained actual SDK observations; it is not native execution.
"""
import importlib.util
import ast
import json
import math
from pathlib import Path
import random
import re
import struct
import sys

sys.set_int_max_str_digits(200000)
ROOT=Path('/workspace/symaira-usage768-retry-main935')
SDK=Path('/workspace/toolchains/go1.26.7/src/internal/strconv')
MASK=(1<<64)-1
def bits(f):return struct.unpack('>Q',struct.pack('>d',f))[0]
def fbits(b):return struct.unpack('>d',struct.pack('>Q',b))[0]
def pairs(text):return [(int(a.replace('_',''),16),int(b.replace('_',''),16)) for a,b in re.findall(r'\(\s*(0x[\da-fA-F_]+),\s*(0x[\da-fA-F_]+)\s*\)',text)]
POWER=sum([pairs((ROOT/('rust/symbrain-usage/src/go_decimal_fast/powers_'+name+'.rs')).read_text())for name in ['negative','positive']],[])
sdkpowers=[(int(a,16),int(b,16))for a,b in re.findall(r'\{\s*(0x[\da-fA-F]+),\s*(0x[\da-fA-F]+)\s*\}',(SDK/'pow10tab.go').read_text())]
assert POWER==sdkpowers and len(POWER)==696
shift=(ROOT/'rust/symbrain-usage/src/go_decimal_shift.rs').read_text()
LEFT=[(int(n),v)for n,v in re.findall(r'\((\d+), b"([0-9]*)"\)',shift)]
sdkleft=(SDK/'decimal.go').read_text().split('var leftcheats =')[1].split('\n}')[0]
assert LEFT==[(int(n),v)for n,v in re.findall(r'\{(\d+), "([0-9]*)"\}',sdkleft)] and len(LEFT)==61
def capped(e):
    neg=e.startswith('-');e=e.lstrip('+-').replace('_','');v=0
    for ch in e:
        if v<10000:v=10*v+int(ch)
    return -v if neg else v
def scan(s):
    neg=s.startswith('-');u=s.lstrip('+-');he=u[:2].lower()=='0x'
    # Full input, exactly one optional sign, digits/underscores as Go grammar.
    dig='[0-9a-fA-F]'if he else'[0-9]'
    seq=dig+'(?:_?'+dig+')*'; coefficient='(?:'+seq+r'(?:\.(?:'+seq+r')?)?|\.'+seq+')'
    pattern=r'[+-]?(?:0[xX]_?'+coefficient+r'[pP][+-]?[0-9](?:_?[0-9])*|'+coefficient+r'(?:[eE][+-]?[0-9](?:_?[0-9])*)?)'
    if he:
        pattern=r'[+-]?0[xX]_?'+coefficient+r'[pP][+-]?[0-9](?:_?[0-9])*'
    else:
        pattern=r'[+-]?'+coefficient+r'(?:[eE][+-]?[0-9](?:_?[0-9])*)?'
    if re.fullmatch(pattern,s) is None:return None
    u=u[2:]if he else u
    marker='[pP]'if he else'[eE]'; parts=re.split(marker,u,maxsplit=1)
    coeff=parts[0].replace('_','');explicit=capped(parts[1])if len(parts)>1 else 0
    dp=coeff.find('.'); dp=len(coeff)if dp<0 else dp
    digits=coeff.replace('.',''); leading=len(digits)-len(digits.lstrip('0'))
    digits=digits.lstrip('0'); dp-=leading
    kept=min(len(digits),16 if he else 19)
    m=int(digits[:kept]or'0',16 if he else 10)
    exp=(dp-kept)*(4 if he else 1)+explicit if m else 0
    return m,exp,neg,any(ch!='0'for ch in digits[kept:]),he
def exact(m,e,neg):
    if m>>52:return None
    v=float(m);v=-v if neg else v
    if e==0:return v
    if 1<=e<=37:
        if e>22:v*=float(10**(e-22));e=22
        if not -1e15<=v<=1e15:return None
        return v*float(10**e)
    if -22<=e<=-1:return v/float(10**(-e))
    return None
def mul(a,b):v=a*b;return v>>64,v&MASK
def eisel(m,e,neg):
    sign=int(neg)<<63
    if m==0:return fbits(sign)
    if not -348<=e<=347:return None
    high,low=POWER[e+348];zeros=64-m.bit_length();m<<=zeros
    be=1+((e*108853)>>15)+63+1023-zeros
    hi,lo=mul(m,high)
    if hi&0x1ff==0x1ff and (lo+m)&MASK<m:
        eh,el=mul(m,low);ml=(lo+eh)&MASK;mh=(hi+(ml<lo))&MASK
        if mh&0x1ff==0x1ff and (ml+1)&MASK==0 and (el+m)&MASK<m:return None
        hi,lo=mh,ml
    lead=hi>>63;r=hi>>(lead+9);be-=1^lead
    if lo==0 and hi&0x1ff==0 and r&3==1:return None
    r+=r&1;r>>=1
    if r>>53:r>>=1;be+=1
    if not 1<=be<2047:return None
    return fbits(sign|(be<<52)|(r&((1<<52)-1)))
class Decimal:
    def __init__(self,s):
        self.neg=s.startswith('-');s=s.lstrip('+-');p=re.split('[eE]',s,maxsplit=1)
        digits=p[0].replace('_','');dp=digits.find('.');dot=dp>=0
        digits=digits.replace('.','');leading=len(digits)-len(digits.lstrip('0'));digits=digits.lstrip('0')
        self.dp=(dp-leading)if dot else min(len(digits),800)
        self.trunc=any(ch!='0'for ch in digits[800:]);self.digits=digits[:800]
        self.dp+=capped(p[1])if len(p)>1 else 0
    def chunk(self,k):
        if not self.digits:return
        old=len(self.digits);d=int(self.digits)
        v=str(d*(1<<k))if k>0 else str(d*5**(-k))
        self.dp+=len(v)-old+(k if k<0 else 0)
        self.trunc|=any(ch!='0'for ch in v[800:]);self.digits=v[:800].rstrip('0')
        if not self.digits:self.dp=0
    def shift(self,k,width=64):
        maximum=width-4
        while k>maximum:self.chunk(maximum);k-=maximum
        while k<-maximum:self.chunk(-maximum);k+=maximum
        if k:self.chunk(k)
    def integer(self):
        if self.dp<0:return 0
        if self.dp>20:return MASK
        d=self.digits;end=self.dp;v=int((d[:end]+'0'*max(0,end-len(d)))or'0')
        up=end<len(d)and(d[end]>'5'or d[end]=='5'and(end+1!=len(d)or self.trunc or end>0 and int(d[end-1])%2))
        return v+int(up)
    def value(self,width=64):
        sign=int(self.neg)<<63
        if not self.digits or self.dp<-330:return fbits(sign)
        if self.dp>310:return None
        powers=[1,3,6,9,13,16,19,23,26];e=0
        while self.dp>0:
            k=powers[self.dp]if self.dp<len(powers)else 27;self.shift(-k,width);e+=k
        while self.dp<0 or self.dp==0 and self.digits[0]<'5':
            p=-self.dp;k=powers[p]if p<len(powers)else 27;self.shift(k,width);e-=k
        e-=1
        if e<-1022:self.shift(e+1022,width);e=-1022
        if e>=1024:return None
        self.shift(53,width);m=self.integer()
        if m==1<<53:
            m>>=1;e+=1
            if e>=1024:return None
        if m&(1<<52)==0:e=-1023
        return fbits(sign|((e+1023)<<52)|(m&((1<<52)-1)))
def parse(s,width=64):
    white='\t\n\v\f\r \x85\xa0\u1680'+''.join(chr(n)for n in range(0x2000,0x200b))+'\u2028\u2029\u202f\u205f\u3000'
    s=s.strip(white)
    if s.lower()=='nan':return fbits(0x7ff8000000000001),'special'
    if s.lstrip('+-').lower()in['inf','infinity']and s[:2]not in['++','+-','-+','--']:
        return (None if s.startswith('-')else float('inf')),'special'
    n=scan(s)
    if n is None:return None,'syntax'
    m,e,neg,trunc,he=n
    if he:
        e+=52
        while m and m>>54==0:m<<=1;e-=1
        if trunc:m|=1
        while m>>55:m=(m>>1)|(m&1);e+=1
        while m>1 and e<-1024:m=(m>>1)|(m&1);e+=1
        r=m&3;m>>=2;r|=m&1;e+=2
        if r==3:
            m+=1
            if m==1<<53:m>>=1;e+=1
        if m>>52==0:e=-1023
        v=None if e>1023 else fbits((int(neg)<<63)|((e+1023)<<52)|(m&((1<<52)-1)))
        route='hex'
    else:
        v=exact(m,e,neg)if not trunc else None;route='exact'
        if v is None:
            v=eisel(m,e,neg);route='eisel'
            if v is None or trunc and eisel(m+1,e,neg)!=v:v=Decimal(s).value(width);route='decimal800'
    return (None if v is not None and v<0 else v),route
def encoded(v):return None if v is None else f'{bits(v):016x}'
def main():
    observed=json.loads((ROOT/'rust/symbrain-usage/tests/fixtures/retry_decimal_sdk_linux_amd64.json').read_text())
    records=[];routes={}
    for row in observed['records']:
        raw=bytes.fromhex(row['value_hex']);s=raw.decode();v,route=parse(s)
        assert encoded(v)==row['retry_bits'],(row['id'],encoded(v),row['retry_bits'],route)
        v32,route32=parse(s,32);assert encoded(v32)==encoded(v),(row['id'],'projected32')
        routes[route]=routes.get(route,0)+1
        records.append(dict(id=row['id'],bytes=len(raw),input_sha256=__import__('hashlib').sha256(raw).hexdigest(),projected_bits=encoded(v),retained_actual_sdk_bits=row['retry_bits'],route=route,projected32_equal=True))
    rng=random.Random(762768);novel=[]
    for i in range(1000):
        count=rng.choice([1,18,19,20,53,399,799]);d=str(rng.randrange(1,10))+''.join(str(rng.randrange(10))for _ in range(count-1))
        p=rng.randrange(count+1);s=d[:p]+'.'+d[p:]+'e'+str(rng.randrange(-340-count,309-count))
        v,route=parse(s);w=float(s);w=None if math.isinf(w)else w
        assert encoded(v)==encoded(w),(s,encoded(v),encoded(w),route)
        novel.append(dict(id=f'rational-decimal-{i}',text=s,route=route,bits=encoded(v)))
    for i in range(300):
        d=f'{rng.randrange(1,1<<64):016x}'+''.join(rng.choice('0123456789abcdef')for _ in range(rng.randrange(100)))
        p=rng.randrange(len(d)+1);s='0x'+d[:p]+'.'+d[p:]+'p'+str(rng.randrange(-1300,800))
        v,route=parse(s)
        try:w=float.fromhex(s);w=None if math.isinf(w)else w
        except OverflowError:w=None
        assert encoded(v)==encoded(w),(s,encoded(v),encoded(w))
        novel.append(dict(id=f'rational-hex-{i}',text=s,route=route,bits=encoded(v)))
    hostile=['+NaN','-NaN','1e_1','1e1__0','_1','1_','0x__1p0','0x1p_0','0x1','1.2.3','1e2tail','nan\0','1\x1c','1\u200b','1\ufeff','0b1','0o1','1e999999z','0x1p999999z']
    for s in hostile:assert parse(s)[0]is None,s
    # Read pure fixed-input expressions, dropping file emission only. No caller
    # harness, process, SDK or product is imported or executed.
    namespace={'__name__':'independent_inputs'}
    tree=ast.parse((ROOT/'scripts/usage-retry-after-oracle/cases.py').read_text())
    tree.body=[n for n in tree.body if not(isinstance(n,ast.Expr)and isinstance(n.value,ast.Call))]
    exec(compile(tree,'original-fixed-input-generation','exec'),namespace)
    original=[]
    for row in namespace['public']:
        raw=bytes.fromhex(row['value_hex'])
        try:s=raw.decode()
        except UnicodeDecodeError:assert encoded(None)is None;original.append(dict(id=row['id'],raw_hex=row['value_hex'],bits=None,route='invalid_utf8'));continue
        v,route=parse(s)
        if route in ['exact','eisel','decimal800','hex']:
            clean=s.strip().replace('_','')
            try:w=float.fromhex(clean)if route=='hex'else float(clean)
            except OverflowError:w=float('inf')
            if math.isinf(w)or w<0:w=None
            assert encoded(v)==encoded(w),(row['id'],encoded(v),encoded(w))
        original.append(dict(id=row['id'],raw_hex=row['value_hex'],bits=encoded(v),route=route))
    assert len(original)==1600
    out=dict(scope='Python source/SDK projection only; retained SDK-only Linux/amd64 observations. No Rust/Go build, product or cross-target execution.',sdk_table_pairs=696,left_cutoff_pairs=61,actual_sdk_reference_records=records,projected_routes=routes,original_1600_inputs_projected=original,novel_rational_decimal_and_hex=novel,novel_full_syntax_rejections=hostile,projected32_not_native=True)
    Path('/workspace/review-artifacts/usage768-retry-main935-independent-doctor/projection.json').write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps(dict(actual_sdk_retained=81,projected_routes=routes,original_inputs_projected=1600,rational_decimal=1000,rational_hex=300,syntax_rejects=len(hostile),sdk_tables=696,shift_tables=61,not_native=True),indent=2))
if __name__=='__main__':main()
