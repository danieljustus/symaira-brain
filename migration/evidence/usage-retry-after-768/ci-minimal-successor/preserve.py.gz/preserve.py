import gzip
import hashlib
import io
import json
import os
from pathlib import Path
import subprocess
import tarfile

os.umask(0o022)
root = Path('/workspace/symaira-usage768-retry-main935')
out = Path('/workspace/review-proof/usage804-ci-minimal-successor')
head = 'cb2e852ed55b95d5e9f62eecbcf3b3eb7a858cd2'
def git(*args):
    return subprocess.check_output(['git', '-C', str(root), *args])
def sha(data):
    return hashlib.sha256(data).hexdigest()
def native(path):
    stat = path.lstat()
    return {key: getattr(stat, key) for key in (
        'st_mode', 'st_uid', 'st_gid', 'st_dev', 'st_ino', 'st_nlink',
        'st_size', 'st_mtime_ns', 'st_ctime_ns', 'st_blocks')}
assert git('rev-parse', 'HEAD').decode().strip() == head
assert git('status', '--porcelain') == b''
assert os.statvfs(out).f_bavail * os.statvfs(out).f_frsize >= 734003200
rows = []
selected = []
for record in git('ls-tree', '-r', '-z', head).split(b'\0'):
    if not record:
        continue
    info, name = record.split(b'\t', 1)
    mode, kind, oid = info.decode().split()
    name = name.decode()
    body = git('cat-file', 'blob', oid)
    rows.append(dict(path=name, mode=mode, object=oid, bytes=len(body), sha256=sha(body)))
    if (name.startswith('rust/symbrain-usage/')
        or name.startswith('migration/evidence/usage-retry-after-768/decimal-sdk-sources/')
        or name in ('AGENTS.md', 'Makefile', 'Cargo.toml', 'Cargo.lock', '.gitattributes',
                    '.github/workflows/ci.yml', '.github/workflows/release.yml',
                    'scripts/fmt_check_test.go', 'scripts/release_fmt_check_test.go')
        or name.endswith('/path.go') and 'original-abf-review' in name
        or name.endswith('symaira-usage768-f759-root-owner-go.go')):
        selected.append((name, mode, body))
(out / 'original-full-git-tree.json').write_text(json.dumps(rows, indent=2) + '\n')
tar_raw = io.BytesIO()
with tarfile.open(fileobj=tar_raw, mode='w') as tar:
    for name, mode, body in selected:
        entry = tarfile.TarInfo(name)
        entry.size = len(body)
        entry.mode = int(mode, 8) & 0o777
        tar.addfile(entry, io.BytesIO(body))
raw = tar_raw.getvalue()
archive = out / 'original-source.tar.gz'
archive.write_bytes(gzip.compress(raw, mtime=0))
assert gzip.decompress(archive.read_bytes()) == raw
with tarfile.open(fileobj=io.BytesIO(raw)) as tar:
    assert len(tar.getmembers()) == len(selected)
    for name, mode, body in selected:
        assert tar.extractfile(name).read() == body
physical = []
for name, _, body in selected:
    path = root / name
    if path.exists():
        actual = path.read_bytes()
        assert actual == body
        physical.append(dict(path=str(path), native=native(path), sha256=sha(actual)))
logs = {
    '111449314987': '7a54a62bca50b2e72c141b0a6e9cc839ade4f8d8ebc6b5f5220f266b21f253f8',
    '111449315080': 'b48c452c347c22a9e6f45cc7f0b7a76a71c2cd409fb2b103399900ffc95377c6',
    '111449315107': '307fee5e3e7a9e67496521c1453bf08626552db90a9347e80c7a982727918211',
    '111449314855': '44b38d87183ec81c794a4bd57b09d077eb047918ccf64279de89c4fb0b2583d9',
}
raws = []
paths = [Path('/workspace/review-proof/root-ci-1438-job-' + job + '.log') for job in logs]
prior = Path('/workspace/review-artifacts/usage768-retry-main935-independent-doctor')
paths += sorted(path for path in prior.rglob('*') if path.is_file())
for index, path in enumerate(paths):
    before = native(path)
    body = path.read_bytes()
    if path.name.startswith('root-ci-1438-job-'):
        assert sha(body) == logs[path.name.removeprefix('root-ci-1438-job-').removesuffix('.log')]
    compressed = out / f'original-{index:03d}-{path.name}.gz'
    compressed.write_bytes(gzip.compress(body, mtime=0))
    assert gzip.decompress(compressed.read_bytes()) == body
    assert before == native(path)
    raws.append(dict(path=str(path), native=before, bytes=len(body), sha256=sha(body),
                     archive=str(compressed), compressed_sha256=sha(compressed.read_bytes())))
receipt = dict(source=head, source_tree=git('rev-parse', head + '^{tree}').decode().strip(),
               complete_git_rows=len(rows), preserved_source_files=len(selected),
               archive=dict(path=str(archive), sha256=sha(archive.read_bytes()),
                            raw_sha256=sha(raw), raw_bytes=len(raw)),
               physical_source=physical, originals=raws,
               tools_executed=['Python', 'Git source reads'],
               compiler_sdk_product_target_port_execution=0)
(out / 'original-preservation.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps({key: receipt[key] for key in ('source', 'complete_git_rows', 'preserved_source_files')}))
