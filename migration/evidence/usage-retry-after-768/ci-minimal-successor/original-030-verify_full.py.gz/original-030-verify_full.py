"""Full immutable source/archive audit; no SDK/product/target/port invocation."""
import ast,csv,gzip,hashlib,json,os,stat,subprocess
from pathlib import Path
ROOT=Path('/workspace/symaira-usage768-retry-main935')
OUT=Path('/workspace/review-artifacts/usage768-retry-main935-independent-doctor')
HEAD='0c978f6a63059384d92f3b3e8f6db5583e41c80e';SOURCE='6761bd8fdb5f002e646f1113985d675a82d233be'
PARENT='3797d40fa34c57cf1314853438170e607cbd7875';MAIN='9353520a34c5819c7d0a6cd58d3bfaa2b22b045b';BASE='5e232700bb9031fc34d4995465a4037837540abb';FROZEN='dcddcef0df5789123c7c9a7ebe6e01f10e941f2c'
checks=[]
def sha(b):return hashlib.sha256(b).hexdigest()
def fingerprint(p,compressed=False):
 h=hashlib.sha256();n=0
 with (gzip.open(p,'rb') if compressed else open(p,'rb')) as file:
  while chunk:=file.read(1024*1024):h.update(chunk);n+=len(chunk)
 return h.hexdigest(),n
def git(*a):return subprocess.check_output(['git','-C',str(ROOT),*a])
def body(ref,name):return git('show',ref+':'+name)
def tree(ref):
 result={}
 for row in git('ls-tree','-rz',ref).split(b'\0'):
  if row:
   h,n=row.split(b'\t',1);m,k,o=h.decode().split();result[n.decode()]={'mode':m,'kind':k,'oid':o}
 return result
assert git('rev-parse','HEAD').decode().strip()==HEAD and not git('status','--porcelain','-uall')
assert git('show','-s','--format=%P',SOURCE).decode().split()==[PARENT,MAIN]
refs=[BASE,PARENT,MAIN,SOURCE,HEAD,FROZEN];trees={r:tree(r) for r in refs}
report=Path('/workspace/review-artifacts/usage768-retry-main935-source/source-integration-verification.json')
assert fingerprint(report)[0]=='54570d99b63c7dda73dc9ed48bd25ea0bd9da635efc2f92a48ffb0faca7d738a'
plan=json.loads(report.read_bytes())
assert fingerprint(report.parent/'handoff.md')[0]=='da5777cdef517f31df138f8cd4d06e454de59ec3e188424b0fed87f3f37705dc'
assert fingerprint(report.parent/'final-source-ready-receipt.json')[0]=='8cb88beae71ad52bdd6a88cd1703beb26a7f1b1a75412ecc8cec4ab3cd80307fce'
changes=set(git('diff','--name-only',BASE,PARENT).decode().splitlines())|set(git('diff','--name-only',BASE,MAIN).decode().splitlines())
assert changes=={row['path'] for row in plan['changed_parent_full_body_bindings']} and len(changes)==2071
# Stream each distinct Git body, preserving modes and checking every map
# record. Avoid creating another checkout, target, archive or large duplicate.
oids=set()
for row in plan['changed_parent_full_body_bindings']:
 for r,expected in row['bindings'].items():
  actual=trees[r].get(row['path']);assert (actual is None)==(expected is None),row['path']
  if actual:
   assert all(actual[k]==expected[k] for k in ('mode','kind','oid')),row['path'];oids.add(actual['oid'])
reader=subprocess.Popen(['git','-C',str(ROOT),'cat-file','--batch'],stdin=subprocess.PIPE,stdout=subprocess.PIPE)
hashes={}
try:
 for oid in sorted(oids):
  reader.stdin.write((oid+'\n').encode());reader.stdin.flush();header=reader.stdout.readline().split();length=int(header[2]);remaining=length;h=hashlib.sha256()
  while remaining:
   raw=reader.stdout.read(min(1024*1024,remaining));assert raw;remaining-=len(raw);h.update(raw)
  assert reader.stdout.read(1)==b'\n';hashes[oid]=(h.hexdigest(),length)
finally:
 reader.stdin.close();reader.stdout.close();assert reader.wait(timeout=10)==0
for row in plan['changed_parent_full_body_bindings']:
 for expected in row['bindings'].values():
  if expected:assert hashes[expected['oid']]==(expected['sha256'],expected['bytes']),row['path']
exceptions={'.github/workflows/ci.yml','migration/contract-matrix.csv','docs/adr/usage-retry-after-768.md'}
for name in changes-exceptions:
 b,p,m,c=[trees[r].get(name) for r in (BASE,PARENT,MAIN,SOURCE)]
 assert p==b or m==b or p==m,('new two-parent collision',name)
 assert c==(m if p==b else p),('lost parent input',name)
for name in git('diff','--name-only',SOURCE,HEAD).decode().splitlines():assert name.startswith('migration/evidence/usage-retry-after-768/main935-source-only/')
source_bindings={}
for name,row in plan['source_sha256'].items():
 raw=(ROOT/name).read_bytes();wanted=row['sha256'];assert sha(raw)==wanted
 assert raw==body(SOURCE,name)==body(HEAD,name),name
 assert bool((ROOT/name).stat().st_mode&0o111)==(row['git_mode']=='100755'),name
 source_bindings[name]=wanted
assert len(source_bindings)==707
for name,row in plan['all_current_physical_git_bindings'].items():
 p=ROOT/name;assert not p.is_symlink() and p.is_file(),name
 assert fingerprint(p)==(row['sha256'],row['bytes']),name
 assert raw is not None
 assert bool(p.stat().st_mode&0o111)==(row['git_mode']=='100755'),name
for ref,count in [(PARENT,1630),(MAIN,383)]:
 selected={n:v for n,v in trees[ref].items() if n.startswith('migration/evidence/')}
 assert len(selected)==count
 assert all(trees[SOURCE].get(n)==v for n,v in selected.items())
main_ci=body(MAIN,'.github/workflows/ci.yml');ci=body(SOURCE,'.github/workflows/ci.yml');old_ci=body(PARENT,'.github/workflows/ci.yml')
start=main_ci.index(b'      - name: Frozen Go and native Windows wide Skills argv acceptance\n')
end=main_ci.index(b'      - name: Native Go/Rust activity validation acceptance\n',start)
block=main_ci[start:end];assert ci.count(block)==1 and ci.replace(block,b'')==old_ci
matrices={}
for r in (BASE,PARENT,MAIN,SOURCE):
 lines=body(r,'migration/contract-matrix.csv').decode().splitlines();matrices[r]={next(csv.reader([s]))[0]:s for s in lines};assert len(matrices[r])==len(lines)
assert set(matrices[SOURCE])==set(matrices[PARENT])|set(matrices[MAIN])
for key in matrices[SOURCE]:
 b,p,m=[matrices[r].get(key) for r in (BASE,PARENT,MAIN)]
 assert p==b or m==b or p==m,('row collision',key)
 assert matrices[SOURCE][key]==(m if p==b else p),key
for name in plan['unchanged_harness_files']:
 assert trees[SOURCE][name]==trees[PARENT][name],name
assert len(plan['unchanged_harness_files'])==59
for name,row in plan['unchanged_all_go_bindings'].items():
 assert trees[SOURCE][name]==trees[PARENT][name]
 assert sha(body(SOURCE,name))==row['sha256']
assert len(plan['unchanged_all_go_bindings'])==1219
for name,wanted in plan['frozen_usage_git_bindings'].items():
 assert sha(body(FROZEN,name))==wanted and body(FROZEN,name)==body(SOURCE,name)
 assert sha((Path('/workspace/oracles/daemon772-go-source')/name).read_bytes())==wanted
assert len(plan['frozen_usage_git_bindings'])==80
original_root=Path('/workspace/oracles/symaira-usage768-retry3797-before-main935');p=original_root/'receipt.json'
assert fingerprint(p)[0]=='08146eba6fa26f0b4c54b3d4f17706cef293b045284882aff0736675d729d12f'
original=json.loads(p.read_bytes())
for row in original['Root_review_originals']:
 assert fingerprint(row['archive'])[0]==row['archive_sha256']
 assert fingerprint(row['archive'],True)==(row['sha256'],row['bytes'])
 if Path(row['original']).is_file():assert fingerprint(row['original'])==(row['sha256'],row['bytes'])
assert len(original['Root_review_originals'])==19
for row in original['all503_original_source_Git_and_physical_bindings']:
 # Schema is preserved explicitly rather than guessing a full-source field.
 checks.append(row)
assert len(checks)==503
provenance=json.loads(Path('/tmp/symaira-usage768-decimal-independent-provenance.json').read_bytes())
for name,wanted in provenance['source_sha256'].items():assert sha(body(PARENT,name))==wanted
for name,wanted in provenance['sdk_sha256'].items():assert fingerprint(name)[0]==wanted
preserve=ROOT/'migration/evidence/usage-retry-after-768/original-independent-review-5e774'
manifest=json.loads((preserve/'manifest.json').read_bytes())
archive_count=0
for row in manifest['records']:
 p=ROOT/row['tracked'] if row.get('tracked') else Path(row['archive'])
 assert fingerprint(p)[0]==row['archive_sha256']
 assert fingerprint(p,row['storage']!='package-tar-gz-raw-retained')==(row['sha256'],row['bytes'])
 archive_count+=1
assert archive_count==246
binary=json.loads((preserve/'binary-preservation.json').read_bytes())
assert len(binary['records'])==569 and len(binary['unique'])==499
for expected,row in binary['unique'].items():
 p=Path(row['archive']);assert fingerprint(p)[0]==row['compressed_sha256']
 assert fingerprint(p,True)==(expected,row['bytes'])
for row in binary['records']:assert row['sha256'] in binary['unique'] and row['bytes']==binary['unique'][row['sha256']]['bytes']
newarchives=0
for dirname in ['independent-780','decimal-sdk-sources','decimal-sdk-linux-amd64','decimal-sdk-linux-amd64-71','decimal-sdk-linux-amd64-81']:
 d=ROOT/'migration/evidence/usage-retry-after-768'/dirname
 for row in json.loads((d/'retention.json').read_bytes())['entries']:
  p=ROOT/row['archive'] if row['archive'].startswith('migration/') else d/row['archive']
  assert fingerprint(p)[0]==row['archive_sha256'] and fingerprint(p,True)==(row['sha256'],row['bytes'])
  live=Path(row.get('original',row.get('source','/missing')))
  if live.is_file():assert fingerprint(live)==(row['sha256'],row['bytes'])
  newarchives+=1
assert newarchives==40
for group in ['root-review-retention.json','retention.json']:
 p=ROOT/'migration/evidence/usage-retry-after-768/main935-source-only'/group
 if not p.exists():continue
 d=json.loads(p.read_bytes())
 for row in d.get('records',d.get('files',[])):
  p=ROOT/row.get('tracked',row.get('retained',''))
  assert fingerprint(p)[0]==row.get('archive_sha256',row.get('gzip_sha256'))
  assert fingerprint(p,True)==(row['sha256'],row['bytes'])
syntax=[]
for p in sorted((ROOT/'scripts').rglob('*.py')):ast.parse(p.read_bytes());syntax.append(str(p.relative_to(ROOT)))
result={'scope':'FULL independent source/archive/body review; no runtime approval','source':SOURCE,'publication':HEAD,'source_sha256':source_bindings,'current_source_count':707,'changed_both_parent_paths':2071,'Git_unique_bodies_hashed':len(hashes),'unchanged_all_Go':1219,'frozen_Usage_refs':80,'parent_evidence_counts':[1630,383],'harnesses_unchanged':59,'Root_original_review_files':19,'historical_source503':503,'historical_proofs':246,'historical_binary_paths':569,'historical_binary_unique_roundtrips':499,'supplemental40_roundtrips':40,'Python_AST':len(syntax),'nativeSDK_product_runs':0,'targets_ports_compilers':0,'available_bytes':os.statvfs('/workspace').f_bavail*os.statvfs('/workspace').f_frsize}
(OUT/'full-source-archive-verification.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k!='source_sha256'},indent=2))
