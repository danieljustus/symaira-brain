"""Pure corpus/source/formatter checks; never invokes SDK/product/Cargo."""
import ast,gzip,hashlib,importlib.util,json,os,subprocess
from pathlib import Path
ROOT=Path('/workspace/symaira-usage768-retry-main935');OUT=Path('/workspace/review-artifacts/usage768-retry-main935-independent-doctor')
def sha(b):return hashlib.sha256(b).hexdigest()
def git(*a):return subprocess.check_output(['git','-C',str(ROOT),*a])
def corpus(ref):
 code=git('show',ref+':scripts/usage-retry-after-oracle/cases.py');tree=ast.parse(code)
 tree.body=[n for n in tree.body if not (isinstance(n,ast.Expr) and isinstance(n.value,ast.Call) and ((isinstance(n.value.func,ast.Attribute) and n.value.func.attr=='write_text') or (isinstance(n.value.func,ast.Name) and n.value.func.id=='print')))]
 values={'__name__':'pure_owned_corpus'};exec(compile(tree,'reviewed-original-corpus','exec'),values)
 spec=importlib.util.spec_from_file_location('pure_additive',ROOT/'scripts/usage-retry-after-oracle/decimal_cases.py');module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
 base={k:values[k] for k in ['public','wire','values','whitespace']};return base,module.expand(base)
old,oldadd=corpus('3797d40fa34c57cf1314853438170e607cbd7875');current,add=corpus('6761bd8fdb5f002e646f1113985d675a82d233be')
assert (old,oldadd)==(current,add)
assert [len(current['public']),len(current['wire']),len(add['public']),len(add['wire'])]==[1600,1164,1681,1356]
assert add['public'][:1600]==current['public'] and add['wire'][:1164]==current['wire']
plan=json.loads(Path('/workspace/review-artifacts/usage768-retry-main935-source/source-integration-verification.json').read_bytes())
for family,rows in [('original_scalar',current['public']),('original_tls',current['wire']),('additive_scalar',add['public']),('additive_tls',add['wire'])]:
 binding=plan['prepared_case_bindings'][family]
 assert len({r['id'] for r in rows})==len(rows)
 assert binding['canonical_corpus_sha256']==sha(json.dumps(rows,sort_keys=True,separators=(',',':')).encode())
 assert binding['all_id_input_record_bindings']==[dict(id=r['id'],canonical_record_sha256=sha(json.dumps(r,sort_keys=True,separators=(',',':')).encode())) for r in rows]
fixture=json.loads((ROOT/'rust/symbrain-usage/tests/fixtures/retry_decimal_sdk_linux_amd64.json').read_bytes())
assert len(fixture['records'])==81 and (fixture['sdk'],fixture['goos'],fixture['goarch'])==('go1.26.7','linux','amd64')
for suffix in ['', '-71','-81']:
 root=Path('/tmp/symaira-usage768-decimal-sdk-proof'+suffix);receipt=json.loads((root/'receipt.json').read_bytes())
 for name,wanted in receipt.get('files_sha256',{}).items():assert sha((root/name).read_bytes())==wanted
 observed=json.loads((root/'stdout.json').read_bytes());inputs=json.loads((root/'input.json').read_bytes())['public']
 assert len(inputs)==len(observed['records'])==receipt.get('cases',receipt.get('inputs'))
 assert all(r['id']==i['id'] and r['value_hex']==i['value_hex'] for r,i in zip(observed['records'],inputs))
 byid={r['id']:r for r in fixture['records']};assert all(byid[r['id']]==r for r in observed['records'])
assert fixture==json.loads(Path('/tmp/symaira-usage768-decimal-sdk-proof-81/stdout.json').read_bytes())
assert sha((ROOT/'scripts/usage-retry-after-oracle/sdk_decimal_probe.go.txt').read_bytes())==sha(Path('/tmp/symaira-usage768-decimal-sdk-proof/probe.go').read_bytes())
assert sha(Path('/tmp/symaira-usage768-decimal-sdk-proof/probe').read_bytes())=='cd483153469e0616aa9d906de0852a717d5e587026bf3f4221bfa7a41354b644'
checkpoint=json.loads((ROOT/'migration/evidence/usage-retry-after-768/main935-source-only/checkpoint.json').read_bytes())
for row in checkpoint['records']:
 p=ROOT/row['tracked'];packed=p.read_bytes();raw=gzip.decompress(packed)
 assert sha(packed)==row['archive_sha256'] and (sha(raw),len(raw))==(row['sha256'],row['bytes'])
assert len(checkpoint['records'])==23
steps=[]
commands=[('actionlint',['/workspace/toolchains/bin/actionlint',*map(str,sorted((ROOT/'.github/workflows').glob('*.yml')))]),('rustfmt-declared',json.loads(Path('/workspace/review-artifacts/usage768-retry-main935-source/workspace-entry-rustfmt.json').read_bytes())['command']),('diff-check-working-tree',['git','diff','--check'])]
for label,command in commands:
 p=subprocess.run(command,cwd=ROOT,capture_output=True,timeout=60)
 (OUT/(label+'.stdout')).write_bytes(p.stdout);(OUT/(label+'.stderr')).write_bytes(p.stderr)
 steps.append(dict(label=label,command=command,exit=p.returncode));assert p.returncode==0,(label,p.stderr[-4000:])
# Whole integration range preserves two exact main raw logs with trailing
# spaces/blank lines. Keep their full warning output; do not edit evidence
# or describe this range check as clean.
full=subprocess.run(['git','-c','diff.renames=false','diff','--check','3797d40fa34c57cf1314853438170e607cbd7875','HEAD'],cwd=ROOT,capture_output=True)
baseline=subprocess.run(['git','-c','diff.renames=false','diff','--check','3797d40fa34c57cf1314853438170e607cbd7875','9353520a34c5819c7d0a6cd58d3bfaa2b22b045b'],cwd=ROOT,capture_output=True)
assert full.returncode==baseline.returncode==2 and full.stdout==baseline.stdout and full.stderr==baseline.stderr
for label,p in [('full-range-diff-check',full),('main-baseline-diff-check',baseline)]:
 (OUT/(label+'.stdout')).write_bytes(p.stdout);(OUT/(label+'.stderr')).write_bytes(p.stderr)
steps.append(dict(label='whole-range-main-inherited-raw-evidence',exit=full.returncode,exact_baseline_equal=True,no_full_range_clean_claim=True))
bash=sorted((ROOT/'scripts').rglob('*.sh'))
for path in bash:
 p=subprocess.run(['bash','-n',str(path)],capture_output=True,timeout=10)
 assert p.returncode==0,(str(path),p.stderr)
assert len(bash)==20
python=sorted((ROOT/'scripts').rglob('*.py'))
for path in python:ast.parse(path.read_bytes())
assert len(python)==68
assert not git('status','--porcelain','-uall')
out={'scope':'Pure current input/source/formatting; no SDK/product/native execution','case_counts':[1600,1164,1681,1356],'full_parent_input_prefixes_records_order_equal':True,'original_control_count':4,'additive_control_count':7,'current_actual_controls':0,'historical_SDK81_matches_actual_stdout_exact':True,'prior62_71_by_id_equal':True,'historical_actual_probe_sha256':'cd483153469e0616aa9d906de0852a717d5e587026bf3f4221bfa7a41354b644','new23_proof_archive_roundtrips':23,'static_tools':steps,'Bash_files':20,'Python_AST':68,'standalone_Rustfmt_entrypoints':110,'Cargo_fmt_still_pending':True,'GoSDK_executions':0,'targets_ports_product_compilers':0}
(OUT/'corpus-and-tools.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({k:v for k,v in out.items() if k!='static_tools'},indent=2))
