"""Owned source routing controls. The formatter is a fake, never a Go SDK."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

os.umask(0o022)
root = Path(sys.argv[1]).resolve()
out = Path(sys.argv[2]).resolve()
out.mkdir()
assert os.statvfs(out).f_bavail * os.statvfs(out).f_frsize >= 734003200
make = (root / 'Makefile').read_text()
workflow = (root / '.github/workflows/release.yml').read_text()
lines = workflow.splitlines()
start = lines.index('      - name: Format check')
start = lines.index('        run: |', start)
end = lines.index('      - name: Vet', start)
assert all(not line or line.startswith('          ') for line in lines[start+1:end])
release = '\n'.join(line[10:] if line else '' for line in lines[start+1:end]) + '\n'
(out / 'release-exact.sh').write_text(release)
tools = out / 'tools'
tools.mkdir()
fake = '''#!/usr/bin/python3
import json, os, pathlib, sys
with open(os.environ['FORMAT_ARGV_LOG'], 'a') as log:
    log.write(json.dumps(sys.argv[1:]) + '\\n')
paths = sys.argv[2:] if sys.argv[1] == '-l' else sys.argv[3:]
for name in paths:
    data = pathlib.Path(name).read_bytes()
    if data.startswith(b'FAIL'):
        print('owned fake formatter failure: ' + name, file=sys.stderr)
        sys.exit(2)
    if data.startswith(b'DRIFT'):
        if sys.argv[1] == '-l':
            print(name)
        else:
            pathlib.Path(name).write_bytes(b'FORMATTED\\n')
'''
(tools / 'gofmt').write_text(fake)
(tools / 'gofmt').chmod(0o755)
for forbidden in ('go', 'cargo', 'rustc'):
    path = tools / forbidden
    path.write_text('#!/bin/sh\necho forbidden SDK/compiler invocation >&2\nexit 99\n')
    path.chmod(0o755)
results = []
for owner in ('make', 'release'):
    for case in ('pass', 'drift', 'error', 'removed-evidence-exclusion', 'format'):
        if owner == 'release' and case == 'format':
            continue
        directory = out / (owner + '-' + case)
        directory.mkdir()
        (directory / 'go.mod').write_text('module p\n\ngo 1.26\n')
        live = []
        for index in range(205):
            path = directory / 'internal' / 'owned' / f'source {index}.go'
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_bytes(b'FORMATTED\n')
            live.append(path)
        special = directory / 'scripts' / 'literal\nnewline.go'
        special.parent.mkdir()
        special.write_bytes(b'FORMATTED\n')
        live.append(special)
        # A live migration tool must remain formatter-owned.
        tool = directory / 'migration' / 'tool.go'
        tool.parent.mkdir()
        tool.write_bytes(b'FORMATTED\n')
        live.append(tool)
        excluded = []
        for relative in ('browse/nested.go', '.git/archive.go',
                         'migration/evidence/retained-original/original.go'):
            path = directory / relative
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_bytes(b'DRIFT immutable original\n')
            excluded.append(path)
        if case == 'drift':
            special.write_bytes(b'DRIFT live source\n')
        if case == 'error':
            special.write_bytes(b'FAIL live source\n')
        if case == 'format':
            special.write_bytes(b'DRIFT live source\n')
        command_body = make if owner == 'make' else release
        if case == 'removed-evidence-exclusion':
            assert command_body.count(" -not -path './migration/evidence/*'") == 1
            command_body = command_body.replace(" -not -path './migration/evidence/*'", '')
        script = directory / ('Makefile' if owner == 'make' else 'check.sh')
        script.write_text(command_body)
        argv_log = directory / 'formatter-argv.jsonl'
        env = dict(os.environ, PATH=str(tools) + ':' + os.environ['PATH'],
                   TMPDIR=str(directory), RUNNER_TEMP=str(directory),
                   FORMAT_ARGV_LOG=str(argv_log), CI='true')
        command = ['make', '-f', str(script), 'fmt' if case == 'format' else 'fmt-check']
        if owner == 'release':
            command = ['bash', str(script)]
        process = subprocess.run(command, cwd=directory, env=env,
                                 stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=20)
        (directory / 'stdout').write_bytes(process.stdout)
        (directory / 'stderr').write_bytes(process.stderr)
        expected_success = case in ('pass', 'format')
        assert (process.returncode == 0) == expected_success, (owner, case, process)
        calls = [json.loads(line) for line in argv_log.read_text().splitlines()]
        actual_paths = [arg for call in calls for arg in call if arg.startswith('./')]
        if case == 'pass':
            assert set(actual_paths) == {'./' + str(path.relative_to(directory)) for path in live}
            if owner == 'release':
                assert [len(call)-1 for call in calls] == [100, 100, 7]
        if case == 'drift':
            assert b'./scripts/literal\nnewline.go' in process.stdout
        if case == 'error':
            assert b'gofmt failed' in process.stdout + process.stderr
        if case == 'removed-evidence-exclusion':
            assert b'./migration/evidence/retained-original/original.go' in process.stdout
        if case == 'format':
            assert special.read_bytes() == b'FORMATTED\n'
        assert all(path.read_bytes() == b'DRIFT immutable original\n' for path in excluded)
        results.append(dict(owner=owner, case=case, exit=process.returncode,
                            command=command, formatter='owned fake; no Go SDK',
                            calls=len(calls), preserved_originals=len(excluded)))
(out / 'results.json').write_text(json.dumps(results, indent=2) + '\n')
print(json.dumps(dict(source_boundary_controls=len(results), passed=len(results),
                     Go_SDK_or_product_execution=0)))
