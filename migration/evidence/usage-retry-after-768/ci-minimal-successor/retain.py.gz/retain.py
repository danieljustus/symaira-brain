import gzip
import hashlib
import io
import json
import os
from pathlib import Path
import subprocess
import tarfile

os.umask(0o022)
out = Path('/workspace/review-proof/usage804-ci-minimal-successor')
root = Path('/workspace/symaira-usage768-retry-ci-fixes')
dest = root / 'migration/evidence/usage-retry-after-768/ci-minimal-successor'
dest.mkdir(parents=True)
def sha(body):
    return hashlib.sha256(body).hexdigest()
def native(path):
    stat = path.lstat()
    return {key: getattr(stat, key) for key in (
        'st_mode', 'st_uid', 'st_gid', 'st_dev', 'st_ino', 'st_nlink',
        'st_size', 'st_mtime_ns', 'st_ctime_ns', 'st_blocks')}
assert os.statvfs(out).f_bavail * os.statvfs(out).f_frsize >= 734003200
records = []
for source in sorted(out.iterdir()):
    if not source.is_file():
        continue
    before = native(source)
    body = source.read_bytes()
    name = source.name if source.name.endswith('.gz') else source.name + '.gz'
    archive = dest / name
    data = body if source.name.endswith('.gz') else gzip.compress(body, mtime=0)
    archive.write_bytes(data)
    assert archive.read_bytes() == data
    if not source.name.endswith('.gz'):
        assert gzip.decompress(data) == body
    assert native(source) == before
    records.append(dict(source=str(source), source_native=before, bytes=len(body),
                        sha256=sha(body), archive=name, archive_sha256=sha(data),
                        original_gzip=source.name.endswith('.gz')))
# Preserve every owned control input/output, including exact scripts, fake argv
# and all deliberately unchanged sources. No SDK or production was executed.
fixture = out / 'scope-controls-attempt1'
raw_tar = io.BytesIO()
fixture_records = []
with tarfile.open(fileobj=raw_tar, mode='w') as tar:
    for path in sorted(fixture.rglob('*')):
        if not path.is_file():
            continue
        before = native(path)
        body = path.read_bytes()
        name = str(path.relative_to(fixture))
        entry = tarfile.TarInfo(name)
        entry.mode = before['st_mode'] & 0o777
        entry.uid = before['st_uid']
        entry.gid = before['st_gid']
        entry.mtime = before['st_mtime_ns'] // 1_000_000_000
        entry.size = len(body)
        tar.addfile(entry, io.BytesIO(body))
        assert native(path) == before
        fixture_records.append(dict(path=str(path), name=name, native=before,
                                    bytes=len(body), sha256=sha(body)))
raw = raw_tar.getvalue()
data = gzip.compress(raw, mtime=0)
(dest / 'owned-fake-formatter-controls.tar.gz').write_bytes(data)
assert gzip.decompress(data) == raw
with tarfile.open(fileobj=io.BytesIO(raw)) as tar:
    assert len(tar.getmembers()) == len(fixture_records)
    for record in fixture_records:
        assert sha(tar.extractfile(record['name']).read()) == record['sha256']
(dest / 'owned-controls-native-manifest.json.gz').write_bytes(
    gzip.compress((json.dumps(fixture_records, indent=2) + '\n').encode(), mtime=0))
extra = []
for name in (
    'migration/evidence/skills-preflight-793/windows-wide-argv/sdk-reference/src/os/exec_windows.go',
    'migration/evidence/skills-preflight-793/windows-wide-argv/sdk-reference/src/syscall/wtf8_windows.go'):
    body = subprocess.check_output(['git', '-C', str(root), 'show', 'cb2e852:' + name])
    archive_name = 'original-sdk-' + Path(name).name + '.gz'
    compressed = gzip.compress(body, mtime=0)
    (dest / archive_name).write_bytes(compressed)
    assert gzip.decompress(compressed) == body
    extra.append(dict(path=name, source='cb2e852ed55b95d5e9f62eecbcf3b3eb7a858cd2',
                      bytes=len(body), sha256=sha(body), archive=archive_name,
                      archive_sha256=sha(compressed)))
receipt = dict(original_source='cb2e852ed55b95d5e9f62eecbcf3b3eb7a858cd2',
               records=records, owned_controls=dict(files=len(fixture_records),
               archive='owned-fake-formatter-controls.tar.gz', compressed_sha256=sha(data),
               raw_bytes=len(raw), raw_sha256=sha(raw)), additional_original_SDK=extra,
               actual_owned_fake_formatter_cases=9, actual_SDK_compiler_product_target_ports=0)
(dest / 'retention.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps(dict(preserved_proof_files=len(records), owned_control_files=len(fixture_records),
                     tracked_evidence_bytes=sum(p.stat().st_size for p in dest.iterdir()))))
