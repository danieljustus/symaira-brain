import fnmatch
import hashlib
import json
import os
from pathlib import Path
import subprocess

root = Path('/workspace/symaira-usage768-retry-ci-fixes')
out = Path('/workspace/review-proof/usage804-ci-minimal-successor')
base = 'cb2e852ed55b95d5e9f62eecbcf3b3eb7a858cd2'
def git(*args):
    return subprocess.check_output(['git', '-C', str(root), *args])
def old(name):
    return git('show', base + ':' + name)
allowed = {
    'rust/symbrain-usage/src/go_decimal.rs':
        b'    #[allow(clippy::manual_is_multiple_of)] // Preserve Go SDK shouldRoundUp\'s parity expression.\n',
    'rust/symbrain-usage/src/go_decimal_fast.rs':
        b'#[allow(clippy::verbose_bit_mask)] // Preserve Go SDK\'s low-nine-bit fallback test.\n',
}
checks = []
for name, attribute in allowed.items():
    body = (root / name).read_bytes()
    assert body.count(attribute) == 1
    assert body.replace(attribute, b'') == old(name)
    checks.append(dict(path=name, exact_algorithm_bytes_unchanged=True))
name = 'rust/symbrain-usage/src/go_float.rs'
body = (root / name).read_bytes()
assert body.count(b'#[derive(Clone, Copy)]\n') == 1
projected = body.replace(b'#[derive(Clone, Copy)]\n', b'').replace(b'`ParseFloat`', b'ParseFloat')
assert projected == old(name)
assert b'''pub(super) struct Number {
    pub(super) mantissa: u64,
    pub(super) exponent: i64,
    pub(super) negative: bool,
    pub(super) truncated: bool,
    hex: bool,
}''' in body
checks.append(dict(path=name, exact_algorithm_bytes_unchanged=True, scalar_Copy_fields=5))
original_rows = json.loads((out / 'original-full-git-tree.json').read_text())
changed = git('diff', '--name-only', base).decode().splitlines()
expected = set(allowed) | {name, 'Makefile', '.github/workflows/release.yml',
                         'scripts/fmt_check_test.go', 'scripts/release_fmt_check_test.go'}
assert set(changed) == expected, changed
protected = 0
for row in original_rows:
    if row['path'] not in expected:
        body = git('show', 'HEAD:' + row['path'])
        assert hashlib.sha256(body).hexdigest() == row['sha256']
        path = root / row['path']
        if path.is_file():
            assert hashlib.sha256(path.read_bytes()).hexdigest() == row['sha256'], row['path']
        protected += 1
go_paths = ['./' + row['path'] for row in original_rows if row['path'].endswith('.go')]
selection = {}
for owner, exclusions in (
    ('Makefile', ('./browse/*', './.git/*', './.worktrees/*')),
    ('release', ('./browse/*', './.git/*'))):
    before = {path for path in go_paths if not any(fnmatch.fnmatchcase(path, rule) for rule in exclusions)}
    after = {path for path in before if not fnmatch.fnmatchcase(path, './migration/evidence/*')}
    removed = sorted(before - after)
    assert removed == [
        './migration/evidence/usage-argv-768/original-abf-review/proof/symaira-usage768-abf-root-doctor-path/path.go',
        './migration/evidence/usage-copilot-kimi-768/original-root-review-7e0b/symaira-usage768-f759-root-owner-go.go']
    selection[owner] = dict(before=len(before), after=len(after), removed=removed)
results = dict(base=base, algorithm_projections=checks, protected_files=protected,
               changed_existing_files=changed, formatter_inventory=selection,
               SDK_Rust_Go_runtime_execution=0)
(out / 'source-checks.json').write_text(json.dumps(results, indent=2) + '\n')
commands = [
    ['/home/agent/.cargo/bin/rustfmt', '--edition', '2024', '--check'] +
    [str(path) for path in sorted((root / 'rust/symbrain-usage').rglob('*.rs'))],
    ['/workspace/toolchains/bin/actionlint'] +
    [str(path) for path in sorted((root / '.github/workflows').glob('*.yml'))],
    ['bash', '-n', str(out / 'scope-controls-attempt1/release-exact.sh')],
    ['git', '-C', str(root), 'diff', '--check'],
]
tool_results = []
for index, command in enumerate(commands):
    result = subprocess.run(command, cwd=root, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    (out / f'static-{index}.stdout').write_bytes(result.stdout)
    (out / f'static-{index}.stderr').write_bytes(result.stderr)
    tool_results.append(dict(command=command, exit=result.returncode))
(out / 'static-tools.json').write_text(json.dumps(tool_results, indent=2) + '\n')
assert all(row['exit'] == 0 for row in tool_results), tool_results
print(json.dumps(dict(protected=protected, exact_algorithm_projections=3,
                      static_tools=len(tool_results), selected_originals_excluded=2)))
