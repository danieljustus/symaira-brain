import gzip
import hashlib
import json
import os
from pathlib import Path
import subprocess

out = Path('/workspace/review-proof/usage804-ci-minimal-successor')
root = Path('/workspace/symaira-usage768-retry-ci-fixes')
original = Path('/workspace/symaira-usage768-retry-main935')
dest = root / 'migration/evidence/usage-retry-after-768/ci-minimal-successor'
source = 'c18c59918a2724b4c871260a0dc1b5389a9720d8'
def sha(body):
    return hashlib.sha256(body).hexdigest()
def git(*args):
    return subprocess.check_output(['git', '-C', str(root), *args])
def native(path):
    stat = path.lstat()
    return {key: getattr(stat, key) for key in (
        'st_mode', 'st_uid', 'st_gid', 'st_dev', 'st_ino', 'st_nlink',
        'st_size', 'st_mtime_ns', 'st_ctime_ns', 'st_blocks')}
assert git('rev-parse', 'HEAD').decode().strip() == source
assert git('status', '--porcelain') == b''
assert subprocess.check_output(['git', '-C', str(original), 'status', '--porcelain']) == b''
assert subprocess.check_output(['git', '-C', str(original), 'rev-parse', 'HEAD']).decode().strip() == 'cb2e852ed55b95d5e9f62eecbcf3b3eb7a858cd2'
preserved = json.loads((out / 'original-preservation.json').read_text())
for row in preserved['physical_source'] + preserved['originals']:
    path = Path(row['path'])
    assert sha(path.read_bytes()) == row['sha256']
    assert native(path) == row['native'], path
    if 'archive' in row:
        archive = Path(row['archive'])
        assert sha(archive.read_bytes()) == row['compressed_sha256']
        assert sha(gzip.decompress(archive.read_bytes())) == row['sha256']
current = []
for record in git('ls-tree', '-r', '-z', source).split(b'\0'):
    if not record:
        continue
    header, name = record.split(b'\t', 1)
    mode, _, oid = header.decode().split()
    name = name.decode()
    body = git('cat-file', 'blob', oid)
    row = dict(path=name, mode=mode, object=oid, bytes=len(body), sha256=sha(body))
    if (root / name).is_file():
        assert (root / name).read_bytes() == body
        row['native'] = native(root / name)
    current.append(row)
raw_map = (json.dumps(current, indent=2) + '\n').encode()
(dest / 'source-c18-full-map.json.gz').write_bytes(gzip.compress(raw_map, mtime=0))
completion = []
selected = [out / 'retention.stdout', out / 'retention.stderr', out / 'check_source_final.py',
            out / 'final-source-check.stdout', out / 'final-source-check.stderr',
            out / 'final-source-checks.json', out / 'final-static-tools.json',
            out / 'finalize.py']
selected += sorted(out.glob('final-static-*'))
for path in selected:
    body = path.read_bytes()
    name = 'completion-' + path.name + '.gz'
    compressed = gzip.compress(body, mtime=0)
    (dest / name).write_bytes(compressed)
    assert gzip.decompress(compressed) == body
    completion.append(dict(path=str(path), native=native(path), bytes=len(body),
                           sha256=sha(body), archive=name, compressed_sha256=sha(compressed)))
tools = json.loads((out / 'final-static-tools.json').read_text())
assert len(tools) == 4 and all(row['exit'] == 0 for row in tools)
controls = json.loads((out / 'scope-controls-attempt1/results.json').read_text())
assert len(controls) == 9
before_rows = {row['path']: row for row in json.loads((out / 'original-full-git-tree.json').read_text())}
for row in current:
    if row['path'] in before_rows:
        assert row['mode'] == before_rows[row['path']]['mode']
assert not (root / 'target').exists()
free = os.statvfs(root).f_bavail * os.statvfs(root).f_frsize
assert free >= 734003200
receipt = dict(status='AUTHOR_SOURCE_ONLY_CHECKPOINT_REQUIRES_INDEPENDENT_REVIEW',
               original_source=preserved['source'], tested_source=source,
               tested_tree=git('rev-parse', source + '^{tree}').decode().strip(),
               full_source_map=dict(path='source-c18-full-map.json.gz', rows=len(current),
                                    raw_sha256=sha(raw_map)),
               original_full_map_rows=4652, original_selected_source_files=114,
               original_prior_review_files=47, original_actual_CI_logs=4,
               originals_fresh_byte_and_native_verified=True,
               completion=completion, tools=tools,
               current_actual_counts=dict(rustfmt_files=len(tools[0]['command'])-4,
                 actionlint_workflows=len(tools[1]['command'])-1,
                 extracted_Bash_syntax=1, Git_diff_whitespace=1,
                 exact_numeric_algorithm_byte_projections=3,
                 owned_fake_formatter_controls=9, rejected_scope_mutants=2,
                 compiled_Rust_tests=0, actual_Go_formatter_tests=0, actual_Clippy=0,
                 SDK_compiler_product_Cargo_target_ports=0),
               actual_command_order='Commit c18, then check_source_final.py; source stayed clean during all four final checks.',
               pending=['Different-author full source review', 'Actual strict Clippy and Rust gates',
                        'Two real Go formatter regression tests and make lint',
                        'Original six Usage process gates', 'Retry1600/1164 and additive1681/1356 plus seven actual controls',
                        'Exact-source native Linux/macOS/Windows CI'],
               original_worktree_clean=True, new_target_absent=True,
               budget=dict(available_bytes=free, floor_bytes=734003200),
               publication='No push, PR, merge, issue closure or runtime approval')
(dest / 'source-only-checkpoint.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps(dict(source=source, full_source_files=len(current),
                     original_inputs_reverified=51, completion_files=len(completion),
                     available_bytes=free)))
