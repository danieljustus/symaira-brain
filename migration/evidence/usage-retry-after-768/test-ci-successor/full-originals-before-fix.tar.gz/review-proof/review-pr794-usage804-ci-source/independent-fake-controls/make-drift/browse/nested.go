DRIFT immutable original
