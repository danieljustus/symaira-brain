import gzip,hashlib,json,subprocess
from pathlib import Path
R=Path('/workspace/symaira-usage768-retry-ci-fixes');O=Path('/workspace/review-proof/review-pr794-usage804-ci-source');P=R/'migration/evidence/usage-retry-after-768';nbytes=0

def fingerprint(p,raw=False):
 global nbytes
 h=hashlib.sha256();n=0
 with (gzip.open(p,'rb') if raw else open(p,'rb'))as f:
  while b:=f.read(1024*1024):h.update(b);n+=len(b)
 nbytes+=n;return h.hexdigest(),n
parent=Path('/workspace/oracles/symaira-usage768-retry3797-before-main935');data=json.loads((parent/'receipt.json').read_bytes());assert fingerprint(parent/'receipt.json')[0]=='08146eba6fa26f0b4c54b3d4f17706cef293b045284882aff0736675d729d12f'
for row in data['Root_review_originals']:
 assert fingerprint(row['archive'])[0]==row['archive_sha256'] and fingerprint(row['archive'],True)==(row['sha256'],row['bytes'])
for row in data['all503_original_source_Git_and_physical_bindings']:
 b=subprocess.check_output(['git','-C',str(R),'show','3797d40fa34c57cf1314853438170e607cbd7875:'+row['path']]);assert hashlib.sha256(b).hexdigest()==row['sha256'] and len(b)==row['bytes']
d=P/'original-independent-review-5e774';records=json.loads((d/'manifest.json').read_bytes())['records'];assert len(records)==246
for row in records:
 p=R/row['tracked']if row.get('tracked')else Path(row['archive']);assert fingerprint(p)[0]==row['archive_sha256'] and fingerprint(p,row['storage']!='package-tar-gz-raw-retained')==(row['sha256'],row['bytes'])
binary=json.loads((d/'binary-preservation.json').read_bytes());assert len(binary['records'])==569 and len(binary['unique'])==499
for expected,row in binary['unique'].items():assert fingerprint(row['archive'])[0]==row['compressed_sha256'] and fingerprint(row['archive'],True)==(expected,row['bytes'])
for row in binary['records']:assert row['sha256']in binary['unique']and row['bytes']==binary['unique'][row['sha256']]['bytes']
count=0
for dirname in ['independent-780','decimal-sdk-sources','decimal-sdk-linux-amd64','decimal-sdk-linux-amd64-71','decimal-sdk-linux-amd64-81']:
 d=P/dirname
 for row in json.loads((d/'retention.json').read_bytes())['entries']:
  p=R/row['archive']if row['archive'].startswith('migration/')else d/row['archive'];assert fingerprint(p)[0]==row['archive_sha256'] and fingerprint(p,True)==(row['sha256'],row['bytes']);count+=1
assert count==40
result=dict(original_Root_records=19,historical_original_Git_source=503,original_failure_proofs=246,historical_ELF_paths=569,historical_unique_ELF_full_roundtrips=499,supplemental_SDK_reference_proofs=40,read_bytes=nbytes,product_execution=0)
(O/'historical-verification.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
