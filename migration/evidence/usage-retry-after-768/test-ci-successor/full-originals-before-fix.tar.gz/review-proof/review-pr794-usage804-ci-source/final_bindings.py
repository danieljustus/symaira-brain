import gzip,hashlib,json,os,re,subprocess,sys
from pathlib import Path
R=Path('/workspace/symaira-usage768-retry-ci-fixes');O=Path('/workspace/review-proof/review-pr794-usage804-ci-source');D=Path('/workspace/review-proof/usage804-ci-doc-clarification');A=Path('/workspace/review-proof/usage804-ci-minimal-successor');H='6572c11e34b0540b7cbc5b4ee6fedb9753ac23ed';P='260cb826689531f44754bf877d2a4801b2679245'
sha=lambda b:hashlib.sha256(b).hexdigest()
def git(*a):return subprocess.check_output(['git','-C',str(R),*a])
def rowcheck(r,physical=True):
 p=Path(r['path']);b=p.read_bytes();assert sha(b)==r['sha256'] and len(b)==r['bytes'],p
 if 'native'in r:
  s=p.lstat();assert all(getattr(s,k)==v for k,v in r['native'].items()),p
assert git('rev-parse','HEAD').decode().strip()==H and git('status','--porcelain')==b''
assert git('diff','--name-only',P,H).decode().splitlines()==['docs/adr/usage804-sdk-lints-and-evidence-format.md']
for n,s in [('handoff.md','bc7d9780e648ed7f85701ed68e302bb93a17aae35242a5d9559028d0bbbc9b18'),('handoff.json','c365bc8261b01c1535f69160758163921d20eb7aebb6c5cad9f2c1e1bff6caad')]:assert sha((D/n).read_bytes())==s
h=json.loads((D/'handoff.json').read_bytes());old=json.loads((A/'handoff.json').read_bytes())
for r in h['proof_files']+old['own_proofs']:rowcheck(r)
rows=json.loads((D/'final-source-native-body-map.json').read_bytes());assert len(rows)==105
for r in rows:
 q=dict(r,path=str(R/r['path']));rowcheck(q);assert (R/r['path']).read_bytes()==git('show',H+':'+r['path'])
current=json.loads((O/('full-source-map-'+H[:12]+'.json')).read_bytes());physical=[]
for r in current:
 p=R/r['path']
 if p.is_file():
  b=p.read_bytes();assert sha(b)==r['sha256'],p;s=p.lstat();physical.append(dict(path=r['path'],sha256=r['sha256'],native={k:getattr(s,k)for k in ['st_mode','st_uid','st_gid','st_size','st_mtime_ns','st_ctime_ns','st_dev','st_ino','st_nlink','st_blocks']}))
(O/'final-full-physical-source-map.json').write_text(json.dumps(physical,indent=2)+'\n')
# Exact rational projection of all pow10 entries; a source/table check, not Rust evaluation.
table=[]
for name,start in [('powers_negative.rs',-348),('powers_positive.rs',0)]:
 body=(R/'rust/symbrain-usage/src/go_decimal_fast'/name).read_text();pairs=re.findall(r'\((0x[0-9a-f_]+), (0x[0-9a-f_]+)\)',body);assert len(pairs)==348
 for i,(high,low)in enumerate(pairs):
  e=start+i;n,d=(10**e,1)if e>=0 else(1,10**-e);q=n.bit_length()-d.bit_length()
  if q>=0:
   if n<d<<q:q-=1
  elif n<<-q<d:q-=1
  shift=127-q;expected=(n<<shift)//d if shift>=0 else n//(d<<-shift)
  actual=(int(high.replace('_',''),16)<<64)|int(low.replace('_',''),16);assert expected==actual,(e,hex(expected),hex(actual));table.append(e)
shift=(R/'rust/symbrain-usage/src/go_decimal_shift.rs').read_text();cutoffs=re.findall(r'\((\d+), b"(\d*)"\)',shift);assert len(cutoffs)==61
for k,(length,cutoff)in enumerate(cutoffs):assert (int(length),cutoff)==((0,'')if k==0 else(len(str(2**k)),str(5**k))),k
# Pure formatter input census; no formatter SDK.
selected=[];excluded=[]
for r in current:
 n=r['path']
 if not n.endswith('.go'):continue
 if any(n.startswith(prefix)for prefix in ['browse/','.git/','.worktrees/']):continue
 (excluded if n.startswith('migration/evidence/')else selected).append(n)
assert len(selected)==802 and len(excluded)==4,(len(selected),excluded)
# Direct formatter/lint executables do not allocate a Cargo/compiler graph.
files=sorted(str(p)for p in (R/'rust/symbrain-usage').rglob('*.rs'));workflows=sorted(str(p)for p in (R/'.github/workflows').glob('*.yml'));script=O/'independent-fake-controls/release-exact.sh'
commands=[['/home/agent/.cargo/bin/rustfmt','--edition','2024','--check',*files],['/workspace/toolchains/bin/actionlint',*workflows],['bash','-n',str(script)],['git','-C',str(R),'diff','--check',P,H]]
results=[]
for i,cmd in enumerate(commands):
 p=subprocess.run(cmd,cwd=R,capture_output=True,timeout=60);(O/f'pure-{i}.stdout').write_bytes(p.stdout);(O/f'pure-{i}.stderr').write_bytes(p.stderr);results.append(dict(command=cmd,exit=p.returncode,stdout_sha256=sha(p.stdout),stderr_sha256=sha(p.stderr)));assert p.returncode==0,(i,p.stderr)
(O/'pure-tools.json').write_text(json.dumps(results,indent=2)+'\n')
result=dict(head=H,old_handoff_proofs=len(old['own_proofs']),doc_handoff_proofs=len(h['proof_files']),changed_native_rows=105,full_physical_source_rows=len(physical),pow10_entries=696,shift_cutoffs=61,formatter_owned_go=802,excluded_exact_go=excluded,rustfmt_files=len(files),actionlint_workflows=len(workflows),Bash_syntax=1,numeric_runtime_claim=False,source_tree=git('rev-parse',H+'^{tree}').decode().strip(),available_bytes=os.statvfs(O).f_bavail*os.statvfs(O).f_frsize)
assert git('status','--porcelain')==b'';(O/'final-bindings.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
