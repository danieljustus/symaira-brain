import gzip
import hashlib
import json
import os
from pathlib import Path

out=Path('/workspace/review-proof/usage804-test-lints-successor')
root=Path('/workspace/symaira-usage768-retry-test-ci-fixes')
dest=root/'migration/evidence/usage-retry-after-768/test-ci-successor'
dest.mkdir(parents=True)
def sha(body):
    return hashlib.sha256(body).hexdigest()
def native(path):
    stat=path.lstat()
    return {key:getattr(stat,key) for key in ('st_mode','st_uid','st_gid','st_size',
        'st_mtime_ns','st_ctime_ns','st_dev','st_ino','st_nlink','st_blocks')}
assert os.statvfs(out).f_bavail*os.statvfs(out).f_frsize>=734003200
rows=[]
for path in sorted(out.iterdir()):
    if not path.is_file():
        continue
    before=native(path)
    body=path.read_bytes()
    name=path.name if path.suffix=='.gz' else path.name+'.gz'
    compressed=body if path.suffix=='.gz' else gzip.compress(body,mtime=0)
    (dest/name).write_bytes(compressed)
    assert (dest/name).read_bytes()==compressed
    if path.suffix!='.gz':
        assert gzip.decompress(compressed)==body
    assert native(path)==before
    rows.append(dict(path=str(path),native=before,bytes=len(body),sha256=sha(body),
                     archive=name,archive_sha256=sha(compressed),already_gzip=path.suffix=='.gz'))
(dest/'retention.json').write_text(json.dumps(dict(source_parent='6572c11e34b0540b7cbc5b4ee6fedb9753ac23ed',
    original_full_raw_inputs=4093,original_reviewer_bindings=2038,original_Git_rows=4750,
    recorded_native2038_all_current_exact=True,preserved=rows,
    source_projections=3,negative_source_controls=4,byte_partition_projections=337,
    rustfmt_files=62,actionlint_workflows=14,SDK_compiler_product_Target_cache_ports=0),indent=2)+'\n')
print(json.dumps(dict(retained_proofs=len(rows),bytes=sum(p.stat().st_size for p in dest.iterdir()))))
