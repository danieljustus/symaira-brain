import gzip
import hashlib
import io
import json
import os
from pathlib import Path
import subprocess
import tarfile

os.umask(0o022)
root=Path('/workspace/symaira-usage768-retry-ci-fixes')
out=Path('/workspace/review-proof/usage804-test-lints-successor')
head='6572c11e34b0540b7cbc5b4ee6fedb9753ac23ed'
review=Path('/workspace/review-proof/review-pr794-usage804-ci-source')
def sha(body):
    return hashlib.sha256(body).hexdigest()
def native(path):
    stat=path.lstat()
    return {key:getattr(stat,key) for key in ('st_mode','st_uid','st_gid','st_size',
        'st_mtime_ns','st_ctime_ns','st_dev','st_ino','st_nlink','st_blocks')}
def git(*args):
    return subprocess.check_output(['git','-C',str(root),*args])
assert git('rev-parse','HEAD').decode().strip()==head
assert git('status','--porcelain')==b''
assert os.statvfs(out).f_bavail*os.statvfs(out).f_frsize >= 734003200
assert sha((review/'independent-review.md').read_bytes())=='c101a0dc6c19831593d2051a3ede773ca45256ad136233d422edff8ab4a95e83'
assert sha((review/'review-receipt.json').read_bytes())=='eb62208ffe1f408b8f866e1ac38bbe791c6d884817c93abc1de53508d2700aa8'
receipt=json.loads((review/'review-receipt.json').read_text())
assert len(receipt['owned_outputs'])==2038
for row in receipt['owned_outputs']:
    assert sha(Path(row['path']).read_bytes())==row['sha256']
logs={
 'root-ci-1535-job-111466802888.log':'2b49bac5fc456498ed9ea8b5edfd46a7163a51d91a3fab8e30ed4bbcb571a999',
 'root-ci-1535-job-111466802991.log':'a94e6546161e31662650655db9dbbdfc90860d94c74a60fe98ec50d7f5209582',
}
originals=[]
for name, expected in logs.items():
    path=Path('/workspace/review-proof')/name
    assert sha(path.read_bytes())==expected
    originals.append(path)
    originals.append(path.with_suffix('.content.json'))
groups=[review,Path('/workspace/review-proof/usage804-ci-minimal-successor'),
        Path('/workspace/review-proof/usage804-ci-doc-clarification')]
for group in groups:
    originals += sorted(path for path in group.rglob('*') if path.is_file())
raw=io.BytesIO()
rows=[]
with tarfile.open(fileobj=raw,mode='w') as tar:
    for path in originals:
        before=native(path)
        body=path.read_bytes()
        name=str(path.relative_to('/workspace'))
        entry=tarfile.TarInfo(name)
        entry.size=len(body)
        entry.mode=before['st_mode']&0o777
        entry.uid=before['st_uid']
        entry.gid=before['st_gid']
        entry.mtime=before['st_mtime_ns']//1_000_000_000
        tar.addfile(entry,io.BytesIO(body))
        assert native(path)==before
        rows.append(dict(path=str(path),member=name,native=before,bytes=len(body),sha256=sha(body)))
tar_body=raw.getvalue()
compressed=gzip.compress(tar_body,mtime=0)
(out/'full-originals-before-fix.tar.gz').write_bytes(compressed)
assert gzip.decompress(compressed)==tar_body
with tarfile.open(fileobj=io.BytesIO(tar_body)) as tar:
    assert len(tar.getmembers())==len(rows)
    for row in rows:
        assert sha(tar.extractfile(row['member']).read())==row['sha256']
(out/'originals-native-full-map.json').write_text(json.dumps(rows,indent=2)+'\n')
source=[]
for record in git('ls-tree','-r','-z',head).split(b'\0'):
    if not record:
        continue
    header,name=record.split(b'\t',1)
    mode,_,oid=header.decode().split()
    name=name.decode()
    body=git('cat-file','blob',oid)
    source.append(dict(path=name,mode=mode,object=oid,bytes=len(body),sha256=sha(body)))
(out/'original657-full-source-map.json').write_text(json.dumps(source,indent=2)+'\n')
for name in ('go_decimal_tests.rs','retry_after_oracle_tests.rs','status_oracle_tests.rs'):
    body=(root/'rust/symbrain-usage/src'/name).read_bytes()
    (out/('original657-'+name+'.gz')).write_bytes(gzip.compress(body,mtime=0))
(out/'preservation.json').write_text(json.dumps(dict(original=head,
    full_original_raw_inputs=len(rows),reviewer2038_bindings_verified=True,
    full_Git_source_rows=len(source),raw_tar_bytes=len(tar_body),raw_tar_sha256=sha(tar_body),
    compressed_tar_bytes=len(compressed),compressed_tar_sha256=sha(compressed),
    native_manifest_sha256=sha((out/'originals-native-full-map.json').read_bytes()),
    source_manifest_sha256=sha((out/'original657-full-source-map.json').read_bytes()),
    SDK_compiler_Target_cache_ports_product=0),indent=2)+'\n')
print(json.dumps(dict(originals=len(rows),review_bindings=2038,source_rows=len(source),
                     archive_bytes=len(compressed))))
