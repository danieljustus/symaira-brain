import hashlib
import json
from pathlib import Path
import subprocess

root=Path('/workspace/symaira-usage768-retry-test-ci-fixes')
out=Path('/workspace/review-proof/usage804-test-lints-successor')
base='6572c11e34b0540b7cbc5b4ee6fedb9753ac23ed'
def git(*args):
    return subprocess.check_output(['git','-C',str(root),*args])
def sha(body):
    return hashlib.sha256(body).hexdigest()
def old(name):
    return git('show',base+':'+name)
names=['rust/symbrain-usage/src/'+name for name in (
    'go_decimal_tests.rs','retry_after_oracle_tests.rs','status_oracle_tests.rs')]
def decoder_projection(body):
    return body.replace(b'.as_chunks::<2>()\n            .0\n            .iter()',b'.chunks_exact(2)').replace(
        b'.as_chunks::<2>()\n        .0\n        .iter()',b'.chunks_exact(2)')
for name in names[:2]:
    body=(root/name).read_bytes()
    assert body.count(b'.as_chunks::<2>()')==1
    assert decoder_projection(body)==old(name)
status=(root/names[2]).read_bytes()
original=old(names[2])
marker=b'        // The same disposable constructor homes/metadata from actual frozen Go.\n'
begin=original.index(marker)
end=original.index(b'        let home = std::path::Path::new',begin)
block=original[begin:end]
helper=b'\nfn prepare_environment(row: &Value) {\n'+b''.join(
    line[4:] if line.startswith(b'    ') else line for line in block.splitlines(keepends=True))+b'}\n'
assert status.endswith(helper)
without=status[:-len(helper)]
call=b'        prepare_environment(row);\n'
assert without.count(call)==1
assert without.replace(call,block)==original
assert without.index(call)<without.index(b'        let before = file_state(home);')
assert without.index(call)<without.index(b'        let provider = match')
# Negative source controls guard against accidental removal/reordering while
# changing test structure. They inspect source bytes, never compiled behavior.
mutants=[
    (names[0],(root/names[0]).read_bytes().replace(b'<2>',b'<3>')),
    (names[1],(root/names[1]).read_bytes().replace(b'assert_eq!(value.len() % 2, 0, "complete byte-oriented hex input");',b'')),
]
for name,mutant in mutants:
    assert decoder_projection(mutant)!=old(name)
assert without.replace(call,b'').replace(b'        let before = file_state(home);',
    b'        let before = file_state(home);\n'+call).replace(call,block)!=original
assert status.replace(b'        "CODEX_HOME",\n',b'').endswith(helper) is False
changed=git('diff','--name-only',base).decode().splitlines()
assert set(changed)==set(names),changed
rows=json.loads((out/'original657-full-source-map.json').read_text())
protected=0
for row in rows:
    if row['path'] not in names:
        assert sha(git('show','HEAD:'+row['path']))==row['sha256']
        physical=root/row['path']
        if physical.is_file():
            assert sha(physical.read_bytes())==row['sha256']
        protected+=1
fixture=json.loads((root/'rust/symbrain-usage/tests/fixtures/retry_decimal_sdk_linux_amd64.json').read_text())
assert len(fixture['records'])==81
partitions=0
inputs=[bytes(range(length)) for length in range(256)]
inputs += [bytes.fromhex(row['value_hex']) for row in fixture['records']]
for value in inputs:
    # Identical complete two-byte prefix; both APIs expose/ignore the same tail.
    chunks=[value[index:index+2] for index in range(0,len(value)-1,2)]
    complete=len(value)//2
    arrays=[value[index*2:index*2+2] for index in range(complete)]
    assert chunks==arrays
    assert b''.join(arrays)==value[:complete*2]
    partitions+=1
result=dict(base=base,changed_existing_paths=names,protected_bodies=protected,
            exact_decoder_file_projections=2,exact_environment_extraction_projection=1,
            original_fixture_records=81,byte_partition_source_projections=partitions,
            negative_source_mutants=4,SDK_compiler_Target_ports_product_runtime=0)
(out/'source-checks.json').write_text(json.dumps(result,indent=2)+'\n')
commands=[
 ['/home/agent/.cargo/bin/rustfmt','--edition','2024','--check']+
 [str(path) for path in sorted((root/'rust/symbrain-usage').rglob('*.rs'))],
 ['/workspace/toolchains/bin/actionlint']+
 [str(path) for path in sorted((root/'.github/workflows').glob('*.yml'))],
 ['git','-C',str(root),'diff','--check'],
]
tools=[]
for index,command in enumerate(commands):
    run=subprocess.run(command,cwd=root,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
    (out/f'tool-{index}.stdout').write_bytes(run.stdout)
    (out/f'tool-{index}.stderr').write_bytes(run.stderr)
    tools.append(dict(command=command,exit=run.returncode))
(out/'tools.json').write_text(json.dumps(tools,indent=2)+'\n')
assert all(row['exit']==0 for row in tools),tools
print(json.dumps(dict(protected=protected,source_mutants=4,projections=partitions,tools=3)))
