"""Source projections only: never invokes Go, Rust, a provider or a peer."""
from pathlib import Path
import hashlib
import json
import math
import struct

ROOT = Path('/tmp/symaira-usage768-retry-independent-static-projection')
ROOT.mkdir(exist_ok=True)
def bits(value):
    return struct.pack('>d', value).hex()
def go_exponent(digits):
    result = 0
    for digit in digits:
        if digit == '_':
            continue
        if result < 10000:
            result = result * 10 + int(digit)
    return result

rows = []
# Single significant digit allows exact source reasoning without reproducing
# the Go/Rust binary64 implementation. Rust conversion remains a prediction.
for ident, prefix, zeros, exponent, direction in [
    ('within-cap-small', '0.', 10, '11', 1),
    ('within-cap-five-digits', '0.', 10000, '10001', 1),
    ('positive-exponent-overflow', '0.', 10000, '100000', 1),
    ('negative-exponent-underflow', '1', 10000, '100000', -1),
    ('underscore-positive-overflow', '0.', 10000, '1_0_0_0_0_0', 1),
]:
    raw = (prefix + '0' * zeros + ('1' if prefix == '0.' else '') +
           ('e-' if direction == -1 else 'e') + exponent).encode()
    path = ROOT / (ident + '.header')
    path.write_bytes(raw)
    capped = go_exponent(exponent) * direction
    decimal_power = capped - zeros - 1 if prefix == '0.' else capped + zeros
    # Python is only the independent arithmetic reference. The pinned Go fast
    # path for 0.1 and Eisel-Lemire/decimal fallback for 1 are read in source.
    go_value = float('1e' + str(decimal_power))
    mathematical = float(raw.decode().replace('_', ''))
    native_accepted_prediction = math.isfinite(mathematical)
    rows.append(dict(id=ident, path=str(path), input_bytes=len(raw),
                     sha256=hashlib.sha256(raw).hexdigest(),
                     wire_bytes_with_minimal_response=len(raw)+96,
                     inside_ureq_64k_header_limit=len(raw)+96 < 65536,
                     go_capped_exponent=capped,
                     pinned_go_source_predicted_bits=bits(go_value),
                     pinned_go_source_predicted_seconds=str(int(go_value)),
                     mathematical_reference_bits=bits(mathematical),
                     native_source_predicted_accepted=native_accepted_prediction,
                     native_source_predicted_seconds=str(int(mathematical)) if native_accepted_prediction else None,
                     equal_prediction=native_accepted_prediction and go_value == mathematical))
assert [r['equal_prediction'] for r in rows] == [True, True, False, False, False]
sdk = Path('/workspace/toolchains/go1.26.7/src/internal/strconv/atof.go')
native = Path('/workspace/symaira-usage768-retry-after/rust/symbrain-usage/src/go_float.rs')
receipt = dict(scope='Source-only Python arithmetic projection, NOT executed pinned Go or compiled candidate acceptance; no provider/API/network/target access.',
               sdk_path=str(sdk), sdk_sha256=hashlib.sha256(sdk.read_bytes()).hexdigest(),
               native_path=str(native), native_sha256=hashlib.sha256(native.read_bytes()).hexdigest(),
               preliminary_example_correction='10001 fully accumulates; cap drops subsequent digits only after prior accumulator >=10000. Original preliminary communication corrected before final finding.',
               cases=rows)
(ROOT/'receipt.json').write_text(json.dumps(receipt, indent=2)+'\n')
print(json.dumps(receipt, indent=2))
