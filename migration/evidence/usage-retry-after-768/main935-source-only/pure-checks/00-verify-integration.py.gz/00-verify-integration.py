"""Pure source/Git/corpus audit. Never execute a product, SDK, compiler or peer."""
import ast
import csv
import gzip
import hashlib
import json
from pathlib import Path
import subprocess
import sys

ROOT = Path('/workspace/symaira-usage768-retry-main935')
OUT = Path('/workspace/review-artifacts/usage768-retry-main935-source')
PARENT = '3797d40fa34c57cf1314853438170e607cbd7875'
MAIN = '9353520a34c5819c7d0a6cd58d3bfaa2b22b045b'
BASE = '5e232700bb9031fc34d4995465a4037837540abb'
FROZEN = 'dcddcef0df5789123c7c9a7ebe6e01f10e941f2c'

def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT)

def sha(body):
    return hashlib.sha256(body).hexdigest()

def body(ref, name):
    return git('show', ref + ':' + name)

def tree(ref):
    result = {}
    for row in git('ls-tree', '-rz', ref).split(b'\0'):
        if not row:
            continue
        info, name = row.split(b'\t', 1)
        mode, kind, oid = info.decode().split()
        result[name.decode()] = dict(mode=mode, kind=kind, oid=oid)
    return result

publication = git('rev-parse', 'HEAD').decode().strip()
head = sys.argv[1] if len(sys.argv) > 1 else publication
assert not git('status', '--porcelain', '-uall')
for name in git('diff', '--name-only', head, publication).decode().splitlines():
    assert name.startswith('migration/evidence/usage-retry-after-768/main935-source-only/'), name
parents = git('show', '-s', '--format=%P', head).decode().split()
assert parents == [PARENT, MAIN]
trees = {ref: tree(ref) for ref in [BASE, PARENT, MAIN, head, FROZEN]}
changed = set(git('diff', '--name-only', BASE, PARENT).decode().splitlines()) | set(git('diff', '--name-only', BASE, MAIN).decode().splitlines())
merge_rows = []
exceptions = {'.github/workflows/ci.yml', 'migration/contract-matrix.csv', 'docs/adr/usage-retry-after-768.md'}
for name in sorted(changed):
    b, p, m, c = [trees[ref].get(name) for ref in [BASE, PARENT, MAIN, head]]
    if name not in exceptions:
        expected = m if p == b else p
        assert p == b or m == b or p == m, ('unreviewed two-parent collision', name)
        assert c == expected, ('lost parent body/mode', name)
    rows = {}
    for ref in [BASE, PARENT, MAIN, head]:
        item = trees[ref].get(name)
        rows[ref] = None if item is None else dict(item, sha256=sha(body(ref, name)), bytes=len(body(ref, name)))
    merge_rows.append(dict(path=name, bindings=rows))
# Complete main added Skills workflow block remains contiguous and byte exact.
ci = body(head, '.github/workflows/ci.yml')
main_ci = body(MAIN, '.github/workflows/ci.yml')
start = b'      - name: Frozen Go and native Windows wide Skills argv acceptance\n'
end = b'      - name: Native Go/Rust activity validation acceptance\n'
skills_start = main_ci.index(start)
skills = main_ci[skills_start:main_ci.index(end, skills_start)]
assert skills in ci
parent_ci = body(PARENT, '.github/workflows/ci.yml')
assert ci.replace(skills, b'') == parent_ci
# The matrix uses per-ID three-way selection plus both independent additions.
matrices = {}
for ref in [BASE, PARENT, MAIN, head]:
    lines = body(ref, 'migration/contract-matrix.csv').decode().splitlines()
    assert all(len(row) == len(next(csv.reader([lines[0]]))) for row in csv.reader(lines))
    matrices[ref] = {next(csv.reader([line]))[0]: line for line in lines}
    assert len(matrices[ref]) == len(lines)
for key in set(matrices[PARENT]) | set(matrices[MAIN]):
    b, p, m = [matrices[ref].get(key) for ref in [BASE, PARENT, MAIN]]
    assert p == b or m == b or p == m, ('two-parent matrix row conflict', key)
    expected = m if p == b else p
    assert matrices[head][key] == expected, key
assert matrices[head]['USE-003'] == matrices[PARENT]['USE-003']
assert matrices[head]['USE-004'] == matrices[PARENT]['USE-004']
assert matrices[head]['SKL-008'] == matrices[MAIN]['SKL-008']
# All six original harnesses and the complete Retry harness remain byte exact.
harnesses = ['usage-credential-oracle', 'usage-hermes-oracle', 'usage-provider-files-oracle', 'usage-copilot-kimi-oracle', 'usage-next-oracle', 'usage-local-files-baseline', 'usage-retry-after-oracle']
harness_rows = {}
for harness in harnesses:
    for name, item in trees[PARENT].items():
        if name.startswith('scripts/' + harness + '/'):
            assert trees[head].get(name) == item, name
            harness_rows[name] = sha(body(head, name))
for name, item in trees[PARENT].items():
    if name.startswith('rust/symbrain-usage/') or name in ['Cargo.toml', 'Cargo.lock', 'rust/symbrain-cli/src/usage_cli.rs', 'rust/symbrain-cli/src/usage_flags.rs', 'rust/symbrain-cli/src/flag_normalization.rs']:
        assert trees[head].get(name) == item, name
# Never write generator output or invoke its main/subprocess branch.
def corpus(ref):
    ns = {'__name__': 'pure_case_projection'}
    parsed = ast.parse(body(ref, 'scripts/usage-retry-after-oracle/cases.py'))
    parsed.body = [node for node in parsed.body if not (isinstance(node, ast.Expr) and isinstance(node.value, ast.Call) and (isinstance(node.value.func, ast.Attribute) and node.value.func.attr == 'write_text' or isinstance(node.value.func, ast.Name) and node.value.func.id == 'print'))]
    exec(compile(parsed, 'pure-original-cases', 'exec'), ns)
    original = {key: ns[key] for key in ['public', 'wire', 'values', 'whitespace']}
    expanded_ns = {'__name__': 'pure_decimal_projection'}
    exec(compile(ast.parse(body(ref, 'scripts/usage-retry-after-oracle/decimal_cases.py')), 'pure-additive-cases', 'exec'), expanded_ns)
    expanded = expanded_ns['expand'](original)
    assert expanded['public'][:1600] == original['public']
    assert expanded['wire'][:1164] == original['wire']
    assert len(original['public']) == 1600 and len(original['wire']) == 1164
    assert len(expanded['public']) == 1681 and len(expanded['wire']) == 1356
    assert len({r['id'] for r in expanded['public']}) == 1681
    assert len({r['id'] for r in expanded['wire']}) == 1356
    return original, expanded
original, expanded = corpus(PARENT)
current_original, current_expanded = corpus(head)
assert (original, expanded) == (current_original, current_expanded)
case_bindings = {}
for family, cases in [('original_scalar', original['public']), ('original_tls', original['wire']), ('additive_scalar', expanded['public']), ('additive_tls', expanded['wire'])]:
    rows = [dict(id=row['id'], canonical_record_sha256=sha(json.dumps(row, sort_keys=True, separators=(',', ':')).encode())) for row in cases]
    case_bindings[family] = dict(count=len(rows), canonical_corpus_sha256=sha(json.dumps(cases, sort_keys=True, separators=(',', ':')).encode()), all_id_input_record_bindings=rows)
controls = ['missing-scalar', 'hex-rounding', 'negative-status', 'finite-only-waiver', 'long-decimal-drop', 'fallback-normalization', 'sticky-halfway']
runner = body(head, 'scripts/usage-retry-after-oracle/oracle.py')
assert runner == body(PARENT, 'scripts/usage-retry-after-oracle/oracle.py')
for control in controls:
    assert control.encode() in runner
for ref in [PARENT, MAIN]:
    assert body(head, 'scripts/activity-validation-oracle/run.sh') == body(ref, 'scripts/activity-validation-oracle/run.sh')
go_bindings = {}
for name, item in trees[PARENT].items():
    if name.endswith('.go') or name in ['go.mod', 'go.sum', 'guard/go.mod', 'guard/go.sum']:
        assert trees[head].get(name) == item, name
        go_bindings[name] = dict(item, sha256=sha(body(head, name)))
frozen_usage = {}
for name, item in trees[FROZEN].items():
    if name.startswith('internal/usage/') or name in ['go.mod', 'go.sum']:
        assert trees[head].get(name) == item, name
        frozen_usage[name] = sha(body(head, name))
# Both parents' complete historical proof bodies remain tracked unchanged.
prior_evidence = {}
for ref in [PARENT, MAIN]:
    count = 0
    for name, item in trees[ref].items():
        if name.startswith('migration/evidence/'):
            assert trees[head].get(name) == item, (ref, name)
            count += 1
    prior_evidence[ref] = count
physical = {}
for name, item in trees[head].items():
    path = ROOT / name
    if path.is_file():
        raw = path.read_bytes()
        assert raw == body(head, name), name
        physical[name] = dict(sha256=sha(raw), bytes=len(raw), git_blob=item['oid'], git_mode=item['mode'])
assert sum(row['bytes'] for row in physical.values()) <= 15 * 1024 * 1024
source_rows = {name: row for name, row in physical.items() if name.startswith(('rust/', 'scripts/', '.github/workflows/', 'docs/adr/')) or name in ['Cargo.toml', 'Cargo.lock', 'migration/contract-matrix.csv', 'MIGRATION-RUST.md']}
retention = json.loads((ROOT / 'migration/evidence/usage-retry-after-768/main935-source-only/root-review-retention.json').read_text())
for row in retention['records']:
    archived = (ROOT / row['tracked']).read_bytes()
    raw = gzip.decompress(archived)
    assert sha(archived) == row['archive_sha256'] and sha(raw) == row['sha256'] and len(raw) == row['bytes']
syntax = []
for path in sorted((ROOT / 'scripts').rglob('*.py')):
    ast.parse(path.read_bytes(), filename=str(path))
    syntax.append(str(path.relative_to(ROOT)))
out = dict(status='SOURCE_READY_PURE_INTEGRATION_ONLY', source_commit=head, normal_merge_parents=parents, common_base=BASE, original_source_retained=PARENT, changed_parent_full_body_bindings=merge_rows, complete_parent_historical_evidence_counts=prior_evidence, all_current_physical_git_bindings=physical, source_sha256=source_rows, source_count=len(source_rows), physical_payload_bytes=sum(r['bytes'] for r in physical.values()), unchanged_harness_files=harness_rows, unchanged_all_go_bindings=go_bindings, frozen_usage_git_bindings=frozen_usage, original_corpus_preserved=True, prepared_case_bindings=case_bindings, prepared_unchanged_controls=controls, retained_full_root_review_files=len(retention['records']), python_ast_syntax_files=syntax, compiler_executions=0, sdk_executions=0, product_executions=0, TLS_peers=0, target_access=False, port_use=False, GitHub_writes=False, no_current_runtime_or_CI_claim=True)
(OUT / 'source-integration-verification.json').write_text(json.dumps(out, indent=2) + '\n')
print(json.dumps({key: out[key] for key in ['status', 'source_commit', 'normal_merge_parents', 'source_count', 'physical_payload_bytes', 'complete_parent_historical_evidence_counts', 'retained_full_root_review_files', 'compiler_executions', 'sdk_executions', 'product_executions', 'target_access']}, indent=2))
