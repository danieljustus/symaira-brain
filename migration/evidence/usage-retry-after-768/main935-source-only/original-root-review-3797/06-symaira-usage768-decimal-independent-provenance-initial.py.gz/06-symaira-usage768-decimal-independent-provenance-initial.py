"""Read-only static/source/hash audit; no compilers, targets or products."""
import ast
import gzip
import hashlib
import importlib.util
import json
from pathlib import Path
import subprocess

ROOT=Path('/workspace/symaira-usage768-retry-after-decimal')
HEAD='3797d40fa34c57cf1314853438170e607cbd7875'
SOURCE='79c834537ef5b8430f8189f32380016e629fed10'
OLD='780f93987e2f20c6dbd6cbed8a4a07af1b914d11'
FROZEN='dcddcef0df5789123c7c9a7ebe6e01f10e941f2c'
SDK=Path('/workspace/toolchains/go1.26.7')
def git(*a):return subprocess.check_output(['git',*a],cwd=ROOT)
def sha(data):return hashlib.sha256(data).hexdigest()
def fingerprint(path,compressed=False):
    n=0;h=hashlib.sha256()
    with (gzip.open(path,'rb')if compressed else open(path,'rb'))as f:
        while raw:=f.read(1024*1024):n+=len(raw);h.update(raw)
    return h.hexdigest(),n
assert git('rev-parse','HEAD').decode().strip()==HEAD and not git('status','--porcelain','-uall')
git('merge-base','--is-ancestor','5e232700bb9031fc34d4995465a4037837540abb',HEAD)
checkpoint=json.loads((ROOT/'migration/evidence/usage-retry-after-768/decimal-source-only/checkpoint.json').read_text())
assert checkpoint['source_commit']==SOURCE and len(checkpoint['source_sha256'])==503
checks={}
for name,expected in checkpoint['source_sha256'].items():
    raw=(ROOT/name).read_bytes();assert sha(raw)==expected,name
    assert raw==git('show',SOURCE+':'+name),name
    assert raw==git('show',HEAD+':'+name),name
    checks[name]=expected
publication_diff=git('diff','--name-only',SOURCE,HEAD).decode().splitlines()
assert publication_diff==['migration/evidence/usage-retry-after-768/decimal-source-only/checkpoint.json']
oldtree=Path('/workspace/symaira-usage768-retry-after')
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=oldtree).decode().strip()==OLD
assert not subprocess.check_output(['git','status','--porcelain','-uall'],cwd=oldtree)
fixedscope=['Cargo.toml','Cargo.lock','rust/symbrain-usage/Cargo.toml','rust/symbrain-usage/src/retry_after.rs','rust/symbrain-usage/src/provider_errors.rs','rust/symbrain-usage/src/transport.rs','rust/symbrain-usage/src/provider_config/routing.rs','rust/symbrain-cli/src/usage_cli.rs','rust/symbrain-cli/src/lib.rs','rust/symbrain-cli/src/flag_normalization.rs']
for name in fixedscope:assert (ROOT/name).read_bytes()==git('show',OLD+':'+name),name
prior_harnesses=['usage-credential-oracle','usage-hermes-oracle','usage-provider-files-oracle','usage-copilot-kimi-oracle','usage-next-oracle','usage-local-files-baseline']
for harness in prior_harnesses:
    for name in git('ls-tree','-r','--name-only',OLD,'--','scripts/'+harness).decode().splitlines():assert(ROOT/name).read_bytes()==git('show',OLD+':'+name),name
original_source={}
for name in ['scripts/usage-retry-after-oracle/cases.py','scripts/usage-retry-after-oracle/peer.py','scripts/usage-retry-after-oracle/scalar_test.go.txt','scripts/usage-retry-after-oracle/status_test.go.txt']:
    raw=(ROOT/name).read_bytes();assert raw==git('show',OLD+':'+name);original_source[name]=sha(raw)
preserve=ROOT/'migration/evidence/usage-retry-after-768/original-independent-review-5e774'
manifest=json.loads((preserve/'manifest.json').read_text());original_proofs=[]
for row in manifest['records']:
    p=ROOT/row['tracked']if row.get('tracked')else Path(row['archive'])
    assert fingerprint(p)[0]==row['archive_sha256'],str(p)
    actual,n=fingerprint(p,row['storage']!='package-tar-gz-raw-retained');assert(actual,n)==(row['sha256'],row['bytes']),str(p)
    original_proofs.append(dict(path=str(p),sha256=actual,bytes=n))
binary=json.loads((preserve/'binary-preservation.json').read_text());archives=[]
assert len(binary['records'])==569 and len(binary['unique'])==499
for expected,row in binary['unique'].items():
    p=Path(row['archive']);assert fingerprint(p)[0]==row['compressed_sha256'],str(p)
    actual,n=fingerprint(p,True);assert(actual,n)==(expected,row['bytes']),str(p)
    archives.append(dict(path=str(p),sha256=actual,bytes=n))
for row in binary['records']:assert row['sha256']in binary['unique']and row['bytes']==binary['unique'][row['sha256']]['bytes']
newarchives=[]
retentions=['independent-780','decimal-sdk-sources','decimal-sdk-linux-amd64','decimal-sdk-linux-amd64-71','decimal-sdk-linux-amd64-81']
for dirname in retentions:
    d=ROOT/'migration/evidence/usage-retry-after-768'/dirname
    for row in json.loads((d/'retention.json').read_text())['entries']:
        p=ROOT/row['archive']if row['archive'].startswith('migration/')else d/row['archive']
        assert fingerprint(p)[0]==row['archive_sha256'],str(p)
        actual,n=fingerprint(p,True);assert(actual,n)==(row['sha256'],row['bytes']),str(p)
        original=Path(row.get('original',row.get('source','/missing')))
        if original.is_file():assert fingerprint(original)==(actual,n),str(original)
        newarchives.append(dict(path=str(p),original=str(original),original_live=original.is_file(),sha256=actual,bytes=n))
sdk={}
for name,expected in checkpoint['sdk_source_sha256'].items():
    p=SDK/'src/internal/strconv'/name;assert fingerprint(p)[0]==expected; sdk[str(p)]=expected
assert fingerprint(SDK/'bin/go')[0]==checkpoint['Go_tool_sha256']
legacy_sdk=json.loads((preserve/'go-sdk-source-bindings.json').read_text())
for name,expected in legacy_sdk.items():assert fingerprint(SDK/name)[0]==expected; sdk[str(SDK/name)]=expected
frozen={}
for entry in git('ls-tree','-r','-z',FROZEN,'--','internal/usage','go.mod','go.sum').split(b'\0'):
    if not entry:continue
    name=entry.split(b'\t',1)[1].decode();raw=(ROOT/name).read_bytes()
    assert raw==git('show',FROZEN+':'+name),name
    assert raw==(Path('/workspace/oracles/daemon772-go-source')/name).read_bytes(),name
    frozen[name]=sha(raw)
sdkresult=json.loads((ROOT/'rust/symbrain-usage/tests/fixtures/retry_decimal_sdk_linux_amd64.json').read_text())
for run in ['', '-71','-81']:
    d=Path('/tmp/symaira-usage768-decimal-sdk-proof'+run)
    receipt=json.loads((d/'receipt.json').read_text())
    for name,expected in receipt.get('files_sha256',{}).items():assert fingerprint(d/name)[0]==expected,name
    r=json.loads((d/'stdout.json').read_text());inputs=json.loads((d/'input.json').read_text())['public']
    assert len(r['records'])==len(inputs)==receipt['cases']
    for row,inp in zip(r['records'],inputs):assert row['id']==inp['id']and row['value_hex']==inp['value_hex']
    assert sdkresult['records'][:len(r['records'])]==r['records']
assert sha((ROOT/'scripts/usage-retry-after-oracle/sdk_decimal_probe.go.txt').read_bytes())==fingerprint(Path('/tmp/symaira-usage768-decimal-sdk-proof/probe.go'))[0]
assert fingerprint(Path('/tmp/symaira-usage768-decimal-sdk-proof/probe'))[0]=='cd483153469e0616aa9d906de0852a717d5e587026bf3f4221bfa7a41354b644'
assert len(sdkresult['records'])==81 and sdkresult['sdk']=='go1.26.7'and sdkresult['goarch']=='amd64'and sdkresult['goos']=='linux'
# Pure case generation, never oracle main, product/SDK/build/socket code.
namespace={'__name__':'independent_case_generation','__file__':str(ROOT/'scripts/usage-retry-after-oracle/cases.py')}
source=(ROOT/'scripts/usage-retry-after-oracle/cases.py').read_text();parsed=ast.parse(source)
parsed.body=[node for node in parsed.body if not(isinstance(node,ast.Expr)and isinstance(node.value,ast.Call)and (isinstance(node.value.func,ast.Attribute)and node.value.func.attr=='write_text'or isinstance(node.value.func,ast.Name)and node.value.func.id=='print')))]
exec(compile(parsed,'original-corpus-source','exec'),namespace)
base={key:namespace[key]for key in ['public','wire','values','whitespace']}
spec=importlib.util.spec_from_file_location('decimal_source_cases',ROOT/'scripts/usage-retry-after-oracle/decimal_cases.py');mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
expanded=mod.expand(base)
assert len(base['public'])==1600 and len(base['wire'])==1164
assert expanded['public'][:1600]==base['public']and expanded['wire'][:1164]==base['wire']
assert len(expanded['public'])==1681 and len(expanded['wire'])==1356
assert len({r['id']for r in expanded['public']})==1681 and len({r['id']for r in expanded['wire']})==1356
assert mod.inputs()==json.loads(Path('/tmp/symaira-usage768-decimal-sdk-proof-81/input.json').read_text())['public']
syntax=[]
for p in sorted((ROOT/'scripts').glob('usage-*/*.py')):ast.parse(p.read_text(),filename=str(p));syntax.append(str(p.relative_to(ROOT)))
lengths={name:len((ROOT/name).read_text().splitlines())for name in checkpoint['changed_production']}
assert all(n<400 for n in lengths.values())
out=dict(head=HEAD,source=SOURCE,status='INDEPENDENT_STATIC_PROVENANCE_ONLY',source_sha256=checks,source_count=len(checks),publication_diff=publication_diff,unchanged_780_scopes=fixedscope,unchanged_six_prior_harnesses=prior_harnesses,original_source_sha256=original_source,original_proofs=original_proofs,original_proofs_count=len(original_proofs),binary_path_count=569,binary_unique_count=499,binary_archive_checks=archives,new_archive_checks=newarchives,new_archive_count=len(newarchives),sdk_sha256=sdk,frozen_go_sha256=frozen,frozen_go_count=len(frozen),actual_sdk_records_retained=81,prior_actual_sdk_62_71_prefixes_equal=True,prepared_original_public=1600,prepared_original_tls=1164,prepared_expanded_public=1681,prepared_expanded_tls=1356,prepared_controls=7,original_prefixes_unchanged=True,production_line_counts=lengths,python_ast=syntax,runtime_executions=0,compilers=0,target_access=False,ports=0,source_clean=True)
Path('/tmp/symaira-usage768-decimal-independent-provenance.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({k:v for k,v in out.items()if k in ['head','source','source_count','original_proofs_count','binary_path_count','binary_unique_count','new_archive_count','frozen_go_count','production_line_counts','actual_sdk_records_retained','prepared_original_public','prepared_original_tls','prepared_expanded_public','prepared_expanded_tls','prepared_controls','runtime_executions','compilers','target_access','ports']},indent=2))
