# Independent full Usage successor review — REQUEST CHANGES, one P2 group

Immutable publication `5e77418ff03491df61a74dcd6435eeb5b4496260`, validated production/harness source `c0ae71c0bc0a5e39c65458484f1024d5940a19aa`, worktree `/workspace/symaira-usage768-remaining`. Normal main `2b6d49f250a81650eda1b93cec7d859a171873bb`; accepted predecessor source `8803847278546f3161eaaa84d2e65bc2eec594a2` / publication `b8621bc26e8d9c5985e8517968d679c127fa152a`. Frozen Go `dcddcef0df5789123c7c9a7ebe6e01f10e941f2c`, SDK1.26.7, actual Linux/amd64. Reviewer did not author this successor and made no candidate source, frozen fixture, workflow or GitHub changes. Candidate remained clean and immutable throughout.

## [P2] Preserve the frozen Go Retry-After parser contract when delivering 429 responses

Location `rust/symbrain-usage/src/provider_errors.rs:142–149`, especially the direct `value.trim().parse::<f64>()` at144 and `seconds as i64` at148. Frozen Go uses `strings.TrimSpace` / `strconv.ParseFloat`, rejects negative values and renders `int(seconds)` in `internal/usage/http.go:55–69` and `errors.go:24–25`. The Rust parser neither rejects negative values nor accepts Go hexadecimal/underscore float syntax; Rust's saturating cast also differs from actual Go/amd64 for nonfinite/out-of-range values.

Actual hostname-verified private TLS replies to the existing production constructor/request/parser path confirm:

| Retry-After | Frozen Go error suffix | Native suffix |
|---|---|---|
| `-3` | none | `; retry in -3s` |
| `0x1p2` | `; retry in 4s` | none |
| `1_0` | `; retry in 10s` | none |
| `1.9` | `; retry in 1s` | `; retry in 1s` |
| `NaN` | `; retry in -9223372036854775808s` | `; retry in 0s` |
| `+Inf`, `1e19` | `; retry in -9223372036854775808s` | `; retry in 9223372036854775807s` |

The first two cases each fail the intended full Kimi CLI TLS/report equality assertion with native exit101; complete original canned/device comparisons still pass beforehand. A third independent corpus keeps the original device responses unchanged and changes only84 privately owned remote responses across twelve strategies; the first full Claude constructor/TLS comparison fails at the negative header. The seven-header corpus's actual frozen-Go84 reports were then compared with84 native public `Service`/`Provider::fixture` calls through an owned response mock using the fresh production library:18 error strings match,66 differ. Every current full native mock debug report and actual Go constructor report is retained. Mock auth/source metadata is deliberately not claimed constructor-identical. Native OpenCode's429 owner ignores the shared retry suffix and is unchanged. Nonfinite/overflow conversions here are measured Linux/amd64 observations, not a portable three-platform contract.

The formatting helper predates this revision, but the successor now disables Ureq's status exceptions so ordinary production429 replies actually reach it. The original normal `Retry-After:3`/`17` cases pass and do not cover this new reachable grammar. Correct the shared parser, preserve these actual failures and add source-bound response/header cases and meaningful controls; verify target-specific conversion before claiming cross-platform equality. This is one parser finding group, not six duplicate findings. No other actionable finding was established.

Raw first-failure inputs, complete Go/native stderr, full TLS request/response bytes and source-bound executable identities:

- `/tmp/symaira-usage768-next-independent-extra-retry-negative.{py,json,log}` and `.evidence/`.
- `/tmp/symaira-usage768-next-independent-extra-retry-hex.{py,json,log}` and `.evidence/`.
- `/tmp/symaira-usage768-next-independent-extra-retry-grammar.{py,json,log}` and `.evidence/`.
- `/tmp/symaira-usage768-next-independent-retry-compare.{py,json,log}`, actual caller `.rs`/executable and copied linked `retry-rlib.rlib`.

## Complete integrated review and provenance

Read applicable root AGENTS; inspected all36 Rust paths changed from main, the integrated provider-config fragments, credential/environment/reference/owner/path/Keychain/JSON/JWT logic, CLI dispatch/whole-vector normalization/forwarding, production Ureq transport, provider request/error/fallback/body/parser/service consumers, tests, all six runner families, package lifecycle restoration, platform workflow, public ADRs and migration rows. Twenty-three of36 changed Rust files are byte-identical to the independently accepted880 predecessor; new production changes are the CLI normalization move/classification dispatch, Kimi device admission, shared agent policy and precise Cursor empty-body diagnostic. Their transitive consumers were reviewed, rather than only the new argv arm. All changed production modules stay under400 lines; there is no successor dependency/lockfile change relative to880. The main-relative existing pinned hostname addition is justified by actual Windows physical hostname ownership, with no Linux-as-Windows claim.

Independent immutable Git/disk/hash checks verify104 source-manifest union files,231 complete scope files and56 frozen-Go files. The scope receipt binds the clean source revision: the publication appends35 acceptance-documentation lines to its ADR, recorded explicitly as a docs-only current hash change. Every source hash agrees with immutable source Git. All143 tracked author raw gzip proofs match their original raw bytes/lengths and compressed hashes. The complete568 ELF-path /498 unique author archive was independently decompressed and hashed; all current original bytes match. Original historical inputs,143 final proof files, six package archives, earlier archives and the first stale-Cargo restoration failure remain intact.

Actual current CLI SHA `df339eeb2cc57b69d51b913a6e9f8b2828ad7e34f5943a2690ea21c4639096db` is retained before/after review,38,010,184bytes. The fresh successor gate produces the actual accepted880 parent plus frozen-Go CLI/provider executable, verifies all parent-source bytes and requires byte-identical candidate restoration. Package clean archives cover CLI plus Usage and enforce zero users on the sole target; no cached-parent assumption or second target. Actual supplemental Go/native provider executables are SHA `8ed4034da4c689666568e4da81b9efefc20d3a11b5c5ac1339c70463d154949f` / `d3a110d18045d85d07b12e6f6f2b3b3daff1420907a682ed5b309fd2c018025c`. Linked public mock caller SHA `94053c888d2c1a65e50f5aa2d338c88d6a1d4e866c169d24a575645524335e82`; fresh copied production rlib SHA `128db8cbdb0b5e153b4c3fba4abe9c33a0f17b7530a2922edfab7e005aa39efa`.

## Independent fresh gates

All commands ran at clean publication5e774 under subreaper, umask022, Go1.26.7, Rust1.98.0, jobs2/debug0/testdebug0/incremental0 using only `/workspace/symaira-usage768-remaining/target`;700MB free floor checked before each stage. No Doctor target, operator credentials, paid provider requests or endpoint11434 use.

- Local89:82 full/seven retained gates,112 CLI,16 full owners/16 owner CLI/22 Unix paths, original97 accounting,82 argv including22 original inputs and12 retained parent failures; actual existing controls pass.
- Successor64 devices: original39 unchanged plus25 exhaustive Go whitespace trim points,57 full/seven retained invalid/raw/control gates;84 constructor status/body TLS cases;147 paired wire observations; four exact/over1MiB native body limits;160 argv retaining original64;15 byte-preserving valid report fallbacks; three real comparison mutants plus two actual argv mutants.
- Files86/85 full/one account gate and151 CLI/five controls; Hermes96/104 CLI/five controls; references44/110 CLI/five controls.
- Shared Fetch133 full reports/266 JSON-table byte comparisons/four actual controls.
- Ordinary CLI+Usage all-features355 passed, zero failures, five ignored explicit oracles and35 parent summaries. All five oracles were actually invoked in the source-bound runners. Strict all-target/all-feature Clippy, workspace fmt and actionlint pass.

Five fresh constructor manifests74/66/66/64/60 agree on all53 common paths and immutable publication source. Logs, exact reports, source hashes and package archives remain under `/tmp/symaira-usage768-next-independent-{local,next,files,hermes,refs,fetch}*`; runner `/tmp/symaira-usage768-next-independent-full-gates.sh`; full log and source-bound verification receipt have the same prefix.

## Supplementary boundaries and truthful limits

An independently owned CA/loopback TLS peer with original-host certificate checks gave84 additional successful full report/request comparisons across201 valid,202 malformed,204 empty,206 valid and400/404/503 for all twelve strategies;298 complete wire rows, no peer errors. The original64 device inputs/57 device TLS reports and four native bounds were freshly executed as prerequisites. No compiler or operator/public provider network was involved in this supplement.

Sixty additional current/accepted-parent/frozen-Go argv triples cover raw bytes, quotes, whitespace, mixed global output flags, terminators and fallback present/absent. Fifty-six match exactly and all owned filesystem metadata is unchanged. Four differences (two invalidUTF8 `--output` values times two fallback modes) are byte-identical in current and accepted880 parent: inherited global-output formatting uses U+FFFD whereas Go quotes `\\xff`/`\\xe2\\x82`. This is explicitly classified as a remaining global-output boundary, not a new successor regression or second P2. All exact inputs/outputs retained. The new local parser's own raw error bytes and firstarg help/terminator semantics pass the original and expanded corpora.

Private CA/resolver proof uses the production agent builder/executor but intentionally retains the private agent through the test wrapper's cooperative request dispatch; it does not independently execute/prove the dynamically created production deadline agent's network path. Both production agents statically share status-as-error false; deadline/cancellation/proxy parity is not claimed. Four response-bound cases are native invariants, not Go body-error-text equivalence. Existing explicit timestamp normalization preserves actual clocks plus OpenCode exact reset offsets; generated/fixed OpenCode instance and transport default headers/order are observed differences, not raw full HTTP parity. No security bypass or new credential disclosure was established. Device UTF8/header safety, account ambiguity, unsafe-file access, source ownership and remaining Keychain/base/workspace/JWT/home gates remain bounded.

Reviewer-owned initial supplemental harness mistakes are retained: an invalid non-ASCII Python bytes literal was corrected before argv execution; a fixture-root path wrongly referred to the frozen executable rather than source tree, before any TLS cases ran, and its own peer process was terminated. Original scripts/logs are preserved; frozen fixtures and candidate stayed unchanged. Initial source-scope verification expected publication ADR bytes to equal its clean-source hash; its failure receipt is retained and the documented docs-only append is now separately verified. None of these attempts is counted as a product failure or accepted semantic case.

Disposition: REQUEST CHANGES solely for the shared Retry-After group. Native macOS/Windows exact-head runtime checks, protected CI and the remaining complete #768 work still apply. Full issue closure, all-platform transport parity and new performance acceptance are not asserted. Target/source are released after receipt completion; author may only resume a successor after Root authorization and original failure preservation.
