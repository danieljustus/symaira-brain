import base64,hashlib,json,os,subprocess,tempfile
from pathlib import Path
ROOT=Path('/workspace/symaira-usage768-remaining')
BIN=Path('/tmp/symaira-usage768-next-final-next.evidence')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def state(home):return {str(p.relative_to(home)):dict(mode=p.lstat().st_mode,size=p.lstat().st_size,mtime=p.lstat().st_mtime_ns,hash=sha(p) if p.is_file() else None) for p in home.rglob('*')}
def invoke(path,args,env,home):
 p=subprocess.run([os.fsencode(path),b'usage',*args],cwd=home,env=env,capture_output=True,timeout=15)
 return dict(exit=p.returncode,stdout=p.stdout.hex(),stderr=p.stderr.hex())
vectors=[[b'--unknown',b'--json'],[b'--json',b'--unknown'],[b'--help',b'--output',b'json'],[b'--output',b'json',b'--help'],[b'--help=false',b'--json'],[b'-h=anything',b'--output=json'],[b'--',b'--json',b'--help'],[b'---',b'owned'],[b'----',b'--help'],[b'--unknown=x=y',b'--output=json'],[b'--unknown',b'--',b'--json'],[b'--\xff',b'--json'],[b'--\xe2\x82',b'--output=json'],[b'raw\xff',b'--help'],[b'raw\xe2\x82',b'--output=json'],[b'--=',b'--json'],[b'--unknown',b'--json=false'],[b'--unknown',b'--output',b'json'],[b'--help',b'--unknown',b'--output=table'],[b'--help',b'--',b'--json'],[b'--unknown',b'--output=csv'],[b'--unknown',b'--output'],[b'--unknown',b'--json=oops'],[b'--unknown',b'--output=\xff'],[b'--unknown',b'--output=\xe2\x82'],[b'--unknown',b'--help',b'--json'],['--雪'.encode(),b'--json'],[b'--help=\xff'],[b'--h=\xe2\x82'],[b'"quote\\tab\t\n',b'--json']]
rows=[]
with tempfile.TemporaryDirectory(prefix='usage-independent-argv-') as temp:
 home=Path(temp)/'home';home.mkdir();before=state(home)
 env=dict(HOME=str(home),USERPROFILE=str(home),PATH='',ANTHROPIC_OAUTH_TOKEN='env://ABSENT',KIMI_CODE_BASE_URL='http://owned.invalid')
 for mode in ['absent','sentinel']:
  log=Path(temp)/(mode+'.jsonl');env.update(SYMBRAIN_GO_BINARY=str(Path(temp)/'missing') if mode=='absent' else str(BIN/'sentinel'),USAGE_NEXT_SENTINEL_LOG=str(log),USAGE_NEXT_SENTINEL_GO=str(BIN/'go-usage'))
  for i,args in enumerate(vectors):
   old=log.read_bytes() if log.exists() else b''
   actual={name:invoke(BIN/file,args,env,home) for name,file in [('go','go-usage'),('native','native-usage'),('parent','parent-usage')]}
   new=log.read_bytes() if log.exists() else b''
   rows.append(dict(mode=mode,id=i,argv_hex=[a.hex() for a in args],observed=actual,candidate_equal=actual['native']==actual['go'],filesystem_unchanged=state(home)==before,sentinel_bytes=(new[len(old):]).hex()))
result=dict(head=subprocess.check_output(['git','-C',str(ROOT),'rev-parse','HEAD'],text=True).strip(),binaries={str(BIN/f):sha(BIN/f) for f in ['go-usage','native-usage','parent-usage','sentinel']},cases=len(rows),matched=sum(r['candidate_equal'] for r in rows),readonly=all(r['filesystem_unchanged'] for r in rows),records=rows)
out=Path('/tmp/symaira-usage768-next-independent-extra-argv.json');out.write_text(json.dumps(result,indent=2)+'\n')
print('Extra argv:',result['matched'],'/',result['cases'],'matched; readonly',result['readonly'])
for row in rows:
 if not row['candidate_equal']:print('DIFFERENCE',row['mode'],row['id'],row['argv_hex'],row['observed'])
