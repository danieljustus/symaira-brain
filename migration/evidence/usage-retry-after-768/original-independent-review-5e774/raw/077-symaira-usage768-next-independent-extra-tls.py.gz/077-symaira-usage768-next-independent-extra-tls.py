import datetime,hashlib,importlib.util,ipaddress,json,os,shutil,subprocess,tempfile
from pathlib import Path
from cryptography import x509
from cryptography.hazmat.primitives import hashes,serialization
from cryptography.hazmat.primitives.asymmetric import ec
from cryptography.x509.oid import NameOID
REPO=Path('/workspace/symaira-usage768-remaining'); OLD=Path('/tmp/symaira-usage768-next-final-next.evidence'); SOURCE=REPO
OUT=Path('/tmp/symaira-usage768-next-independent-extra-tls.evidence');OUT.mkdir(exist_ok=True)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def run(label,command,env,cwd):
 p=subprocess.run(command,env=env,cwd=cwd,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=120)
 (OUT/(label+'.log')).write_bytes(p.stdout); print(label,p.returncode,flush=True);return p.returncode
hosts=['api.kimi.com','www.kimi.com','api.anthropic.com','chatgpt.com','api.github.com','cursor.com','api.moonshot.ai','portal.nousresearch.com','opencode.ai','openrouter.ai']
# Own supplemental peer serves fixtures for all 2xx statuses, preserving the original peer file.
text=(REPO/'scripts/usage-next-oracle/peer.py').read_text().replace('elif status==200','elif 200<=status<300')
peerpath=OUT/'peer.py';peerpath.write_text(text)
spec=importlib.util.spec_from_file_location('owned_extra_peer',peerpath);module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
with tempfile.TemporaryDirectory(prefix='usage-independent-tls-') as directory:
 root=Path(directory);key=ec.generate_private_key(ec.SECP256R1());name=x509.Name([x509.NameAttribute(NameOID.COMMON_NAME,'Independent owned Usage CA')]); now=datetime.datetime.now(datetime.timezone.utc)
 ca=x509.CertificateBuilder().subject_name(name).issuer_name(name).public_key(key.public_key()).serial_number(1).not_valid_before(now-datetime.timedelta(days=1)).not_valid_after(now+datetime.timedelta(days=1)).add_extension(x509.BasicConstraints(ca=True,path_length=None),critical=True).add_extension(x509.KeyUsage(digital_signature=True,content_commitment=False,key_encipherment=False,data_encipherment=False,key_agreement=False,key_cert_sign=True,crl_sign=True,encipher_only=False,decipher_only=False),critical=True).sign(key,hashes.SHA256())
 leaf=x509.CertificateBuilder().subject_name(x509.Name([x509.NameAttribute(NameOID.COMMON_NAME,'api.kimi.com')])).issuer_name(name).public_key(key.public_key()).serial_number(2).not_valid_before(now-datetime.timedelta(days=1)).not_valid_after(now+datetime.timedelta(days=1)).add_extension(x509.BasicConstraints(ca=False,path_length=None),critical=True).add_extension(x509.SubjectAlternativeName([x509.DNSName(h) for h in hosts]+[x509.IPAddress(ipaddress.ip_address('127.0.0.1'))]),critical=False).add_extension(x509.ExtendedKeyUsage([x509.oid.ExtendedKeyUsageOID.SERVER_AUTH]),critical=False).sign(key,hashes.SHA256())
 for name,data in [('ca.pem',ca.public_bytes(serialization.Encoding.PEM)),('leaf.pem',leaf.public_bytes(serialization.Encoding.PEM)),('key.pem',key.private_bytes(serialization.Encoding.PEM,serialization.PrivateFormat.PKCS8,serialization.NoEncryption()))]: (root/name).write_bytes(data)
 for name in ['ca.pem','leaf.pem']:shutil.copyfile(root/name,OUT/name)
 cases=json.loads((OLD/'input.json').read_text()); statuses=json.loads((OLD/'status-input.json').read_text());mapping=[('success201',201,'success'),('malformed202',202,'malformed'),('empty204',204,'empty'),('success206',206,'success'),('error400',400,'400'),('error404',404,'404'),('error503',503,'503')]
 for index,row in enumerate(statuses):
  title,status,kind=mapping[index%7];row.update(id='independent-'+row['provider']+'-'+row['source']+'-'+title,status=status,kind=kind,responses=[status]*4)
 for name,rows in [('input.json',cases),('status-input.json',statuses)]: (OUT/name).write_text(json.dumps(rows,indent=2)+'\n')
 bounds=[dict(id=f'transport-bound-{status}-{kind}',responses=[status],kind='transport-bound',length=1048576+(kind=='over')) for status in [200,401] for kind in ['exact','over']]
 peer=module.Peer(root,cases+statuses+bounds,(OLD/'api.json').read_bytes(),(OLD/'web.json').read_bytes());peer.fixtures={row['fixture']:(SOURCE/'internal/usage/testdata'/row['fixture']).read_bytes() for row in statuses}
 env=os.environ.copy();env.update(USAGE_REMAINING_INPUT=str(OUT/'input.json'),USAGE_REMAINING_ROOT=str(root/'homes'),USAGE_REMAINING_OUTPUT=str(OUT/'go.json'),USAGE_DEVICE_CA=str(root/'ca.pem'),USAGE_DEVICE_API=str(OLD/'api.json'),USAGE_DEVICE_WEB=str(OLD/'web.json'),USAGE_STATUS_ROOT=str(root/'status-homes'),USAGE_STATUS_INPUT=str(OUT/'status-input.json'),USAGE_STATUS_GO=str(OUT/'status-go.json'),USAGE_STATUS_HOSTS='|'+'||'.join(hosts)+'|')
 exits={}
 try:
  exits['go-canned']=run('go-canned',[str(OLD/'go-provider-tests'),'-test.run','^TestRemainingDeviceBaseline768$','-test.count=1'],env,SOURCE/'internal/usage')
  env.update(USAGE_DEVICE_PEER=peer.address,USAGE_REMAINING_OUTPUT=str(OUT/'go-wire.json'))
  exits['go-wire']=run('go-wire',[str(OLD/'go-provider-tests'),'-test.run','^TestRemainingDeviceBaseline768$','-test.count=1'],env,SOURCE/'internal/usage')
  exits['go-status']=run('go-status',[str(OLD/'go-provider-tests'),'-test.run','^TestUsageStatusTLS768$','-test.count=1'],env,SOURCE/'internal/usage')
  peer.phase='rust';env.update(USAGE_DEVICE_GO=str(OUT/'go.json'),USAGE_DEVICE_WIRE_GO=str(OUT/'go-wire.json'),USAGE_DEVICE_NATIVE=str(OUT/'native.json'),USAGE_STATUS_NATIVE=str(OUT/'status-native.json'))
  exits['native']=run('native',[str(OLD/'native-provider-tests'),'device_oracle_matches_fresh_go','--ignored','--nocapture'],env,REPO)
 finally:
  peer.close();(OUT/'wire.json').write_text(json.dumps(peer.rows,indent=2)+'\n')
 result=dict(head=subprocess.check_output(['git','-C',str(REPO),'rev-parse','HEAD'],text=True).strip(),binaries={str(OLD/name):sha(OLD/name) for name in ['go-provider-tests','native-provider-tests']},cases=84,additional_statuses=[201,202,204,206,400,404,503],exits=exits,wire_rows=len(peer.rows),peer_errors=peer.errors,proofs={str(p):sha(p) for p in OUT.iterdir() if p.is_file()},scope='Read-only existing exact source-bound executables, independently owned CA/hostname-verified private TLS original public DNS names pinned to own loopback, no compiler/operator/provider network. Original64/57 device and4bounds retained as executable prerequisites;84 new status/body comparisons. Original fixtures/candidate unchanged; private duplicate input/peer explicit.')
 Path('/tmp/symaira-usage768-next-independent-extra-tls.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:result[k] for k in ['cases','exits','wire_rows','peer_errors']}))
