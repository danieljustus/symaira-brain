#!/usr/bin/env bash
set -euo pipefail
umask 022
cd /workspace/symaira-usage768-remaining
. /home/agent/.cargo/env
export PATH=/workspace/toolchains/go1.26.7/bin:$PATH
export CARGO_TARGET_DIR=/workspace/symaira-usage768-remaining/target
export CARGO_INCREMENTAL=0 CARGO_PROFILE_DEV_DEBUG=0 CARGO_PROFILE_TEST_DEBUG=0 CARGO_BUILD_JOBS=2
prefix=/tmp/symaira-usage768-next-independent
assert_space() {
 python3 - <<'PY'
import shutil
space=shutil.disk_usage('/workspace').free
assert space>=700000000,space
print('Headroom',space)
PY
}
stage() {
 local label=$1
 shift
 assert_space
 printf '%s\n' "Running $label"
 if "$@" >"$prefix-$label.log" 2>&1; then tail -n 8 "$prefix-$label.log"; else local code=$?; tail -n 100 "$prefix-$label.log" >&2; return "$code"; fi
}
[[ $(git rev-parse HEAD) == 5e77418ff03491df61a74dcd6435eeb5b4496260 ]]
[[ -z $(git status --porcelain) ]]
stage local bash scripts/usage-copilot-kimi-oracle/run.sh "$prefix-local.json"
stage next bash scripts/usage-next-oracle/run.sh "$prefix-next.json"
stage files bash scripts/usage-provider-files-oracle/run.sh "$prefix-files.json"
stage hermes bash scripts/usage-hermes-oracle/run.sh "$prefix-hermes.json"
stage refs bash scripts/usage-credential-oracle/run.sh "$prefix-refs.json"
stage fetch bash scripts/usage-fetch-oracle/run.sh "$prefix-fetch.json"
stage tests cargo test --locked -p symbrain-cli -p symbrain-usage --all-features
stage clippy cargo clippy --locked -p symbrain-cli -p symbrain-usage --all-targets --all-features -- -D warnings
stage fmt cargo fmt --all -- --check
stage actionlint /workspace/toolchains/bin/actionlint .github/workflows/ci.yml
[[ -z $(git status --porcelain) ]]
sha256sum "$CARGO_TARGET_DIR/debug/symbrain" > "$prefix-final-cli-sha256.txt"
