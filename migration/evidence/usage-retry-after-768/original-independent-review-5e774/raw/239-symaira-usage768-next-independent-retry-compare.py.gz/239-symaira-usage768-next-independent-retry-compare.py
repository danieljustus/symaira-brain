import hashlib,json,subprocess
from pathlib import Path
caller=Path('/tmp/symaira-usage768-next-independent-retry-caller');root=Path('/tmp/symaira-usage768-next-independent-extra-retry-grammar.evidence');inputs={r['id']:r for r in json.loads((root/'status-input.json').read_text())};rows=[]
for go in json.loads((root/'status-go.json').read_text()):
 original=inputs[go['id']];p=subprocess.run([str(caller),go['provider'],original['retry_after']],capture_output=True,timeout=10)
 assert p.returncode==0,(go['id'],p)
 native=p.stdout.decode().rstrip('\n');expected=go['report']['providers'][0]['error']
 rows.append(dict(id=go['id'],provider=go['provider'],source=go['input']['source'],header=original['retry_after'],actual_go_error=expected,actual_native_error=native,exact_error_equal=expected==native,full_native_mock_report_debug=p.stderr.decode(),full_go_constructor_tls_report=go['report'],native_mock_exit=p.returncode))
result=dict(head='5e77418ff03491df61a74dcd6435eeb5b4496260',source='c0ae71c0bc0a5e39c65458484f1024d5940a19aa',cases=len(rows),matches=sum(r['exact_error_equal']for r in rows),differences=sum(not r['exact_error_equal']for r in rows),records=rows,caller_sha256=hashlib.sha256(caller.read_bytes()).hexdigest(),rlib_sha256='128db8cbdb0b5e153b4c3fba4abe9c33a0f17b7530a2922edfab7e005aa39efa',scope='84 actual frozen-Go ownedTLS constructor reports versus84 fresh native public Service/Provider.fixture ownedMock429 response/error observations. Full native mock debug reports retained; auth/source fixture metadata is not claimed constructor-identical. Actual first native full-constructor/TLS failure separately retained; nonfinite/overflow Go int results are Linux-amd64 observations only, no native3 claim.')
Path('/tmp/symaira-usage768-next-independent-retry-compare.json').write_text(json.dumps(result,indent=2)+'\n');print('Retry grammar',result['matches'],'matched',result['differences'],'differ')
for row in rows[:7]:print(row['header'],repr(row['actual_go_error']),repr(row['actual_native_error']))
