use std::{collections::BTreeMap,sync::Arc};
use symbrain_usage::{Provider,Request,Response,Service,Transport};
struct Owned(String);
impl Transport for Owned {
 fn request(&self,_request:Request)->Result<Response,String>{
  Ok(Response{status:429,body:b"{}".to_vec(),headers:BTreeMap::from([("retry-after".into(),self.0.clone())])})
 }
}
fn main(){
 let mut args=std::env::args().skip(1);let provider=args.next().unwrap();let header=args.next().unwrap();
 let report=Service::with_transport(vec![Provider::fixture(&provider,&provider)],Arc::new(Owned(header))).report();
 println!("{}",report.providers[0].error.as_deref().unwrap_or("MISSING ERROR"));
 eprintln!("{report:?}");
}
