#![deny(unsafe_code)]

#[cfg(unix)]
mod unix {
    use std::{
        fs,
        io::{BufRead, BufReader, Write},
        os::unix::fs::{FileTypeExt, PermissionsExt},
        path::{Path, PathBuf},
        sync::{
            Arc, Barrier,
            atomic::{AtomicBool, AtomicU64, Ordering},
        },
        thread,
        time::{Duration, Instant},
    };

    use sha2::{Digest, Sha256};
    use symbrowse_daemon::{
        Client, ClientOptions, Frame, Response, Server, ServerError, ServerOptions, codes,
        connect_unix,
    };

    static NEXT: AtomicU64 = AtomicU64::new(1);

    #[test]
    fn socket_lifecycle_permissions_status_and_stop() {
        let root = root("lifecycle");
        let socket = root.join("run/default.sock");
        let server = Arc::new(
            Server::new(ServerOptions {
                socket_path: socket.clone(),
                session: "default".to_owned(),
                idle_timeout: None,
                ..Default::default()
            })
            .unwrap(),
        );
        let running = server.clone();
        let thread = thread::spawn(move || running.listen_and_serve());
        wait_for_socket(&socket);
        let metadata = fs::symlink_metadata(&socket).unwrap();
        assert!(metadata.file_type().is_socket());
        assert_eq!(metadata.permissions().mode() & 0o777, 0o600);
        assert_eq!(
            fs::metadata(socket.parent().unwrap())
                .unwrap()
                .permissions()
                .mode()
                & 0o777,
            0o700
        );

        let client = Client::new(ClientOptions {
            socket_path: socket.clone(),
            session: "default".to_owned(),
            autostart: false,
            ..Default::default()
        });
        let status = client
            .request_without_autostart(Frame {
                cmd: "daemon.status".to_owned(),
                ..Default::default()
            })
            .unwrap();
        assert!(status.success);
        assert_eq!(status.data.as_ref().unwrap()["running"], true);

        let mut stream = std::os::unix::net::UnixStream::connect(&socket).unwrap();
        stream
            .write_all(b"{\"cmd\":\"daemon.ping\"}\n{\"cmd\":\"daemon.ping\"}\n")
            .unwrap();
        let mut reader = BufReader::new(stream);
        for _ in 0..2 {
            let mut line = String::new();
            reader.read_line(&mut line).unwrap();
            let response: Response = serde_json::from_str(&line).unwrap();
            assert!(response.success);
            assert_eq!(response.data.unwrap()["pong"], true);
        }

        let stop = client
            .request_without_autostart(Frame {
                cmd: "daemon.stop".to_owned(),
                ..Default::default()
            })
            .unwrap();
        assert!(stop.success);
        assert!(thread.join().unwrap().is_ok());
        assert!(!socket.exists());
        fs::remove_dir_all(root).unwrap();
    }

    #[test]
    #[allow(clippy::result_large_err)]
    fn unix_listener_shutdown_runs_runtime_cleanup_hook() {
        let root = root("shutdown-hook");
        let socket = root.join("default.sock");
        let cleaned = Arc::new(AtomicBool::new(false));
        let cleanup = cleaned.clone();
        let server = Arc::new(
            Server::new(ServerOptions {
                socket_path: socket.clone(),
                session: "default".to_owned(),
                idle_timeout: None,
                handler: Some(Arc::new(|_, _| Ok((None, Vec::new())))),
                shutdown_handler: Some(Arc::new(move || cleanup.store(true, Ordering::Release))),
                ..Default::default()
            })
            .unwrap(),
        );
        let running = server.clone();
        let thread = thread::spawn(move || running.listen_and_serve());
        wait_for_socket(&socket);

        server.stop();
        assert!(thread.join().unwrap().is_ok());
        assert!(cleaned.load(Ordering::Acquire));
        assert!(!socket.exists());
        fs::remove_dir_all(root).unwrap();
    }

    #[test]
    fn shutdown_does_not_unlink_replacement_socket() {
        let root = root("replacement");
        let socket = root.join("default.sock");
        let server = Arc::new(
            Server::new(ServerOptions {
                socket_path: socket.clone(),
                session: "default".to_owned(),
                idle_timeout: None,
                ..Default::default()
            })
            .unwrap(),
        );
        let running = server.clone();
        let thread = thread::spawn(move || running.listen_and_serve());
        wait_for_socket(&socket);

        // Unlinking the old directory entry does not stop the first listener;
        // a different live listener can publish the same configured path.
        fs::remove_file(&socket).unwrap();
        let replacement = std::os::unix::net::UnixListener::bind(&socket).unwrap();
        let replacement_connection = connect_unix(&socket, Duration::from_secs(1)).unwrap();

        server.stop();
        assert!(thread.join().unwrap().is_ok());
        assert!(socket.exists(), "the replacement socket was unlinked");
        drop(replacement_connection);
        drop(replacement);
        fs::remove_file(&socket).unwrap();
        fs::remove_dir_all(root).unwrap();
    }

    #[test]
    fn stale_socket_is_recovered_but_live_socket_is_not_unlinked() {
        let root = root("stale");
        let socket = root.join("default.sock");
        fs::create_dir_all(&root).unwrap();
        let stale = std::os::unix::net::UnixListener::bind(&socket).unwrap();
        drop(stale);

        let server = Arc::new(
            Server::new(ServerOptions {
                socket_path: socket.clone(),
                session: "default".to_owned(),
                idle_timeout: None,
                ..Default::default()
            })
            .unwrap(),
        );
        let running = server.clone();
        let started = Instant::now();
        let thread = thread::spawn(move || running.listen_and_serve());
        wait_for_listener(&socket);
        let elapsed = started.elapsed();
        assert!(
            elapsed < Duration::from_secs(1),
            "stale socket startup probe blocked for {elapsed:?}"
        );

        let competitor = Server::new(ServerOptions {
            socket_path: socket.clone(),
            session: "default".to_owned(),
            idle_timeout: None,
            ..Default::default()
        })
        .unwrap();
        assert!(matches!(
            competitor.listen_and_serve(),
            Err(ServerError::AlreadyRunning)
        ));
        assert!(socket.exists());
        server.stop();
        assert!(thread.join().unwrap().is_ok());
        fs::remove_dir_all(root).unwrap();
    }

    // Mirrors the pinned Go oracle's TestConcurrentStartupYieldsOneOwner:
    // concurrent recovery of one session must never unlink a live socket and
    // split ownership across multiple daemon instances.
    #[test]
    #[allow(clippy::result_large_err)]
    fn concurrent_unix_starts_have_one_owner_and_recover_after_stop() {
        const STARTERS: usize = 6;

        let root = root("concurrent");
        let socket = root.join("default.sock");
        let barrier = Arc::new(Barrier::new(STARTERS));
        let servers: Vec<_> = (0..STARTERS)
            .map(|_| {
                Arc::new(
                    Server::new(ServerOptions {
                        socket_path: socket.clone(),
                        session: "default".to_owned(),
                        idle_timeout: None,
                        handler: Some(Arc::new(|_, _| {
                            Ok((Some(serde_json::json!({"pong": true})), Vec::new()))
                        })),
                        ..Default::default()
                    })
                    .unwrap(),
                )
            })
            .collect();
        let threads = servers
            .iter()
            .cloned()
            .map(|server| {
                let barrier = barrier.clone();
                thread::spawn(move || {
                    barrier.wait();
                    server.listen_and_serve()
                })
            })
            .collect::<Vec<_>>();

        wait_for_listener(&socket);
        let client = Client::new(ClientOptions {
            socket_path: socket.clone(),
            session: "default".to_owned(),
            autostart: false,
            ..Default::default()
        });
        let response = client
            .request_without_autostart(Frame {
                cmd: "daemon.ping".to_owned(),
                request_id: "race-owner".to_owned(),
                ..Default::default()
            })
            .unwrap();
        assert!(response.success, "ping the surviving daemon: {response:?}");
        assert_eq!(response.data.unwrap()["pong"], true);
        for server in &servers {
            server.stop();
        }
        let results = threads
            .into_iter()
            .map(|thread| thread.join().unwrap())
            .collect::<Vec<_>>();

        assert_eq!(
            results.iter().filter(|result| result.is_ok()).count(),
            1,
            "exactly one concurrent starter owns the endpoint: {results:?}"
        );
        assert_eq!(
            results
                .iter()
                .filter(|result| matches!(result, Err(ServerError::AlreadyRunning)))
                .count(),
            STARTERS - 1,
            "every losing starter must preserve the live owner's socket: {results:?}"
        );
        assert!(!socket.exists(), "owner did not clean up its socket");

        // Once the owner has released its advisory lock and removed its own
        // socket, a fresh same-process daemon can reclaim the endpoint.
        let replacement = Server::new(ServerOptions {
            socket_path: socket,
            session: "default".to_owned(),
            idle_timeout: Some(Duration::from_millis(1)),
            handler: Some(Arc::new(|_, _| Ok((None, Vec::new())))),
            ..Default::default()
        })
        .unwrap();
        assert!(
            replacement.listen_and_serve().is_ok(),
            "released endpoint was not recoverable"
        );
        fs::remove_dir_all(root).unwrap();
    }

    #[test]
    #[allow(clippy::result_large_err)]
    fn operation_timeout_response_keeps_connection_usable_and_matches_go_oracle() {
        const GO_SERVER_COMMIT: &str = "4180a1072245c542e22b5c294894009f1672fdf8";
        const GO_SERVER_SHA256: &str =
            "4dbf19e9c0e067a8e8bf93d5c020875ccda0af2a7e9eb9d00814e19394b38720";
        const GO_TEST_SHA256: &str =
            "32ae1c6e56bb77b00b4773e2694dde6290f40ceb62912984310628bd50faae37";
        let go_server = include_bytes!("../../../internal/daemon/server.go");
        let go_test = include_bytes!("../../../internal/daemon/server_test.go");
        let server_hash: String = Sha256::digest(go_server)
            .iter()
            .map(|byte| format!("{byte:02x}"))
            .collect();
        let test_hash: String = Sha256::digest(go_test)
            .iter()
            .map(|byte| format!("{byte:02x}"))
            .collect();
        assert_eq!(
            server_hash, GO_SERVER_SHA256,
            "Go oracle server at {GO_SERVER_COMMIT}"
        );
        assert_eq!(
            test_hash, GO_TEST_SHA256,
            "Go timeout oracle test at {GO_SERVER_COMMIT}"
        );

        let root = root("timeout-live");
        let socket = root.join("default.sock");
        let cancellation_seen = Arc::new(AtomicBool::new(false));
        let seen = cancellation_seen.clone();
        let server = Arc::new(
            Server::new(ServerOptions {
                socket_path: socket.clone(),
                session: "default".to_owned(),
                idle_timeout: None,
                operation_timeout: Duration::from_millis(10),
                handler: Some(Arc::new(move |_, operation| {
                    while !operation.is_cancelled() {
                        thread::sleep(Duration::from_millis(1));
                    }
                    seen.store(true, Ordering::Release);
                    Ok((None, Vec::new()))
                })),
                ..Default::default()
            })
            .unwrap(),
        );
        let running = server.clone();
        let thread = thread::spawn(move || running.listen_and_serve());
        let startup_deadline = Instant::now() + Duration::from_secs(2);
        while Instant::now() < startup_deadline {
            if fs::symlink_metadata(&socket)
                .map(|metadata| metadata.permissions().mode() & 0o777 == 0o600)
                .unwrap_or(false)
            {
                break;
            }
            if thread.is_finished() {
                panic!("server startup failed: {:?}", thread.join().unwrap());
            }
            thread::sleep(Duration::from_millis(5));
        }
        let mut stream = std::os::unix::net::UnixStream::connect(&socket).unwrap();
        stream
            .set_read_timeout(Some(Duration::from_secs(2)))
            .unwrap();
        for frame in [
            Frame {
                cmd: "slow".to_owned(),
                session: "default".to_owned(),
                ..Default::default()
            },
            Frame {
                cmd: "daemon.ping".to_owned(),
                session: "default".to_owned(),
                ..Default::default()
            },
        ] {
            stream
                .write_all(&serde_json::to_vec(&frame).unwrap())
                .unwrap();
            stream.write_all(b"\n").unwrap();
        }
        let mut reader = BufReader::new(stream);
        let mut line = String::new();
        reader.read_line(&mut line).unwrap();
        let timeout: Response = serde_json::from_str(&line).unwrap();
        assert!(!timeout.success);
        let error = timeout.error.unwrap();
        assert_eq!(error.code, codes::OPERATION_TIMEOUT);
        assert_eq!(error.message, "daemon operation exceeded its timeout");
        line.clear();
        reader.read_line(&mut line).unwrap();
        let ping: Response = serde_json::from_str(&line).unwrap();
        assert!(ping.success, "connection unusable after timeout: {ping:?}");
        assert_eq!(ping.data.unwrap()["pong"], true);
        let deadline = Instant::now() + Duration::from_secs(1);
        while !cancellation_seen.load(Ordering::Acquire) && Instant::now() < deadline {
            thread::sleep(Duration::from_millis(1));
        }
        assert!(cancellation_seen.load(Ordering::Acquire));
        server.stop();
        assert!(thread.join().unwrap().is_ok());
        fs::remove_dir_all(root).unwrap();
    }

    fn wait_for_socket(path: &Path) {
        let deadline = Instant::now() + Duration::from_secs(2);
        while Instant::now() < deadline {
            if fs::symlink_metadata(path)
                .map(|metadata| metadata.permissions().mode() & 0o777 == 0o600)
                .unwrap_or(false)
            {
                return;
            }
            thread::sleep(Duration::from_millis(5));
        }
        panic!("secured socket was not created: {}", path.display());
    }

    fn wait_for_listener(path: &Path) {
        let deadline = Instant::now() + Duration::from_secs(2);
        while Instant::now() < deadline {
            if connect_unix(path, Duration::from_millis(100)).is_ok() {
                return;
            }
            thread::sleep(Duration::from_millis(5));
        }
        panic!("socket did not accept connections: {}", path.display());
    }

    fn root(name: &str) -> PathBuf {
        std::env::temp_dir().join(format!(
            "symbrowse-daemon-{name}-{}-{}",
            std::process::id(),
            NEXT.fetch_add(1, Ordering::Relaxed)
        ))
    }
}
