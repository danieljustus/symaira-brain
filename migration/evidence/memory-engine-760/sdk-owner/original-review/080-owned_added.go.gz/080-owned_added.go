package fmt
func ownedAdditionalInput() {}
