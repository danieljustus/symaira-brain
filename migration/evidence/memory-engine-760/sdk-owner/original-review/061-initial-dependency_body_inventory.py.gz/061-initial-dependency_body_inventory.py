import pathlib,json,hashlib,tomllib,sys,zipfile,tarfile,shutil
sys.dont_write_bytecode=True
r=pathlib.Path('/workspace/symaira-memory760-hermetic-build');out=pathlib.Path('/workspace/review-proof/memory760-780-independent-source');sdk=pathlib.Path('/workspace/toolchains/go1.26.7');go=pathlib.Path('/workspace/oracles/daemon772-go-source');sys.path.insert(0,str(r/'scripts/memory-engine-oracle'));import dependencies
pinned=json.loads((r/'scripts/memory-engine-oracle/dependency-inputs.json').read_text());bound=json.loads((r/'scripts/memory-engine-oracle/trusted.json').read_text())['sdk_platforms']['linux-x86_64']['go'];known=set(bound['files'])|set(bound['source_files']);refs=[]
for name in ['src/cmd/go/internal/base/goflags.go','src/cmd/go/internal/work/gc.go',*['pkg/include/'+p.name for p in sorted((sdk/'pkg/include').iterdir())]]:
 p=sdk/name;dest=out/'finding-sdk-source'/name;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,dest);refs.append({'path':str(p),'sha256':dependencies.sha(p),'bytes':p.stat().st_size,'in_trusted_sdk_map':name in known,'preserved':str(dest)})
assert all(not x['in_trusted_sdk_map'] for x in refs if '/pkg/include/' in x['path'])
(out/'sdk-omitted-includes-source.json').write_text(json.dumps({'behavior_executed':False,'references':refs,'go_env_in_trusted_sdk_map':'go.env' in known},indent=2)+'\n')
rows=[];missing={'cargo':[],'go':[]};cache=pathlib.Path('/home/agent/.cargo');gc=pathlib.Path('/home/agent/go/pkg/mod')
for package in tomllib.loads((r/'Cargo.lock').read_text())['package']:
 if not package.get('source','').startswith('registry+'):continue
 name=package['name']+'-'+package['version'];rel='registry/cache/'+pinned['registry']+'/'+name+'.crate';p=cache/rel
 if not p.exists():missing['cargo'].append(name);continue
 assert dependencies.sha(p)==package['checksum']; names=set()
 with tarfile.open(p,'r:gz') as archive:
  for item in archive:
   path=pathlib.PurePosixPath(item.name);assert item.name not in names and not path.is_absolute() and '..' not in path.parts and path.parts and path.parts[0]==name and (item.isfile() or item.isdir());names.add(item.name)
 rows.append({'role':'cargo','path':rel,'sha256':package['checksum'],'members':len(names)})
for line in (go/'go.sum').read_text().splitlines():
 module,version,want=line.split();base='cache/download/'+dependencies.escaped(module)+'/@v/'+dependencies.escaped(version.removesuffix('/go.mod'));rel=base+('.mod' if version.endswith('/go.mod') else '.zip');p=gc/rel
 if not p.exists():missing['go'].append(rel);continue
 if version.endswith('/go.mod'):actual=dependencies.hash1({'go.mod':p.read_bytes()});members=1
 else:
  files={}
  with zipfile.ZipFile(p) as archive:
   names=archive.namelist();assert len(names)==len(set(names))
   for item in archive.infolist():
    path=pathlib.PurePosixPath(item.filename);assert not item.is_dir() and item.filename.startswith(module+'@'+version+'/') and '..' not in path.parts and not path.is_absolute();files[item.filename]=archive.read(item)
  actual=dependencies.hash1(files);members=len(files)
 assert actual==want;rows.append({'role':'go','path':rel,'sha256':dependencies.sha(p),'h1':want,'members':members})
# Offline metadata has already been independently checked against its fixed map.
original=json.loads((r/'migration/evidence/memory-engine-760/hermetic-build/current/dependency-availability.json').read_text());old_go=original['go_missing'];old_cargo=original['cargo_missing']
summary={'classification':'read-only-dependency-body-and-availability-check-no-SDK','verified_archive_or_mod_bodies':rows,'currently_missing':missing,'recorded_preparation_missing':original,'current_missing_count':{k:len(v) for k,v in missing.items()},'sdk_or_compiler_product_executions':0,'candidate_changed':False}
(out/'dependency-body-verification.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps({'verified_bodies':len(rows),'missing':summary['current_missing_count'],'recorded_missing':{'cargo':len(old_cargo),'go':len(old_go)}},indent=2))
