import pathlib,json,hashlib,gzip,subprocess,sys,time,ast,collections,shutil
sys.dont_write_bytecode=True
root=pathlib.Path('/workspace/symaira-memory760-hermetic-build');out=pathlib.Path('/workspace/review-proof/memory760-780-independent-source');go=pathlib.Path('/workspace/oracles/daemon772-go-source')
head='7804d91b6f7b712a9d8fdfa68160bb8375b07a60';parent='c5e8a4db8e9159fbaecd88c791f1486b496fc755';base='a30bba8bbd52323fa5e000207f1c391d576ac86c'
def sha(b):return hashlib.sha256(b).hexdigest()
def pathsha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1<<20),b''):h.update(b)
 return h.hexdigest()
def git(*args,cwd=root,input=None):return subprocess.check_output(['/usr/bin/git','-c','core.fsmonitor=false','-c','core.hooksPath=/dev/null',*args],cwd=cwd,input=input,env={'GIT_CONFIG_NOSYSTEM':'1','GIT_CONFIG_GLOBAL':'/dev/null','GIT_CONFIG_SYSTEM':'/dev/null'})
def tree(rev):
 result={}
 for record in git('ls-tree','-rz',rev).split(b'\0'):
  if record:
   detail,name=record.split(b'\t',1); mode,typ,oid=detail.decode().split();assert typ=='blob';result[name.decode()]={'mode':mode,'git_blob':oid}
 return result
assert git('rev-parse','HEAD').decode().strip()==head;assert git('status','--porcelain=v1','--untracked-files=all')==b''
handoff=json.loads((out/'author-final-handoff.json').read_text());current=tree(head);prior=tree(parent)
unchanged=[p for p in prior if current.get(p)==prior[p]];deltas=[p for p in current if current[p]!=prior.get(p)];assert len(unchanged)==4325 and len(deltas)==36 and len(prior)==4330 and len(current)==4361
packed=git('cat-file','--batch',input=''.join(head+':'+p+'\n' for p in current).encode());pos=0
for name in current:
 end=packed.index(b'\n',pos);record=packed[pos:end].split();assert len(record)==3 and record[1]==b'blob';size=int(record[2]);pos=end+1;body=packed[pos:pos+size];pos+=size;assert packed[pos:pos+1]==b'\n';pos+=1;current[name].update(bytes=size,sha256=sha(body))
 if (root/name).is_file(): assert pathsha(root/name)==sha(body)
assert pos==len(packed)
for row in handoff['changed']: assert current[row['path']]['sha256']==row['sha256'] and current[row['path']]['bytes']==row['bytes']
(out/'full-current-index.json').write_text(json.dumps({'source':head,'files':current},indent=2)+'\n')
original=json.loads((root/'migration/evidence/memory-engine-760/static-validation.json').read_text())['protected_original_source_and_manifest_files'];assert len(original)==1777
original_changes=[]
for row in original:
 assert sha(git('show',base+':'+row['path']))==row['sha256']
 if current[row['path']]['sha256']!=row['sha256']:original_changes.append(row['path'])
assert original_changes==[]; lib='rust/symbrain-memory/src/lib.rs'; old=git('show',base+':'+lib);new=git('show',head+':'+lib);assert new.replace(b'pub mod engine;\n',b'',1)==old
trusted=json.loads((root/'scripts/memory-engine-oracle/trusted.json').read_text());assert git('rev-parse','HEAD',cwd=go).decode().strip()==trusted['frozen_go_commit'];assert git('status','--porcelain=v1',cwd=go)==b''
frozen=[]
for name,want in trusted['frozen_go_sources'].items():
 p=go/name;observed=pathsha(p);assert observed==want;frozen.append({'path':name,'sha256':observed,'bytes':p.stat().st_size})
assert len(frozen)==1219
(out/'frozen-go-readonly.json').write_text(json.dumps({'source':trusted['frozen_go_commit'],'rows':frozen},indent=2)+'\n')
sdk_orig=json.loads(gzip.decompress((root/'migration/evidence/memory-engine-760/hermetic-build/original-review/014-sdk-bytes-verification.json.gz').read_bytes()));sdk=[]
for row in sdk_orig['rows']:
 p=pathlib.Path(row['path']);assert pathsha(p)==row['sha256'] and p.stat().st_size==row['size'];sdk.append(row)
assert len(sdk)==7947
(out/'sdk-readonly-current.json').write_text(json.dumps({'sdk_behavior_executed':False,'rows':sdk},indent=2)+'\n')
pinned=json.loads((root/'scripts/memory-engine-oracle/dependency-inputs.json').read_text());available=[];missing=[]
for role,folder,maps in [('cargo',pathlib.Path('/home/agent/.cargo'),[pinned['cargo_metadata'],pinned['cargo_git_database']]),('go',pathlib.Path('/home/agent/go/pkg/mod'),[pinned['go_metadata']])]:
 for mapping in maps:
  for name,want in mapping.items():
   p=folder/name
   if not p.exists():missing.append({'role':role,'path':name});continue
   assert pathsha(p)==want;available.append({'role':role,'path':name,'sha256':want,'bytes':p.stat().st_size})
sys.path.insert(0,str(root/'scripts/memory-engine-oracle'));import reader
kit=reader.blob_map(pathlib.Path('/home/agent/.cargo')/pinned['git_database_dir'],pinned['git_revision']);assert kit==pinned['git_source_blobs'] and len(kit)==456
(out/'fixed-dependency-inputs-readonly.json').write_text(json.dumps({'available':available,'missing':missing,'corekit':kit,'corekit_revision':pinned['git_revision'],'reader_git_sha256':pathsha(pathlib.Path(pinned['source_reader_git']['path'])),'archives_admitted':False},indent=2)+'\n')
api=json.loads((root/'migration/evidence/memory-engine-760/go-api-census.json').read_text())['functions'];calls=json.loads((root/'migration/evidence/memory-engine-760/production-callsite-census.json').read_text())['calls']
for row in api+calls:
 lines=(go/row['path']).read_text().splitlines();assert lines[row['line']-1].strip()==row['declaration'].strip()
binding=json.loads((root/'migration/evidence/memory-engine-760/frozen-go-binding.json').read_text());paths=binding['same_original_engine_paths'];declarations=[]
for path in paths:
 if path.endswith('_test.go'):continue
 for number,line in enumerate((go/path).read_text().splitlines(),1):
  if line.startswith('func '):declarations.append((path,number,line))
assert len(declarations)==115 and {(r['path'],r['line'],r['declaration']) for r in api}==set(declarations)
assert len(calls)==22 and len(paths)==39
parsed=[]
for p in (root/'scripts/memory-engine-oracle').glob('*.py'):ast.parse(p.read_bytes(),filename=str(p));parsed.append(str(p.relative_to(root)))
case=(root/'scripts/memory-engine-oracle/cases.json').read_bytes();values=json.loads(case);assert sha(case)==trusted['cases_sha256'] and [[v['id'],v['operation']] for v in values]==trusted['case_identities'];assert len(values)==60
helper=root/'scripts/memory-engine-oracle/oracle_test.go.txt';assert pathsha(helper)==trusted['go_helper_sha256'];assert current['Cargo.lock']['sha256']==pinned['cargo_lock_sha256'] and pathsha(go/'go.sum')==pinned['go_sum_sha256']
new_script_files=[p for p in deltas if p.endswith('.py')];assert all(len((root/p).read_text().splitlines())<400 for p in new_script_files)
assert git('status','--porcelain=v1','--untracked-files=all')==b'' and git('rev-parse','HEAD').decode().strip()==head
for rel in ['src/cmd/go/internal/base/goflags.go']:
 p=pathlib.Path('/workspace/toolchains/go1.26.7')/rel;dest=out/'finding-sdk-source'/rel;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,dest)
summary={'source':head,'status':'SOURCE_ONLY_VERIFIED','full_current_git_blob_files':len(current),'parent_git_blob_files':len(prior),'unchanged_parent_paths':len(unchanged),'delta':len(deltas),'original_protected_files':len(original),'original_protected_changes':original_changes,'frozen_go_files':len(frozen),'sdk_current_hashes_verified':len(sdk),'fixed_dependency_inputs_available':len(available),'fixed_dependency_inputs_missing':len(missing),'fixed_corekit_git_blobs':len(kit),'census_functions':len(api),'census_calls':len(calls),'frozen_engine_files':len(paths),'python_ast_files':len(parsed),'original_cases':len(values),'operation_counts':dict(collections.Counter(v['operation'] for v in values)),'actual_sdk_compiler_product_store_http_port_executions':0,'candidate_unchanged':True}
(out/'source-verification-summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary,indent=2))
