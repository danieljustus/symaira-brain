"""Unchanged sdks predicate over owned synthetic SDK files; no SDK execution."""
import hashlib
import importlib.util
import json
from pathlib import Path
import sys
from unittest.mock import patch

sys.dont_write_bytecode = True
CHECKOUT = Path('/workspace/symaira-memory760-hermetic-build')
HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(CHECKOUT/'scripts/memory-engine-oracle'))
import binding


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def main():
    root = HERE/'sdk-projection-owned'
    root.mkdir(exist_ok=False)
    go, rust = root/'go', root/'rust'
    selected = {'go': {'bin/go': b'owned synthetic Go tool bytes',
                       'src/fmt/doc.go': b'package fmt\n'},
                'rust': {'bin/cargo': b'owned synthetic Cargo tool bytes',
                         'bin/rustc': b'owned synthetic Rust tool bytes'}}
    for role, records in selected.items():
        for name, body in records.items():
            path = root/role/name
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_bytes(body)
    plan = {'sdk_platforms': {'linux-x86_64': {
        'go': {'files': {'bin/go': digest(selected['go']['bin/go'])},
               'source_files': {'src/fmt/doc.go': digest(selected['go']['src/fmt/doc.go'])}},
        'rust': {'files': {name: digest(body) for name, body in selected['rust'].items()}}}}}
    observations = []
    with patch.object(binding, 'trusted', return_value=plan), \
         patch.object(binding.platform, 'system', return_value='Linux'), \
         patch.object(binding.platform, 'machine', return_value='x86_64'):
        original = binding.sdks(go, rust)
        observations.append({'control': 'known-only', 'accepted': True})
        added = go/'src/fmt/owned_added.go'
        added.write_bytes(b'package fmt\nfunc ownedAdditionalInput() {}\n')
        after_source = binding.sdks(go, rust)
        assert after_source == original
        observations.append({'control': 'additional-stdlib-Go-source', 'accepted': True,
                             'map_unchanged': True, 'added_sha256': digest(added.read_bytes())})
        config = go/'go.env'
        config.write_bytes(b'GOFLAGS=-tags=owned_sdk_config\n')
        after_config = binding.sdks(go, rust)
        assert after_config == original
        observations.append({'control': 'GOROOT-go.env', 'accepted': True,
                             'map_unchanged': True, 'added_sha256': digest(config.read_bytes())})
        (go/'src/fmt/doc.go').write_bytes(b'altered known input')
        try:
            binding.sdks(go, rust)
        except ValueError as error:
            assert 'unbound SDK bytes' in str(error)
            observations.append({'control': 'known-file-change', 'accepted': False,
                                 'diagnostic': str(error)})
        else:
            raise AssertionError('positive guard did not reject a bound input change')
    actual_plan = json.loads((CHECKOUT/'scripts/memory-engine-oracle/trusted.json').read_bytes())
    actual_go = actual_plan['sdk_platforms']['linux-x86_64']['go']
    assert 'go.env' not in actual_go['files'] and 'go.env' not in actual_go['source_files']
    sources = {}
    for relative in ['src/cmd/go/internal/cfg/cfg.go', 'src/go/build/build.go',
                     'src/cmd/go/internal/modindex/scan.go', 'go.env']:
        path = Path('/workspace/toolchains/go1.26.7')/relative
        body = path.read_bytes()
        dest = HERE/'finding-sdk-source'/relative
        dest.parent.mkdir(parents=True, exist_ok=True)
        dest.write_bytes(body)
        sources[str(path)] = {'sha256': digest(body), 'bytes': len(body), 'preserved': str(dest)}
    record = {'classification': 'synthetic-source-predicate-projection-not-SDK-runtime',
              'candidate': '7804d91b6f7b712a9d8fdfa68160bb8375b07a60',
              'binding_sha256': digest((CHECKOUT/'scripts/memory-engine-oracle/binding.py').read_bytes()),
              'mocked_inputs': ['trusted SDK envelope', 'platform identity'],
              'unmodified_function': 'binding.sdks', 'observations': observations,
              'actual_sdk_source_reference_bindings': sources,
              'sdk_compiler_product_executions': 0, 'target_or_cache_allocation': False}
    (HERE/'sdk-input-projection.json').write_text(json.dumps(record, indent=2)+'\n')
    print(json.dumps(record, indent=2))


if __name__ == '__main__':
    main()
