fn main(){println!("cargo:rustc-cfg=owned_untracked_configuration");}
