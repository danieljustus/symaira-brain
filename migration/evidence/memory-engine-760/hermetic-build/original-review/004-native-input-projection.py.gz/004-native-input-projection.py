"""Exact reviewed source_map predicate, synthetic Git adapter, no SDK/product."""
import hashlib,importlib.util,json,subprocess
from pathlib import Path
from unittest.mock import patch
SOURCE=Path('/workspace/symaira-memory760-runner-binding')
OUT=Path('/workspace/review-artifacts/memory760-c5e-review-794')
spec=importlib.util.spec_from_file_location('binding',SOURCE/'scripts/memory-engine-oracle/binding.py');proof=importlib.util.module_from_spec(spec);spec.loader.exec_module(proof)
root=OUT/'native-source-projection';root.mkdir()
names=['Cargo.toml','Cargo.lock','rust/symbrain-memory/Cargo.toml','rust/symbrain-memory/src/lib.rs']
blobs={name:(SOURCE/name).read_bytes()for name in names}
for name,data in blobs.items():p=root/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data)
packet=b''.join(('synthetic-git-blob blob '+str(len(data))+'\n').encode()+data+b'\n'for data in blobs.values())
with patch.object(proof,'git',return_value='\n'.join(names)),patch.object(proof.subprocess,'check_output',return_value=packet):
 before=proof.source_map(root,'rust')
 added={'rust/symbrain-memory/build.rs':b'fn main(){println!("cargo:rustc-cfg=owned_untracked_configuration");}\n','.cargo/config.toml':b'[build]\nrustflags=["--cfg", "owned_untracked_configuration"]\n'}
 for name,data in added.items():p=root/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data)
 after=proof.source_map(root,'rust')
report={'scope':'PURE SOURCE PREDICATE PROJECTION; synthetic Git adapter; no actual Git checkout/compiler/SDK/native/Go/product/target/HTTP/port execution','binding_sha256':proof.digest(SOURCE/'scripts/memory-engine-oracle/binding.py'),'before':before,'after':after,'admission_unchanged':before==after,'extra_physical_files':{n:proof.digest(root/n)for n in added},'memory_manifest_has_explicit_build_false':b'build = false'in blobs['rust/symbrain-memory/Cargo.toml']}
(OUT/'native-input-projection.json').write_text(json.dumps(report,indent=2)+'\n')
assert before==after and not report['memory_manifest_has_explicit_build_false']
print(json.dumps(report,indent=2))
