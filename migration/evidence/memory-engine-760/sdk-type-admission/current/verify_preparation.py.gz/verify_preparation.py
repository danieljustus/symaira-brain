"""Source, archive and read-only SDK bytes; no SDK/compiler/product child."""
import ast
import gzip
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
sys.dont_write_bytecode = True
ROOT = Path('/workspace/symaira-memory760-sdk-type-admission')
OUT = Path('/workspace/review-proof/memory760-sdk-type-admission-preparation/current')
BASE = 'b8ba0865ac28a98f829843cb34e5e09f19973876'
def sha(data): return hashlib.sha256(data).hexdigest()
def git(*args): return subprocess.check_output(['git', '-C', str(ROOT), *args])
retentions = [
 (ROOT, json.loads((ROOT / 'migration/evidence/memory-engine-760/hermetic-build/retention.json').read_bytes())['original108_and_new17']),
 (ROOT / 'migration/evidence/memory-engine-760/sdk-owner/original-review', json.loads((ROOT / 'migration/evidence/memory-engine-760/sdk-owner/original-review/retention.json').read_bytes())['files']),
 (ROOT / 'migration/evidence/memory-engine-760/sdk-type-admission/original-review', json.loads((ROOT / 'migration/evidence/memory-engine-760/sdk-type-admission/original-review/retention.json').read_bytes())['original_full_review30_plus_receipt'])]
for base, records in retentions:
 for row in records:
  blob = (base / row['retained']).read_bytes()
  assert sha(blob) == row['gzip_sha256'], row
  data = gzip.decompress(blob)
  assert sha(data) == row['sha256'] and len(data) == row['bytes'], row
  if 'path' in row and row['path'].startswith('/workspace/review-proof/memory760-b8-independent-source/'):
   original = Path(row['path'])
   assert sha(original.read_bytes()) == row['sha256']
   st = original.stat()
   expected = row['native_metadata']
   assert (st.st_mode, st.st_uid, st.st_gid, st.st_mtime_ns) == (expected['mode'], expected['uid'], expected['gid'], expected['mtime_ns']), row
files = sorted((ROOT / 'scripts/memory-engine-oracle').glob('*.py'))
for path in files:
 ast.parse(path.read_bytes())
 assert len(path.read_text().splitlines()) < 400, path
old_tests = {}
new_tests = {}
for name in ('test_binding.py', 'test_ownership.py', 'test_sdk.py'):
 path = 'scripts/memory-engine-oracle/' + name
 for data, result in ((git('show', BASE + ':' + path), old_tests), ((ROOT / path).read_bytes(), new_tests)):
  for node in ast.walk(ast.parse(data)):
   if isinstance(node, ast.FunctionDef) and node.name.startswith('test_'):
    result[name + ':' + node.name] = ast.dump(node, include_attributes=False)
assert old_tests.keys() == new_tests.keys() and len(old_tests) == 33
changed_tests = [name for name in old_tests if old_tests[name] != new_tests[name]]
assert changed_tests == ['test_binding.py:test_wrong_sdk_bytes_are_rejected'], changed_tests
changes = [row.split('\t') for row in git('diff', '--name-status', BASE).decode().splitlines()]
tracked_changes = [row[1] for row in changes if row[0] == 'M']
assert set(tracked_changes) == {'scripts/memory-engine-oracle/binding.py', 'scripts/memory-engine-oracle/sdk.py', 'scripts/memory-engine-oracle/test_binding.py'}, tracked_changes
names = git('ls-tree', '-r', '--name-only', BASE).decode().splitlines()
protected = [name for name in names if name not in tracked_changes]
assert git('diff', BASE, '--', *protected) == b''
sys.path.insert(0, str(ROOT / 'scripts/memory-engine-oracle'))
import binding
assert len(binding.cases()) == 60
assert binding.trusted()['controls'] == ['changed-input', 'zero-selected', 'output-obstruction']
roots = {'go': Path('/workspace/toolchains/go1.26.7'), 'rust': Path('/home/agent/.rustup/toolchains/1.98.0-x86_64-unknown-linux-gnu')}
assert os.statvfs('/workspace').f_bavail * os.statvfs('/workspace').f_frsize >= 700 * 1024 * 1024
observed = binding.sdks(roots['go'], roots['rust'])
counts = {role: {'files': len(value['physical_inventory']['files']), 'directories': len(value['physical_inventory']['directories']), 'legacy_hashes': len({**value['files'], **value.get('source_files', {})})} for role, value in observed.items()}
assert counts == {'go': {'files': 15034, 'directories': 1667, 'legacy_hashes': 7720}, 'rust': {'files': 303, 'directories': 28, 'legacy_hashes': 227}}
rows = [json.loads(line) for line in (OUT / 'admission-journal.jsonl').read_text().splitlines()]
assert len(rows) == 13
assert len([row for row in rows if row['legacy_first_mutant'] and row['timed_out'] and row['child_exit'] == -15]) == 3
assert len([row for row in rows if not row['legacy_first_mutant'] and not row['timed_out'] and row['child_exit'] == 0]) == 10
result = {'kind': 'source-only-memory760-sdk-type-admission', 'parent': BASE,
 'lossless_original_groups': [len(records) for base, records in retentions], 'original33_method_identities': len(old_tests), 'changed_old_method': changed_tests,
 'protected_parent_tracked': len(protected), 'python_files_under400_ast': len(files),
 'corpus': 60, 'controls': binding.trusted()['controls'], 'read_only_current_sdk_admission': counts,
 'SDK_map_sha256': sha((ROOT / 'scripts/memory-engine-oracle/sdk-inputs.json').read_bytes()),
 'exact_original_composite_conditions': 10, 'old_order_fifo_mutants': 3,
 'SDK_compiler_product_runs': 0, 'targets_ports_network_cache_access': 0,
 'available_bytes': os.statvfs('/workspace').f_bavail * os.statvfs('/workspace').f_frsize}
(OUT / 'static-verification.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result, indent=2))
