# Memory760 b8ba: full independent source review

**REQUEST_CHANGES: one P2 in SDK admission error ordering.** The previous
whole-input omission is structurally corrected for regular files, but the
composite SDK predicate still reads legacy entries before the new file-type
refusal. No additional production algorithm defect was confirmed. This is a
full review of the bounded additive library/proof kit, not compiled acceptance
or completion of #760.

Immutable candidate `b8ba0865ac28a98f829843cb34e5e09f19973876`, parent
`7804d91b6f7b712a9d8fdfa68160bb8375b07a60`, clean sparse worktree
`/workspace/symaira-memory760-sdk-owner`. The reviewer authored none of this
candidate and edited no candidate, SDK, prior proof, dependency or target.
Author handoff SHA256
`e51a7730f2da296fc7f567478df79d830856136c241fc6d4e331a2c80416115a`
verified. Full prior780 report and both earlier original reviews were read
completely; their unchanged raw failures, source projections and receipts are
retained with their literal REQUEST_CHANGES identities.

## P2: refuse special inputs before legacy SDK byte reads

Location: `scripts/memory-engine-oracle/binding.py:117–120`; byte reader at
lines22–23. The builder enters this predicate before any compiler child, and
replay/snapshots use it again.

`sdks()` first calls `digest(root / name)` for every legacy trusted SDK file.
`digest()` opens the path using `Path.read_bytes()`. Only after that loop does
`sdk.admit()` perform the new `lstat` census that rejects symlinks/special files.
A stable FIFO substituted at a legacy mapped pathname therefore blocks inside
the earlier byte read instead of reaching the promised special-input refusal.
The Python admission operation has no timeout; the builder's1800-second SDK
child timeout applies later and does not bound this read. No sender is present
in the owned FIFO fixture. No actual SDK was replaced or executed.

Fresh source-bound, explicitly synthetic whole/legacy SDK envelopes exercise
the unchanged production Python admission predicate. Replacing respectively
`go:bin/go`, `go:src/fmt/doc.go`, and `rust:bin/rustc` with a FIFO leaves each
Python predicate child blocked through the0.5-second observation; each required
explicit termination (final exit-15). Calling unchanged `sdk.admit()` directly
on the same stable owned FIFO immediately raises the expected
`ValueError: unbound SDK symlink/special input`. Thus the new census has the
necessary refusal, but composite error ordering bypasses it until after a
potentially nonterminating read. These are real owned filesystem/Python
predicate observations with mocked trusted/platform envelopes, not Go/Rust
compiler or native product observations.

The clean envelope is accepted. Six controls reject immediately: an extra FIFO
outside the legacy list, config symlink, directory-mode mutation, removed
assembler header, added empty directory, and symlink SDK root. Full expected
inventories, legacy plans, synthetic byte values, mutation identities, source
hashes, outcomes and child termination are retained in
`extra_sdk_predicates.py`, `extra-sdk-predicates.json/.stdout/.stderr` and the
complete journal. The first successful10-case run is preserved unchanged in
`first-complete-extra-predicates`; the second10-case run adds complete input-map
retention and confirms the same results. No attempts or observations are
discarded.

Required focused correction: ensure type/name admission precedes every SDK
byte open, including the legacy mandatory map. Then retain those mandatory
hashes, whole-root content/modes/config inventory and environment checks. Reuse
the observed validated regular-file hashes where appropriate rather than
opening unchecked legacy paths first. Preserve these exact three FIFO cases
and meaningful clean/type/name/mode/header/error-precedence controls, with a
bounded portable harness that proves refusal rather than timing out. Keep
original SDK/reference maps, algorithms, frozen Go, corpus and controls intact.
Exclusive owned runtime inputs remain necessary; this finding does not claim
that before/after hashes prevent concurrent transient mutation.

## Full correction and contract assessment

The whole-root map now fixes Go15034 files/1667 directories and Rust303
files/28 directories, including root modes, `go.env`, all five assembler
headers, sources, assembly, objects, embedded/distribution/runtime assets and
tools. Independently read and matched every file byte hash/mode and complete
physical path/directory set against the immutable map. All7947 former SDK
hashes remain identical and mandatory. Unknown platforms remain rejected; only
Linux x86_64 is prepared. Installed foreign-target libraries confer no
Windows/macOS runtime proof. Missing/subset maps, extra/missing names, directory
enumeration errors and regular-byte/mode changes fail the prepared predicate.
The remaining special-path pre-read is the single actionable finding above.

Child `GOROOT` is now explicit and `GOFLAGS=-mod=readonly` is nonempty, matching
the existing actual Go argv. Pinned SDK cfg/Getenv/goflags source shows why the
old empty value did not exclude root-config fallback. Root configuration is
now included in the whole map; `GOENV=off`, `GOWORK=off`, local toolchain and
offline resolution remain explicit. Environment construction excludes
operator flags, wrappers, include paths, homes, caches and global Git settings.
SDK-only PATH and explicit Rust compiler ownership are retained. No new ambient
C/linker permission is implied.

Read complete source admission, private staging, dependency bodies/materialize/
postchecks, byte-pinned Git reader, builder and replay code. Fresh owned source
and private archive/index/Git cache staging remain required; extracted borrowed
sources/configuration are not copied. Fixed dependency declarations/metadata/
CoreKit revision and source maps remain intact. Existing empty-target, actual
newly compiled Cargo-artifact/package/path attribution, full argv/cwd/env/raw
logs, source/SDK/input checks and before/between/after executable identity
criteria are unchanged. Whole SDK inventory is carried in actual future
build/replay snapshots. These are inspectable process contracts, not signatures
or currently executed build receipts. Original missing46 Cargo archives and79
Go files remain absent on a fresh read-only existence census; no cache is
populated or represented as complete. C/linker ownership remains a prerequisite.

All six engine production modules, all10 prepared Rust assertions, example,
original Go helper, complete60 ordered cases, source/function/callsite census,
inventory/ledger/matrix, existing ADRs, future conflict/provider plan and raw
importer boundary were reviewed. Production/API/algorithm/probe/helper/corpus,
manifest/lock, dependency maps, prior20 test methods, build/replay and existing
CLI/MCP admission are byte-identical to parent780. The only original library
addition remains `pub mod engine;`. Original797 identity/full-corpus findings
and794 physical-source/configuration owner finding remain corrected on source
evidence, subject to their unchanged actual future controls.

Extraction retains fixed rule/sentence order, ASCII regex whitespace, capture
thresholds, first-occurrence dedup, single-pass replacement and grounded evidence
with caller-owned source identity. Its validUTF8 input limit/raw importer bridge
remains explicit. Summary preserves rune rebuilding, pairwise score/chronology
swaps and byte-valued first-byte uppercase; the API's nonnegative limit is not
full negative-Go-domain equivalence. Budget retains raw identifiers, malformed
RuneError counting, Go64 wrapping totals and positional two-piece protection.
Aging retains injected time, duration saturation, zero-last-access/nonpositive
fallbacks, original constants and IEEE behavior. Exact Unicode/libm/NaN/native
error behavior still requires real comparisons. No Store, clock constructor,
provider, HTTP, subprocess or operator credential access is introduced in
these algorithms.

Full #760 still includes governed secondary extraction/store effects, raw
evidence bridge, embedding cache/cooldown/metrics, conflict, consolidation/undo,
aging Store partial writes, context/profile/receipt/snapshot assembly, temporal/
entity/working/discovery and shared CLI/MCP/configuration/service owners. The
future conflict plan correctly keeps actor trust out of winner ranking. No
fallback or capability exposure changes are granted here.

## Independent source/portable verification

* All4474 Git blob bodies, modes and sizes bound;4358 parent paths unchanged,
 116 deltas; all384 materialized tracked files match Git. Every230 author
 handoff file binding verified. Current sparse checkout is not an admitted
 fully materialized runtime source tree.
* All1777 original protected source/manifest bodies match base/current;
 lib.rs separately differs only by the additive engine declaration. All1219
 frozen Go source/module bodies match dcddcef0. Exact39 engine source paths,
115 production declarations and22 production call anchors verified.
* All95 new original-review archives roundtrip with native metadata retained;
 all94 prior full-review proof rows and its receipt cross-bind to those
 archives. All125 earlier originals roundtrip and retain exact payload/
 compressed hashes. Historical metadata is preservation information, not a
 claim that current access times/inodes remained unchanged after source reads.
* Complete physical Go/Rust SDK inventories and all7947 old hashes verified
 read-only. No SDK executable was invoked or copied.
* All33 portable methods pass (20 old+13 new),0 failures/0 skips. Ten proof-kit
 Python files parse and remain under400 lines. Full116-delta whitespace check
 passes. Original60 stays pattern18/summary10/tokens9/aging13/budget10; original
 three controls and omitted-case behavior remain exact and unexecuted.
* Two10-case own predicate runs reproduce the special-file ordering finding
 plus all controls. Original first own helper failed on pipe EOF after an
 explicitly terminated child; complete source/stdout/stderr and attribution
 are preserved in `initial-extra-predicate-EOF`. Only the reviewer helper was
 corrected. Candidate, SDKs, expected criteria and original proof remain intact.

Evidence root `/workspace/review-proof/memory760-b8-independent-source`: full
Git/physical map, full SDK read-only map, source-verification summary,
retained-original verification, original-availability check, portable streams,
all own predicate sources/inputs/journals/outputs and first helper failure.
The final receipt binds every review artifact and this complete report.

Actual reviewer SDK/compiler/native product/probe/Store/SQLite/HTTP/provider/port
runs: **zero**. Real target/cache allocation, target access, candidate/GitHub
mutation: **zero**. Python fixture processes execute only SDK-admission
predicates; every owned child is terminated/joined or exits and temporary
fixtures are cleaned. No resources belonging to other owners were touched or
claimed released. Root198/249 UNVERIFIED descriptor observations remain
unaffected; this review performs no broad process/descriptor absence audit.

Keep b8ba immutable. Correct this single P2 in a preserved successor and obtain
different-author full source review. After complete verified dependencies,
explicit C/linker ownership and separate resource allocation, execute strict
affected/full graph builds, all60 exact real comparisons, original three plus
omitted-case controls, genuine source/config/dependency/SDK/executable mutation
controls and native Linux/macOS/Windows acceptance. This report grants no
compiled approval, source cutover or full #760 closure.
