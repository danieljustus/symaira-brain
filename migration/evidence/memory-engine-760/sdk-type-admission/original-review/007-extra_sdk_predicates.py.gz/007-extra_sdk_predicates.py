"""Owned Python admission predicates only; no SDK/product subprocess."""
import hashlib
import json
import multiprocessing
import os
from pathlib import Path
import sys
import tempfile
from unittest.mock import patch

sys.dont_write_bytecode = True
ROOT = Path('/workspace/symaira-memory760-sdk-owner')
OUT = Path('/workspace/review-proof/memory760-b8-independent-source')
sys.path.insert(0, str(ROOT / 'scripts/memory-engine-oracle'))
import binding
import sdk


def make(root, names):
    for name in names:
        path = root / name
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(b'owned source bytes\n')


def invocation(go, rust, manifest, plan, send):
    with patch.object(binding, 'HERE', manifest), patch.object(binding, 'trusted', return_value=plan), patch.object(binding.platform, 'system', return_value='Linux'), patch.object(binding.platform, 'machine', return_value='x86_64'):
        try:
            binding.sdks(go, rust)
            send.send(dict(status='accepted'))
        except Exception as exc:
            send.send(dict(status='rejected', error=type(exc).__name__, detail=str(exc)))
    send.close()


def observe(mutation):
    with tempfile.TemporaryDirectory(dir=OUT / 'owned-tmp') as temp:
        root = Path(temp)
        go, rust, manifest = [root / name for name in ['go', 'rust', 'runner']]
        manifest.mkdir()
        make(go, ['bin/go', 'src/fmt/doc.go', 'go.env', 'pkg/include/textflag.h'])
        make(rust, ['bin/cargo', 'bin/rustc', 'lib/runtime.so'])
        expected = dict(go=sdk.inventory(go), rust=sdk.inventory(rust))
        plan = dict(sdk_platforms={'linux-x86_64': {'go': {'files': {'bin/go': sdk.sha(go / 'bin/go')}, 'source_files': {'src/fmt/doc.go': sdk.sha(go / 'src/fmt/doc.go')}}, 'rust': {'files': {'bin/cargo': sdk.sha(rust / 'bin/cargo'), 'bin/rustc': sdk.sha(rust / 'bin/rustc')}}}})
        (manifest / 'sdk-inputs.json').write_text(json.dumps(dict(kind='memory760-whole-sdk-v1', platforms={'linux-x86_64': expected})))
        selected = None
        if mutation.startswith('fifo:'):
            _, role, name = mutation.split(':', 2)
            selected = dict(go=go, rust=rust)[role] / name
            if selected.exists():
                selected.unlink()
            os.mkfifo(selected)
        elif mutation == 'config-link':
            selected = go / 'go.env'
            selected.unlink()
            selected.symlink_to('src/fmt/doc.go')
        elif mutation == 'directory-mode':
            (rust / 'lib').chmod(0o775)
        elif mutation == 'header-removal':
            (go / 'pkg/include/textflag.h').unlink()
        elif mutation == 'missing-directory':
            empty = go / 'empty'
            empty.mkdir()
        elif mutation == 'root-link':
            alias = root / 'alias'
            alias.symlink_to(go, target_is_directory=True)
            go = alias
        receive, send = multiprocessing.Pipe(duplex=False)
        child = multiprocessing.get_context('fork').Process(target=invocation, args=(go, rust, manifest, plan, send))
        child.start()
        send.close()
        child.join(0.5)
        timed_out = child.is_alive()
        if timed_out:
            child.terminate()
            child.join(2)
            assert not child.is_alive()
        result = dict(status='blocked-before-refusal') if timed_out else receive.recv()
        receive.close()
        if selected is not None and mutation.startswith('fifo:'):
            try:
                sdk.admit(go if ':go:' in mutation else rust, 'owned', expected['go' if ':go:' in mutation else 'rust'])
            except Exception as exc:
                result['direct_inventory'] = dict(error=type(exc).__name__, detail=str(exc))
        row = dict(mutation=mutation, python_predicate_child_only=True, waited_seconds=0.5, timed_out=timed_out, child_final_exit=child.exitcode, actual_compiler_sdk_product_runs=0, independently_owned_expected_inventory=expected, independently_owned_legacy_plan=plan, synthetic_regular_input_bytes_hex=b'owned source bytes\n'.hex(), **result)
        with (OUT / 'extra-sdk-predicates-journal.jsonl').open('a') as journal:
            journal.write(json.dumps(row) + '\n')
        return row


rows = [observe(name) for name in ['clean', 'fifo:go:bin/go', 'fifo:go:src/fmt/doc.go', 'fifo:rust:bin/rustc', 'fifo:go:src/fmt/extra.pipe', 'config-link', 'directory-mode', 'header-removal', 'missing-directory', 'root-link']]
assert rows[0]['status'] == 'accepted'
assert all(row['status'] == 'blocked-before-refusal' and row['timed_out'] and row['direct_inventory']['error'] == 'ValueError' for row in rows[1:4])
assert all(row['status'] == 'rejected' and not row['timed_out'] for row in rows[4:])
output = dict(scope='Actual owned filesystem and unchanged Python SDK-admission predicates; not SDK/compiler/product behavior.', candidate='b8ba0865ac28a98f829843cb34e5e09f19973876', source_sha256={name: hashlib.sha256((ROOT / 'scripts/memory-engine-oracle' / name).read_bytes()).hexdigest() for name in ['binding.py', 'sdk.py']}, observations=rows, SDK_executions=0, products=0, target_access=False, ports=0)
(OUT / 'extra-sdk-predicates.json').write_text(json.dumps(output, indent=2) + '\n')
print(json.dumps(output, indent=2))
