"""Independent pure source/bytes review; never invokes SDK/compiler/products."""
import ast
import collections
import gzip
import hashlib
import json
import os
from pathlib import Path
import stat
import subprocess
import sys

sys.dont_write_bytecode = True
ROOT = Path('/workspace/symaira-memory760-sdk-owner')
OUT = Path('/workspace/review-proof/memory760-b8-independent-source')
HEAD = 'b8ba0865ac28a98f829843cb34e5e09f19973876'
PARENT = '7804d91b6f7b712a9d8fdfa68160bb8375b07a60'
BASE = 'a30bba8bbd52323fa5e000207f1c391d576ac86c'
GO = Path('/workspace/oracles/daemon772-go-source')

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

def pathsha(path):
    h = hashlib.sha256()
    with path.open('rb') as source:
        for raw in iter(lambda: source.read(1048576), b''):
            h.update(raw)
    return h.hexdigest()

def git(*args, cwd=ROOT, input=None):
    return subprocess.check_output(['/usr/bin/git', '-c', 'core.fsmonitor=false', '-c', 'core.hooksPath=/dev/null', *args], cwd=cwd, input=input, env={'GIT_CONFIG_NOSYSTEM': '1', 'GIT_CONFIG_GLOBAL': '/dev/null', 'GIT_CONFIG_SYSTEM': '/dev/null'})

def tree(ref):
    items = {}
    for row in git('ls-tree', '-rz', ref).split(b'\0'):
        if not row:
            continue
        info, name = row.split(b'\t', 1)
        mode, kind, oid = info.decode().split()
        assert kind == 'blob'
        items[name.decode()] = dict(mode=mode, git_blob=oid)
    return items

assert git('rev-parse', 'HEAD').decode().strip() == HEAD
assert not git('status', '--porcelain', '--untracked-files=all')
handoff_path = Path('/workspace/review-proof/memory760-sdk-owner-preparation/final-handoff.json')
assert pathsha(handoff_path) == 'e51a7730f2da296fc7f567478df79d830856136c241fc6d4e331a2c80416115a'
handoff = json.loads(handoff_path.read_bytes())
for row in handoff['file_bindings']:
    path = Path(row['path'])
    assert pathsha(path) == row['sha256'] and path.stat().st_size == row['bytes'], str(path)
assert len(handoff['file_bindings']) == 230
current, parent = tree(HEAD), tree(PARENT)
packed = git('cat-file', '--batch', input=''.join(HEAD + ':' + name + '\n' for name in current).encode())
pos = 0
physical = {}
for name, record in current.items():
    end = packed.index(b'\n', pos)
    header = packed[pos:end].split()
    assert len(header) == 3 and header[1] == b'blob'
    size = int(header[2]);pos = end + 1
    raw = packed[pos:pos + size];pos += size
    assert packed[pos:pos + 1] == b'\n';pos += 1
    record.update(sha256=sha(raw), bytes=size)
    path = ROOT / name
    if path.is_file():
        assert pathsha(path) == sha(raw), name
        physical[name] = record
assert pos == len(packed)
unchanged = [name for name in parent if current.get(name, {}).get('git_blob') == parent[name]['git_blob'] and current[name]['mode'] == parent[name]['mode']]
delta = [name for name in current if name not in parent or current[name]['git_blob'] != parent[name]['git_blob'] or current[name]['mode'] != parent[name]['mode']]
assert (len(current), len(unchanged), len(delta), len(physical)) == (4474, 4358, 116, 384)
(OUT / 'full-current-index.json').write_text(json.dumps(dict(source=HEAD, files=current, physical=physical), indent=2) + '\n')
original = json.loads((ROOT / 'migration/evidence/memory-engine-760/static-validation.json').read_bytes())['protected_original_source_and_manifest_files']
assert len(original) == 1777
for row in original:
    assert sha(git('show', BASE + ':' + row['path'])) == row['sha256'] == current[row['path']]['sha256'], row['path']
lib = 'rust/symbrain-memory/src/lib.rs'
assert git('show', HEAD + ':' + lib).replace(b'pub mod engine;\n', b'', 1) == git('show', BASE + ':' + lib)
for name, rec in parent.items():
    if name.startswith(('rust/', 'internal/', 'cmd/', 'guard/')) or name in ['Cargo.lock', 'Cargo.toml', 'go.mod', 'go.sum'] or name.startswith('scripts/memory-engine-oracle/') and name not in ['scripts/memory-engine-oracle/README.md', 'scripts/memory-engine-oracle/binding.py', 'scripts/memory-engine-oracle/owner.py']:
        assert current.get(name, {}).get('git_blob') == rec['git_blob'], name
trusted = json.loads((ROOT / 'scripts/memory-engine-oracle/trusted.json').read_bytes())
assert git('rev-parse', 'HEAD', cwd=GO).decode().strip() == trusted['frozen_go_commit']
assert not git('status', '--porcelain', cwd=GO)
frozen = {}
for name, expected in trusted['frozen_go_sources'].items():
    assert pathsha(GO / name) == expected == sha(git('show', trusted['frozen_go_commit'] + ':' + name)), name
    frozen[name] = expected
assert len(frozen) == 1219
cases_raw = (ROOT / 'scripts/memory-engine-oracle/cases.json').read_bytes();cases = json.loads(cases_raw)
assert len(cases) == 60 and sha(cases_raw) == trusted['cases_sha256']
assert [[row['id'], row['operation']] for row in cases] == trusted['case_identities']
assert trusted['controls'] == ['changed-input', 'zero-selected', 'output-obstruction']
assert current['scripts/memory-engine-oracle/oracle_test.go.txt']['sha256'] == trusted['go_helper_sha256']
assert b'omitted-case' in (ROOT / 'scripts/memory-engine-oracle/replay.py').read_bytes()
api = json.loads((ROOT / 'migration/evidence/memory-engine-760/go-api-census.json').read_bytes())['functions']
calls = json.loads((ROOT / 'migration/evidence/memory-engine-760/production-callsite-census.json').read_bytes())['calls']
for row in api + calls:
    assert (GO / row['path']).read_text().splitlines()[row['line'] - 1].strip() == row['declaration'].strip()
paths = json.loads((ROOT / 'migration/evidence/memory-engine-760/frozen-go-binding.json').read_bytes())['same_original_engine_paths']
declarations = [(name, number, line) for name in paths if not name.endswith('_test.go') for number, line in enumerate((GO / name).read_text().splitlines(), 1) if line.startswith('func ')]
assert len(declarations) == len(api) == 115 and len(calls) == 22 and len(paths) == 39
assert set(declarations) == {(row['path'], row['line'], row['declaration']) for row in api}
retention = ROOT / 'migration/evidence/memory-engine-760/sdk-owner/original-review'
original95 = []
for row in json.loads((retention / 'retention.json').read_bytes())['files']:
    path = retention / row['retained'];compressed = path.read_bytes();raw = gzip.decompress(compressed)
    assert sha(compressed) == row['gzip_sha256'] and sha(raw) == row['sha256'] and len(raw) == row['bytes']
    assert set(['mode', 'uid', 'gid', 'mtime_ns', 'atime_ns', 'inode', 'device']).issubset(row['native_metadata'])
    original95.append(dict(path=str(path), sha256=sha(raw), bytes=len(raw), native_metadata=row['native_metadata']))
assert len(original95) == 95
old_report = Path('/workspace/review-proof/memory760-780-independent-source/independent-review.md')
old_receipt = Path('/workspace/review-proof/memory760-780-independent-source/independent-review-receipt.json')
assert pathsha(old_report) == '12693e65ef343c5e15218d5aeeeb52b06696b57855c4abd00d32de13e7a46f0b'
assert pathsha(old_receipt) == '6fd2e8300f175a06a7aa0d3fc96c05096b6918fa356986878a3c66669a6a7e0a'
original125 = []
for row in json.loads((ROOT / 'migration/evidence/memory-engine-760/hermetic-build/retention.json').read_bytes())['original108_and_new17']:
    path = ROOT / row['retained'];compressed = path.read_bytes();raw = gzip.decompress(compressed)
    assert sha(compressed) == row['gzip_sha256'] and sha(raw) == row['sha256'] and len(raw) == row['bytes']
    original125.append(dict(path=str(path), sha256=sha(raw), bytes=len(raw)))
assert len(original125) == 125
sys.path.insert(0, str(ROOT / 'scripts/memory-engine-oracle'))
import sdk
import binding
sdk_roots = dict(go=Path('/workspace/toolchains/go1.26.7'), rust=Path('/home/agent/.rustup/toolchains/1.98.0-x86_64-unknown-linux-gnu'))
plan = json.loads((ROOT / 'scripts/memory-engine-oracle/sdk-inputs.json').read_bytes())
assert set(plan) == {'kind', 'platforms'} and plan['kind'] == 'memory760-whole-sdk-v1' and set(plan['platforms']) == {'linux-x86_64'}
observed = {}
for role, root in sdk_roots.items():
    # Whole physical input source inventory only; hash reads, never executable run.
    observed[role] = sdk.admit(root, role, plan['platforms']['linux-x86_64'][role])
    assert all(record['mode'] == stat.S_IMODE((root / name).stat().st_mode) for name, record in observed[role]['files'].items())
old_sdk_count = 0
for role, root in sdk_roots.items():
    old = trusted['sdk_platforms']['linux-x86_64'][role]
    for name, expected in {**old['files'], **old.get('source_files', {})}.items():
        assert observed[role]['files'][name]['sha256'] == expected
        old_sdk_count += 1
assert old_sdk_count == 7947
for name in ['go.env', 'pkg/include/textflag.h', 'pkg/include/funcdata.h', 'pkg/include/asm_amd64.h', 'pkg/include/asm_ppc64x.h', 'pkg/include/asm_riscv64.h']:
    assert name in observed['go']['files']
counts = {role: dict(files=len(value['files']), directories=len(value['directories'])) for role, value in observed.items()}
assert counts == dict(go=dict(files=15034, directories=1667), rust=dict(files=303, directories=28))
(OUT / 'whole-sdk-readonly-verified.json').write_text(json.dumps(dict(source=HEAD, inventories=observed, legacy_hashes_unchanged=old_sdk_count, no_SDK_executable_run=True), indent=2) + '\n')
modules = {}
for path in sorted((ROOT / 'scripts/memory-engine-oracle').glob('*.py')):
    ast.parse(path.read_bytes(), filename=str(path));modules[path.name] = len(path.read_text().splitlines())
assert len(modules) == 10 and all(count < 400 for count in modules.values())
assert not git('status', '--porcelain', '--untracked-files=all')
summary = dict(source=HEAD, parent=PARENT, candidate_clean_unchanged=True, full_current_git_blobs=len(current), current_materialized_tracked=len(physical), source_deltas=len(delta), unchanged_parent_blobs=len(unchanged), handoff230_bindings_verified=True, original_protected1777_verified=True, frozen_Go1219_verified=True, full_engine39_functions115_calls22_verified=True, original95_full_archives_and_metadata_verified=True, prior125_lossless_archives_verified=True, original60_case_bytes_order_control_criteria_unchanged=True, SDK_whole_readonly_inventory=counts, all7947_old_SDK_hashes_unchanged=True, Python10_AST_and_under400=modules, operations=dict(collections.Counter(row['operation'] for row in cases)), actual_SDK_compiler_product_Store_SQLite_HTTP_port_runs=0, real_target_access=False, candidate_or_GitHub_writes=False)
(OUT / 'source-verification-summary.json').write_text(json.dumps(summary, indent=2) + '\n')
(OUT / 'retained-originals-verified.json').write_text(json.dumps(dict(original95=original95, prior125=original125), indent=2) + '\n')
print(json.dumps(summary, indent=2))
