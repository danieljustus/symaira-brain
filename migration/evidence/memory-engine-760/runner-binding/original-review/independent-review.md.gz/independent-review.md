# Independent source review: Memory760 engine 9f1b1dc

Disposition: **REQUEST_CHANGES**. Two P2 findings affect the prepared differential runner's proof integrity. No new production algorithm defect was confirmed by this source-only review. This is neither compiled acceptance nor a full #760 implementation review approval.

Reviewed immutable candidate `9f1b1dc07503e7ede84d1e38074100929cb50805` against published Memory803 base `a30bba8bbd52323fa5e000207f1c391d576ac86c`, worktree `/workspace/symaira-memory760-engine`. Frozen Go checkout `/workspace/oracles/daemon772-go-source` is `dcddcef0df5789123c7c9a7ebe6e01f10e941f2c`. Candidate was clean at entry and exit. The reviewer authored none of this candidate and did not edit it.

## Findings

### P2 — Bind the oracle independently instead of accepting caller-selected provenance

Location: `scripts/memory-engine-oracle/replay.py:70–100`; executable checks at lines 67 and 106, execution at lines 132–133, final source-only check at line 150.

The runner requires nonempty provenance labels, then compares checkout HEAD and file contents only to the same caller-supplied manifest. It never checks the retained frozen Go identity/hash map or real SDK receipts. Consequently a replacement Go checkout can declare its own revision and hashes as `frozen_go_commit`/`original_go_file_hashes`, while arbitrary nonempty text satisfies both SDK labels. The actual historical source verified elsewhere in this candidate does not constrain this runner. Successful records can therefore be attributed to an altered oracle instead of the required original Go implementation.

The independent projection executes the **unchanged AST-extracted `verify_sources` body**, using owned physical files and a explicitly synthetic Git-query adapter. It accepts `caller-selected-altered-go`, two altered tracked Go files and `not-an-actual-SDK-receipt` labels. The helper remains the exact candidate helper. Evidence: `verify_sources-exact.py.txt`, `provenance-projection.json`, `.log`. This is direct evidence about the admission predicate, **not an actual Git/Go/Rust process comparison**. Runner SHA256 `53b40d957f86874bc8b62b478b471c02ad1a9b52a2c8edec880218aa58091ba7`; extracted guard SHA256 `08e25671ff6b9b9b6a514d60f7e41936fa4b7ad66550bb1cba8cfa2cd03e53fc`.

Related attribution gap: both executable SHA reads precede the first process. After execution the runner verifies source files, not executables. A replaced executable is not rejected at receipt publication; no actual replacement/process race was performed or claimed. `executable-binding-order.json` records the exact AST line order.

Required correction: bind a separately retained immutable Go identity and complete original source/dependency/helper proof; validate actual SDK/build attribution rather than merely nonempty labels; retain before/after executable and source verification for actual future runs. Add meaningful altered-oracle and executable-change controls without changing the original algorithms or weakening comparisons.

### P2 — Retain and enforce the complete prepared input set

Location: `scripts/memory-engine-oracle/replay.py:60–62`, `85–88`, `102–107`, `142–149`.

Input admission requires only a nonempty array with unique IDs. Source maps deliberately include Go/Rust source and manifests but omit `cases.json` and the runner. Removing 59 of the prepared 60 cases leaves a valid input. `records()` then compares outputs to that shortened list, so one matching case suffices for the result's `PASS` calculation. The receipt reports the current input hash/count but never verifies them against the immutable candidate or the declared full60 plan. Changing this unbound file need not change HEAD or any verified Go/Rust source hash.

The independent exact-AST predicate accepts the first case alone. The unchanged `records()` function accepts a synthetic one-record result against that shortened expectation and rejects it against the original full60 expectation. `coverage-projection.json` retains every omitted ID; `coverage-records-projection.json`, `coverage-predicate-exact.py.txt`, `truncated-input.json` and `single-result-projection.json` retain the source projection inputs/results. These are **source-predicate/synthetic-record projections**, not actual native or Go results and not a claimed real PASS receipt.

Required correction: bind the complete runner/input/helper set to the immutable reviewed source and enforce the complete expected case identities/order/count. Add a true omitted-case control alongside the existing changed-input, zero-selected and output-obstruction controls. Preserve every original60 assertion and all actual failures when runtime allocation arrives.

### Nonblocking plan correction

`migration/evidence/memory-engine-760/prepared-fake-http-plan.json:58` asks for actor-trust winner thresholds. Frozen `internal/memory/conflict/conflict.go:319–340` explicitly excludes client trust and orders by importance, recency, then lexical ID. Actor attribution is retained in audits. Correct the future plan to those actual inputs before implementing conflict; no conflict production port is introduced by this patch and no runtime regression is claimed.

## Complete source scope and assessment

All production changes were read: `rust/symbrain-memory/src/engine/{mod,text,aging,budget,extractor,summarizer}.rs`; sole pre-existing production edit is exactly `pub mod engine;` in `src/lib.rs`. Also read all10 tests in `engine/tests.rs`, `examples/engine_probe.rs`, complete replay/helper/60 cases, ADR, inventory, implementation ledger/contract matrix additions, original issue record, all retention/proof maps and the115-function/22-call census. No manifests, dependencies, existing Go, CLI/MCP routes or existing service/admission implementations changed. No workflow change introduces native acceptance. The111 changed-file byte/hash map is in `verification.json`.

Reviewed original algorithm owners: extractor pattern/embeddings; summarizer; aging; contextassembler budget and full assembler methods; conflict/LLM policy; consolidation/engine/journal/prompts; temporal; entity; working; discovery. Original shared sources establish config/MemoryService/Store/MCP/CLI/evidence/embedding constructor and admission boundaries. The original39 engine Go files match the frozen checkout. The independently enumerated115 actual non-test function declarations exactly match the census, and all22 production import-call anchors match exact source lines (`census-verification.json`). Constructor-absence conclusions are scoped to tracked non-test cmd/internal source, not downstream library callers.

Pattern rule ordering, ASCII Go regexp whitespace, overlapping-rule behavior, replacement order, global dedup and reused grounded evidence were inspected. Pattern input remains valid UTF8; the raw importer/evidence bridge is explicitly pending. Summarizer operates on bytes, repairs invalid bytes through RuneError iteration as original Go does, retains ranking/swap chronology and unusual first-byte uppercase behavior. A potential raw-byte preservation concern was rejected after reading Go's rune-rebuilding splitSentences. Go/simple-Unicode tables still need actual SDK process proof.

Aging retains explicit injected time, Go duration saturation/hour conversion, zero/last-access handling, log boosts/clamps and disabled/nonpositive paths. Prepared exact IEEE-754 bit comparisons appropriately do not canonicalize NaNs or add a tolerance; actual Go/native transcendental and platform results remain unknown until execution. Raw context budgeting retains malformed UTF8 token behavior, Go64 wrapping totals, positional first-two protection, nil/nonpositive budget behavior and original report/drop ordering. No wall-clock, Store, provider or HTTP access is introduced by these deterministic functions.

The Go helper calls the original functions, including private enforceBudget through the test package; it does not duplicate the algorithms. The Rust example calls the new production functions, retains raw hex/bit fields and file-output errors. Both remain probes, not genuine application routing. The60 prepared cases divide into pattern18, summary10, tokens9, aging13, budget10. Three negative-control modes exist but have **not been run**. The16 fake-HTTP scenarios are a future plan, not a runnable or executed HTTP suite. Tests and source plausibility do not prove compilation or strict lint success.

## Independent preservation and checks

`verification.json` records84 compressed originals: every archive hash, decompressed hash and payload matches its exact manifest Git source. All1777 protected original source/manifest files match; old lib bytes differ only by the single new module declaration. All39 frozen Go engine sources match. All111 changed files have retained immutable bytes/hash attribution. Final handoff checks independently reverified11 proof-map hashes and7 new source-file hashes (`final-source-verification.json`). Python AST parsing and `git diff --check` passed. All review outputs/projection fixtures are private under `/workspace/review-artifacts/memory760-9f1-review-797`; raw copies of the original runner/input/helper/probe are retained there.

Actual reviewer executions: zero Cargo/compiler/SDK/product/probe/HTTP/provider/port processes; zero targets created or held; zero GitHub writes. Python source predicates, hashing, gzip roundtrip checks and read-only Git source queries were performed. No source-only projection is counted as product parity.

## Remaining acceptance

Both P2 corrections need a clean immutable successor and different-author review. The full #760 engine port remains open: governed secondary extraction/store effects, raw evidence/importer bridge, cache/cooldown/metrics, conflict, consolidation/journal/undo, aging Store pass/partial writes, temporal routing, Unicode entity policy, working compaction, full context/profile/receipts/snapshot/delta assembly, discovery composition, shared config/service and CLI/MCP constructors. Admission must remain pinned until complete owners/error-order/state/process proofs pass. Fresh actual affected/full workspace gates, all60 plus real controls and native Linux/macOS/Windows acceptance are mandatory; this review grants none of those gates.
