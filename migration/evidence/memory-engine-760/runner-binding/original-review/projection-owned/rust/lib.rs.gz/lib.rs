// source-projection fixture only
