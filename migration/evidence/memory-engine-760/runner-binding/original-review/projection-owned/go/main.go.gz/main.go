package altered
// deliberately not the frozen Memory source
