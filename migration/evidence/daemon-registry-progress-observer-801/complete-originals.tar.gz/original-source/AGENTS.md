# AGENTS.md — Symaira Brain (`symbrain`)

This file documents coding conventions, project standards, and Symaira-specific rules for AI agents and humans contributing to `symaira-brain`.

**README:** [README.md](README.md)

---

## Product Boundary

**Accepted target: [PB-2026-09-09](docs/adr/0002-product-boundaries.md).** Brain owns portable agent context/control and the optional Browse and Operate modules. Browse remains actively developed; Operate is retained, not automatically replaced by Cua or Hermes. Brain GUI/CLI become the integrated credential-management surface, backed by the independently usable `symvault` service. Browser and OS-automation workers remain optional and permission-isolated; no master keys enter the gateway. Module moves and replacement UI are not yet completed. This target supersedes conflicting state-core-only and no-GUI scope restrictions below; existing commands and safety contracts remain until tested cutovers.

**Symbrain is the portable agent-context layer.** It exposes the three Symaira
*state cores* — credentials, memory/entities, and the skill SSOT — behind one
MCP gateway, with one profile per harness connection controlling what that
harness is allowed to see.

Two of the three now live in this repository: memory (`internal/memory`) and
skills (`internal/skills`) were absorbed by the repo consolidation on
2026-08-21 (steps 4 and 7), together with guard (`guard/`). Only `symvault`
remains a separate process, deliberately — the secret store assumes its caller
is untrusted. The separate credential process is defense-in-depth alongside service-side authorization, scoped grants and protected IPC; it is not a complete same-user sandbox.

Symbrain is explicitly **not**:

- **A generic MCP hub or aggregator.** Symbrain is not a convenience bundle —
  aggregation without a policy gain is out (ADR 0001). It bundles the state
  cores and, where a profile explicitly names a foreign server, passes it
  through for exposure control and audit. Other tools (`symdesk`, `symbrowse`,
  `symcockpit`, `symfritz`, …) are bound directly to the harness by the user
  unless a profile declares them.
- **A second `symguard`.** See "Brain ↔ Guard Boundary" below.
- **A second `symskills`.** Skill rendering/installation was absorbed on
  2026-08-21 and now runs in-process through `internal/skills` (driven by
  `internal/skillsrunner`). No external `symskills` binary is resolved or
  executed, and the CLI surface lives here as `symbrain skills`.
- **A remote memory or credential store.** Memory and skills are embedded
  in-process (absorbed 2026-08-21); credentials stay behind the separate
  `symvault` process on purpose. symbrain brokers the external vault and
  owns the embedded memory + skills stores.
- **A second general credential service.** Brain owns human administration, including the planned credential UI, but delegates credential storage, cryptography and authorization to the separate service. Human administration must not automatically expand agent MCP exposure.

### Brain ↔ Guard Boundary (verbatim — do not weaken)

Both tools sit between a harness and its tool servers, but at a different
question:

| | **Brain** | **Guard** |
|---|---|---|
| Question | *What is this agent even allowed to see?* | *Is this specific call allowed to happen right now?* |
| Mechanism | **Capability shaping**: filtered `tools/list`, servers on/off per profile, modes like vault `request_only` | **Conduct policing**: risk classification, allow/ask/deny/redact per call, human approval, schema pinning, hash-chain audit |
| Scope | Only the Symaira state cores | Any MCP server, any client |
| Timing | At handshake / catalog build | On every tool call |
| Audit | Lightweight JSONL log (who/what/when, redacted) | Tamper-evident audit (hash chain) |

Consequences:

1. Symbrain implements **no** approval prompts, **no** risk classes, **no**
   schema pinning. A user who needs those puts `symguard` in front.
2. Feature requests for per-call ask/deny policies, risk classification, or
   approval flows belong in the `guard/` module, not in the brain packages —
   redirect them. (Guard was a separate repository until 2026-08-21; the
   boundary is now a module boundary, and is no weaker for it.)
3. What symbrain does today must stay guard-compatible: stable deterministic
   tool names (guard pins schemas), snake_case JSON, zero stdio pollution.

---

## Project Structure

```
symaira-brain/
├── cmd/symbrain/          # CLI entrypoint (main package)
│   └── main.go
├── internal/              # Private packages (not importable outside this module)
│   ├── profile/           # Profile schema (TOML), loading, validation, defaults
│   ├── policy/            # Exposure policy: allow/deny lists, mode presets
│   ├── broker/            # MCP client: spawn, initialize, tools/list, tools/call,
│   │                      #   child lifecycle (health, crash-restart with backoff)
│   ├── gateway/           # MCP server side: handshake, catalog merge,
│   │                      #   namespacing, routing, error mapping
│   ├── catalog/           # Tool catalog: namespacing rules, collision detection
│   ├── audit/             # JSONL audit log, redaction rules
│   ├── instructions/      # Canonical instructions source + managed blocks
│   ├── adapter/           # One small module per harness (claude, codex, cursor,
│   │                      #   opencode, antigravity): instructions + MCP config
│   ├── harness/           # Harness registry: config paths, formats, backup
│   ├── memory/            # Absorbed symmemory: store, entities, consolidation
│   ├── skills/            # Absorbed symskills: skill SSOT, MCP tools
│   └── skillsrunner/      # In-process render+install pipeline used by
│                          #   `symbrain sync` and `symbrain skills`
├── Sources/               # Native SwiftUI apps (macOS + iOS)
│   ├── SymBrainCore/      # Static library: CLI client, models, view models
│   ├── SymBrainApp/       # macOS application (NavigationSplitView dashboard)
│   └── SymBrainMobile/    # iOS companion (read-only overview)
├── Tests/                 # Swift unit tests
│   └── SymBrainCoreTests/ # Decoding tests for CLI JSON shapes
├── guard/                 # Nested module: symguard security gateway (own go.mod,
│   │                      #   module github.com/danieljustus/symaira-guard) —
│   │                      #   absorbed 2026-08-21 (repo consolidation step 7,
│   │                      #   relicensed MIT → Apache-2.0)
│   ├── cmd/symguard/      #   CLI entrypoint (main package)
│   └── internal/          #   private packages: policy, capability, audit, approval, …
├── docs/                  # Local planning docs (git-ignored, not part of the module)
├── project.yml            # Xcode project generation (xcodegen)
├── go.mod, go.sum
├── Makefile
├── README.md
├── LICENSE                # Apache-2.0
└── AGENTS.md              # This file
```

**Rules:**
- Use `cmd/` for the CLI entrypoint, `internal/` for all private logic.
- No `pkg/` directory — all library code stays internal until there is a
  proven external consumer.
- Each package under `internal/` maps to one subsystem. Keep package scope
  narrow.
- New subsystems get their own `internal/<name>/` directory with at least a
  `doc.go` package comment.

---

## Go Coding Standards

### Module and Dependencies

- Module path: `github.com/danieljustus/symaira-brain`
- Go version: 1.26+ (see `go.mod`), `CGO_ENABLED=0`.
- Depends on `symaira-corekit` (pinned to a tagged release, no `replace`
  directive on `main`) for: `configkit`, `logkit`, `exitcodes`, `fsutil`,
  `versionkit`, `updatecheck`.
- **Minimal dependencies.** Prefer the standard library. When a dependency is
  needed, justify it explicitly.

### Error Handling

- Return errors, do not panic. Use `fmt.Errorf("context: %w", err)` for
  wrapping.
- Check errors immediately at the call site. Do not ignore errors.
- Use `corekit/exitcodes` to map errors to the process exit code.

### Naming

- Package names: short, lowercase, single-word (`profile`, `policy`, `audit`).
- Exported types: PascalCase. Unexported: camelCase.
- Avoid stuttering: `profile.Profile` is fine, `profile.ProfileConfig` is not.

### Package Layout

- Each package has a clear, single responsibility.
- Package-level `doc.go` or file-level doc comment explains purpose.
- Keep files under 400 lines. Split when a file grows beyond that.

### Formatting

- Run `gofmt -w -s .` before committing. No exceptions.
- Use `go vet ./...` and `golangci-lint run ./...` (with `go vet` fallback)
  via `make lint`.

---

## Testing Conventions

- Table-driven tests for function-level unit tests.
- Co-locate tests with source: `config_test.go` next to `config.go`.
- Use `t.TempDir()` for filesystem tests — never hardcode temp paths.
- Prioritize tests for: profile/policy evaluation (table-driven, every preset
  matrix), catalog collision detection, adapter output (golden files per
  harness), instructions managed-block idempotency (sync twice = identical
  file).
- Integration tests against the broker use a fake MCP child binary
  (JSON-RPC over stdio) checked into the repo — no test may assume a real
  Symaira binary is present (CI containers have none).
- CI runs `go test -race ./...`. Local verification is optional but
  recommended before pushing.

```bash
make test          # or: go test ./...
make test-race      # go test -race ./...
```

---

## Git Workflow

### Commit Messages

Follow Conventional Commits. Format:

```
<type>: <description>

<body>

Closes #<issue>
```

**Types:** `feat`, `fix`, `docs`, `refactor`, `test`, `chore`, `ci`, `build`

Subject line: imperative mood, lowercase after type, no period, max 72 chars.
Body explains *what* and *why*, not *how*. Reference issues with `Refs #N`,
`Closes #N`, or `Fixes #N`.

### Branch Naming

- Feature branches: `feat/<short-description>` or `issue/<number>-<short-description>`
- Session branches: `session/YYYYMMDD-HHMMSS` (used for batch work)
- Hotfix branches: `fix/<short-description>`

---

## Symaira-Specific Rules

### Binary Name

The binary is always named `symbrain`. Do not use alternative names.

```bash
go build -o symbrain ./cmd/symbrain
```

### Standalone-First

`symbrain` must work without any other Symaira tool installed:

- **No compile-time imports of separately released tools.** Since the
  consolidation this means `symvault` and any tool outside this repo; memory,
  skills and guard are now packages here and are linked directly. The MCP
  client (broker) that talks to external children lives in `internal/broker`.
- Children are found at runtime via `exec.LookPath` with a timeout, never
  assumed to be present.
- If a child binary is missing, the corresponding server is simply left out
  of the catalog and `symbrain doctor` explains why — never a hard error.

> **Verified (2026-08-25).** Skill rendering and installation for `symbrain sync`
> run in-process through `internal/skills` via `internal/skillsrunner` — no
> external `symskills` binary is resolved or executed. Removing the archived
> binary from `PATH` does not skip any requested target; render/install
> failures surface in JSON and human output with a non-zero exit status.

```go
// Good — graceful degradation
path, err := exec.LookPath("symvault")
if err != nil {
    // server omitted from catalog; doctor reports it as a warning, not fatal
    return nil
}
```

### Secret References

Config values that name a secret (e.g. `jwt.secret`) accept a `symvault://<path>`
URI, resolved via a `symvault get <path> --print` subprocess (5s timeout,
env-var fallback). `vault://<path>` is accepted as a deprecated alias for
backward compatibility — both resolve to the identical path and behavior.
New configs and error messages should use `symvault://`; see
`internal/memory/secrets/resolve.go`.

### XDG Paths

| Purpose | Path | Env prefix |
|---------|------|------------|
| Config | `~/.config/symbrain/config.toml` | `SYMBRAIN_*` |
| Data (audit log) | `~/.local/share/symbrain/` | `SYMBRAIN_*` |
| Cache | `~/.cache/symbrain/` | `SYMBRAIN_*` |

### Zero Stdio Pollution (`serve` mode)

When running as an MCP gateway (`symbrain serve --profile <name>`):

- stdin/stdout are the MCP JSON-RPC transport.
- All diagnostic output goes to stderr (`corekit/logkit`, which logs to
  stderr).
- Never write non-JSON-RPC data to stdout while serving.

### snake_case JSON

All MCP/API JSON payloads and every `--json` CLI output use snake_case field
names. Go structs use idiomatic CamelCase with `json:"snake_case"` tags.

### Exit Codes

- `0`: success
- `1`: general runtime error
- `2`: usage or configuration error

### Code Belongs in the Public Core

- No tenant, billing, or hosted-sync code in this repository. There is no Pro
  edition; multi-device sync is out of scope, not deferred elsewhere.

---

## Documentation

- Keep README.md updated with build instructions, usage, and project overview.
- Code comments explain *why*, not *what*.
- Package-level doc comments are mandatory for every package.

---

## CLI Command Reference

| Command | Purpose |
|---|---|
| `symbrain init` | Create XDG directories, default config, and example profiles |
| `symbrain doctor [--json]` | Check environment, config, profiles, and child binaries |
| `symbrain setup` | Download and install pinned core binaries to `~/.symaira/bin` |
| `symbrain setup --from-source DIR [--modules browse,operate,scope]` | Build optional module binaries (browse/operate/scope) from in-repo sources at `DIR` and install them into the managed directory with a provenance sidecar; `doctor`/`setup --fix` treat this as intentional and skip unless `--force-release` |
| `symbrain profile list \| show \| add \| remove` | Manage profiles under `~/.config/symbrain/profiles/` |
| `symbrain config` | Inspect and edit the global config (path, get, set) |
| `symbrain harness list [--project DIR]` | Inspect every known harness and its registered MCP servers |
| `symbrain harness health [--harness NAME] [--project DIR]` | Probe the MCP `initialize` handshake of registered servers |
| `symbrain usage` | AI subscription/token usage per provider |
| `symbrain mcp --profile <name> \| --profile-file <path>` | Run the MCP gateway over stdio (`serve` is a deprecated alias) |
| `symbrain install --harness <name> --profile <name> [--project DIR] [--dry-run]` | Register symbrain with a harness |
| `symbrain uninstall --harness <name> [--project DIR] [--dry-run]` | Remove symbrain from a harness |
| `symbrain sync [--project DIR] [--dry-run] [<harness>...]` | Push instructions/skills to installed harnesses |
| `symbrain memory` | Operate the embedded memory store |
| `symbrain audit tail [-n N] [--profile <name>] [--json]` | Inspect the local JSONL audit log |
| `symbrain vault` | Passthrough to symvault |
| `symbrain guard` | Absorbed symguard commands (decide, scan, doctor, grants, version) |
| `symbrain version` | Print version information |
| `symbrain help` | Show this help message |

---

## Quick Reference

```bash
# Build
make build

# Test
make test
make test-race

# Lint
make lint

# Format
make fmt

# Full local check
go vet ./... && go test -race ./... && go build -o symbrain ./cmd/symbrain
```

---

*This file is a living document. Update it when conventions change.*
