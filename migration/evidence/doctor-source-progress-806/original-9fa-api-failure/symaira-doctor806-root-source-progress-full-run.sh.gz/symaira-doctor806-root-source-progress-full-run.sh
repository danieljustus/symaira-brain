#!/usr/bin/env bash
# Retrospective exact replay command record: first execution used exec_command,
# not this saved file. Original failure precedes any fixture/compiler/CLI launch.
set -euo pipefail
cd /workspace/symaira-doctor806-source-progress
PATH=/workspace/toolchains/go1.26.7/bin:/workspace/toolchains/bin:$PATH GOTOOLCHAIN=local python3 /tmp/symaira-subreaper.py python3 scripts/setup-source-oracle/replay.py /tmp/symaira-doctor806-root-owned-bin/symbrain-go /tmp/symaira-doctor806-root-owned-bin/symbrain /tmp/symaira-doctor806-root-source-progress-full.json > /tmp/symaira-doctor806-root-source-progress-full.log 2>&1
