from pathlib import Path
import json,subprocess,hashlib,gzip,ast
root=Path('/workspace/symaira-doctor806-source-progress-fix')
sha=lambda b:hashlib.sha256(b).hexdigest()
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
assert head=='7ea3cfb9f816291abecc91eef453ec7f3cbc4492' and not subprocess.check_output(['git','status','--porcelain'],cwd=root)
prefix=Path('/tmp/symaira-doctor806-root-source-progress-fixed-full.json')
a=json.loads(prefix.read_text());j=json.loads(Path(str(prefix)+'.progress.json').read_text())
assert a['candidate_head']==head and not a['candidate_dirty'] and a['total']==a['matched']==a['complete_observations']==111 and not a['failures'] and a['exit']==0
assert j['status']=='complete' and j['comparison_exit']==0 and len(j['complete_pairs'])==111 and len(j['events'])==893
assert a['native_cleanup']['actual_native_process'] and not a['native_cleanup']['descendant_active_after_return']
for name,d in a['candidate_source_sha256'].items():assert sha((root/name).read_bytes())==d,name
for name,d in a['go_source_sha256'].items():assert sha(subprocess.check_output(['git','show',a['go_oracle_ref']+':'+name],cwd=root))==d,name
for name,d in j['identities']['candidate_source_sha256'].items():assert sha((root/name).read_bytes())==d,name
for role in ['go','rust']:
 b=Path(j['identities'][role+'_binary']);assert sha(b.read_bytes())==a[role+'_binary_sha256']==j['identities'][role+'_binary_sha256']
# Production unchanged relative to the fully compiled58 source.
files=subprocess.check_output(['git','ls-files','rust'],cwd=root,text=True).splitlines()
production=[]
for name in files:
 if '/src/' in name and not any(x in name for x in ['/tests/','_tests.rs']):
  old=subprocess.check_output(['git','show','58fe50b9d275f0cc8a7ab6a8252a6595a58e52ab:'+name],cwd=root)
  assert (root/name).read_bytes()==old,name
  production.append(name)
# Original contract functions unchanged by diagnostic hooks.
old=subprocess.check_output(['git','show','c6723ab21a3bfe73e84d715695b3d5ea45c661d1:scripts/setup-source-oracle/replay.py'],cwd=root,text=True)
new=(root/'scripts/setup-source-oracle/replay.py').read_text()
for name in ['cases','normalize','filesystem','configure','native_cleanup']:
 extract=lambda s:ast.dump(next(n for n in ast.parse(s).body if isinstance(n,ast.FunctionDef) and n.name==name),include_attributes=False)
 assert extract(old)==extract(new),name
controls=[]
for mode,fields in [('wrong-exit',['exit']),('wrong-source',['stdout_base64'])]:
 q=Path('/tmp/symaira-doctor806-root-source-progress-'+mode+'.json');c=json.loads(q.read_text());jj=json.loads(Path(str(q)+'.progress.json').read_text())
 assert c['exit']==1 and c['total']==1 and c['matched']==0 and c['failures'][0]['fields']==fields and jj['status']=='complete' and jj['comparison_exit']==1
 controls.append({'mode':mode,'actual_rejected_fields':fields})
t=json.loads(Path('/tmp/symaira-doctor806-root-source-progress-timeout.json').read_text());assert t['fixture_removed_after_checkpoint'] and t['journal_retained_after_teardown'] and t['complete_pairs']==0
receipt={'reviewer':'Root different author','source':head,'result':'BOUNDED APPROVE diagnostic journal and portable API correction','actual_source_pairs':111,'complete_journal_events':893,'candidate_hashes_verified':len(a['candidate_source_sha256']),'frozen_go_hashes_verified':len(a['go_source_sha256']),'production_files_byte_identical_to_compiled58':len(production),'actual_controls':controls,'actual_owned_python_timeout_control':t,'actual_go_binary_sha256':a['go_binary_sha256'],'actual_reused_rust_binary_sha256':a['rust_binary_sha256'],'fresh_rust_compilation':False,'prepared_windows_job_experiment':'source-only, neither compiled nor executed; original nativeWindows timeout exactcase/phase/cause still unknown','unchanged_contracts':'all111 cases, five core AST functions, actual binary,25s watchdog and complete streams/files/assertions unchanged','source_archive_scope':'temporary tool/source fixture binaries have exact hashes/source/raw observations; no retained payload claim'}
Path('/tmp/symaira-doctor806-root-source-progress-review.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({k:v for k,v in receipt.items() if k not in ['actual_owned_python_timeout_control']},indent=2))
