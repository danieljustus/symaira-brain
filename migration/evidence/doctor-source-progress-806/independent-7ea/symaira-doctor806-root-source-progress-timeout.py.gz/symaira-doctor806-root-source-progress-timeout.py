import sys,json,tempfile,subprocess,hashlib,base64,time
from pathlib import Path
sys.path.insert(0,str(Path.cwd()/"scripts/setup-source-oracle"))
import replay
from progress import Journal
report=Path("/tmp/symaira-doctor806-root-source-progress-timeout.json")
case=replay.cases()[0]
source=Path("/tmp/symaira-doctor806-root-source-timeout-child.py")
source.write_text("#!/usr/bin/python3\nimport os,time\nfrom pathlib import Path\nPath('owned-diagnostic-marker').write_bytes(bytes(range(256)))\nos.write(1,b'owned-timeout-stdout\\x00\\xff')\nos.write(2,b'owned-timeout-stderr\\x00\\xff')\ntime.sleep(60)\n")
source.chmod(0o755)
go=Path("/tmp/symaira-doctor806-root-owned-bin/symbrain-go")
journal=Journal(report,[case],"root-actual-owned-child-timeout",{"head":subprocess.check_output(["git","rev-parse","HEAD"],text=True).strip(),"child_sha256":hashlib.sha256(source.read_bytes()).hexdigest(),"scope":"actual controlled Python child through unchanged observe25s, not production binary/Windows original-cause claim"})
started=time.monotonic()
with tempfile.TemporaryDirectory(prefix="source-root-timeout-owned-") as directory:
 root=Path(directory)
 try:replay.observe(source,case,root,go,source,journal=journal,label="owned-timeout-control")
 except subprocess.TimeoutExpired as error:journal.failed(error)
 else:raise AssertionError("real timeout not detected")
 live=json.loads(journal.path.read_text());event=live["events"][-1]
 assert event["phase"]=="child-exception" and event["exception_type"]=="TimeoutExpired"
 assert base64.b64decode(event["timeout_stdout_base64"])==b"owned-timeout-stdout\x00\xff"
 assert base64.b64decode(event["timeout_stderr_base64"])==b"owned-timeout-stderr\x00\xff"
 marker=next(x for x in event["fixture"]["rows"] if x["path"].endswith("owned-diagnostic-marker"))
 assert marker["sha256_complete"] and marker["raw_bytes_complete"] and base64.b64decode(marker["raw_bytes_base64"])==bytes(range(256))
 assert live["status"]=="failed" and not live["complete_pairs"] and root.exists()
assert not root.exists() and journal.path.exists()
elapsed=time.monotonic()-started
assert 25<=elapsed<30,elapsed
report.write_text(json.dumps({"candidate_head":journal.data["identities"]["head"],"elapsed_seconds":elapsed,"original_outer_timeout_seconds":25,"fixture_removed_after_checkpoint":True,"journal_retained_after_teardown":True,"raw_all256bytes_and_null_ff_streams_verified":True,"no_production_child_or_native_windows_claim":True,"complete_pairs":0},indent=2)+"\n")
print(report.read_text())
