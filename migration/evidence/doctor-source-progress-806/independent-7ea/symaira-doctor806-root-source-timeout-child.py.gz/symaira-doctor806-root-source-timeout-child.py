#!/usr/bin/python3
import os,time
from pathlib import Path
Path('owned-diagnostic-marker').write_bytes(bytes(range(256)))
os.write(1,b'owned-timeout-stdout\x00\xff')
os.write(2,b'owned-timeout-stderr\x00\xff')
time.sleep(60)
