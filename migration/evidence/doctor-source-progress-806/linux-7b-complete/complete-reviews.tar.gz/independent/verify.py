import ast, gzip, hashlib, json, pathlib, re, subprocess, time
OUT=pathlib.Path(__file__).resolve().parent
BASE=pathlib.Path('/workspace/symaira-source765-full-independent-runtime-review')
ROOT=pathlib.Path('/workspace/symaira-source765-windows-job-runtime-review')
PREP=pathlib.Path('/workspace/symaira-source765-runtime-review-preparation')
R=json.loads((BASE/'receipt.json').read_bytes())
checks={}; hashes={}; archives={}; started=time.time()
def digest(path):
 p=str(path)
 if p not in hashes:
  h=hashlib.sha256(); n=0
  with open(p,'rb') as f:
   while b:=f.read(1024*1024): h.update(b); n+=len(b)
  hashes[p]=(h.hexdigest(),n)
 return hashes[p]
def record(row):
 assert digest(row['path'])[0]==row['sha256'],row['path']
 if 'bytes' in row: assert digest(row['path'])[1]==row['bytes'],row['path']
def archive(row):
 p=row['archive']
 if 'archive_sha256' in row: assert digest(p)[0]==row['archive_sha256'],p
 if row.get('already_gzip'):
  assert digest(p)[0]==row['sha256'] and digest(p)[1]==row['bytes'],p
 if p not in archives:
  h=hashlib.sha256();n=0;prefix=b''
  with gzip.open(p,'rb') as f:
   while b:=f.read(1024*1024):
    if not prefix:prefix=b[:4]
    h.update(b);n+=len(b)
  archives[p]=(h.hexdigest(),n,prefix.hex())
 if not row.get('already_gzip'):
  assert archives[p][0]==row['sha256'],p
  if 'bytes' in row:assert archives[p][1]==row['bytes'],p
def save():
 checks.update(elapsed=time.time()-started,unique_read_paths=len(hashes),unique_gzip_roundtrips=len(archives))
 (OUT/'verification.json').write_text(json.dumps(checks,indent=2)+'\n')
h=json.loads((BASE/'handoff.json').read_bytes())
for p,s in h['proofs'].items():assert digest(p)[0]==s
for row in json.loads((BASE/'manifest.json').read_bytes()):record(row)
checks['handoff_manifest']='PASS'
for old in R['old_receipts_roundtrip_verified']:
 record(old);d=json.loads(pathlib.Path(old['path']).read_bytes())
 assert len(d['raw_records'])+len(d['cache_ELF_archives'])==old['raw_records_roundtrip']
 for row in d['raw_records']+d['cache_ELF_archives']:archive(row)
 checks[old['path']]={'raw_records':len(d['raw_records']),'additional_cache_ELF_archives':len(d['cache_ELF_archives']),'PASS':True}
 save();print('old complete',old['path'],flush=True)
for row in R['raw_records']: archive(row)
for p,s in R['unique_archive_paths_roundtrip_verified'].items():archive({'archive':p,'sha256':s})
for key in ['ELF_roles','actual_Go_observed_build_roles','cache_ELF_archives']:
 for row in R[key]:archive(row)
 checks[key]={'rows':len(R[key]),'PASS':True}
save();print('all executable archives complete',len(archives),flush=True)
for row in R['current_ELF_paths']:
 record(row)
 with open(row['path'],'rb') as f:assert f.read(4)==b'\x7fELF'
checks['current_ELF_paths']={'rows':len(R['current_ELF_paths']),'PASS':True}
for row in json.loads((BASE/'sdk-payload-retention.json').read_bytes()):record(row);archive(row)
for row in R['SDK_registry_source_records_verified']:record(row)
checks['SDK_original_retention']={'rows':len(R['SDK_registry_source_records_verified']),'PASS':True}
for row in R['wrapper_byte_projections']:
 assert digest(row['projection'])[0]==row['sha256']
checks['wrappers']={'rows':len(R['wrapper_byte_projections']),'not_product_execution':True}
bind=json.loads((PREP/'current-source-frozen-bindings.json').read_bytes())
requests=[]
for key,rev in [('candidate',bind['head']),('frozen',bind['frozen_revision'])]:
 for path,sha in bind[key].items():
  requests.append((rev+':'+path,sha,key,path))
proc=subprocess.Popen(['git','-C',str(ROOT),'cat-file','--batch'],stdin=subprocess.PIPE,stdout=subprocess.PIPE)
for ident,sha,key,path in requests:
 proc.stdin.write((ident+'\n').encode());proc.stdin.flush()
 hdr=proc.stdout.readline().decode().strip().split();assert hdr[1]=='blob',ident
 size=int(hdr[2]);raw=proc.stdout.read(size);assert proc.stdout.read(1)==b'\n'
 assert hashlib.sha256(raw).hexdigest()==sha,ident
 if key=='candidate':assert digest(ROOT/path)[0]==sha,path
proc.stdin.close();assert proc.wait()==0
checks['immutable_git_sources']={k:len(bind[k]) for k in ['candidate','frozen']}
assert subprocess.check_output(['git','-C',str(ROOT),'rev-parse','HEAD']).decode().strip()==R['source']
assert not subprocess.check_output(['git','-C',str(ROOT),'status','--porcelain=v1','-uall'])
static=json.loads(pathlib.Path('/workspace/symaira-source765-windows-job-independent-static-review-receipt.json').read_bytes())
for row in static['files']:record(row)
checks['original_static_files']={'count':len(static['files']),'PASS':True}
stage_rows=[]; summaries=[]
for stage in R['completed_stages']:
 assert stage['exit']==0 and not stage.get('space_abort') and not stage.get('outer_timeout')
 candidates=[]
 for run in ['/workspace/symaira-source765-runtime-review-run','/workspace/symaira-source765-runtime-review-resume-run','/workspace/symaira-source765-runtime-final-writer-run']:
  for stream in ['stdout','stderr']:
   p=pathlib.Path(run)/'logs'/(stage['name']+'.'+stream)
   if p.exists() and digest(p)[0]==stage[stream+'_sha256']: candidates.append((stream,str(p)))
 assert set(s for s,p in candidates)=={'stdout','stderr'},stage['name']
 stage_rows.append(dict(name=stage['name'],streams=candidates,exit=0))
 if stage['name']=='whole-tests':
  p=next(p for s,p in candidates if s=='stdout')
  for text in pathlib.Path(p).read_text().splitlines():
   m=re.match(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;',text)
   if m:summaries.append(tuple(map(int,m.groups())))
assert len(stage_rows)==32 and len(summaries)==66
assert sum(v[0] for v in summaries)==567 and all(v[1:]==(0,0) for v in summaries)
checks['actual_stages']=stage_rows
checks['test_summaries']={'summaries':len(summaries),'passed':567,'failed':0,'ignored':0}
checks['no_new_product_SDK_compiler_network_port_execution']=True
checks['source']=R['source'];checks['status']='PASS_RECORDED_PROOF_BINDINGS_NOT_NATIVE_WINDOWS_ACCEPTANCE'
save();print(json.dumps({k:v for k,v in checks.items() if k not in ['actual_stages']})[-3000:],flush=True)
