import hashlib,json,pathlib
OUT=pathlib.Path(__file__).resolve().parent
BASE=pathlib.Path('/workspace/symaira-source765-full-independent-runtime-review')
R=json.loads((BASE/'receipt.json').read_bytes());manifests={}
def stable(v):return json.dumps(v,sort_keys=True,separators=(',',':'))
for row in R['ELF_roles']:
 p=row['manifest']
 if p not in manifests:manifests[p]={stable(v) for v in json.loads(pathlib.Path(p).read_bytes())}
 assert stable({k:v for k,v in row.items() if k!='manifest'}) in manifests[p],(p,row['original_path'])
go=[]
for base in ['/workspace/symaira-source765-runtime-review-run','/workspace/symaira-source765-runtime-review-resume-run','/workspace/symaira-source765-runtime-final-writer-run']:
 p=pathlib.Path(base)/'go-binaries/actual-go-builds.jsonl'
 if p.exists():go.extend(json.loads(line) for line in p.read_bytes().splitlines())
assert len(go)==40 and [stable(v) for v in go]==[stable(v) for v in R['actual_Go_observed_build_roles']]
result={'source':R['source'],'stage_ELF_role_manifest_membership':len(R['ELF_roles']),'original_role_manifests':len(manifests),'actual_Go_compiler_observation_rows':40,'controls':{},'outputs':{}}
RUN=pathlib.Path('/workspace/symaira-source765-runtime-review-run/reports')
for rel in ['activity.json.controls.json','guard-controls.json','memory-read-controls.json','setup-output/controls.json','doctor-output/controls.json']:
 d=json.loads((RUN/rel).read_bytes());rows=d.get('controls',d.get('groups',[]));assert rows
 for row in rows:
  if 'rejected' in row:assert row['rejected']
  if 'exit' in row:assert row['exit']!=0
  if 'rejected_cases' in row:assert row['rejected_cases']
  if 'exact_rejected_cases' in row:assert row['exact_rejected_cases']
  if 'actual_rejected_cases' in row:assert row['actual_rejected_cases']
 result['controls'][rel]=len(rows)
for rel,total in [('doctor-output/process.json',9),('doctor-output/fix.json',4),('setup-output/source-output.json',2),('setup-output/pipe-probes.json',6),('setup-output/human-pipe-probes.json',6),('setup-output/output-probes.json',4)]:
 d=json.loads((RUN/rel).read_bytes());assert len(d['cases'])==total
 for row in d['cases']:assert not row['differences']
 result['outputs'][rel]=total
ev=json.loads(pathlib.Path('/workspace/symaira-source765-runtime-review-resume-run/reports/evidence.json').read_bytes())
assert ev['alignment_cases']==32 and ev['validation_cases']==48 and ev['jsonl_records']==3
assert ev['production_go_db_tests_passed']==['TestSaveMemoryEvidence_PersistsGroundedExtractions','TestSaveMemoryEvidence_SkipsUnmatched','TestMemoryEvidence_CascadeDeletesWithMemory','TestReparentMemoryEvidenceTx_MovesRows']
controls=json.loads(pathlib.Path('/workspace/symaira-source765-runtime-review-resume-run/reports/evidence-controls.json').read_bytes());assert len(controls)==3
for c in controls:assert c['exit_code']!=0 and c['observed_reason'] is True
result['evidence']={'alignment':32,'validation':48,'JSONL':3,'Go_tests':True,'controls':3}
result['new_executions']=0;result['status']='PASS_RETAINED_ROLE_AND_RESULT_BINDINGS'
(OUT/'roles-controls-verification.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
