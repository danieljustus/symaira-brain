import ast,base64,hashlib,json,os,pathlib,re,subprocess
OUT=pathlib.Path(__file__).resolve().parent
ROOT=pathlib.Path('/workspace/symaira-source765-windows-job-runtime-review')
PREP=pathlib.Path('/workspace/symaira-source765-runtime-review-preparation')
SOURCE='7b10ff20027407ca9bc32f3d72e28d07003fce77';GO='dcddcef0df5789123c7c9a7ebe6e01f10e941f2c'
RUN=pathlib.Path('/workspace/symaira-source765-runtime-review-run')
RESUME=pathlib.Path('/workspace/symaira-source765-runtime-review-resume-run')
FINAL=pathlib.Path('/workspace/symaira-source765-runtime-final-writer-run')
result={'source':SOURCE,'scope':'PURE retained report comparison, Git-source SHA and adapter AST; no SDK/product execution','reports':[]};requests=[]
for base in [RUN,RESUME,FINAL]:
 for p in (base/'reports').rglob('*.json'):
  d=json.loads(p.read_bytes());result['reports'].append({'path':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
  if isinstance(d,dict):
   for k,v in d.items():
    if k in ['candidate_source_sha256','candidate_manifest_sha256','go_source_sha256','immutable_go_cli_source_sha256','immutable_go_db_source_sha256','frozen_go_source_sha256']:
     rev=SOURCE if k.startswith('candidate') else GO
     for rel,sha in v.items():requests.append((rev+':'+rel,sha,str(p),k))
proc=subprocess.Popen(['git','-C',str(ROOT),'cat-file','--batch'],stdin=subprocess.PIPE,stdout=subprocess.PIPE)
cache={}
for ident,sha,path,key in requests:
 if ident not in cache:
  proc.stdin.write((ident+'\n').encode());proc.stdin.flush();head=proc.stdout.readline().decode().split();assert head[1]=='blob',ident
  raw=proc.stdout.read(int(head[2]));assert proc.stdout.read(1)==b'\n';cache[ident]=hashlib.sha256(raw).hexdigest()
 assert cache[ident]==sha,(path,key,ident)
proc.stdin.close();assert proc.wait()==0
result['all_report_source_map_entries']=len(requests);result['unique_git_source_identifiers']=len(cache)
def load(rel,base=RUN):return json.loads((base/'reports'/rel).read_bytes())
for name,total in [('source',111),('doctor',285)]:
 d=load(name+'.json');assert d['total']==d['matched']==d['complete_observations']==total and d['exit']==0 and not d['failures']
 for row in d['observations']:assert row['go']['contract']==row['rust']['contract']
 result[name]={'full_contract_pairs':total,'PASS':True}
 for suffix in ['wrong-exit','wrong-source'] if name=='source' else ['wrong-exit','missing-header','missing-core-event']:
  c=load(name+'.json.'+suffix+'.json');assert c['exit']==1 and c['matched']==0 and c['failures']
  assert c['observations'][0]['go']['contract']!=c['observations'][0]['rust']['contract']
result['source_progress_exact']=load('source.json.progress.json')['complete_pairs']==load('source.json')['observations']
assert result['source_progress_exact']
# Extract exactly the unchanged pure Guard comparator AST, without importing any runner.
tree=ast.parse((ROOT/'scripts/guard-standalone-oracle/replay.py').read_text())
funcs=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name in ['comparable','compare']]
ns={'json':json};exec(compile(ast.Module(body=funcs,type_ignores=[]),'<immutable-pure-guard-comparator>','exec'),ns)
d=load('guard.json');assert len(d['results'])==124
counts={}
for row in d['results']:
 verdict=ns['compare'](row,row['go'],row['rust']);counts[verdict or 'matched']=counts.get(verdict or 'matched',0)+1
assert counts=={'matched':121,'native-fail-closed-remaining-port':3}
result['guard_exact_original_comparator']=counts
d=load('guard-raw-paths.json');assert len(d['results'])==d['matched']==63
for row in d['results']:assert ns['comparable'](row['go'])==ns['comparable'](row['rust'])
result['guard_raw_contract_pairs']=63
d=load('activity.json');assert d['total']==265 and d['matches'] is True
for row in d['observations']:assert row['go']==row['rust']
result['activity_exact_pairs']=265
d=load('memory-read.json');assert d['cases']==d['passed']==590 and not d['operator_home_used'] and not d['fallback_available']
for row in d['records']:
 assert row['match'] and row['go']==row['rust']
 if 'database_state_unchanged' in row:assert row['database_state_unchanged']
result['memory_read_exact_pairs']=len(d['records'])
# Embedded criteria are the original explicit field selectors; raw unnormalized stderr is retained separately.
for rel,expected in [('setup-output/embedded.json',24),('doctor-output/embedded.json',27),('partial-writer18.json',18)]:
 d=load(rel,FINAL if rel=='partial-writer18.json' else RUN);assert len(d['cases'])==expected
 for row in d['cases']:
  fields=['exit','stdout_base64','before','after']+(['logs'] if row.get('route')=='fix' and rel.startswith('doctor-') else ['stderr_base64'])
  diff=[k for k in fields if row['go'][k]!=row['rust'][k]]
  assert diff==row['differences']==[]
 result[rel]={'actual_full_embedded_rows':expected,'PASS':True}
d=load('novel.json',RESUME);assert len(d['records'])==18
for row in d['records']:assert row['go']['contract']==row['rust']['contract'] and not row['differences']
result['novel_full_contract_pairs']=18
# Verify all original supplementary byte literals and entire AST after documented path-only substitutions.
mapping=json.loads((RESUME/'parent-adapter-map.json').read_bytes());originals=json.loads((PREP/'original-parent-driver-map.json').read_bytes());ast_checks=[]
for name,item in mapping.items():
 old=next(pathlib.Path(p) for p,v in originals.items() if pathlib.Path(p).name==name)
 oldraw=old.read_bytes();assert hashlib.sha256(oldraw).hexdigest()==item['original_sha256']
 t=ast.parse(oldraw);changes={r['original']:r['replacement'] for r in item['path_literals_only']}
 class Replace(ast.NodeTransformer):
  def visit_Constant(self,node):
   if isinstance(node.value,str) and node.value in changes:return ast.copy_location(ast.Constant(changes[node.value]),node)
   return node
 fixed=Replace().visit(t);new=ast.parse((RESUME/'parent-supplements'/name).read_bytes())
 assert ast.dump(fixed)==ast.dump(new),name
 ast_checks.append(name)
result['full_original_supplemental_AST_exact_except_documented_paths']=ast_checks
bind=json.loads((FINAL/'binding.json').read_bytes());p=pathlib.Path(bind['script']);assert hashlib.sha256(p.read_bytes()).hexdigest()==bind['script_sha256']
driver=ast.parse((PREP/'runtime-review.py').read_bytes());stage=next(n for n in ast.walk(driver) if isinstance(n,ast.FunctionDef) and n.name=='stage')
assert hashlib.sha256(ast.dump(stage).encode()).hexdigest()==bind['unchanged_original_stage_function_AST_sha256']
assert bind['missing_report_path_only_environment_correction']=={'SETUP_OUTPUT_REPORT':str(FINAL/'reports/partial-writer18.json')}
result['final_stage_same_AST_only_missing_report_env']=True
result['no_product_SDK_compiler_port_network_calls']=True
(OUT/'report-comparison-verification.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k!='reports'},indent=2))
