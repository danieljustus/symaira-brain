import ast,base64,gzip,hashlib,io,json,pathlib,re,zipfile
ROOT=pathlib.Path('/workspace/symaira-source765-windows-job-runtime-review');OUT=pathlib.Path(__file__).resolve().parent
RUN=pathlib.Path('/workspace/symaira-source765-runtime-review-run')
ret=json.loads((ROOT/'migration/evidence/setup-source-765/windows-job-443-original/retention.json').read_bytes());raws={};rows=[]
for r in ret['files']:
 p=ROOT/r['retained'];raw=gzip.decompress(p.read_bytes());assert len(raw)==r['bytes'] and hashlib.sha256(raw).hexdigest()==r['sha256']
 raws[r['path']]=raw;rows.append({'original':r['path'],'retained':str(p),'sha256':r['sha256'],'bytes':len(raw)})
zips=[]
member_receipts=[json.loads(raw) for path,raw in raws.items() if path.endswith('original-member-receipt.json')]
for path,raw in raws.items():
 if not path.endswith('.zip'):continue
 with zipfile.ZipFile(io.BytesIO(raw)) as z:
  members=[]
  for info in z.infolist():
   b=z.read(info);members.append({'member':info.filename,'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b),'zip_external_attr':info.external_attr})
  matching=[r for r in member_receipts if r['zip_sha256']==hashlib.sha256(raw).hexdigest()]
  if matching:
   expected=[{k:v for k,v in r.items() if k in ['member','sha256','bytes','zip_external_attr']} for r in matching[0]['members']]
   assert members==expected
 zips.append({'path':path,'sha256':hashlib.sha256(raw).hexdigest(),'members':members,'original_receipt_matched':bool(matching)})
assert len(rows)==63 and len(zips)==4 and sum(len(z['members']) for z in zips)==30
def report(rel):return json.loads((RUN/'reports'/rel).read_bytes())
# Recompute Setup's unchanged root, backup and download-scratch substitutions on complete raw streams.
tree=ast.parse((ROOT/'scripts/rust-differential.py').read_bytes());f=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='normalize_fixture_root')
ns={'Path':pathlib.Path,'json':json};exec(compile(ast.Module(body=[f],type_ignores=[]),'<original-pure-normalizer>','exec'),ns)
d=report('setup.json');assert d['total']==201 and len(d['observations'])==402
def stream(row,key):
 b=ns['normalize_fixture_root'](base64.b64decode(row[key]),pathlib.Path(row['fixture_root']))
 b=re.sub(rb'\.bak\.[0-9]{8}T[0-9]{6}Z(?:\.[0-9]+)?',b'.bak.<timestamp>',b)
 return re.sub(rb'[/\\][^"\n]*?[/\\]symbrain-managed-[^/\\"\n]+[/\\]',b'<download>/',b)
for a,b in zip(d['observations'][::2],d['observations'][1::2]):
 assert a['exit']==b['exit'] and stream(a,'stdout_base64')==stream(b,'stdout_base64') and stream(a,'stderr_base64')==stream(b,'stderr_base64')
 assert a['filesystem_before']==b['filesystem_before'] and a['filesystem_after']==b['filesystem_after']
counts={}
for name,total in [('writes.json',60),('deletes.json',16),('write-failures.json',10)]:
 d=report('memory-write/'+name);assert len(d['cases'])==d['passed']==d['total']==total
 for r in d['cases']:
  assert r['match']
  if 'comparison' in r['go']:assert r['go']['comparison']==r['rust']['comparison']
  else:
   assert r['go']['transcript']==r['rust']['transcript']
 counts[name]=total
d=report('memory-write/fallback-boundaries.json');assert len(d['cases'])==d['passed']==d['total']==13
for r in d['cases']:
 assert r['match'] and r['database_unchanged']==(r['database_before']==r['database_after'])
 if r['name'] in ('invalid-duplicate-metadata','invalid-scope','bad-metadata-delete','bad-embedding-delete','bad-time-delete','leap-second-delete'):
  assert r['delegated']['exit'] in (1,2) and r['database_unchanged']
 assert {k:r['delegated'][k] for k in ['exit','stdout','stderr']}==r['transcript']
counts['fallback-boundaries.json']=13
result={'source':ret['original_publication'],'candidate':'7b10ff20027407ca9bc32f3d72e28d07003fce77','original63_roundtrips':rows,'four_original_ZIPs':zips,'Setup_complete_raw_stream_and_full_filesystem_pairs':201,'Memory_original_comparison_rows':counts,'scope':'PURE original observations and unchanged narrow comparator, not new SQLite/product execution','status':'PASS'}
(OUT/'retention-state-verification.json').write_text(json.dumps(result,indent=2)+'\n');print('PASS63archives4ZIP30membersSetup201Memory60/16/13/10')
