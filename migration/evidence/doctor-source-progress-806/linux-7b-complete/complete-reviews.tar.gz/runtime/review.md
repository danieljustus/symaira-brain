# Independent Source765 review of immutable 7b10ff2

All 32 declared Linux stages passed on clean `7b10ff20027407ca9bc32f3d72e28d07003fce77`. I found no additional actionable production defect in the bounded Windows cleanup correction or the exercised Linux parent contracts. This completes the allocated Linux review, with an explicit original-executable retention limitation below. It does **not** establish the Windows correction at runtime or authorize a merge without the exact-head native checks.

## Source and ownership

This is a different-author review. The candidate, frozen Go `dcddcef0df5789123c7c9a7ebe6e01f10e941f2c`, original cases, deadlines, and comparison rules were not edited. The final receipt verifies 711 candidate source bindings, 1,217 frozen source bindings, and 23 pinned Go SDK/process-wrap registry source references. The original complete 174-proof source review and full parent census are retained in the preparation and original preservation receipts.

The Windows change polls `ChildWrapper::inner_mut().try_wait()` rather than consuming JobObject completion notifications during parent polling. Cleanup requests whole-job termination with `start_kill()`, then calls wrapper `wait()` even if termination failed; `Result::and` preserves termination-error precedence. Unix process-group cancellation and file capture are unchanged. I reviewed the entire affected process owner, private cleanup helper, diagnostic test, native collector/watchdog, workflow, pinned process-wrap `std/core.rs`, `std/job_object.rs`, and Windows completion-port code. Lookup, argv/cwd, capture ordering, cancellation, output callbacks, receiver ownership, and existing managed/store boundaries remain covered by the original full-source review and fresh affected parent gates.

The pinned wrapper's `wait_on_job` does not inspect the completion message type. A wrapper return is therefore not independent evidence that every descendant is inactive. The native watchdog explicitly checks actual descendant inactivity, retains phases/raw output/PE bytes, and rejects forced cleanup in the corrected modes. That diagnostic and the original 95-case Windows Source gate still require genuine Windows execution. The five diagnostic modes import the same production helper; their Linux cfg-empty test output is not Windows evidence. The original Windows timeout and historical polling/cleanup observations remain unchanged, including their absent original PE payload qualification.

## Actual Linux checks

The first run completed 17 stages before the disk guard stopped Evidence at 728,621,056 bytes, below the unchanged 734,003,200-byte floor. The complete interrupted attempt is preserved as a resource abort, not a product mismatch. After the Root resume lease and source/SDK/binary verification, the remaining 14 stages passed. The last unchanged 18-case script then failed because this review driver omitted its required `SETUP_OUTPUT_REPORT` environment variable. That failed attempt and its actual helper bytes are retained; its cases were not accepted from an incomplete report. Root authorized only that final stage with a new owned report path. It passed with its complete 18-row report. The accounting is **17 + 14 + 1 = 32**, with neither interruption counted as a pass and no unrelated prior stage repeated.

- Whole CLI/Core/Managed/Gateway/MCP/Broker/Memory/Activity/Guard graph: all targets/features build, 567 passed tests across 66 summaries, strict Clippy, rustfmt, and actionlint. The selected package list and exact Cargo argv are in the stage records.
- Original Source 111/111 plus both actual intended mismatch controls; Doctor 285/285 plus all three controls; Setup 201/201. The Windows counterparts 95/269/177 were inventoried separately and not reported as Linux observations.
- Guard: all 124 original process cases exercised, 121 matches and exactly three previously declared unported diagnostic states; zero audit diagnostic deviations. The original raw-path series contains 63 matches and two real rejection controls. This is not a newly invented Doctor typed-config 63-case suite.
- Activity 265/265 plus three actual native fixture controls; all original SetupOutput six reports/four control groups and DoctorOutput three reports/three control groups. SetupOutput covers 24 embedded, 2 source-output, 6 closed/partial pipe, 6 human-pipe, and 4 output-probe rows; DoctorOutput covers 27 embedded, 9 process, and 4 fix rows.
- Memory 590/590; both read mutation controls each reject their 32 cases; write 60 Set/16 Delete/13 fallback boundaries/10 committed-output-failure pairs and all three actual mutation controls. The original deterministic database fixture check passes (29 tables, four negative and two ordering cases).
- Evidence: 32 alignments/48 validations/three exact JSONL records; four actual frozen-Go database evidence tests; all three missing-fixture/status/missing-case controls reject for their intended reasons.
- Full MCP process differential, all seven printed groups; every original Doctor6 finding, lookup, raw-signal/cancellation, home, boundary, symlink, consumer and fix-consumer supplement. The final 18 actual paired partial-writer cases cover raw pipe/raw full/callback × install/fix/source × human/JSON with complete output and committed-state comparisons.
- Eighteen independent owned Source/Doctor boundary cases all match, including healthy unknown configuration, malformed bool/terminator spellings, literal HOME parent paths, valid raw TMP paths, and TMP files. Native builds and callbacks used owned fixtures; no operator credentials or external paid providers were used.

No full legacy-memory-schema acceptance is inferred: the historical schema runner is not present in this source checkpoint. Original typed-config/parse requirements and older supplements retain their actual attribution, rather than being relabeled as a new suite.

## Executable and raw-proof availability

The actual primary Rust CLI is `f68e048329cb336fab92b9d5d23fa5127a7a675cbb4f95d3fe9fbf05b883be32`. The retained fixed Go CLI used by later Memory/novel/supplement callers is `7368c27fc8f6a268fe223cc4082866ac6ee6197ea5e2295468fd59cf6bb14245`. These bytes are archived and verified separately. The actual native partial-writer caller is `9111b598b663dfb3f86f8e304df52bd75b73e4ec9e91629ba2e0e72e8ac32f43`; the successful final Go partial-writer is `9a486896796dc56100963bc1eeb69dc91f511dc675a4cf29ab4e2101e558df39`. Failed and successful helper builds with differing source paths remain distinct actual payloads.

The final receipt binds 9,431 cumulative stage ELF-role records, 738 currently retained executable path records, and 786 round-trip-verified archive paths representing 702 distinct ELF hashes. Repeated stage records are not additional tests. Unselected cached/build-tool binaries are identified separately from Cargo-reported and actually executed artifacts. Forty observed Go build-role rows preserve their actual argv/cwd/stage and archived bytes. Four current owned Go-cache ELF payloads are also archived; the cache has not been retired.

**Six original ephemeral Go CLI executable payloads are unavailable.** Their actual reported SHA, frozen sources, full raw reports/controls, candidate bindings, original runner stage argv and bound build recipes remain preserved, but the private runner paths were deleted before retention. The observer captured only `args[0] == 'build'`; the original oracle driver uses `go -C SOURCE build`, and some runners use the absolute SDK path. The six hashes do not match the separately archived original cache executables. No new build, fixed CLI, helper, or archive is substituted for these original bytes:

| Actual original role | Recorded SHA256 |
| --- | --- |
| Source | `b2e1d526c6355e9c56533196ac4f12cc57b0094adfd8ee6c68558ce929ec8691` |
| Doctor | `58a561f7c37ee33b5dd6a46def2d2946d67f84e757fe576e8ae90240e4b7ad7f` |
| Setup | `885c037653856e4b10e132705329c58a38cdef86dd39b48fd5f74c8ef94b9a2d` |
| Activity | `c3f200b39cdc81c77c6dc47656146e1886f8579a9c05a694f91336f5c9d497a6` |
| DoctorOutput | `057e1f3c06bdb6d41b55960b5c73555ed6e7a169b0b65e2dffc7f7921718170a` |
| SetupOutput | `3c3c3efd32301d28c1478686b30017424a3d5f129e739b6e6fe8f4d907b5df85` |

Ten text control-wrapper payloads match their recorded SHA exactly. Four are original literal `wrapper_text` retained in reports; six are projections of the original bound source literal and recorded native path/mode. The projections are explicitly labeled, were not executed again, and are not represented as original filesystem captures or ELF programs. Per-build argv records missing for the six absent Go payloads are not fabricated from their source recipes.

## Remaining admission and lifecycle

The final source remains clean and immutable. No production edit, route expansion, fallback waiver, GitHub write, or closure occurred. Exact-head Windows95/five diagnostic modes/native PE retention and all required native-platform/protected CI checks remain necessary; Root handles publication and final acceptance. The complete raw resource abort and runner-environment failure remain independently archived. Linux passes do not erase either attempt or establish Windows runtime correctness.

At freeze, `/proc` has zero visible target/cache/scratch consumers and port11434 has no listener. Root-owned dockerd198/containerd249 fd/environment visibility is unavailable and is explicitly recorded rather than declared proven absent. The target and port remain allocated until the separate explicit release receipt. No cache or target deletion has been performed during finalization.
