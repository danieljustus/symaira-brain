import ast,base64,csv,hashlib,importlib.util,io,json,os,subprocess,sys,tempfile,time
from pathlib import Path
repo=Path('/workspace/symaira-doctor806-source-progress-fix')
assert not subprocess.check_output(['git','status','--porcelain'],cwd=repo)
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()
command=[sys.executable,str(repo/'scripts/setup-source-oracle/test_progress.py')]
result=subprocess.run(command,cwd=repo,capture_output=True)
log=Path('/tmp/symaira-doctor806-journal-api-fixed-clean-tests.log');log.write_bytes(result.stdout+result.stderr)
assert result.returncode==0 and b'Ran 6 tests' in log.read_bytes() and b'OK' in log.read_bytes()
modules={'base64':base64,'csv':csv,'hashlib':hashlib,'json':json,'os':os,'subprocess':subprocess,'tempfile':tempfile,'time':time}
checks=[]
for name in ['progress.py','windows_job_probe.py']:
 for node in ast.walk(ast.parse((repo/'scripts/setup-source-oracle'/name).read_bytes())):
  if not isinstance(node,ast.Call) or not isinstance(node.func,ast.Attribute) or not isinstance(node.func.value,ast.Name):continue
  if node.func.value.id in modules:
   module=node.func.value.id;api=node.func.attr;assert callable(getattr(modules[module],api))
   checks.append({'source':name,'line':node.lineno,'api':module+'.'+api,'callable_exists':True})
for cls,names in [(Path,['resolve','mkdir','read_bytes','read_text','write_bytes','open','iterdir','lstat','relative_to','readlink','exists','unlink']), (subprocess.Popen,['wait','poll']), (io.BufferedWriter,['write','flush','fileno','close']), (io.BufferedReader,['read'])]:
 for name in names:
  assert callable(getattr(cls,name));checks.append({'api':cls.__name__+'.'+name,'callable_exists':True})
old=Path('/workspace/symaira-doctor806-source-progress/scripts/setup-source-oracle/progress.py')
spec=importlib.util.spec_from_file_location('original_9fa_progress',old);module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
with tempfile.TemporaryDirectory(prefix='journal-original-api-owned-')as root:
 try:module.Journal(Path(root)/'report.json',[{'name':'owned-case'}],None,{'identity':'owned-no-process'})
 except AttributeError as error:
  assert 'NamedTempFile' in str(error)
  original={'source_sha256':hashlib.sha256(old.read_bytes()).hexdigest(),'exception_type':type(error).__name__,'exception':str(error),'report_created':(Path(root)/'report.json.progress.json').exists()}
 else:raise AssertionError('original9fa failure must remain reproducible')
new=(repo/'scripts/setup-source-oracle/progress.py').read_bytes();assert old.read_bytes().replace(b'tempfile.NamedTempFile(',b'tempfile.NamedTemporaryFile(')==new
for name in ['replay.py','windows_job_probe.py']:
 assert (repo/'scripts/setup-source-oracle'/name).read_bytes()==subprocess.check_output(['git','show','9faee8b0a2619909aa8ee53ed84b2cb4d6ef50b8:scripts/setup-source-oracle/'+name],cwd=repo)
receipt={'clean_source_head':head,'candidate_dirty':False,'cwd':str(repo),'python':sys.version,'portable_test_command':command,'portable_tests':6,'exit':result.returncode,'test_log':str(log),'test_log_sha256':hashlib.sha256(log.read_bytes()).hexdigest(),'api_availability':checks,'original_actual_direct_failure':original,'sole_journal_fix':'NamedTempFile -> NamedTemporaryFile','replay_and_watchdog_bytes_unchanged_from_original_9fa':True,'source_sha256':{name:hashlib.sha256((repo/'scripts/setup-source-oracle'/name).read_bytes()).hexdigest()for name in ['progress.py','replay.py','test_progress.py','windows_job_probe.py']},'compiler_or_product_or_port_executions':0,'native_windows_claim':False,'fullSource_acceptance':False,'driver_path':__file__,'driver_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
Path('/tmp/symaira-doctor806-journal-api-fixed-clean-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print('PASS6 portable tests; callable availability',len(checks),'original9fa exact API failure reproduced; no product/nativeWindows acceptance')
