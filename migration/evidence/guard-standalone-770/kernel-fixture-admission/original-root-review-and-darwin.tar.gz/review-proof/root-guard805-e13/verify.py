import ast, gzip, hashlib, importlib.util, json, pathlib, subprocess, sys, zipfile

ROOT = pathlib.Path('/workspace/symaira-guard805-discovery-fixtures')
OUT = pathlib.Path(__file__).parent
OLD = pathlib.Path('/workspace/review-proof/review-pr800-guard805-windows43')
BASE = '43dfda366437d586b8609478164292e77685665f'
HEAD = 'e13f4caa07a4aecff5ab54a4ab57e2e248374438'
FROZEN = 'dcddcef0df5789123c7c9a7ebe6e01f10e941f2c'

def sha(data): return hashlib.sha256(data).hexdigest()
def git(*args): return subprocess.check_output(['git', '-C', str(ROOT), *args])
def blob(ref, name): return git('show', ref+':'+name.replace('\\', '/'))
def load(path): return json.loads(path.read_bytes())
def check(data, row):
    assert sha(data) == row.get('sha256', row.get('raw_sha256'))
    size = row.get('bytes', row.get('raw_bytes'))
    if size is not None: assert len(data) == size

assert git('rev-parse','HEAD').decode().strip() == HEAD
assert not git('status','--porcelain')
handoff = load(pathlib.Path('/workspace/review-proof/review-pr800-guard805-fixture-fix/final-handoff.json'))
changed = git('diff','--name-only',BASE,HEAD).decode().splitlines()
assert set(changed) == set(handoff['changed27files'])
for name, row in handoff['changed27files'].items():
    check((ROOT/name).read_bytes(), row); assert (ROOT/name).read_bytes() == blob(HEAD,name)
protected = git('ls-tree','-r','--name-only',BASE,'rust','internal','cmd','guard','go.mod','go.sum','Cargo.toml','Cargo.lock').decode().splitlines()
for name in protected: assert git('rev-parse',BASE+':'+name) == git('rev-parse',HEAD+':'+name)
evidence = ROOT/'migration/evidence/guard-standalone-770/windows-discovery-fixture-43'
binding = load(evidence/'original-binding.json')
for name, row in binding['raw_records'].items():
    compressed = (evidence/row['retained']).read_bytes()
    assert sha(compressed) == row['compressed_sha256']
    raw = gzip.decompress(compressed); check(raw,row)
    assert raw == pathlib.Path(row['original_path']).read_bytes()
sdk = load(evidence/'pinned-sdk-binding.json')
for name,row in sdk['actual_source_only_copies'].items():
    compressed = (evidence/row['retained']).read_bytes()
    assert sha(compressed) == row['compressed_sha256']
    raw = gzip.decompress(compressed);check(raw,row)
    assert raw == (pathlib.Path('/workspace/toolchains/go1.26.7')/name).read_bytes()
manifest = load(OLD/'artifact-manifest.json')
originalzip = evidence/'pr805-guard-standalone-Windows-43.zip'
assert sha(originalzip.read_bytes()) == manifest['zip_sha256']
assert originalzip.read_bytes() == (OLD/originalzip.name).read_bytes()
with zipfile.ZipFile(originalzip) as archive:
    assert set(archive.namelist()) == {x['path'] for x in manifest['members']}
    for row in manifest['members']:
        raw = archive.read(row['path']);check(raw,row)
        assert raw == (OLD/'artifact'/row['path']).read_bytes()
        if row['PE']: assert raw[:2] == b'MZ'
report = load(OLD/'artifact/guard-standalone.json')
source_count = 0
for key,ref in [('candidate_source_sha256',BASE),('candidate_manifest_sha256',BASE),('go_source_sha256',FROZEN)]:
    for name,digest in report[key].items():
        assert sha(blob(ref,name)) == digest;source_count += 1
assert source_count == 1311
journal = load(OLD/'artifact/guard-standalone-config-paths.json.progress.json')
assert len(journal['events']) == 122 and journal['status'] == 'failed'
pairs = [x['observation'] for x in journal['events'] if x['phase']=='pair-complete']
assert len(pairs) == 23
sys.path.insert(0,str(ROOT/'scripts/guard-standalone-oracle'))
import config_paths, replay
assert len(config_paths.cases()) == 25
for case in pairs:
    if case['contract'] != 'gated': assert replay.comparable(case['go']) == replay.comparable(case['native'])
child = [x for x in journal['events'] if x['phase']=='control-native-child']
assert len(child)==1
actual = child[0]['report']
assert actual['exit_code'] == 1
assert b'physical_owner' in bytes.fromhex(actual['stderr_hex'])
assert b'claude_desktop_config.json' in bytes.fromhex(actual['stdout_hex'])
assert b'The system cannot find the path specified' in bytes.fromhex(actual['stdout_hex'])
oldtree = ast.parse(blob(BASE,'scripts/guard-standalone-oracle/config_paths.py'))
newtree = ast.parse((ROOT/'scripts/guard-standalone-oracle/config_paths.py').read_bytes())
for name in ['cases','control','link_directory','metadata','run','main']:
    a = next(x for x in oldtree.body if isinstance(x,ast.FunctionDef) and x.name==name)
    b = next(x for x in newtree.body if isinstance(x,ast.FunctionDef) and x.name==name)
    assert ast.dump(a,include_attributes=False)==ast.dump(b,include_attributes=False),name
steps=[(['python3','-m','unittest','discover','-s','scripts/guard-standalone-oracle','-p','test_config_path*.py','-v'],'portable15'),
       (['bash','-n','scripts/guard-standalone-oracle/run.sh'],'shell'),
       (['git','diff','--check',BASE,HEAD],'diff')]
results=[]
for argv,label in steps:
    run=subprocess.run(argv,cwd=ROOT,capture_output=True)
    (OUT/(label+'.stdout')).write_bytes(run.stdout);(OUT/(label+'.stderr')).write_bytes(run.stderr)
    results.append({'id':label,'argv':argv,'exit':run.returncode,'stdout_sha256':sha(run.stdout),'stderr_sha256':sha(run.stderr)})
    assert run.returncode==0,(label,run.stderr)
maclog=pathlib.Path('/workspace/review-proof/root-discovery801-8e-macARM/job-111412706458.logs.decoded').read_bytes()
assert b'OSError: [Errno 92] Illegal byte sequence' in maclog
finding={'priority':'P2','scope':'native Darwin test fixture portability, source-confirmed with independent actual Darwin kernel rejection',
    'paths':['scripts/guard-standalone-oracle/test_config_path_fixtures.py:34','scripts/guard-standalone-oracle/config_paths.py:74','scripts/guard-standalone-oracle/raw_paths.py:25'],
    'trigger':'Invalid UTF-8 owned filenames are selected for all POSIX systems and the new mandatory portable unit attempts mkdir on Darwin. Actual Darwin PR801 job111412706458 already rejects the same E2 82 bytes at fixture mkdir with errno92 before product launch.',
    'limit':'No current Guard Darwin execution or product regression claimed. Linux valid; Windows conditional owner source correction is coherent.'}
receipt={'candidate':HEAD,'base':BASE,'decision':'REQUEST_CHANGES one additional P2; full Windows fixture correction source-coherent, actual native validation pending',
    'changed_files_verified':len(changed),'protected_production_files_identical':len(protected),'full_original_archive_members_verified':len(manifest['members']),
    'full_original_source_bindings_verified':source_count,'full_journal_events':122,'full_pairs_recomputed':23,'all20_comparables_equal':True,
    'full_raw_retention_roundtrips':len(binding['raw_records']),'actualSDKsourcecopies':len(sdk['actual_source_only_copies']),
    'portable_results':results,'finding':finding,'compiler_SDK_product_SQLite_target_port_execution':False,
    'candidate_clean_after':not bool(git('status','--porcelain'))}
assert receipt['candidate_clean_after']
(OUT/'verification.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt,indent=2))
