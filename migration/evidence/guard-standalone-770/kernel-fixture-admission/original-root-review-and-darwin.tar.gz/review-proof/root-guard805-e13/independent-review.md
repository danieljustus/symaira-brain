# Full Root review of Guard805 e13

REQUEST CHANGES: one additional P2 in Darwin fixture admission. The Windows
Discovery-parent and explicit-owner corrections are coherent with all original
actual Go/native observations. This is source review, not current native
acceptance. Immutable candidate e13f4caa07a4aecff5ab54a4ab57e2e248374438 and
original 43dfda366437d586b8609478164292e77685665f remained clean and unchanged.

Root verified all 27 changed files against Git and the author handoff, the full
protected production tree, every original ZIP member including both PE files,
all 1,311 original candidate/manifest/frozen-Go source bindings, all original
lossless raw-log/report roundtrips and eight pinned Go SDK source copies.
The full 122-event failure journal was read and the original 23 case records
recomputed: all 20 nongated comparable stdout/stderr/exit/state projections
are equal. The actual control selects physical_owner and fails on the missing
Claude parent with Windows ERROR_PATH_NOT_FOUND. This supports the fixture
correction and does not show a native product difference.

The new parent initializer seeds directories, leaves config files absent, and
runs before beforemetadata for all lexical/physical/home/unused-XDG owners.
Malformed Cursor is inserted afterwards; the two additional assertions require
that exact intended frozen-Go gate rather than incidental Hermes failure.
Windows explicit overrides keep the observed lexical owner; Unix keeps physical
traversal. Original 23/25 case generation, real canonicalization control, readonly
snapshot, seven compare predicates, healthy0/semantic1 and child5s deadline are
preserved. Root independently ran the 15 portable Python checks, shell syntax and
diff hygiene successfully. These are fixture machinery checks only.

P2: test_config_path_fixtures.py:34 only excludes Windows but directly mkdirs
the invalid UTF-8 E2 82 component on Darwin. run.sh now makes that unit mandatory.
config_paths.py:74 and the inherited raw_paths.py:25 also materialize invalid
byte filenames on every POSIX platform. The full actual PR801 macOS ARM job
111412706458 rejects the identical E2 82 fixture mkdir with errno92 before the
first product launch. Its full original log and seven artifact members are
retained under root-discovery801-8e-macARM; no Guard execution is inferred from it.
These paths cannot be mandatory executable Darwin fixtures as currently written.

Preserve all original criteria and Linux raw-byte cases. Before selecting raw
filesystem fixtures, record an actual owned kernel admission probe, raw component
bytes, full error/errno and cleanup state. An unavailable path must be reported
as unexecuted rather than a successful pair/control. Keep representable Unicode
and ordinary Darwin path cases, and test malformed byte diagnostics through an
actually reachable non-filesystem source where the frozen contract permits it.
Do not silently skip cases or turn kernel fixture failure into native parity.
The new pure unit must distinguish kernel admission from owner/read-only assertions.
Fresh native3, protected checks and complete #770/#769 remain required.

No compiler, Go SDK behavior, native product, SQLite, target or port was used.
Full raw verification output and machine receipt are retained beside this report.
