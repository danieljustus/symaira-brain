"""Source-only domain/accounting/retention controls; zero native/SDK/SQL runs."""
from pathlib import Path
import ast,gzip,hashlib,importlib.util,json,re,subprocess
P=Path(__file__).resolve().parent;R=Path('/workspace/symaira-guard805-rust-fixture-admission');H='cdb2aca223bd9030f834608fd13cc4e643ebdc68'
checks=[]
def check(name,value):assert value,name;checks.append(name)
def sha(b):return hashlib.sha256(b).hexdigest()
def git(*a):return subprocess.check_output(['git',*a],cwd=R)
old=json.loads((P/'original-Git.json').read_bytes())
sourcepaths=['rust/symguard-cli/tests/doctor_warnings.rs','rust/symguard-cli/tests/raw_diagnostics.rs']
helper=(R/'rust/symguard-cli/tests/support/raw_fixture_admission.rs').read_text()
# Exact source-shape projection, not Rust/kernel execution.
predicate='macos && component == COMPONENT && errno == Some(92)'
check('exact source predicate present',predicate in helper)
raw=b'owned-\xe2\x82<&>'
def projected(platform,component,errno):return platform=='macos'and component==raw and errno==92
for platform,component,errno,expected in [('macos',raw,92,True),('linux',raw,92,False),('windows',raw,92,False),('macos',raw,84,False),('macos',raw,13,False),('macos',raw,None,False),('macos',b'other-\xe2\x82<&>',92,False),('macos','owned-\ufffd<&>'.encode(),92,False),('macos',b'owned',92,False)]:
 check('Rust predicate projection '+repr((platform,component,errno)),projected(platform,component,errno)==expected)
check('runtime platform and error from actual error', all(token in helper for token in ['cfg!(target_os = "macos")','path.file_name().unwrap().as_bytes()','error.raw_os_error()']))
check('actual two operation identities','Self::ConfigWrite => "fs::write"'in helper and 'Self::AuditDirectory => "fs::create_dir"'in helper)
check('strict cleanup not exists falsepositive','fs::symlink_metadata(&owned_root).unwrap_err().kind() == io::ErrorKind::NotFound'in helper)
check('case IDs never parity','"parity": false'in helper and '"original_requested_domain_complete": false'in helper)
check('passing libtest emits durable OS stderr','writeln!(io::stderr().lock(), "{record}").unwrap();'in helper)
check('accounting strict exact/unique',all(x in helper for x in ['expected.windows(2)','actual.windows(2)','assert_eq!(actual, expected']))
def account(requested,done,excluded):
 assert len(requested)==len(set(requested));assert len(done+excluded)==len(set(done+excluded));assert sorted(requested)==sorted(done+excluded)
account(['healthy','semantic','type','discovery','raw'],['healthy','semantic','type','discovery'],['raw']);checks.append('four admitted Doctor roles exact accounting projection')
for requested,done,excluded in [(['healthy','raw'],['healthy'],[]),(['healthy','raw'],['healthy','raw'],['raw']),(['healthy','raw'],['healthy'],['foreign']),(['healthy','healthy'],['healthy'],['healthy'])]:
 try:account(requested,done,excluded)
 except AssertionError:checks.append('reject missing/duplicate/foreign accounting '+repr((requested,done,excluded)))
 else:raise AssertionError('silent exclusion accepted')
# Source-shape mutants are projections, never native test results.
required=[predicate,'"parity": false','fs::symlink_metadata(&owned_root).unwrap_err().kind() == io::ErrorKind::NotFound','expected.windows(2)','actual.windows(2)','assert_eq!(actual, expected']
def accepts_source(text):return all(token in text for token in required)
check('complete current helper source shape',accepts_source(helper))
for name,token,replacement in [
 ('remove-platform',predicate,'component == COMPONENT && errno == Some(92)'),
 ('broaden-errno',predicate,'macos && component == COMPONENT && errno == Some(84)'),
 ('broaden-component',predicate,'macos && errno == Some(92)'),
 ('fake-parity','"parity": false','"parity": true'),
 ('cleanup-falsepositive',required[2],'!owned_root.exists()'),
 ('remove-duplicate-check','actual.windows(2)','actual.windows(3)'),
]:
 check('reject source mutant '+name,not accepts_source(helper.replace(token,replacement)))
# Preserve all original assertion calls including full raw byte/literal arguments.
def assertions(source):
 found=[]
 for m in re.finditer(r'\bassert(?:_eq|_ne)?!\s*\(',source):
  start=m.start();i=m.end();depth=1;quote=None;escaped=False
  while depth:
   c=source[i]
   if quote:
    if escaped:escaped=False
    elif c=='\\':escaped=True
    elif c==quote:quote=None
   elif c=='"':quote=c
   elif c=='(':depth+=1
   elif c==')':depth-=1
   i+=1
  # Whitespace outside literals is formatter-only; compare tokens with raw strings intact.
  body=source[start:i]
  tokens=re.findall(r'br?"(?:\\.|[^"\\])*"|r"[^\"]*"|"(?:\\.|[^"\\])*"|\w+|[^\s]',body)
  found.append(tokens)
 return found
for name in sourcepaths:
 before=git('show',H+':'+name).decode();after=(R/name).read_text()
 a=assertions(before);b=assertions(after)
 for assertion in a:check('original assertion retained '+name+str(a.index(assertion)),assertion in b)
 check('no ignore/cfgskip '+name,'#[ignore'not in after and after.count('#![cfg(unix)]')==before.count('#![cfg(unix)]'))
warning=(R/sourcepaths[0]).read_text();audit=(R/sourcepaths[1]).read_text()
check('no role-domain removal',all(f'"{role}"'in warning for role in ['healthy','semantic','type','discovery','raw']))
check('Doctor actual write then exact error classification',warning.index('fs::write(&config, text)')<warning.index('record_failed_creation'))
check('completed Doctor roles after read-only assertions',warning.index('executed_roles.push(role)')>warning.index('before.modified().unwrap()'))
check('independent help still runs before unavailable audit',audit.index('assert!(!help.is_empty()')<audit.index('std::fs::create_dir(&path)'))
check('independent audit controls continue after unavailability','executed: &["help", "critical", "unknown", "invalid-json"]'in audit and 'unavailable: &["low", "medium", "high"]'in audit)
check('only directory-dependent inputs excluded','creation_error.is_some() && matches!(risk, "low" | "medium" | "high")'in audit)
check('audit allrisk assertions retained' ,'for risk in ["low", "medium", "high", "critical", "unknown"]'in audit and 'b"not json"'in audit)
# Every Python gate/corpus/manifest/lock/workflow/main source stays exact complete Git.
changed=set(git('diff','--name-only',H).decode().splitlines())
allowed=set(sourcepaths+['migration/guard-standalone-tree-770.md'])
original_paths={r['path']for r in old['all_bodies']}
check('only allowed original file deltas',changed & original_paths<=allowed)
check('new paths bounded to helper/doc/proofs',all(name=='rust/symguard-cli/tests/support/raw_fixture_admission.rs'or name=='docs/adr/guard-rust-kernel-fixture-admission-805.md'or name.startswith('migration/evidence/guard-standalone-770/rust-fixture-admission/')for name in changed-original_paths))
check('4057 parent complete Git map',len(old['all_bodies'])==4057)
for row in old['all_bodies']:
 if row['path'] in allowed:continue
 check_body=git('show','HEAD:'+row['path']);assert sha(check_body)==row['sha256']
 current_mode=git('ls-tree','HEAD','--',row['path']).decode().split()[0];assert current_mode==row['git_mode']
checks.append('all4054 untouched original Git bodies/modes remain parent exact')
for r in json.loads((P/'preservation.json').read_bytes())['records']:
 packed=Path(r['archive']).read_bytes();restored=gzip.decompress(packed)
 check('full original roundtrip '+r['path'],sha(packed)==r['archive_sha256']and sha(restored)==r['sha256']and len(restored)==r['bytes'])
# Existing pure predicate retains its wider independent frozen domain.
spec=importlib.util.spec_from_file_location('original_kernel',R/'scripts/guard-standalone-oracle/kernel_admission.py');k=importlib.util.module_from_spec(spec);spec.loader.exec_module(k)
check('existing Python classification unchanged',k.classify(raw,OSError(92,'pure source projection'),'darwin')=='unavailable-darwin-EILSEQ92')
for system,component,errno in [('linux',raw,92),('darwin',raw,84),('darwin',b'owned',92)]:
 try:k.classify(component,OSError(errno,'pure source projection'),system)
 except OSError:checks.append('existing classifier rejection '+repr((system,component,errno)))
 else:raise AssertionError('old gate weakened')
result=dict(status='PURE_SOURCE_ONLY_NOT_NATIVE',source_parent=H,checks=checks,count=len(checks),Rust_Go_SDK_Cargo_SQL_Target_ports=0,
 actual_failure='only macOS doctor_warnings fs::write observed in complete job111449257217',source_derived_sibling='raw_diagnostics fs::create_dir not reached by that job',new_Rust_test_functions_prepared=2,future_Unix_integration_instances=4,future_Windows_new_test_instances=0,original_assertions_retained=True)
(P/'source-checks.json').write_text(json.dumps(result,indent=2)+'\n');print('pure source controls',len(checks))
