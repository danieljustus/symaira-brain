import ast,gzip,hashlib,io,json,pathlib,subprocess,zipfile
R=pathlib.Path('/workspace/symaira-guard805-config-control');O=pathlib.Path('/workspace/review-proof/root-guard805-207');P=R/'migration/evidence/guard-standalone-770/windows-config-owner-a1';A=pathlib.Path('/workspace/symaira-guard805-config-control-original')
sha=lambda b:hashlib.sha256(b).hexdigest()
head='207ba8bc7fb5fd0b62a98375dcc3c1d2dc829503';base='a1a29878f9b1b236862c09ac5c2bb5fb6cd3f4db';git=lambda ref,name:subprocess.check_output(['git','-C',str(R),'show',ref+':'+name])
assert subprocess.check_output(['git','-C',str(R),'rev-parse','HEAD'],text=True).strip()==head
assert not subprocess.check_output(['git','-C',str(R),'status','--porcelain'])
rows=json.loads((P/'original/retention.json').read_bytes())['records']
for row in rows:
 compressed=(R/row['retained']).read_bytes();raw=gzip.decompress(compressed)
 assert sha(compressed)==row['gzip_sha256'] and sha(raw)==row['sha256'] and len(raw)==row['bytes']
 original=pathlib.Path(row['original']);assert original.read_bytes()==raw,str(original)
protected=json.loads(gzip.decompress((P/'original/protected-source.json.gz').read_bytes()))
for name,digest in protected.items():assert sha(git(head,name))==digest,name
receipt=json.loads((A/'zip-receipt.json').read_bytes());z=(A/'guard805-a1-windows-original.zip').read_bytes();assert sha(z)==receipt['zip_sha256']
with zipfile.ZipFile(io.BytesIO(z)) as archive:
 assert len(archive.infolist())==8
 for item in archive.infolist():assert archive.read(item)==(A/'members'/item.filename).read_bytes(),item.filename
 assert not any('config-paths' in x.filename for x in archive.infolist())
main=json.loads((A/'members/guard-standalone.json').read_bytes());bindings={}
for key,ref in [('candidate_source_sha256',base),('candidate_manifest_sha256',base),('go_source_sha256',main['oracle_ref'])]:
 for name,digest in main[key].items():
  name=name.replace('\\','/');assert sha(git(ref,name))==digest,(key,name);bindings[key+':'+name]=digest
assert sha(git(base,'scripts/guard-standalone-oracle/main.go.txt'))==main['supplemental_go_entry_sha256']
for role,name in [('rust','native.exe'),('go','go.exe')]:
 b=(A/'members/guard-standalone-binaries'/name).read_bytes();assert sha(b)==main['binaries_sha256'][role]
 assert b[:2]==b'MZ';offset=int.from_bytes(b[60:64],'little');assert b[offset:offset+4]==b'PE\0\0';assert int.from_bytes(b[offset+4:offset+6],'little')==0x8664
log=(A/'root-ci-job-111390702060.log').read_bytes();api=json.loads((A/'log-api.json').read_bytes());assert log==api['structuredContent']['content'].encode();assert sha(log)==receipt['log_sha256'];assert b'AssertionError: incidental mutant failure' in log
old=ast.parse(git(base,'scripts/guard-standalone-oracle/config_paths.py'));new=ast.parse((R/'scripts/guard-standalone-oracle/config_paths.py').read_bytes())
fn=lambda tree,name:next(x for x in tree.body if isinstance(x,ast.FunctionDef) and x.name==name)
for name in ['cases','link_directory','metadata','compare']:assert ast.dump(fn(old,name))==ast.dump(fn(new,name)),name
for name in ['observe','control']:
 assert [ast.dump(x) for x in ast.walk(fn(old,name)) if isinstance(x,ast.Assert)]==[ast.dump(x) for x in ast.walk(fn(new,name)) if isinstance(x,ast.Assert)],name
assert all(len((R/n).read_text().splitlines())<400 for n in ['scripts/guard-standalone-oracle/config_paths.py','scripts/guard-standalone-oracle/config_path_journal.py','scripts/guard-standalone-oracle/test_config_path_progress.py'])
(O/'all-source-bindings.json').write_text(json.dumps({'protected_current':protected,'original_executed':bindings},indent=2)+'\n')
report={'disposition':'APPROVE_SOURCE_READY_CURRENT_NATIVE_CI','head':head,'base':base,'original_roundtrips':len(rows),'protected_product_files':len(protected),'actual_original_execution_bindings':len(bindings),'original_zip_members':8,'original_full_log_sha256':sha(log),'original_PE_sha256':main['binaries_sha256'],'all_original_actual_control_child_outputs_absent':True,'original_failure_cause_proved':False,'Windows_path_library_source_defect':True,'unchanged_original_normal_cases_readonly_comparator_control_criteria':True,'actual_current_product_or_compiler_executions':0,'actual_independent_portable_tests':10,'native_three_OS_current_Guard_gates_and_protected_checks_required':True}
(O/'receipt.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
