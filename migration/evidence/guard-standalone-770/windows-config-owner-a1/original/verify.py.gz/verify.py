import gzip,hashlib,json,subprocess
from pathlib import Path
ROOT=Path('/workspace/symaira-guard770')
OUT=Path('/workspace/symaira-guard805-config-control-original')
PUB='a1a29878f9b1b236862c09ac5c2bb5fb6cd3f4db'
sha=lambda b:hashlib.sha256(b).hexdigest()
git=lambda ref,name:subprocess.check_output(['git','show',ref+':'+name],cwd=ROOT)
main=json.loads((OUT/'members/guard-standalone.json').read_bytes())
native={}
for field in ['candidate_source_sha256','candidate_manifest_sha256']:
 for name,digest in main[field].items():
  name=name.replace('\\','/'); b=git(PUB,name);assert sha(b)==digest,name
  p=OUT/'publication-source'/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b);native[name]=digest
for name,digest in main['go_source_sha256'].items():assert sha(git(main['oracle_ref'],name))==digest,name
assert sha(git(PUB,'scripts/guard-standalone-oracle/main.go.txt'))==main['supplemental_go_entry_sha256']
for f in (OUT/'members').glob('*.json'):
 report=json.loads(f.read_bytes())
 for name,digest in report.get('source_sha256',{}).items():assert sha(git(PUB,name.replace('\\','/')))==digest,name
bindings={'guard-standalone-raw-paths.json':('runner_sha256','raw_paths.py'),'guard-standalone-doctor-boundaries.json':('runner_sha256','doctor_boundaries.py'),'guard-standalone-controls.json':('controls_sha256','controls.py')}
for file,(key,name) in bindings.items():assert sha(git(PUB,'scripts/guard-standalone-oracle/'+name))==json.loads((OUT/'members'/file).read_bytes())[key]
for name in ['config_paths.py','config_warnings.py','replay.py','controls.py','run.sh','retain_binaries.py','windows_path_reference.py']:
 b=git(PUB,'scripts/guard-standalone-oracle/'+name);p=OUT/'publication-source/scripts/guard-standalone-oracle'/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)
for name in ['AGENTS.md','guard/AGENTS.md','.github/workflows/ci.yml','rust-toolchain.toml']:
 b=git(PUB,name);p=OUT/'publication-source'/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)
receipt=json.loads((OUT/'members/guard-standalone-binaries/receipt.json').read_bytes())
for role,name in [('rust','native.exe'),('go','go.exe')]:
 b=(OUT/'members/guard-standalone-binaries'/name).read_bytes();assert sha(b)==main['binaries_sha256'][role]
 assert b[:2]==b'MZ';offset=int.from_bytes(b[60:64],'little');assert b[offset:offset+4]==b'PE\0\0'
 assert int.from_bytes(b[offset+4:offset+6],'little')==0x8664
assert main['candidate_head']=='375d77c504d0665a6416a0278a9dd381ebc30f3e' and not main['candidate_dirty']
log=(OUT/'root-ci-job-111390702060.log').read_bytes();api=json.loads((OUT/'log-api.json').read_bytes());assert log==api['structuredContent']['content'].encode()
assert b'AssertionError: incidental mutant failure' in log
assert not (OUT/'members/guard-standalone-config-paths.json').exists()
names=subprocess.check_output(['git','ls-tree','-r','--name-only',PUB],cwd=ROOT).decode().splitlines()
protected={n:sha(git(PUB,n)) for n in names if n.endswith(('.rs','.go')) or n.endswith(('Cargo.toml','Cargo.lock','go.mod','go.sum','rust-toolchain.toml'))}
(OUT/'protected-source.json').write_text(json.dumps(protected,indent=2)+'\n')
summary={'publication':PUB,'actual_CI_merge':main['candidate_head'],'run_id':37186919053,'job_id':111390702060,'native_source_files_verified':len(main['candidate_source_sha256']),'manifests_verified':len(main['candidate_manifest_sha256']),'frozen_Go_files_verified':len(main['go_source_sha256']),'frozen_ref':main['oracle_ref'],'actual_original_PE_sha256':main['binaries_sha256'],'full_raw_log_bytes':len(log),'full_raw_log_sha256':sha(log),'protected_source_count':len(protected),'original_control_stdout_stderr_env_gap':'config_paths.control assertion preceded final report write; no config-paths report or control bytes uploaded. Exact failure cause is not asserted retrospectively.','product_compiler_SDK_target_port_executions':0}
(OUT/'provenance.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary,indent=2))
