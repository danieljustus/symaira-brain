"""Independent bounded source/retention checks; no compilation or product runs."""
from pathlib import Path
import gzip
import hashlib
import json
import subprocess

root = Path('/workspace/symaira-guard770-warning-owner')
head = '0701491b10d10c28759c1c5c2c97d00f01acb09d'
base = 'a83f26a6ead7e7106e4873d96de7f9bfdc3fbff0'
sha = lambda raw: hashlib.sha256(raw).hexdigest()
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip() == head
assert not subprocess.check_output(['git','status','--porcelain'],cwd=root)
folder = root/'migration/evidence/guard-doctor-config-paths-770/windows-warning-owner-a83-original'
original = json.loads((folder/'original-receipt.json').read_bytes())
handoff = json.loads(Path('/tmp/symaira-guard805-warning-owner-final-handoff.json').read_bytes())
for row in handoff['changed_files']:
    raw = (root/row['path']).read_bytes()
    assert sha(raw) == row['sha256'] and len(raw) == row['bytes']
for row in original['originals']:
    raw = gzip.decompress((root/row['retained']).read_bytes())
    assert sha(raw) == row['sha256'] and len(raw) == row['bytes']
    if row['original'].startswith('/tmp/'):
        assert raw == Path(row['original']).read_bytes()
    else:
        assert raw == subprocess.check_output(['git','show',base+':'+row['original']],cwd=root)
test_path = 'rust/symguard-cli/tests/doctor_config_paths.rs'
for row in original['source_map']:
    assert sha(subprocess.check_output(['git','show',base+':'+row['path']],cwd=root)) == row['sha256']
    if row['path'] != test_path:
        assert sha((root/row['path']).read_bytes()) == row['sha256']
    assert oct((root/row['path']).stat().st_mode & 0o777) == row['mode']
old = subprocess.check_output(['git','show',base+':'+test_path],cwd=root,text=True)
new = (root/test_path).read_text()
marker = '#[cfg(windows)]\n#[test]\nfn windows_discovery_file_and_parent_errors_keep_doctor_contract()'
assert old.split(marker,1)[1] == new.split(marker,1)[1]
assert 'let roles = ["healthy", "semantic", "typed", "discovery"].into_iter();' in new
assert '#[cfg(windows)]\n    let roles = roles.chain(["healthy-slash-xdg", "healthy-slash-override"]);' in new
assert '.join("config")\n            .join("symguard")\n            .join("config.toml")' in new
assert 'assert_eq!(stderr, warning.as_ref(), "role {role}: warning owner bytes");' in new
assert '"config: warning: unknown key \\"lexical_owner\\" in "' in new
assert '"\\n",\n            );' in new
for source in ['assert_eq!(result, None);','assert!(stdout.is_empty() && stderr.is_empty());',
               'Some(u8::from(role == "semantic"))','assert!(stdout.starts_with(b"symguard doctor\\n"));',
               'assert_eq!(fs::read(&config).unwrap(), text.as_bytes());',
               'assert_eq!(fs::metadata(&config).unwrap().modified().unwrap(), before);']:
    assert source in old and source in new
assert new.count('if role == "healthy-slash-override" {') == 2
assert 'command.env("SYMGUARD_CONFIG", &expected_config);' in new
assert 'if role == "healthy-slash-xdg" {' in new
assert '.env_clear()' in new and '.env("PATH", "")' in new
sdk_sources = json.loads((folder/'source-controls.json').read_bytes())['pinned_windows_sdk_sources']
for row in sdk_sources:assert sha(Path(row['path']).read_bytes()) == row['sha256']
gates = [['/home/agent/.rustup/toolchains/1.98.0-x86_64-unknown-linux-gnu/bin/rustfmt','--edition','2024','--check',test_path],
         ['/workspace/toolchains/bin/actionlint','.github/workflows/ci.yml'],['git','diff','--check']]
for command in gates:
    result = subprocess.run(command,cwd=root,capture_output=True)
    assert result.returncode == 0,(command,result.stderr)
changed = subprocess.check_output(['git','diff','--name-only',base,head],cwd=root,text=True).splitlines()
assert changed == [r['path'] for r in handoff['changed_files']]
assert not (root/'target').exists()
receipt = dict(head=head,base=base,changed_files=handoff['changed_files'],original_complete_logs_source=3,
               original617_source_maps_verified=len(original['source_map']),current616_protected_maps_verified=len(original['source_map'])-1,
               original_discovery_errno_and_raw_wide_test_tail_unchanged=True,old4_roles_preserved=True,new_windows_roles=2,
               full_warning_assertion_strengthened=True,config_bytes_mtime_assertions_unchanged=True,
               sdk_source_hashes_verified=sdk_sources,format_actionlint_diff='PASS',
               candidate_builds=0,product_provider_sdk_execution=0,targets=0,ports=0,native_runtime_proved=False)
Path('/tmp/symaira-guard805-warning-owner-independent-checks.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({'head':head,'original_maps':617,'unchanged_maps':616,'full_originals':3,'changed_files':len(changed),'new_roles':2,'runtime':0}))
