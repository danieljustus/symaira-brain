# Memory762 concrete sync backends — full independent static review

**Verdict: REQUEST CHANGES, exactly three P2 findings.** Different-author review of clean immutable `8a3226828d045b4307d2c3601e283d1ecfa4ce4f` in `/workspace/symaira-memory762-sync-backends`, relative to `c4a020e0cec77fd38060c591aa1fde244df4b796`. The frozen Go reference remains `dcddcef0df5789123c7c9a7ebe6e01f10e941f2c`; SDK source is the actual `/workspace/toolchains/go1.26.7` installation. No source or GitHub edits occurred.

This is the authorized **static source/SDK/dependency/evidence review**, not runtime acceptance. No Cargo/Go compiler, typecheck, test, Clippy, target, database, HTTP request, crypto operation, listener, credential or operator state was used. The conclusions below are traced through concrete source; HTTP observations described below are proposed future owned fixtures, not process results. No runtime approval or full #762 closure is given.

## P2-1: Remove the unregistered Serde helper attribute

`rust/symbrain-memory/src/sync/model.rs:112` introduces `#[serde(skip)]` on `RelayBlob::blob_present`, but the owning struct derives only `Debug, Clone, Default`. It has neither `Serialize` nor `Deserialize` derive. Importing their macros at module scope does not register a helper attribute for this struct. The pinned `serde_derive-1.0.229/src/lib.rs:114,121` registers `attributes(serde)` on those two derive macros. The manual JSON/wire implementation does not register attributes.

This is a source-level compilation blocker in an unconditional public Memory module, so it affects the Memory graph before the fourteen prepared unit tests or concrete transport can run. The earlier model did not have this attribute. Rustfmt's successful parse/check does not perform Rust attribute resolution. No compiler diagnostic is being claimed as observed.

Keep the presence flag and manual codec, remove the inapplicable helper attribute, and require full affected graph compilation and strict linting after resource allocation. Adding unrelated Serde derives just to register the attribute would introduce an unnecessary second serialization contract.

## P2-2: Preserve Go's ASCII host identity when deciding redirect header inheritance

`rust/symbrain-memory/src/sync/http.rs:169–170` lowercases both initial and destination hostnames before deciding whether to retain sensitive original headers. The actual Go1.26.7 SDK differs:

- `net/http/client.go:688–696` considers stripping when the current URL's raw `Host` differs from the initial URL's raw `Host`; stripping is sticky.
- `client.go:1019–1021` passes `idnaASCIIFromURL` hostnames to `isDomainOrSubdomain`.
- `net/http/transport.go:3024–3029` obtains the URL hostname and calls `idnaASCII`.
- `net/http/request.go:781–795` returns an ASCII hostname **unchanged**; only non-ASCII input goes through IDNA conversion.
- `client.go:1028–1044` compares identity and suffix case-sensitively.

For a synthetic explicit Bearer header, initial `http://localhost:PORT` and a Location of `http://LOCALHOST:PORT/next` reach the same owned listener but have different ASCII host identities in this contract. Go strips the original Authorization and does not restore it on a later hop back to the initial host. Native lowercasing admits it and continues copying the initial Bearer header. This is a functional request-header mismatch on supported ordinary ASCII URLs. It does not depend on the explicitly unproven IDNA family and is not characterized as a demonstrated exploit.

Use the pinned SDK's actual ASCII identity rule and outer raw-Host decision; preserve the existing sticky-strip/subdomain/IPv6 behavior. Once runtime is allocated, add an owned same-listener mixed-case redirect pair and a subsequent return-hop control that records literal headers for both actual processes.

## P2-3: Do not copy URL-derived Basic as an initial explicit Authorization header

`rust/symbrain-memory/src/sync/http.rs:98–104,116–129` computes `original_auth` from the initial URL's Basic userinfo when the explicit token is empty. It copies that value on every allowed redirect, generating Basic from the current URL only after sensitive stripping.

The frozen `internal/memory/syncclient/client.go` explicitly sets Authorization only for a nonempty Bearer token. Go SDK `net/http/client.go:610` creates the original-header copier **before** the first send. `client.go:229–257` adds URL-derived Basic to a cloned request and cloned Header inside `send`, leaving the original request/header-copy closure without that generated Authorization. Each redirected request can therefore generate Basic independently from its current URL. `net/url/url.go:1102–1113` retains an absolute reference's own userinfo, including its absence; only relative references inherit base userinfo at `1134–1136`.

Two constructor-only supported source cases demonstrate the distinction, without the Store/Run route:

1. Initial `http://owned-u:owned-p@localhost:PORT`, absolute Location `http://localhost:PORT/next`: Go's first request uses initial Basic and the second has no Authorization; native copies initial Basic to the second.
2. The same initial URL, absolute Location `http://new-u:new-p@localhost:PORT/next`: Go generates the destination's Basic; native still uses the initial Basic.

These URLs keep exactly the same raw host, so this issue is independent of P2-2. The intentionally documented native **Run** refusal of credential-bearing remotes before cursor access is correct as a bounded divergence, but the handoff explicitly admits standalone synthetic Basic constructor probes. That refusal does not remove this constructor-level mismatch.

Separate original explicit Bearer/header-copy state from Basic generated independently from the current request URL. Preserve Bearer precedence, sticky original sensitive-header stripping, and Run's early userinfo refusal. Add actual owned absolute-reference/no-userinfo and changed-userinfo pairs; no HTTP execution occurred during this review.

## Full source and boundary review

Read all forty-one changed files, all sync production modules and both unit-test modules, retained earlier implementation texts, case/control plans, both Go probe sources, provenance verifier, ADR, ledger/matrix changes, dependency manifests and raw dependency-resolution history. Reviewed the whole inherited Store/runner foundation against frozen `syncclient/runner.go`, `db/sync.go`, `db/sync_oplog.go`, storage scan/upsert/keysets, client and crypto, rather than limiting the review to the newest backend files.

The candidate keeps real `memory sync` routing delegated to Go; it changes no CLI, policy/profile, JWT, HTTP server, UI, Doctor or historical-migration admission. The ledger says source-only/uncompiled and keeps independent review, exact diagnostics, real protocol/state proof and native three-OS runtime pending. Every sync source/test file remains under 400 lines. Public backend ownership stays within existing `symbrain-memory::sync`; no shared CoreKit subsystem is added.

The ordered JSON implementation retains raw duplicate fields, ignores unknown values with bounded depth, applies Go field folding, preserves pointer/null/empty/allocated-byte distinctions, and treats first-value stream decoding separately from whole-message unmarshal. Metadata merge/reset, hidden slice backing slots, recoverable type errors, raw quoted timestamps, Unicode replacement, base64 CRLF and non-strict tail bits were traced against SDK source and the prepared cases. No additional confirmed defect was identified in this static pass. Extreme offsets, malformed diagnostics, unsupported URI/IDNA families, nullable-memory panic policy, scalar floating-point wire bytes and Store encoding still need actual proof; this review does not infer parity from the hand-written parser.

Wire ordering follows the frozen structs, metadata uses sorted keys, and HTML/JavaScript escaping is explicit. The HTTP implementation owns redirects, sticky body/Content-Type removal after 301/302/303, ten-hop bounding, request/response deadline ownership, response/error read limits, platform certificate verification and explicit owned roots. Ureq3.4.1's `max_redirects(0)` actually returns responses without internal redirect-limit errors; `accept("")` disables its automatic Accept header. Its gzip implementation uses multi-member decoding. HTTP2, environment proxy/NO_PROXY, TLS/platform diagnostics, draining/pooling, partial response failures and cancellation remain unproven, as documented.

Crypto source uses pinned RustCrypto AES256-GCM, PBKDF2-HMAC-SHA256 with 600000 iterations, v1 salt/nonce envelope plus legacy decrypt fallback, fresh nonce entropy, passphrase fingerprint/salt cache and phase reset. Sensitive key/fingerprint/cache storage is zeroized; options/client/engine do not derive secret-bearing Debug. Source traces preserve the inherited legacy cached-salt quirk instead of normalizing it silently. The frozen crypto obtains entropy through `io.ReadFull(rand.Reader)`, so the prepared Go probe's owned Reader override corresponds to the actual reference call path. Cross-runtime vectors, actual nonce/salt/error entropy sequences and real failure-state effects remain mandatory; no encryption/decryption was executed.

Runner/Store ordering remains validation before cursor access, pull before push, memory before tombstone, strictly-newer row/tombstone checks, equality delete behavior, existing audit-ignore contract, per-row commits and final cursor persistence only after successful completion. No broad transaction or retry is added; earlier writes must remain committed on a later failure. Creation identity/validity/superseded fields remain unchanged on Go-compatible updates. The original continuation tombstone predicate, equal-clock relay pagination and unbound outer relay identity are explicitly retained as unresolved protocol decisions. Destructive families require separately approved decisions and genuine full-state controls before admission.

URL userinfo rejection occurs before cursor access in native Run, and authority diagnostic redaction is bounded. It does not claim to sanitize arbitrary query/path/peer response data or to protect the still-Go-routed CLI. Entropy and test roots are owned; no external or operator credentials were consulted.

## Actual independent static verification and provenance

The following checks were actually performed and passed:

- Candidate remains clean at the exact immutable HEAD; no candidate target exists.
- Recursive actual-source `rustfmt --edition 2024 --check`, both pinned-probe gofmt checks, Git whitespace check, Python AST and TOML parsing.
- Exact hashes for **1217 frozen Go/module files**, **420 native source/harness/doc files** including 410 Rust files, **21 SDK files**, six original checkpoint artifacts and all 41 candidate changed-file handoff hashes.
- **617 registry source files** and **25 official crate archives** match the final dependency manifest; all resolution-log hashes and final Cargo.lock bytes match.
- All **273 original locked identities/checksums** remain unchanged; sixteen packages were added. Retained initial missing-PBKDF2 offline failure, original lock, authorized official dependency fetch, final offline success and both earlier uncompiled implementation texts are byte-preserved.
- Original plans retain **230 cases/four controls**; additive plans contain **98 cases/four controls** (47 JSON, 31 HTTP, 20 crypto). Fourteen unit tests (six original/eight new) are prepared. **None of these tests, cases or controls has run.** The two Go probes and future native/process/HTTP/full-state harness are not substitutes for materialized actual comparisons.

The suspected SHA2/HMAC/PBKDF2 incompatibility is **not present in this candidate**: workspace SHA2 is 0.10.9, HMAC0.12.1 and PBKDF2 0.12.2 use Digest0.10.7, and the lock retains those identities. AES-GCM0.11.1's newer crypto-common0.2.2 takes independently derived key bytes; it does not require the HMAC Digest trait generation to match. The actual hybrid-array0.4.15 nonce-conversion API and pinned dependency features/MSRVs/licenses were read. This establishes source/API compatibility of that suspected seam, not a successful Rust typecheck or cryptographic audit.

No runtime results, source/binary map, native platform pass or HTTP/crypto comparison exists for this source-only checkpoint. Retained Go binaries from older work must not be represented as candidate backend proof.

## Preserved evidence, ownership and next gate

Full report: `/tmp/symaira-memory762-backends-independent-static-review.md`.
Machine receipt: `/tmp/symaira-memory762-backends-independent-static-review-receipt.json`.
Independent proof directory: `/tmp/symaira-memory762-backends-independent-static/`.

The receipt binds the exact candidate/frozen/SDK/dependency maps, additional SDK/serde source traces, author handoff, copied complete changed-file inputs, original dependency/correction evidence, actual static logs and this independent recorder. No candidate source was mutated. The final sibling manifest hashes the report and receipt; it avoids circular receipt/report hashes.

**No resource is held:** no target was allocated or accessed, no compiler/runtime child is running, and no port was used. The historical Store target and port remain exclusively Root-owned and were untouched. The author must preserve this immutable source/evidence and correct the three findings in a distinct successor before fresh allocated compilation, full affected Memory/CLI/MCP gates, materialized 230+98 process/HTTP/crypto/full-SQLite comparisons and eight meaningful mutation controls. Native Linux/macOS/Windows exact-source CI and a different-author runtime review remain required before cutover. #762 remains open.
