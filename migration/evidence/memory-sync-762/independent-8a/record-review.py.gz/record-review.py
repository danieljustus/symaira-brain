from pathlib import Path
import ast, hashlib, json, shutil, subprocess, tomllib
from datetime import datetime, timezone
root=Path('/workspace/symaira-memory762-sync-backends')
out=Path('/tmp/symaira-memory762-backends-independent-static')
proof=root/'migration/evidence/memory-sync-762/backends-static'
sdk=Path('/workspace/toolchains/go1.26.7')
frozen=Path('/workspace/oracles/daemon772-go-source')
registry=Path('/home/agent/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def git(*args):return subprocess.check_output(['git','-C',str(root),*args],text=True).strip()
assert git('rev-parse','HEAD')=='8a3226828d045b4307d2c3601e283d1ecfa4ce4f'
assert git('status','--porcelain')==''
assert not (root/'target').exists()
inv=json.loads((proof/'source-inventory.json').read_text())
dep=json.loads((proof/'final-dependency-provenance.json').read_text())
hand=json.loads(Path('/tmp/symaira-memory762-sync-backends-static-handoff.json').read_text())
for name,where in [('frozen',frozen),('native',root),('sdk',sdk),('checkpoint_retained',root)]:
 for file, expected in inv[name+'_sha256'].items():assert sha(where/file)==expected,(name,file)
for file,expected in hand['tracked_changed_files_sha256'].items():assert sha(root/file)==expected,file
for name,where in [('registry_source',Path(dep['registry_source_root'])),('registry_archive',Path(dep['registry_cache_root']))]:
 for file,expected in dep[name+'_sha256'].items():assert sha(where/file)==expected,file
for file in root.glob('scripts/memory-sync-oracle/*.py'):ast.parse(file.read_text())
for file in [root/'Cargo.toml',root/'Cargo.lock',root/'rust/symbrain-memory/Cargo.toml']:tomllib.loads(file.read_text())
old=json.loads((root/'scripts/memory-sync-oracle/cases.json').read_text())
new=json.loads((root/'scripts/memory-sync-oracle/backend-cases.json').read_text())
assert len(old['cases'])==230 and len(old['controls'])==4
assert len(new['cases'])==98 and len(new['controls'])==4
assert all(c['status']=='prepared_not_executed' for c in new['cases']+new['controls'])
assert sum(p.read_text().count('#[test]') for p in (root/'rust/symbrain-memory/src/sync').rglob('*.rs'))==14
changed=git('diff','--name-only','c4a020e0cec77fd38060c591aa1fde244df4b796','HEAD').splitlines()
for name in changed:
 dest=out/'candidate'/name;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(root/name,dest)
for name in ['md','json']:shutil.copyfile(Path('/tmp/symaira-memory762-sync-backends-static-handoff.'+name),out/('author-handoff.'+name))
extra={
 'serde-helper-registration':(registry/'serde_derive-1.0.229/src/lib.rs',[(106,126)]),
 'go-client-header-and-basic-ownership':(sdk/'src/net/http/client.go',[(216,261),(597,627),(677,707),(1005,1049)]),
 'go-idna-ascii-preservation':(sdk/'src/net/http/request.go',[(781,795)]),
 'go-idna-hostname':(sdk/'src/net/http/transport.go',[(3024,3032)]),
 'go-URL-reference-userinfo':(sdk/'src/net/url/url.go',[(1102,1139)]),
 'go-sync-client':(frozen/'internal/memory/syncclient/client.go',[(1,400)]),
 'go-sync-runner':(frozen/'internal/memory/syncclient/runner.go',[(1,500)]),
 'go-sync-cursor':(frozen/'internal/memory/db/sync.go',[(1,100)]),
 'go-sync-oplog':(frozen/'internal/memory/db/sync_oplog.go',[(1,250)]),
 'go-sync-memory-storage':(frozen/'internal/memory/db/memory.go',[(698,922)]),
 'actual-ureq-zero-redirect-and-accept':(registry/'ureq-3.4.1/src/config.rs',[(258,275),(480,505),(794,812)]),
 'actual-hybrid-array-nonce-conversion':(registry/'hybrid-array-0.4.15/src/lib.rs',[(1,1000)]),
}
traces={}
for name,(source,ranges) in extra.items():
 dest=out/'source-traces'/(name+'.txt');dest.parent.mkdir(parents=True,exist_ok=True)
 lines=source.read_text().splitlines()
 text='Source: '+str(source)+'\nSHA256: '+sha(source)+'\n'
 for start,end in ranges:
  text+='\n'+''.join(f'{i}: {lines[i-1]}\n' for i in range(start,min(end,len(lines))+1))
 dest.write_text(text)
 traces[str(source)]={'sha256':sha(source),'line_ranges':ranges,'retained_excerpt':str(dest),'excerpt_sha256':sha(dest)}
(out/'static-accounting.log').write_text('Python AST/three TOML parses: PASS\nOriginal planned cases/controls: 230/4, unexecuted\nAdditive planned cases/controls: 98/4, unexecuted\nPrepared Rust unit tests: 14, unexecuted\nClean immutable HEAD and absent target: PASS\nAll author source/dependency/handoff SHA maps independently verified: PASS\n')
receipt={
 'status':'REQUEST_CHANGES_STATIC_ONLY', 'reviewer':'memory758_port (different author)',
 'created_utc':datetime.now(timezone.utc).isoformat(), 'worktree':str(root),'head':git('rev-parse','HEAD'),
 'base':'c4a020e0cec77fd38060c591aa1fde244df4b796','head_clean':True,'target_exists':False,
 'executed_checks':[{'check':'source/dependency SHA and lock provenance','result':'PASS','log':str(out/'provenance-verifier.log')},{'check':'rustfmt recursive parse/check','result':'PASS','log':str(out/'rustfmt.log')},{'check':'pinned gofmt both probe sources','result':'PASS','log':str(out/'gofmt.log')},{'check':'git diff whitespace','result':'PASS','log':str(out/'diffcheck.log')},{'check':'Python AST/TOML/plan/test accounting and immutable source checks','result':'PASS','log':str(out/'static-accounting.log')}],
 'runtime_or_compilation_executed':False,'test_or_control_results_claimed':0,'resources_owned':[],
 'prepared_only':{'original_cases':230,'original_controls':4,'additive_cases':98,'additive_controls':4,'Rust_unit_tests':14},
 'independently_verified_counts':{'frozen_source_modules':len(inv['frozen_sha256']),'native_source_harness_docs':len(inv['native_sha256']),'SDK':len(inv['sdk_sha256']),'checkpoint_retained':len(inv['checkpoint_retained_sha256']),'registry_source':len(dep['registry_source_sha256']),'official_registry_archives':len(dep['registry_archive_sha256']),'old_locked_identities':273,'added_locked_identities':16,'changed_candidate_files':len(changed)},
 'source_maps':{k:inv[k] for k in ['frozen_sha256','native_sha256','sdk_sha256','checkpoint_retained_sha256']},
 'dependency_maps':{k:dep[k] for k in ['registry_source_sha256','registry_archive_sha256','resolution_logs_sha256']},
 'author_handoff_sha256':sha(Path('/tmp/symaira-memory762-sync-backends-static-handoff.json')),
 'source_inventory_sha256':sha(proof/'source-inventory.json'),'dependency_provenance_sha256':sha(proof/'final-dependency-provenance.json'),
 'static_validation_sha256':sha(proof/'static-validation.json'),'extra_source_traces':traces,
 'findings':[
 {'id':'P2-1','priority':2,'kind':'static build blocker','file':'rust/symbrain-memory/src/sync/model.rs','line':112,'summary':'Unregistered serde helper attribute on RelayBlob without serde derive.'},
 {'id':'P2-2','priority':2,'kind':'source-traced functional redirect parity','file':'rust/symbrain-memory/src/sync/http.rs','line':169,'summary':'Lowercased ASCII hosts retain original explicit Authorization where pinned Go strips it and keeps stripping sticky.'},
 {'id':'P2-3','priority':2,'kind':'source-traced functional redirect parity','file':'rust/symbrain-memory/src/sync/http.rs','line':98,'summary':'URL-generated Basic is copied as an original header instead of generated independently from each current request URL.'}],
 'limitations':['No Rust typecheck/Clippy/build or Go build/run.','No HTTP, crypto, database, target, port, credentials, operator state or external system accessed.','328 plans and eight controls plus 14 unit tests are prepared only.','Native Linux/macOS/Windows runtime, full affected graph, actual frozen-process/wire/crypto/full-state comparisons and separate admission approval remain required.']
}
# Bind all retained proof bytes, excluding this receipt which has its own external digest.
receipt['retained_proof_sha256']={str(p.relative_to(out)):sha(p) for p in sorted(out.rglob('*')) if p.is_file()}
path=Path('/tmp/symaira-memory762-backends-independent-static-review-receipt.json')
path.write_text(json.dumps(receipt,indent=2,sort_keys=True)+'\n')
print(json.dumps({'head':receipt['head'],'status':receipt['status'],'counts':receipt['independently_verified_counts'],'retained_proofs':len(receipt['retained_proof_sha256']),'receipt':str(path),'sha256':sha(path)},indent=2))
