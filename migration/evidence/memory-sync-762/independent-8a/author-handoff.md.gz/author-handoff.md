# Memory762 concrete backend source-only handoff

Immutable clean HEAD `8a3226828d045b4307d2c3601e283d1ecfa4ce4f`, branch `issue/762-native-memory-sync-backends`,
worktree `/workspace/symaira-memory762-sync-backends`. Base `c4a020e0cec77fd38060c591aa1fde244df4b796` remains clean and untouched in
`/workspace/symaira-memory762-sync`. Frozen Go dcddcef0 and its1217 source/module
hashes remain unchanged. No target is allocated/created; no compiler, oracle,
listener, HTTP request or crypto operation ran. No GitHub writes occurred.

The next concrete backend is implemented on the existing Store/sync owner:
pinned ureq3.4.1 HTTP transport, Go-derived ordered/typed JSON and wire encoding,
Go raw URL/redirect ownership, RustCrypto AES256-GCM/PBKDF2-HMAC-SHA256 with
600000 iterations/v1+legacy/run-phase cache.14 source-only unit tests are prepared
(6 original+8 backend);230 original planned cases/four controls stay byteexact,
and98 additive cases/four new meaningful controls are separately prepared.
Zero tests/controls have passed at this checkpoint. No native CLI/HTTP admission.

Static checks actually passed: rustfmt source parse/check, new-probe gofmt,
git diff whitespace, JSON/TOML/case accounting, all1217 frozen source hashes,
420 bound native/source/harness/doc hashes (410 Rust files),21 SDK hashes,
six original checkpoint artifact hashes and locked dependency provenance.
390 C4 Rust files stay unchanged;three modified owner/model files and17 added
modules. Every sync production/test file is below400 lines (maximum329).
The worktree is103MiB with no target. Typechecking/Clippy remain unperformed.

Dependency failure/history is retained verbatim: initial offline missingPBKDF2
error, original C4 lock, authorized official crates.io fetch/resolution and final
offline resolution.16 new packages;all273 old package identities/checksums stay
unchanged.25 relevant official crate archives and617 registry source files,
licenses/MSRVs and final lock SHA are bound by final-dependency-provenance.json.
No remaining dependency fetch or compiler action is needed before allocation.

Source correction history is explicit: pinned SDK1.26.7 makes redirect body and
Content-Type removal sticky after301/302/303 (later307/308 does not restore it);
Decoder.readValue accepts the first scalar before its delayed invalid trailing
byte, while whole Unmarshal rejects trailing bytes. Earlier uncompiled source
assumptions are retained as two .rs.txt artifacts, never called runtime failures.

Native HTTP run refuses URL userinfo before cursor access because the frozen
runner persists/reports the literal remote. Authority credentials are redacted
in URL/prefix diagnostics; constructor-only synthetic Basic probes remain
possible without a Store. This intentional bounded divergence requires actual
no-write/secret-absence proof. It does not sanitize arbitrary path/query/peer
payloads or confer protection on the still-Go-gated CLI.

Required before admission: allocate one owned target, compile/check full affected
Memory/CLI/MCP parent graph with strict Clippy/fmt and all old real gates; build
both prepared Go probes only in an unchanged private frozen copy; implement an
actual native/Go process+ephemeral-HTTP+full-state harness and execute every230+98
case with materialized raw inputs, normal failures and8 substantive controls.
Run actual cross-runtime encryption/decryption and exact entropy vectors; do not
substitute a local roundtrip. Full source/binary/SDK manifests, independent
review and native Linux/macOS/Windows exact-head workflows remain mandatory.

Remaining explicit bounds: exact malformed time/JSON/network/TLS error messages,
extreme offsets/local-zone and raw platform input semantics; direct allocated-
empty versus nil request slices; unsupported IDNA/zone/opaque URI families;
Go HTTP2/proxy/NO_PROXY/TLS/body lifecycle/cancellation and numeric wire/Store
bytes. Nullable memory panic is refused. Equal-clock relay pagination/unbound
outer identity and destructive tombstone continuation remain original Go quirks;
no blanket native admission or silent destructive behavior normalization. No
separate BUSY/historical Store fix, Memory763 HTTP owner or full762 closure.

Decisions: docs/adr/memory-sync-concrete-backends-762.md. Manifest/provenance:
migration/evidence/memory-sync-762/backends-static. Reproducible static-only
verification: `python3 scripts/memory-sync-oracle/verify-backends-static.py`.
Source restrictions stay in force until Root explicitly allocates runtime.
