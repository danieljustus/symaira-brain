package main

import (
	"bytes"
	"context"
	"encoding/json"
	"os"
	"path/filepath"
	"runtime"
	"strings"
	"testing"

	"github.com/danieljustus/symaira-brain/internal/harness"
	memorydb "github.com/danieljustus/symaira-brain/internal/memory/db"
	memorypaths "github.com/danieljustus/symaira-brain/internal/memory/paths"
	skillsconfig "github.com/danieljustus/symaira-brain/internal/skills/config"
	"github.com/danieljustus/symaira-corekit/exitcodes"
)

// isolatedPATH excludes both PATH binaries and higher-priority config/managed
// binaries so discovery cannot reach tools installed on the test host.
func isolatedPATH(t *testing.T, dir string) {
	t.Helper()
	home := t.TempDir()
	t.Setenv("HOME", home)
	t.Setenv("USERPROFILE", home)
	t.Setenv("XDG_CONFIG_HOME", filepath.Join(home, ".config"))
	t.Setenv("SYMBRAIN_SERVERS_VAULT_BINARY_PATH", "")
	t.Setenv("PATH", dir)
}

// fakeBinary writes an executable shell script named name into dir that
// prints stdout on `version --json` args and exits 0, or exits 1 with no
// output for any other args.
func fakeBinary(t *testing.T, dir, name, stdout string) string {
	t.Helper()
	path := filepath.Join(dir, name)
	script := "#!/bin/sh\n" +
		`if [ "$1" = "version" ] && [ "$2" = "--json" ]; then` + "\n" +
		"  printf '%s'\n" +
		"  exit 0\n" +
		"fi\n" +
		"exit 1\n"
	script = strings.Replace(script, "%s", stdout, 1)
	if err := os.WriteFile(path, []byte(script), 0o755); err != nil {
		t.Fatalf("write fake binary %s: %v", name, err)
	}
	return path
}

func TestCheckServers_NotFound(t *testing.T) {
	if runtime.GOOS == "windows" {
		t.Skip("fake binary is a POSIX shell script")
	}
	isolatedPATH(t, t.TempDir())

	checks := checkServers(context.Background())

	if len(checks) != len(knownServers) {
		t.Fatalf("len(checks) = %d, want %d", len(checks), len(knownServers))
	}
	for _, c := range checks {
		if c.Found {
			t.Errorf("server %s: Found = true, want false (isolated PATH)", c.Name)
		}
		if c.InstallHint == "" {
			t.Errorf("server %s: InstallHint is empty, want an install hint", c.Name)
		}
	}
}

func TestCheckServers_FoundAndProbeSucceeds(t *testing.T) {
	if runtime.GOOS == "windows" {
		t.Skip("fake binary is a POSIX shell script")
	}
	dir := t.TempDir()
	fakeBinary(t, dir, "symvault", `{"tool":"symvault","version":"9.9.9","schema_version":1}`)
	isolatedPATH(t, dir)

	checks := checkServers(context.Background())

	var vault *serverCheck
	for i := range checks {
		if checks[i].Name == "vault" {
			vault = &checks[i]
		}
	}
	if vault == nil {
		t.Fatal("no check for server \"vault\"")
	}
	if !vault.Found {
		t.Fatal("vault.Found = false, want true")
	}
	if vault.ProbeError != "" {
		t.Errorf("vault.ProbeError = %q, want empty", vault.ProbeError)
	}
	if vault.Version != "9.9.9" {
		t.Errorf("vault.Version = %q, want %q", vault.Version, "9.9.9")
	}
}

func TestCheckServers_FoundButProbeFails(t *testing.T) {
	if runtime.GOOS == "windows" {
		t.Skip("fake binary is a POSIX shell script")
	}
	dir := t.TempDir()
	fakeBinary(t, dir, "symvault", "not json")
	isolatedPATH(t, dir)

	checks := checkServers(context.Background())

	var vault *serverCheck
	for i := range checks {
		if checks[i].Name == "vault" {
			vault = &checks[i]
		}
	}
	if vault == nil {
		t.Fatal("no check for server \"vault\"")
	}
	if !vault.Found {
		t.Fatal("vault.Found = false, want true (binary is on PATH)")
	}
	if vault.ProbeError == "" {
		t.Error("vault.ProbeError is empty, want a parse error (output is not JSON)")
	}
}

// TestCheckServers_AbsorbedCoresAreNotProbed pins the consolidation outcome:
// memory, skills and the embedded usage tool run inside this binary, so
// doctor must not report them as missing sibling processes — and must not
// hand out install hints for their deprecated Homebrew formulae.
func TestCheckServers_AbsorbedCoresAreNotProbed(t *testing.T) {
	checks := checkServers(context.Background())
	for _, c := range checks {
		if c.Name == "memory" || c.Name == "skills" || c.Name == "usage" {
			t.Errorf("%s is built in and must not be probed as a sibling binary", c.Name)
		}
	}
	if len(builtinServers) != 3 {
		t.Errorf("builtinServers = %v, want memory, skills and usage", builtinServers)
	}
}

func TestCheckDir(t *testing.T) {
	dir := t.TempDir()
	missing := filepath.Join(dir, "does-not-exist")

	if c := checkDir(dir); !c.Exists {
		t.Errorf("checkDir(%q).Exists = false, want true", dir)
	}
	if c := checkDir(missing); c.Exists {
		t.Errorf("checkDir(%q).Exists = true, want false", missing)
	}
}

func TestDiscoverProfiles(t *testing.T) {
	home := t.TempDir()
	t.Setenv("HOME", home)

	if got := discoverProfiles(); len(got) != 0 {
		t.Errorf("discoverProfiles() with no profiles dir = %v, want empty", got)
	}

	profilesDir := filepath.Join(home, ".config", "symbrain", "profiles")
	if err := os.MkdirAll(profilesDir, 0o755); err != nil {
		t.Fatalf("MkdirAll: %v", err)
	}
	for _, name := range []string{"restricted.toml", "personal.toml", "notes.txt"} {
		if err := os.WriteFile(filepath.Join(profilesDir, name), []byte("x"), 0o644); err != nil {
			t.Fatalf("WriteFile(%s): %v", name, err)
		}
	}

	got := discoverProfiles()
	want := []string{"personal", "restricted"}
	if len(got) != len(want) || got[0] != want[0] || got[1] != want[1] {
		t.Errorf("discoverProfiles() = %v, want %v", got, want)
	}
}

func TestCmdDoctor_JSONIsSnakeCaseAndExitsOK(t *testing.T) {
	if runtime.GOOS == "windows" {
		t.Skip("fake binary is a POSIX shell script")
	}

	tests := []struct {
		name string
		args []string
	}{
		{name: "double-dash json", args: []string{"--json"}},
		{name: "single-dash json", args: []string{"-json"}},
		{name: "double-dash output json", args: []string{"--output", "json"}},
		{name: "single-dash output json", args: []string{"-output", "json"}},
		{name: "double-dash output=json", args: []string{"--output=json"}},
		{name: "single-dash output=json", args: []string{"-output=json"}},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			home := t.TempDir()
			t.Setenv("HOME", home)
			isolatedPATH(t, t.TempDir())

			var stdout, stderr bytes.Buffer
			code := cmdDoctor(tt.args, &stdout, &stderr)

			if code != exitcodes.ExitOK {
				t.Fatalf("cmdDoctor(%v) = %d, want %d (stderr: %s)", tt.args, code, exitcodes.ExitOK, stderr.String())
			}

			trimmed := strings.TrimSpace(stdout.String())
			if !strings.HasPrefix(trimmed, "{") {
				t.Fatalf("cmdDoctor(%v) output does not start with '{': %q", tt.args, trimmed)
			}

			var report map[string]any
			if err := json.Unmarshal(stdout.Bytes(), &report); err != nil {
				t.Fatalf("output is not valid JSON: %v (output: %q)", err, stdout.String())
			}

			for _, key := range []string{"config_dir", "data_dir", "cache_dir", "config", "servers", "profiles", "harnesses"} {
				if _, ok := report[key]; !ok {
					t.Errorf("JSON report missing key %q: %v", key, report)
				}
			}
		})
	}
}

func TestCmdDoctor_ExitsOKEvenWithNoOptionalToolsInstalled(t *testing.T) {
	if runtime.GOOS == "windows" {
		t.Skip("fake binary is a POSIX shell script")
	}
	home := t.TempDir()
	t.Setenv("HOME", home)
	isolatedPATH(t, t.TempDir())

	var stdout, stderr bytes.Buffer
	code := cmdDoctor(nil, &stdout, &stderr)

	if code != exitcodes.ExitOK {
		t.Fatalf("cmdDoctor() = %d, want %d (stderr: %s)", code, exitcodes.ExitOK, stderr.String())
	}
	if !strings.Contains(stdout.String(), "not found on PATH") {
		t.Errorf("stdout = %q, want it to explain missing optional tools", stdout.String())
	}
}

// writeHarnessConfig writes a config file for h at its resolved config
// path, with symbrain already installed and bound to profile. It uses the
// harness package's own Document/Marshal so the fixture is guaranteed to
// be something checkHarness can parse (issue #21 builds directly on #19's
// registry).
func writeHarnessConfig(t *testing.T, h harness.Harness, profile string) string {
	t.Helper()
	path, err := h.ConfigPath()
	if err != nil {
		t.Fatalf("ConfigPath: %v", err)
	}
	if err := os.MkdirAll(filepath.Dir(path), 0o755); err != nil {
		t.Fatalf("MkdirAll: %v", err)
	}

	doc := harness.Empty(h)
	doc.SetServer(harness.ServerName, harness.NewEntry(profile))
	data, err := doc.Marshal()
	if err != nil {
		t.Fatalf("Marshal: %v", err)
	}
	if err := os.WriteFile(path, data, 0o644); err != nil {
		t.Fatalf("WriteFile: %v", err)
	}
	return path
}

// writeStubProfileFile creates an (empty-content) profile file at
// ~/.config/symbrain/profiles/<name>.toml, the on-disk existence
// checkHarness looks for per issue #21's narrower "no internal/profile
// yet" fallback.
func writeStubProfileFile(t *testing.T, home, name string) {
	t.Helper()
	dir := filepath.Join(home, ".config", "symbrain", "profiles")
	if err := os.MkdirAll(dir, 0o755); err != nil {
		t.Fatalf("MkdirAll: %v", err)
	}
	content := "[profile]\nname = \"" + name + "\"\n"
	if err := os.WriteFile(filepath.Join(dir, name+".toml"), []byte(content), 0o644); err != nil {
		t.Fatalf("WriteFile profile: %v", err)
	}
}

func TestCheckHarness_NoConfig(t *testing.T) {
	harnessSandbox(t)
	h := harnessByName(t, "claude")

	check := checkHarness(h)
	if check.ConfigFound {
		t.Error("ConfigFound = true, want false")
	}
	if check.Installed {
		t.Error("Installed = true, want false")
	}
	if check.ConfigPath == "" {
		t.Error("ConfigPath is empty, want the resolved path even when the file is missing")
	}
}

func TestCheckHarness_ConfigFoundButNotInstalled(t *testing.T) {
	harnessSandbox(t)
	h := harnessByName(t, "cursor")
	path, err := h.ConfigPath()
	if err != nil {
		t.Fatalf("ConfigPath: %v", err)
	}
	if err := os.MkdirAll(filepath.Dir(path), 0o755); err != nil {
		t.Fatalf("MkdirAll: %v", err)
	}
	if err := os.WriteFile(path, []byte("{\n  \"mcpServers\": {}\n}\n"), 0o644); err != nil {
		t.Fatalf("WriteFile: %v", err)
	}

	check := checkHarness(h)
	if !check.ConfigFound || !check.ConfigParsed {
		t.Fatalf("ConfigFound=%v ConfigParsed=%v, want true/true", check.ConfigFound, check.ConfigParsed)
	}
	if check.Installed {
		t.Error("Installed = true, want false")
	}
}

func TestCheckHarness_InstalledAndProfileExists(t *testing.T) {
	home := harnessSandbox(t)
	h := harnessByName(t, "claude")
	writeHarnessConfig(t, h, "personal")
	writeStubProfileFile(t, home, "personal")

	check := checkHarness(h)
	if !check.Installed {
		t.Fatal("Installed = false, want true")
	}
	if check.Profile != "personal" {
		t.Errorf("Profile = %q, want %q", check.Profile, "personal")
	}
	if !check.ProfileExists {
		t.Error("ProfileExists = false, want true")
	}
	if check.ProfileMissing {
		t.Error("ProfileMissing = true, want false")
	}
}

func TestCheckHarness_InstalledButProfileMissing(t *testing.T) {
	home := harnessSandbox(t)
	h := harnessByName(t, "claude")
	writeHarnessConfig(t, h, "ghost")
	_ = home // deliberately do not create profiles/ghost.toml

	check := checkHarness(h)
	if !check.Installed {
		t.Fatal("Installed = false, want true")
	}
	if check.ProfileExists {
		t.Error("ProfileExists = true, want false")
	}
	if !check.ProfileMissing {
		t.Error("ProfileMissing = false, want true — a binding to a nonexistent profile must be flagged")
	}
}

func TestCheckHarness_CorruptConfig(t *testing.T) {
	harnessSandbox(t)
	h := harnessByName(t, "claude")
	path, err := h.ConfigPath()
	if err != nil {
		t.Fatalf("ConfigPath: %v", err)
	}
	if err := os.WriteFile(path, []byte("{not valid json"), 0o644); err != nil {
		t.Fatalf("WriteFile: %v", err)
	}

	check := checkHarness(h)
	if !check.ConfigFound {
		t.Error("ConfigFound = false, want true")
	}
	if check.ConfigParsed {
		t.Error("ConfigParsed = true, want false")
	}
	if check.ConfigError == "" {
		t.Error("ConfigError is empty, want an error message")
	}
	if check.Installed {
		t.Error("Installed = true, want false for a corrupt config")
	}
}

func TestCheckHarness_ForeignEntrySharingTheNameIsNotInstalled(t *testing.T) {
	harnessSandbox(t)
	h := harnessByName(t, "cursor")
	path, err := h.ConfigPath()
	if err != nil {
		t.Fatalf("ConfigPath: %v", err)
	}
	if err := os.MkdirAll(filepath.Dir(path), 0o755); err != nil {
		t.Fatalf("MkdirAll: %v", err)
	}
	doc := harness.Empty(h)
	doc.SetServer(harness.ServerName, harness.Entry{Command: "not-symbrain", Args: []string{"foo"}})
	data, err := doc.Marshal()
	if err != nil {
		t.Fatalf("Marshal: %v", err)
	}
	if err := os.WriteFile(path, data, 0o644); err != nil {
		t.Fatalf("WriteFile: %v", err)
	}

	check := checkHarness(h)
	if check.Installed {
		t.Error("Installed = true, want false — command does not resolve to symbrain")
	}
}

func TestCheckHarnesses_CoversEveryRegisteredHarness(t *testing.T) {
	harnessSandbox(t)
	checks := checkHarnesses()
	if len(checks) != len(harness.All) {
		t.Fatalf("len(checkHarnesses()) = %d, want %d", len(checks), len(harness.All))
	}
}

func TestCmdDoctor_HumanOutput_ReportsHarnessBindings(t *testing.T) {
	if runtime.GOOS == "windows" {
		t.Skip("fake binary is a POSIX shell script")
	}
	isolatedPATH(t, t.TempDir())
	home := harnessSandbox(t)

	installed := harnessByName(t, "cursor")
	writeHarnessConfig(t, installed, "personal")
	writeStubProfileFile(t, home, "personal")

	missing := harnessByName(t, "antigravity")
	writeHarnessConfig(t, missing, "ghost")

	var stdout, stderr bytes.Buffer
	code := cmdDoctor(nil, &stdout, &stderr)
	if code != exitcodes.ExitOK {
		t.Fatalf("cmdDoctor() = %d, want %d (stderr: %s)", code, exitcodes.ExitOK, stderr.String())
	}

	out := stdout.String()
	if !strings.Contains(out, "cursor") || !strings.Contains(out, `"personal"`) {
		t.Errorf("stdout missing the installed cursor/personal line: %q", out)
	}
	if !strings.Contains(out, `missing profile "ghost"`) {
		t.Errorf("stdout missing the flagged missing-profile line: %q", out)
	}
	if !strings.Contains(out, "codex") {
		t.Errorf("stdout missing a harness with no config at all: %q", out)
	}
}

func TestCmdDoctor_HumanOutput_ReportsSupersededBesideSymbrain(t *testing.T) {
	if runtime.GOOS == "windows" {
		t.Skip("fake binary is a POSIX shell script")
	}
	isolatedPATH(t, t.TempDir())
	home := harnessSandbox(t)

	h := harnessByName(t, "claude")
	path, err := h.ConfigPath()
	if err != nil {
		t.Fatalf("ConfigPath: %v", err)
	}
	if err := os.MkdirAll(filepath.Dir(path), 0o755); err != nil {
		t.Fatalf("MkdirAll: %v", err)
	}
	doc := harness.Empty(h)
	doc.SetServer(harness.ServerName, harness.NewEntry("personal"))
	doc.SetServer("symmemory", harness.Entry{Command: "/opt/homebrew/bin/symmemory", Args: []string{"serve"}})
	data, err := doc.Marshal()
	if err != nil {
		t.Fatalf("Marshal: %v", err)
	}
	if err := os.WriteFile(path, data, 0o644); err != nil {
		t.Fatalf("WriteFile: %v", err)
	}
	writeStubProfileFile(t, home, "personal")

	var stdout, stderr bytes.Buffer
	code := cmdDoctor(nil, &stdout, &stderr)
	if code != exitcodes.ExitOK {
		t.Fatalf("cmdDoctor() = %d, want %d (stderr: %s)", code, exitcodes.ExitOK, stderr.String())
	}

	out := stdout.String()
	if !strings.Contains(out, "superseded core entries registered beside symbrain") {
		t.Errorf("stdout missing superseded-core warning beside symbrain: %q", out)
	}
	if !strings.Contains(out, "symmemory") {
		t.Errorf("stdout missing the superseded server name symmemory: %q", out)
	}
	if !strings.Contains(out, "run `symbrain install` to migrate") {
		t.Errorf("stdout missing the migration hint: %q", out)
	}
}

func TestCmdDoctor_JSON_HarnessesIncludeProfileBindingFields(t *testing.T) {
	if runtime.GOOS == "windows" {
		t.Skip("fake binary is a POSIX shell script")
	}
	isolatedPATH(t, t.TempDir())
	home := harnessSandbox(t)

	h := harnessByName(t, "codex")
	writeHarnessConfig(t, h, "personal")
	writeStubProfileFile(t, home, "personal")

	var stdout, stderr bytes.Buffer
	code := cmdDoctor([]string{"--json"}, &stdout, &stderr)
	if code != exitcodes.ExitOK {
		t.Fatalf("cmdDoctor(--json) = %d, want %d (stderr: %s)", code, exitcodes.ExitOK, stderr.String())
	}

	type harnessJSON struct {
		Name           string `json:"name"`
		Installed      bool   `json:"installed"`
		Profile        string `json:"profile"`
		ProfileExists  bool   `json:"profile_exists"`
		ProfileMissing bool   `json:"profile_missing"`
	}
	var report struct {
		Harnesses []harnessJSON `json:"harnesses"`
	}
	if err := json.Unmarshal(stdout.Bytes(), &report); err != nil {
		t.Fatalf("output is not valid JSON: %v (output: %q)", err, stdout.String())
	}

	var codex *harnessJSON
	for i := range report.Harnesses {
		if report.Harnesses[i].Name == "codex" {
			codex = &report.Harnesses[i]
		}
	}
	if codex == nil {
		t.Fatalf("no codex entry in harnesses: %+v", report.Harnesses)
	}
	if !codex.Installed || codex.Profile != "personal" || !codex.ProfileExists || codex.ProfileMissing {
		t.Errorf("codex check = %+v, want installed/personal/exists/not-missing", *codex)
	}
}

func TestRunDoctorChecks_FlagsMissingProfileBinding(t *testing.T) {
	if runtime.GOOS == "windows" {
		t.Skip("fake binary is a POSIX shell script")
	}
	isolatedPATH(t, t.TempDir())
	harnessSandbox(t)

	h := harnessByName(t, "antigravity")
	writeHarnessConfig(t, h, "ghost")

	report := runDoctorChecks(context.Background(), "claude-code")

	var found *harnessCheck
	for i := range report.Harnesses {
		if report.Harnesses[i].Name == "antigravity" {
			found = &report.Harnesses[i]
		}
	}
	if found == nil {
		t.Fatal("no harness check for gemini")
	}
	if !found.ProfileMissing {
		t.Error("ProfileMissing = false, want true")
	}
}

func TestCheckHarness_FlagsSupersededCoreBesideSymbrain(t *testing.T) {
	// A harness registering both symbrain and a superseded core
	// (symmemory/symskills) is a live tool collision — doctor must report it
	// with the exact fix (issue #337).
	harnessSandbox(t)
	h := harnessByName(t, "claude")
	path, err := h.ConfigPath()
	if err != nil {
		t.Fatalf("ConfigPath: %v", err)
	}
	if err := os.MkdirAll(filepath.Dir(path), 0o755); err != nil {
		t.Fatalf("MkdirAll: %v", err)
	}
	doc := harness.Empty(h)
	doc.SetServer(harness.ServerName, harness.NewEntry("personal"))
	doc.SetServer("symmemory", harness.Entry{Command: "/opt/homebrew/bin/symmemory", Args: []string{"serve"}})
	data, err := doc.Marshal()
	if err != nil {
		t.Fatalf("Marshal: %v", err)
	}
	if err := os.WriteFile(path, data, 0o644); err != nil {
		t.Fatalf("WriteFile: %v", err)
	}

	check := checkHarness(h)
	if !check.Installed {
		t.Fatal("Installed = false, want true")
	}
	if len(check.Superseded) != 1 || !strings.Contains(check.Superseded[0], "symmemory") {
		t.Errorf("Superseded = %v, want [symmemory entry]", check.Superseded)
	}
}

func TestCheckHarness_NoSupersededWhenOnlySymbrain(t *testing.T) {
	harnessSandbox(t)
	h := harnessByName(t, "claude")
	writeHarnessConfig(t, h, "personal")

	check := checkHarness(h)
	if !check.Installed {
		t.Fatal("Installed = false, want true")
	}
	if len(check.Superseded) != 0 {
		t.Errorf("Superseded = %v, want none", check.Superseded)
	}
}

func TestCheckMemoryDB_NotYetCreated(t *testing.T) {
	t.Setenv("HOME", t.TempDir())

	check := checkMemoryDB()
	if check.Exists {
		t.Errorf("Exists = true, want false (no database file written yet)")
	}
	if check.Error != "" {
		t.Errorf("Error = %q, want empty (an uncreated database is not a failure)", check.Error)
	}
}

func TestCheckMemoryDB_ValidDB(t *testing.T) {
	t.Setenv("HOME", t.TempDir())

	db, err := memorydb.Open(nil)
	if err != nil {
		t.Fatalf("memorydb.Open: %v", err)
	}
	if err := db.Close(); err != nil {
		t.Fatalf("db.Close: %v", err)
	}

	check := checkMemoryDB()
	if !check.Exists {
		t.Fatal("Exists = false, want true")
	}
	if check.Error != "" {
		t.Fatalf("Error = %q, want empty", check.Error)
	}
	if !check.ModeOK {
		t.Errorf("ModeOK = false (mode %s), want true", check.Mode)
	}
	if check.QuickCheck != "ok" {
		t.Errorf("QuickCheck = %q, want %q", check.QuickCheck, "ok")
	}
	if check.Legacy {
		t.Errorf("Legacy = true, want false (freshly resolved current path)")
	}
}

func TestCheckMemoryDB_CorruptFile(t *testing.T) {
	t.Setenv("HOME", t.TempDir())

	if _, err := memorypaths.EnsureDataDir(); err != nil {
		t.Fatalf("EnsureDataDir: %v", err)
	}
	path, err := memorypaths.DatabasePath()
	if err != nil {
		t.Fatalf("DatabasePath: %v", err)
	}
	if err := os.WriteFile(path, []byte("this is not a sqlite database"), 0o600); err != nil {
		t.Fatalf("WriteFile: %v", err)
	}

	check := checkMemoryDB()
	if !check.Exists {
		t.Fatal("Exists = false, want true (the corrupt file is present)")
	}
	if check.Error == "" {
		t.Error("Error is empty, want a quick_check/open failure for a corrupt database file")
	}
}

func TestCheckSkillsLibrary_Empty(t *testing.T) {
	t.Setenv("HOME", t.TempDir())

	check := checkSkillsLibrary()
	if check.Count != 0 {
		t.Errorf("Count = %d, want 0", check.Count)
	}
	if check.Exists {
		t.Errorf("Exists = true, want false (no library dir created)")
	}
	if check.Error != "" {
		t.Errorf("Error = %q, want empty", check.Error)
	}
}

func TestCheckSkillsLibrary_WithSkills(t *testing.T) {
	t.Setenv("HOME", t.TempDir())

	cfg := skillsconfig.Defaults()
	for _, name := range []string{"alpha-skill", "beta-skill"} {
		dir := filepath.Join(cfg.LibraryDir, name)
		if err := os.MkdirAll(dir, 0o755); err != nil {
			t.Fatalf("MkdirAll(%s): %v", dir, err)
		}
		content := "---\nname: " + name + "\ndescription: test skill\n---\nBody.\n"
		if err := os.WriteFile(filepath.Join(dir, "SKILL.md"), []byte(content), 0o644); err != nil {
			t.Fatalf("WriteFile SKILL.md: %v", err)
		}
	}

	check := checkSkillsLibrary()
	if check.Count != 2 {
		t.Errorf("Count = %d, want 2", check.Count)
	}
	if !check.Exists {
		t.Error("Exists = false, want true")
	}
	if check.Error != "" {
		t.Errorf("Error = %q, want empty", check.Error)
	}
}

func TestCmdDoctor_JSONIncludesMemoryAndSkillsChecks(t *testing.T) {
	if runtime.GOOS == "windows" {
		t.Skip("fake binary is a POSIX shell script")
	}
	t.Setenv("HOME", t.TempDir())
	isolatedPATH(t, t.TempDir())

	var stdout, stderr bytes.Buffer
	code := cmdDoctor([]string{"--json"}, &stdout, &stderr)
	if code != exitcodes.ExitOK {
		t.Fatalf("cmdDoctor(--json) = %d, want %d (stderr: %s)", code, exitcodes.ExitOK, stderr.String())
	}

	var report map[string]any
	if err := json.Unmarshal(stdout.Bytes(), &report); err != nil {
		t.Fatalf("output is not valid JSON: %v", err)
	}
	for _, key := range []string{"memory_db", "skills_library"} {
		if _, ok := report[key]; !ok {
			t.Errorf("JSON report missing key %q: %v", key, report)
		}
	}
}
