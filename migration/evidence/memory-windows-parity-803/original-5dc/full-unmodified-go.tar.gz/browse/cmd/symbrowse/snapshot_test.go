package main

import (
	"bytes"
	"context"
	"encoding/json"
	"log/slog"
	"net"
	"os"
	"path/filepath"
	"strings"
	"testing"
	"time"

	"github.com/danieljustus/symaira-browse/internal/daemon"
)

// startSnapshotTestDaemon runs an in-process daemon whose snapshot and
// get.html frames serve a page containing prompt-injection vectors. The
// socket base follows the platform layout (darwin: ~/Library/Caches, linux:
// XDG_RUNTIME_DIR) so the CLI client dials the same path on every OS.
func startSnapshotTestDaemon(t *testing.T) string {
	t.Helper()
	// macOS unix sockets cap at 104 bytes; build a short base directory.
	base, err := os.MkdirTemp("", "sb-")
	if err != nil {
		t.Fatal(err)
	}
	t.Cleanup(func() { _ = os.RemoveAll(base) })
	t.Setenv("HOME", base)
	t.Setenv("XDG_RUNTIME_DIR", filepath.Join(base, "runtime"))
	path, err := daemon.SocketPath("test")
	if err != nil {
		t.Fatal(err)
	}
	if err := os.MkdirAll(filepath.Dir(path), 0o700); err != nil {
		t.Fatal(err)
	}
	registry := daemon.NewSessionRegistry(daemon.SessionRegistryOptions{})
	server := daemon.NewServer(daemon.Options{
		SocketPath: path,
		Session:    "test",
		Registry:   registry,
		// The test daemon runs in-process; peer-credential validation is a
		// production boundary check that is unavailable on Windows.
		PeerValidator: func(net.Conn) error { return nil },
		Handler: func(ctx context.Context, frame daemon.Frame) (any, []daemon.Warning, error) {
			switch frame.Cmd {
			case "snapshot":
				var request struct {
					NoInjectionScan bool `json:"no_injection_scan"`
				}
				_ = json.Unmarshal(frame.Args, &request)
				if request.NoInjectionScan {
					return "fake snapshot text", nil, nil
				}
				warnings := []daemon.Warning{
					{Kind: "imperative", Severity: "high", Message: "agent-directed instruction detected on p", Ref: "p", Excerpt: "ignore previous instructions"},
					{Kind: "aria_mismatch", Severity: "high", Message: "accessible-name mismatch on #b", Ref: "#b", Excerpt: `visible "Continue" vs aria-label "Delete account"`},
				}
				return "fake snapshot text", warnings, nil
			default:
				return nil, nil, daemon.NewError(daemon.ErrorUnknownCommand, "not implemented in test daemon: "+frame.Cmd)
			}
		},
	})
	ctx, cancel := context.WithCancel(context.Background())
	done := make(chan error, 1)
	go func() { done <- server.ListenAndServe(ctx) }()
	t.Cleanup(func() {
		cancel()
		select {
		case <-done:
		case <-time.After(2 * time.Second):
			t.Error("test daemon did not shut down")
		}
	})
	deadline := time.Now().Add(3 * time.Second)
	for time.Now().Before(deadline) {
		if conn, dialErr := dialUnix(path); dialErr == nil {
			_ = conn.Close()
			return path
		}
		time.Sleep(10 * time.Millisecond)
	}
	t.Fatal("test daemon socket never became ready")
	return path
}

// TestSnapshotRunsInjectionScanByDefault verifies the issue #28 integration:
// snapshot scans the page HTML and surfaces the detections as warnings[] in
// the unified envelope (kind/severity/ref/excerpt).
func TestSnapshotRunsInjectionScanByDefault(t *testing.T) {
	startSnapshotTestDaemon(t)
	command := newRootCommand()
	var output, errOutput bytes.Buffer
	command.SetOut(&output)
	command.SetErr(&errOutput)
	command.SetArgs([]string{"snapshot", "--session", "test", "--json"})
	if err := command.Execute(); err != nil {
		t.Fatal(err)
	}
	var envelope struct {
		Success  bool `json:"success"`
		Warnings []struct {
			Kind     string `json:"kind"`
			Severity string `json:"severity"`
			Ref      string `json:"ref"`
			Excerpt  string `json:"excerpt"`
		} `json:"warnings"`
	}
	if err := json.Unmarshal(output.Bytes(), &envelope); err != nil {
		t.Fatalf("output = %q: %v", output.String(), err)
	}
	if !envelope.Success {
		t.Fatalf("envelope = %+v, want success", envelope)
	}
	var kinds []string
	for _, warning := range envelope.Warnings {
		kinds = append(kinds, warning.Kind)
		if warning.Severity == "" || warning.Ref == "" || warning.Excerpt == "" {
			t.Errorf("warning lacks severity/ref/excerpt: %+v", warning)
		}
	}
	joined := strings.Join(kinds, ",")
	if !strings.Contains(joined, "imperative") || !strings.Contains(joined, "aria_mismatch") {
		t.Errorf("warnings = %v, want imperative and aria_mismatch detections", kinds)
	}
}

// TestSnapshotNoInjectionScanDisablesTheScan verifies --no-injection-scan:
// the scan is skipped and a warning is logged.
func TestSnapshotNoInjectionScanDisablesTheScan(t *testing.T) {
	startSnapshotTestDaemon(t)
	var logBuffer bytes.Buffer
	slog.SetDefault(slog.New(slog.NewTextHandler(&logBuffer, nil)))
	t.Cleanup(func() { slog.SetDefault(slog.New(slog.NewTextHandler(os.Stderr, nil))) })
	command := newRootCommand()
	var output, errOutput bytes.Buffer
	command.SetOut(&output)
	command.SetErr(&errOutput)
	command.SetArgs([]string{"snapshot", "--session", "test", "--json", "--no-injection-scan"})
	if err := command.Execute(); err != nil {
		t.Fatal(err)
	}
	var envelope struct {
		Success  bool `json:"success"`
		Warnings []struct {
			Kind string `json:"kind"`
		} `json:"warnings"`
	}
	if err := json.Unmarshal(output.Bytes(), &envelope); err != nil {
		t.Fatalf("output = %q: %v", output.String(), err)
	}
	for _, warning := range envelope.Warnings {
		if warning.Kind == "imperative" || warning.Kind == "aria_mismatch" {
			t.Errorf("scan ran despite --no-injection-scan: %+v", envelope.Warnings)
		}
	}
	if !strings.Contains(logBuffer.String(), "injection scan disabled") {
		t.Errorf("log = %q, want the disabled-scan log line", logBuffer.String())
	}
}

func dialUnix(path string) (interface{ Close() error }, error) {
	return net.Dial("unix", path)
}
