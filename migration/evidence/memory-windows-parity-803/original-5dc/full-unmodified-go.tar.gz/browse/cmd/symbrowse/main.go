package main

import (
	"context"
	"fmt"
	"io"
	"log/slog"
	"os"
	"runtime"

	"github.com/spf13/cobra"

	"github.com/danieljustus/symaira-browse/internal/config"
	"github.com/danieljustus/symaira-browse/internal/engine/doctor"
	"github.com/danieljustus/symaira-browse/internal/exitcodes"
	"github.com/danieljustus/symaira-browse/internal/logging"
	"github.com/danieljustus/symaira-browse/internal/output"
	"github.com/danieljustus/symaira-browse/internal/policy"
	symversion "github.com/danieljustus/symaira-browse/internal/version"
)

const (
	groupIDCore    = "core"
	groupIDNav     = "nav"
	groupIDState   = "state"
	groupIDNetwork = "network"
	groupIDDebug   = "debug"
	groupIDFlows   = "flows"
)

// version is replaced at build time by the Makefile's VERSION value.
var version = "dev"

func newRootCommand() *cobra.Command {
	root := &cobra.Command{
		Use:           "symbrowse",
		Short:         "Agent-operable browser automation over Chrome DevTools Protocol",
		Long:          "symbrowse is the standalone command-line entrypoint for Symaira Browse.",
		Version:       version,
		SilenceUsage:  true,
		SilenceErrors: true,
	}
	root.AddGroup(
		&cobra.Group{ID: groupIDCore, Title: "Core Commands:"},
		&cobra.Group{ID: groupIDNav, Title: "Navigation Commands:"},
		&cobra.Group{ID: groupIDState, Title: "State Commands:"},
		&cobra.Group{ID: groupIDNetwork, Title: "Network Commands:"},
		&cobra.Group{ID: groupIDDebug, Title: "Debug Commands:"},
		&cobra.Group{ID: groupIDFlows, Title: "Flows Commands:"},
	)
	// The global --json flag switches every command to the unified
	// machine-readable output envelope (docs/errors.md, internal/output).
	// --output extends it with text|json|yaml; --json stays the shorthand
	// for --output json with unchanged behaviour (issue #254).
	root.PersistentFlags().Bool("json", false, "print the unified machine-readable output envelope (shorthand for --output json)")
	root.PersistentFlags().String("output", "text", "output format: text, json or yaml (--json is shorthand for --output json)")
	root.PersistentPreRunE = func(cmd *cobra.Command, _ []string) error {
		if _, err := resolveOutputFormat(cmd); err != nil {
			return err
		}
		return nil
	}
	root.AddCommand(newVersionCommand())
	root.AddCommand(newConfigCommand())
	root.AddCommand(newDoctorCommand())
	root.AddCommand(newDaemonCommand())
	root.AddCommand(newCompatSidecarCommand())
	root.AddCommand(newSessionCommand())
	root.AddCommand(newMCPCommand())
	for _, command := range newNavigationCommands() {
		root.AddCommand(command)
	}
	root.AddCommand(newSnapshotCommand())
	root.AddCommand(newScreenshotCommand())
	root.AddCommand(newReadCommand())
	root.AddCommand(newBatchCommand())
	root.AddCommand(newFindCommand())
	root.AddCommand(newConsoleCommand())
	root.AddCommand(newCacheCommand())
	root.AddCommand(newErrorsCommand())
	root.AddCommand(newEvalCommand())
	root.AddCommand(newNetworkCommand())
	root.AddCommand(newUploadCommand())
	root.AddCommand(newDownloadsCommand())
	for _, command := range newInspectionCommands() {
		root.AddCommand(command)
	}
	for _, command := range newInteractionCommands() {
		root.AddCommand(command)
	}
	for _, command := range newStateCommands() {
		root.AddCommand(command)
	}
	root.AddCommand(newStateCommand())
	root.AddCommand(newAuthCommand())
	root.AddCommand(newProfilesCommand())
	root.AddCommand(newSetCommand())
	root.AddCommand(newJournalCommand())
	root.AddCommand(newPolicyCommand())
	root.AddCommand(newTraceCommand())
	root.AddCommand(newOOBCommand())
	root.AddCommand(newHandoffCommand())
	root.AddCommand(newWatchCommand())
	root.AddCommand(newFlowCommand())
	root.AddCommand(newTabCommand())
	root.AddCommand(newFrameCommand())
	root.AddCommand(newDialogCommand())
	root.AddCommand(newA11yCommand())
	root.AddCommand(newDiffCommand())
	root.AddCommand(newUpgradeCommand())
	return root
}

func newVersionCommand() *cobra.Command {
	command := &cobra.Command{
		GroupID: groupIDDebug,
		Use:     "version",
		Short:   "Print the symbrowse version",
		Args:    cobra.NoArgs,
		RunE: func(cmd *cobra.Command, _ []string) error {
			// version --json is the versionkit handshake payload
			// ({tool, version, schema_version}) consumed by GUI clients
			// (symaira-appkit SymairaToolKit) and Hub/Brain. It
			// deliberately bypasses the unified output envelope: the
			// payload IS the contract (issue #32).
			info := symversion.Info(version)
			if structuredOutput(cmd) {
				return info.Write(cmd.OutOrStdout())
			}
			_, err := fmt.Fprintln(cmd.OutOrStdout(), info.String())
			return err
		},
	}
	return command
}

func newConfigCommand() *cobra.Command {
	var logLevel, logFormat, configDir, cacheDir, stateDir, executablePath string

	show := &cobra.Command{
		Use:   "show",
		Short: "Show the effective configuration and its source",
		Args:  cobra.NoArgs,
		RunE: func(cmd *cobra.Command, _ []string) error {
			overrides := config.FlagOverrides{}
			if cmd.Flags().Changed("log-level") {
				overrides.LogLevel = &logLevel
			}
			if cmd.Flags().Changed("log-format") {
				overrides.LogFormat = &logFormat
			}
			if cmd.Flags().Changed("config-dir") {
				overrides.ConfigDir = &configDir
			}
			if cmd.Flags().Changed("cache-dir") {
				overrides.CacheDir = &cacheDir
			}
			if cmd.Flags().Changed("state-dir") {
				overrides.StateDir = &stateDir
			}
			if cmd.Flags().Changed("executable-path") {
				overrides.ExecutablePath = &executablePath
			}

			result, err := config.LoadWithOverrides(overrides)
			if err != nil {
				return err
			}
			slog.Debug("configuration loaded", "command", "config show")
			if structuredOutput(cmd) {
				return writeEnvelope(cmd, output.OK(config.ShowOutputFor(result), nil))
			}
			return config.WriteShow(cmd.OutOrStdout(), result, false)
		},
	}
	show.Flags().StringVar(&logLevel, "log-level", "", "override the configured log level")
	show.Flags().StringVar(&logFormat, "log-format", "", "override the configured log format")
	show.Flags().StringVar(&configDir, "config-dir", "", "override the config directory")
	show.Flags().StringVar(&cacheDir, "cache-dir", "", "override the cache directory")
	show.Flags().StringVar(&stateDir, "state-dir", "", "override the state directory")
	show.Flags().StringVar(&executablePath, "executable-path", "", "override the browser executable path")

	command := &cobra.Command{
		GroupID: groupIDDebug,
		Use:     "config",
		Short:   "Inspect symbrowse configuration",
	}
	command.AddCommand(show)
	return command
}

func newDoctorCommand() *cobra.Command {
	var fix bool
	command := &cobra.Command{
		GroupID: groupIDDebug,
		Use:     "doctor",
		Short:   "Check browser discovery and local runtime prerequisites",
		Args:    cobra.NoArgs,
		RunE: func(cmd *cobra.Command, _ []string) error {
			cfg, err := config.Load()
			if err != nil {
				return err
			}
			options := doctor.Options{
				ExecutablePath: cfg.ExecutablePath,
				Paths: doctor.Paths{
					ConfigDir: cfg.ConfigDir,
					CacheDir:  cfg.CacheDir,
					StateDir:  cfg.StateDir,
				},
			}
			report := doctor.Run(options)
			report.Checks = append(report.Checks, guardDoctorCheck())
			if fix {
				report.Fixes = doctor.FixInstructions(runtime.GOOS, options)
			}
			if structuredOutput(cmd) {
				if err := writeEnvelope(cmd, output.OK(report, nil)); err != nil {
					return err
				}
			} else if err := doctor.Write(cmd.OutOrStdout(), report, false); err != nil {
				return err
			}
			if report.HasFailure("chrome") {
				message := doctorFailureMessage(report, "chrome")
				return exitcodes.Wrap(nil, exitcodes.ExitNotFound, exitcodes.KindNotFound, message)
			}
			if report.HasFailures() {
				return exitcodes.Wrap(nil, exitcodes.ExitGeneric, exitcodes.KindInternal, "one or more doctor checks failed")
			}
			return nil
		},
	}
	command.Flags().BoolVar(&fix, "fix", false, "print non-mutating, copyable remediation guidance")
	return command
}

func doctorFailureMessage(report doctor.Report, name string) string {
	for _, check := range report.Checks {
		if check.Name == name && check.Status == doctor.StatusFail {
			return check.Message
		}
	}
	return "doctor check failed"
}

// guardDoctorCheck reports the external risk decider (issue #299): which
// binary was found, at which path, or that none was. A missing decider is a
// warning, never a failure — the daemon falls back to the built-in policy
// and logs that fallback at startup.
func guardDoctorCheck() doctor.Check {
	guard := policy.DetectGuard()
	if guard != nil && guard.Active() {
		return doctor.Check{
			Name:    "guard",
			Status:  doctor.StatusPass,
			Message: fmt.Sprintf("risk decisions delegated to %s", guard.Command()),
			Details: map[string]string{
				"binary":  policy.GuardBinaryName,
				"path":    guard.Executable,
				"command": guard.Command(),
			},
		}
	}
	return doctor.Check{
		Name:    "guard",
		Status:  doctor.StatusWarn,
		Message: fmt.Sprintf("no external risk decider found (%s not on PATH and SYMBROWSE_SYMGUARD unset); risk decisions fall back to the built-in policy", policy.GuardBinaryName),
		Details: map[string]string{"override": policy.GuardEnvName},
	}
}

func main() {
	logging.Init()
	// Optional async update hint (opt-in via SYMBROWSE_CHECK_UPDATES). The
	// hint goes to stderr only, so stdout stays clean for JSON/MCP frames.
	checkUpdatesAsync(context.Background())
	os.Exit(runCLI(os.Args[1:], os.Stdout, os.Stderr))
}

// runCLI executes the root command and returns the process exit code. In JSON
// mode failures are printed as the unified machine-readable envelope on
// stdout; otherwise the human-readable error goes to stderr.
func runCLI(args []string, stdout, stderr io.Writer) int {
	root := newRootCommand()
	root.SetArgs(args)
	root.SetOut(stdout)
	root.SetErr(stderr)
	if err := normalizeCommandError(root.Execute()); err != nil {
		if structuredOutput(root) {
			_ = writeErrorEnvelope(root, err)
		} else {
			_, _ = fmt.Fprintln(stderr, exitcodes.FormatCLIError(err))
		}
		return int(exitcodes.ExitCodeFromError(err))
	}
	return int(exitcodes.ExitOK)
}
