package policy

import (
	"context"
	"encoding/json"
	"os"
	"path/filepath"
	"runtime"
	"strings"
	"testing"
	"time"
)

// fakeGuard writes an executable decider script into a temp dir and returns
// its path. The script prints verdict (or fails when failWith is set).
func fakeGuard(t *testing.T, verdict string, failWith string) string {
	t.Helper()
	dir := t.TempDir()
	path := filepath.Join(dir, "symbrain")
	script := "#!/bin/sh\n"
	if failWith != "" {
		script += "echo '" + failWith + "' >&2\nexit 3\n"
	} else {
		script += "printf '%s\\n' '" + verdict + "'\n"
	}
	if err := os.WriteFile(path, []byte(script), 0o755); err != nil {
		t.Fatal(err)
	}
	return path
}

func TestDetectGuardFromPath(t *testing.T) {
	if runtime.GOOS == "windows" {
		t.Skip("fake unix executable under test; POSIX exec semantics are covered on linux/darwin CI")
	}

	path := fakeGuard(t, `{"decision":"allow"}`, "")
	t.Setenv(GuardEnvName, "")
	t.Setenv("PATH", filepath.Dir(path)+string(os.PathListSeparator)+os.Getenv("PATH"))
	guard := DetectGuard()
	if guard == nil || !guard.Active() {
		t.Fatal("guard not detected on PATH")
	}
	if guard.Executable != path {
		t.Fatalf("executable = %s, want %s", guard.Executable, path)
	}
	if len(guard.Subcommand) != 1 || guard.Subcommand[0] != "guard" {
		t.Fatalf("subcommand = %v, want [guard] (symbrain guard decide)", guard.Subcommand)
	}
	if want := path + " guard decide"; guard.Command() != want {
		t.Fatalf("Command() = %q, want %q", guard.Command(), want)
	}
}

func TestDetectGuardEnvOverrideIsBareDecide(t *testing.T) {
	if runtime.GOOS == "windows" {
		t.Skip("fake unix executable under test; POSIX exec semantics are covered on linux/darwin CI")
	}

	path := fakeGuard(t, `{"decision":"allow"}`, "")
	t.Setenv(GuardEnvName, path)
	guard := DetectGuard()
	if guard == nil || guard.Executable != path {
		t.Fatalf("env override not honored: %+v", guard)
	}
	if len(guard.Subcommand) != 0 {
		t.Fatalf("override must call the binary directly with decide, subcommand = %v", guard.Subcommand)
	}
	if want := path + " decide"; guard.Command() != want {
		t.Fatalf("Command() = %q, want %q", guard.Command(), want)
	}
}

func TestGuardDecideCallsSymbrainSubcommand(t *testing.T) {
	if runtime.GOOS == "windows" {
		t.Skip("fake unix executable under test; POSIX exec semantics are covered on linux/darwin CI")
	}

	dir := t.TempDir()
	path := filepath.Join(dir, "symbrain")
	argsPath := filepath.Join(dir, "args.txt")
	// The fake symbrain writes its argv to a file and answers allow.
	script := "#!/bin/sh\necho \"$*\" > \"$ARGS_FILE\"\nprintf '%s\\n' '{\"decision\":\"allow\",\"reason\":\"ok\"}'\n"
	if err := os.WriteFile(path, []byte(script), 0o755); err != nil {
		t.Fatal(err)
	}
	guard := &Guard{Executable: path, Subcommand: []string{"guard"}, Timeout: 2 * time.Second}
	t.Setenv("ARGS_FILE", argsPath)
	outcome, err := guard.Decide(context.Background(), GuardInput{Command: "open", Class: ClassNavigate, Domain: "example.com"})
	if err != nil {
		t.Fatal(err)
	}
	if outcome.Decision != Allow {
		t.Fatalf("decision = %s, want allow", outcome.Decision)
	}
	raw, err := os.ReadFile(argsPath)
	if err != nil {
		t.Fatal(err)
	}
	if got := strings.TrimSpace(string(raw)); got != "guard decide" {
		t.Fatalf("argv = %q, want %q", got, "guard decide")
	}
}

func TestDetectGuardEnvOverrideAndDisable(t *testing.T) {
	path := fakeGuard(t, `{"decision":"allow"}`, "")
	t.Setenv(GuardEnvName, path)
	if guard := DetectGuard(); guard == nil || guard.Executable != path {
		t.Fatalf("env override not honored: %+v", guard)
	}
	for _, disable := range []string{"0", "none", "off", "false"} {
		t.Setenv(GuardEnvName, disable)
		if guard := DetectGuard(); guard != nil {
			t.Fatalf("disable value %q still detected a guard", disable)
		}
	}
	t.Setenv(GuardEnvName, "")
	t.Setenv("PATH", "/nonexistent")
	if guard := DetectGuard(); guard != nil {
		t.Fatalf("guard detected without binary: %+v", guard)
	}
}

func TestGuardDecide(t *testing.T) {
	if runtime.GOOS == "windows" {
		t.Skip("fake unix executable under test; POSIX exec semantics are covered on linux/darwin CI")
	}

	path := fakeGuard(t, `{"decision":"deny","reason":"test guard says no"}`, "")
	guard := &Guard{Executable: path, Timeout: 2 * time.Second}
	outcome, err := guard.Decide(context.Background(), GuardInput{Command: "eval", Class: ClassEval, Domain: "example.com"})
	if err != nil {
		t.Fatal(err)
	}
	if outcome.Decision != Deny || outcome.Reason != "test guard says no" {
		t.Fatalf("outcome = %+v", outcome)
	}
}

func TestGuardRiskLevelMapping(t *testing.T) {
	tests := []struct {
		class RiskClass
		want  string
	}{
		{ClassRead, "low"},
		{ClassNavigate, "medium"},
		{ClassInteract, "medium"},
		{ClassDownload, "medium"},
		{ClassSubmit, "high"},
		{ClassUpload, "high"},
		{ClassNetworkMock, "high"},
		{ClassEval, "critical"},
		{ClassCredential, "critical"},
	}
	for _, tt := range tests {
		got, err := guardRiskLevel(tt.class)
		if err != nil {
			t.Fatalf("guardRiskLevel(%s): %v", tt.class, err)
		}
		if got != tt.want {
			t.Fatalf("guardRiskLevel(%s) = %q, want %q", tt.class, got, tt.want)
		}
	}
	if _, err := guardRiskLevel(RiskClass("unknown")); err == nil {
		t.Fatal("guardRiskLevel(unknown) should fail")
	}
}

// TestGuardDecideSendsStdinJSON verifies the wire contract against a fake
// guard that echoes the stdin request back as its reason: the request must
// be one JSON object with the mapped risk_class field, sent via stdin, not
// as CLI flags.
func TestGuardDecideSendsStdinJSON(t *testing.T) {
	if runtime.GOOS == "windows" {
		t.Skip("fake unix executable under test; POSIX exec semantics are covered on linux/darwin CI")
	}

	dir := t.TempDir()
	path := filepath.Join(dir, "symguard")
	sentPath := filepath.Join(dir, "sent.json")
	// The fake guard writes its stdin to a file (no JSON escaping needed in
	// shell) and answers a valid allow verdict.
	script := "#!/bin/sh\ncat > \"$SENT_FILE\"\nprintf '%s\\n' '{\"decision\":\"allow\",\"reason\":\"ok\"}'\n"
	if err := os.WriteFile(path, []byte(script), 0o755); err != nil {
		t.Fatal(err)
	}
	guard := &Guard{Executable: path, Timeout: 2 * time.Second}
	t.Setenv("SENT_FILE", sentPath)
	outcome, err := guard.Decide(context.Background(), GuardInput{
		Command:  "open",
		Class:    ClassNavigate,
		Domain:   "example.com",
		Warnings: []string{"warn-1"},
	})
	if err != nil {
		t.Fatal(err)
	}
	if outcome.Decision != Allow {
		t.Fatalf("decision = %s, want allow", outcome.Decision)
	}
	raw, err := os.ReadFile(sentPath)
	if err != nil {
		t.Fatal(err)
	}
	var sent struct {
		Command   string   `json:"command"`
		RiskClass string   `json:"risk_class"`
		Domain    string   `json:"domain"`
		Warnings  []string `json:"warnings"`
	}
	if err := json.Unmarshal(raw, &sent); err != nil {
		t.Fatalf("stdin payload not valid JSON: %v (payload=%q)", err, string(raw))
	}
	if sent.Command != "open" {
		t.Fatalf("command = %q, want open", sent.Command)
	}
	if sent.RiskClass != "medium" {
		t.Fatalf("risk_class = %q, want medium (mapped from navigate)", sent.RiskClass)
	}
	if sent.Domain != "example.com" {
		t.Fatalf("domain = %q, want example.com", sent.Domain)
	}
	if len(sent.Warnings) != 1 || sent.Warnings[0] != "warn-1" {
		t.Fatalf("warnings = %v, want [warn-1]", sent.Warnings)
	}
}

func TestGuardDecideFailuresDeny(t *testing.T) {
	if runtime.GOOS == "windows" {
		t.Skip("fake unix executable under test; POSIX exec semantics are covered on linux/darwin CI")
	}

	// Non-zero exit with a stderr message.
	guard := &Guard{Executable: fakeGuard(t, "", "guard exploded"), Timeout: 2 * time.Second}
	if _, err := guard.Decide(context.Background(), GuardInput{Command: "eval", Class: ClassEval}); err == nil {
		t.Fatal("expected an error for a failing guard")
	} else if !strings.Contains(err.Error(), "guard exploded") {
		t.Fatalf("error = %v, want stderr message", err)
	}
	// Unparseable verdict.
	guard = &Guard{Executable: fakeGuard(t, "not json", ""), Timeout: 2 * time.Second}
	if _, err := guard.Decide(context.Background(), GuardInput{Command: "eval", Class: ClassEval}); err == nil {
		t.Fatal("expected an error for an unparseable verdict")
	}
	// Invalid decision value.
	guard = &Guard{Executable: fakeGuard(t, `{"decision":"maybe"}`, ""), Timeout: 2 * time.Second}
	if _, err := guard.Decide(context.Background(), GuardInput{Command: "eval", Class: ClassEval}); err == nil {
		t.Fatal("expected an error for an invalid decision value")
	}
	// Missing executable.
	guard = &Guard{Executable: filepath.Join(t.TempDir(), "missing"), Timeout: 2 * time.Second}
	if _, err := guard.Decide(context.Background(), GuardInput{Command: "eval", Class: ClassEval}); err == nil {
		t.Fatal("expected an error for a missing executable")
	}
	// Inactive guard.
	guard = &Guard{}
	if _, err := guard.Decide(context.Background(), GuardInput{Command: "eval", Class: ClassEval}); err == nil {
		t.Fatal("expected an error for an inactive guard")
	}
}
