package daemon

import (
	"context"
	"encoding/json"
	"fmt"
	"log/slog"
	"sync"
	"time"

	"github.com/danieljustus/symaira-browse/internal/budget"
	"github.com/danieljustus/symaira-browse/internal/fetch/agentdom"
	"github.com/danieljustus/symaira-browse/internal/fetch/archive"
	"github.com/danieljustus/symaira-browse/internal/fetch/fetch"
	"github.com/danieljustus/symaira-browse/internal/fetch/pipeline"
	"github.com/danieljustus/symaira-browse/internal/fetch/robots"
	"github.com/danieljustus/symaira-browse/internal/policy"
)

// FetchRuntime exposes the absorbed SymFetch fetch pipeline through the
// daemon protocol without requiring a browser session. It serves the
// fetch.url, fetch.batch and wayback.snapshots compatibility frames (issue
// #258): the three SymFetch MCP contracts that Hermes relied on before the
// archived symfetch runtime was retired. All three work on plain HTTP and
// never launch a browser.
type FetchRuntime struct {
	mu                   sync.Mutex
	client               fetch.Client
	allowlist            *policy.Allowlist
	allowPrivate         bool
	robots               bool
	userAgent            string
	cacheDir             string
	cacheTTL             time.Duration
	outputCache          *budget.Cache
	noCache              bool
	contentBoundaries    bool
	disableInjectionScan bool
	injectionPatterns    string
	injectionMu          sync.Mutex
	injectionCache       map[string][]Warning
}

// FetchRuntimeOptions configures the fetch runtime.
type FetchRuntimeOptions struct {
	// AllowedDomains restricts every fetch target and redirect to the same
	// host allowlist used by browser navigation.
	AllowedDomains []string
	// AllowPrivate relaxes the SSRF guard for plain HTTP fetches
	// (mirrors the daemon --allow-private opt-in).
	AllowPrivate bool
	// Robots enables robots.txt compliance checks before fetching.
	Robots bool
	// UserAgent is used for the robots check and honest fetches.
	UserAgent string
	// CacheDir and CacheTTL configure the response cache (empty disables
	// the shared cache instance; the pipeline falls back to its default).
	CacheDir string
	CacheTTL time.Duration
	// OutputCacheDir is the unified cache root for budgeted and full-text
	// retrieval handles. It normally points at <cache-dir>/out.
	OutputCacheDir string
	// NoCache disables the fetch response cache while leaving explicit output
	// handles available for store_full_text retrieval.
	NoCache bool
	// DisableInjectionScan disables the default bounded prompt-injection scan.
	DisableInjectionScan bool
	// InjectionPatterns replaces the embedded scanner patterns when set.
	InjectionPatterns string
	// ContentBoundaries enables unforgeable content boundaries by default.
	// The MCP launcher enables this for its daemon.
	ContentBoundaries bool
}

// NewFetchRuntime creates the runtime with an honest (CGO-free) fetch
// client. The honest profile keeps the binary free of the browser-impersonation
// dependency tree while preserving the stable response semantics clients
// rely on.
func NewFetchRuntime(options FetchRuntimeOptions) (*FetchRuntime, error) {
	client, err := fetch.New(fetch.ProfileHonest)
	if err != nil {
		return nil, fmt.Errorf("create fetch client: %w", err)
	}
	allowlist, err := policy.ParseAllowlist(options.AllowedDomains)
	if err != nil {
		_ = client.Close()
		return nil, fmt.Errorf("parse fetch domain allowlist: %w", err)
	}
	if options.UserAgent == "" {
		options.UserAgent = "symbrowse/1.0"
	}
	var outputCache *budget.Cache
	if options.OutputCacheDir != "" {
		outputCache = budget.NewCache(options.OutputCacheDir, options.CacheTTL)
	}
	return &FetchRuntime{
		client:               client,
		allowlist:            allowlist,
		allowPrivate:         options.AllowPrivate,
		robots:               options.Robots,
		userAgent:            options.UserAgent,
		cacheDir:             options.CacheDir,
		cacheTTL:             options.CacheTTL,
		outputCache:          outputCache,
		noCache:              options.NoCache,
		contentBoundaries:    options.ContentBoundaries,
		disableInjectionScan: options.DisableInjectionScan,
		injectionPatterns:    options.InjectionPatterns,
		injectionCache:       make(map[string][]Warning),
	}, nil
}

// Close releases the underlying fetch client.
func (r *FetchRuntime) Close() error {
	r.mu.Lock()
	defer r.mu.Unlock()
	if r.client == nil {
		return nil
	}
	return r.client.Close()
}

func (r *FetchRuntime) safetyOptions(noScan bool, patterns string, boundaries *bool, command string) (bool, string, bool) {
	scan := !r.disableInjectionScan && !noScan
	if !scan {
		slog.Warn("injection scan disabled for fetch output", "command", command)
	}
	if patterns == "" {
		patterns = r.injectionPatterns
	}
	withBoundaries := r.contentBoundaries
	if boundaries != nil {
		withBoundaries = *boundaries
	}
	return scan, patterns, withBoundaries
}

func (r *FetchRuntime) scanFetchedHTML(source []byte, fallback, patterns string, enabled bool) []Warning {
	if !enabled {
		return nil
	}
	pageHTML := string(source)
	if pageHTML == "" {
		pageHTML = fallback
	}
	cacheInput := fallback
	if cacheInput == "" {
		cacheInput = pageHTML
	}
	key := warningCacheKey(cacheInput, patterns)
	r.injectionMu.Lock()
	if cached, ok := r.injectionCache[key]; ok {
		warnings := cloneWarnings(cached)
		r.injectionMu.Unlock()
		return warnings
	}
	r.injectionMu.Unlock()

	warnings := scanFetchInjectionHTML(pageHTML, patterns)
	r.injectionMu.Lock()
	if len(r.injectionCache) >= maxInjectionScanEntries {
		r.injectionCache = make(map[string][]Warning)
	}
	r.injectionCache[key] = cloneWarnings(warnings)
	r.injectionMu.Unlock()
	return warnings
}

// Handle executes one fetch frame.
func (r *FetchRuntime) Handle(ctx context.Context, frame Frame) (any, []Warning, error) {
	switch frame.Cmd {
	case "fetch.url":
		return r.handleFetchURL(ctx, frame)
	case "fetch.batch":
		return r.handleFetchBatch(ctx, frame)
	case "wayback.snapshots":
		return r.handleWaybackSnapshots(ctx, frame)
	default:
		return nil, nil, NewError(ErrorUnknownCommand, fmt.Sprintf("command %q is not implemented by the fetch runtime", frame.Cmd))
	}
}

// fetchURLArgs is the fetch.url frame payload. Field names match the
// SymFetch fetch_url contract so existing clients keep working (issue #258).
type fetchURLArgs struct {
	URL               string `json:"url"`
	Format            string `json:"format"` // markdown (default), json, text
	MaxChars          int    `json:"max_chars"`
	CharLimit         int    `json:"char_limit"`
	CSSSelector       string `json:"css_selector"`
	Frontmatter       bool   `json:"frontmatter"`
	IncludeLinks      bool   `json:"include_links"`
	Query             string `json:"query"`
	Raw               bool   `json:"raw"`
	SchemaPath        string `json:"schema_path"`
	StoreFullText     bool   `json:"store_full_text"`
	WaybackTimestamp  string `json:"wayback_timestamp"`
	WaybackFallback   bool   `json:"wayback_fallback"`
	TopK              int    `json:"top_k"`
	NoCache           *bool  `json:"no_cache"`
	RetrievalSurface  string `json:"retrieval_surface"`
	NoInjectionScan   bool   `json:"no_injection_scan"`
	InjectionPatterns string `json:"injection_patterns"`
	ContentBoundaries *bool  `json:"content_boundaries"`
}

func (r *FetchRuntime) handleFetchURL(ctx context.Context, frame Frame) (any, []Warning, error) {
	var args fetchURLArgs
	if err := decodeOptionalArgs(frame, &args); err != nil {
		return nil, nil, err
	}
	if args.URL == "" {
		return nil, nil, NewError(ErrorMalformedRequest, "fetch.url requires a url argument")
	}

	format, err := pipeline.ParseFormat(args.Format)
	if err != nil {
		return nil, nil, NewError(ErrorMalformedRequest, err.Error())
	}
	scanInjection, patternsFile, withBoundaries := r.safetyOptions(args.NoInjectionScan, args.InjectionPatterns, args.ContentBoundaries, "fetch.url")

	if args.Raw {
		// The raw contract returns the decoded response body without any
		// pipeline processing (SymFetch fetch_url raw=true).
		resp, err := pipeline.RunRaw(ctx, r.client, args.URL, fetch.Request{
			AllowPrivate: r.allowPrivate,
			Allowlist:    r.allowlist,
			UserAgent:    r.userAgent,
		})
		if err != nil {
			return nil, nil, fetchError(err)
		}
		response := map[string]any{
			"url":          args.URL,
			"final_url":    resp.FinalURL,
			"status":       resp.StatusCode,
			"content":      string(resp.Body),
			"content_type": resp.ContentType,
		}
		if withBoundaries {
			if err := addFetchBoundary(response, pipeline.FormatText, resp.FinalURL, true); err != nil {
				return nil, nil, err
			}
		}
		warnings := r.scanFetchedHTML(resp.Body, string(resp.Body), patternsFile, scanInjection)
		return response, warnings, nil
	}

	result, err := pipeline.Run(ctx, r.client, pipeline.StaticEngine{}, args.URL, r.pipelineOptions(args.pipelineFields(), format))
	if err != nil {
		return nil, nil, fetchError(err)
	}
	warnings := r.scanFetchedHTML(result.SourceHTML, result.Output, patternsFile, scanInjection)

	switch format {
	case pipeline.FormatJSON:
		// The SymFetch fetch_url json schema (url, final_url, title, lang,
		// content, interactive) plus the escalate hint the pipeline attached
		// to the document, and the response metadata every format reports.
		response := withResponseMeta(documentMap(result.Doc), result.Meta)
		if withBoundaries {
			if err := addFetchBoundary(response, format, result.Meta.FinalURL, false); err != nil {
				return nil, nil, err
			}
		}
		addFetchCacheHint(response, result.Output, args.RetrievalSurface)
		return response, warnings, nil
	case pipeline.FormatText:
		response := withResponseMeta(withEscalation(map[string]any{
			"url":     result.Doc.URL,
			"content": result.Output,
		}, result.Meta), result.Meta)
		if withBoundaries {
			if err := addFetchBoundary(response, format, result.Meta.FinalURL, false); err != nil {
				return nil, nil, err
			}
		}
		addFetchCacheHint(response, result.Output, args.RetrievalSurface)
		return response, warnings, nil
	default:
		response := withResponseMeta(withEscalation(map[string]any{
			"url":      result.Doc.URL,
			"title":    result.Doc.Title,
			"markdown": result.Output,
		}, result.Meta), result.Meta)
		if withBoundaries {
			if err := addFetchBoundary(response, format, result.Meta.FinalURL, false); err != nil {
				return nil, nil, err
			}
		}
		addFetchCacheHint(response, result.Output, args.RetrievalSurface)
		return response, warnings, nil
	}
}

// responseMeta is the metadata every fetch response carries alongside the
// content: enough for an agent to tell a complete page from a partial one
// without parsing the rendered body. The field names match the ones
// symbrowse read reports (docs/output-schema.md).
type responseMeta struct {
	StatusCode int    `json:"status_code"`
	FinalURL   string `json:"final_url,omitempty"`
	Lang       string `json:"lang,omitempty"`
	CharCount  int    `json:"char_count"`
	EstTokens  int    `json:"est_tokens"`
	Truncated  bool   `json:"truncated"`
	// LikelyClientRendered marks a page whose visible content a plain HTTP
	// fetch probably could not retrieve in full.
	LikelyClientRendered bool `json:"likely_client_rendered"`
}

// withResponseMeta attaches the response metadata to a frame response.
func withResponseMeta(response map[string]any, meta agentdom.Meta) map[string]any {
	response["meta"] = responseMeta{
		StatusCode:           meta.StatusCode,
		FinalURL:             meta.FinalURL,
		Lang:                 meta.Lang,
		CharCount:            meta.CharCount,
		EstTokens:            meta.EstTokens,
		Truncated:            meta.Truncated,
		LikelyClientRendered: meta.LikelyClientRendered,
	}
	return response
}

// documentMap renders the agentdom document as a plain map so the JSON
// response can carry the shared response metadata beside the document's own
// fields without changing the document type itself.
func documentMap(doc *agentdom.Document) map[string]any {
	raw, err := json.Marshal(doc)
	if err != nil {
		slog.Debug("marshal fetch document", "error", err)
		return map[string]any{}
	}
	var fields map[string]any
	if err := json.Unmarshal(raw, &fields); err != nil {
		slog.Debug("decode fetch document", "error", err)
		return map[string]any{}
	}
	return fields
}

// withEscalation attaches the tier-0 -> tier-1 hint to a frame response as a
// structured sibling, so an agent does not have to parse it out of the
// rendered text. Responses for pages a plain fetch retrieved in full are
// unchanged (docs/tiers.md).
func withEscalation(response map[string]any, meta agentdom.Meta) map[string]any {
	if meta.Escalate != nil {
		response["escalate"] = meta.Escalate
	}
	return response
}

// fetchBatchArgs is the fetch.batch frame payload (SymFetch fetch_batch
// contract: urls up to 20, optional concurrency, per-page format/budget).
type fetchBatchArgs struct {
	URLs              []string `json:"urls"`
	Format            string   `json:"format"`
	MaxChars          int      `json:"max_chars"`
	CharLimit         int      `json:"char_limit"`
	Concurrency       int      `json:"concurrency"`
	StoreFullText     bool     `json:"store_full_text"`
	Frontmatter       bool     `json:"frontmatter"`
	IncludeLinks      bool     `json:"include_links"`
	NoInjectionScan   bool     `json:"no_injection_scan"`
	NoCache           *bool    `json:"no_cache"`
	InjectionPatterns string   `json:"injection_patterns"`
	ContentBoundaries *bool    `json:"content_boundaries"`
	RetrievalSurface  string   `json:"retrieval_surface"`
}

func (r *FetchRuntime) handleFetchBatch(ctx context.Context, frame Frame) (any, []Warning, error) {
	var args fetchBatchArgs
	if err := decodeOptionalArgs(frame, &args); err != nil {
		return nil, nil, err
	}
	if len(args.URLs) == 0 {
		return nil, nil, NewError(ErrorMalformedRequest, "fetch.batch requires a urls array")
	}
	if len(args.URLs) > 20 {
		return nil, nil, NewError(ErrorMalformedRequest, "fetch.batch supports at most 20 urls")
	}

	format, err := pipeline.ParseFormat(args.Format)
	if err != nil {
		return nil, nil, NewError(ErrorMalformedRequest, err.Error())
	}
	scanInjection, patternsFile, withBoundaries := r.safetyOptions(args.NoInjectionScan, args.InjectionPatterns, args.ContentBoundaries, "fetch.batch")

	results := make([]any, 0, len(args.URLs))
	var mu sync.Mutex
	var wg sync.WaitGroup
	sem := make(chan struct{}, batchConcurrency(args.Concurrency))

	for _, url := range args.URLs {
		wg.Add(1)
		sem <- struct{}{}
		go func(target string) {
			defer wg.Done()
			defer func() { <-sem }()
			entry := r.fetchBatchEntry(ctx, target, args, format, scanInjection, patternsFile, withBoundaries)
			mu.Lock()
			results = append(results, entry)
			mu.Unlock()
		}(url)
	}
	wg.Wait()

	// Preserve input order (SymFetch contract).
	ordered := make([]any, len(args.URLs))
	index := map[string]int{}
	for i, url := range args.URLs {
		index[url] = i
	}
	for _, entry := range results {
		if m, ok := entry.(map[string]any); ok {
			if u, ok := m["url"].(string); ok {
				if i, ok := index[u]; ok {
					ordered[i] = entry
				}
			}
		}
	}
	for i, entry := range ordered {
		if entry == nil {
			ordered[i] = map[string]any{"url": args.URLs[i], "ok": false, "error": "fetch failed"}
		}
	}
	return ordered, nil, nil
}

func (r *FetchRuntime) fetchBatchEntry(ctx context.Context, target string, args fetchBatchArgs, format pipeline.Format, scanInjection bool, patternsFile string, withBoundaries bool) map[string]any {
	result, err := pipeline.Run(ctx, r.client, pipeline.StaticEngine{}, target, r.pipelineOptions(args.pipelineFields(), format))
	if err != nil {
		entryErr := fetchError(err)
		entry := map[string]any{
			"url":       target,
			"ok":        false,
			"error":     entryErr.Message,
			"code":      entryErr.Code,
			"retryable": entryErr.Retryable != nil && *entryErr.Retryable,
		}
		if entryErr.Details != nil {
			entry["details"] = entryErr.Details
		}
		return entry
	}
	content := result.Output
	switch format {
	case pipeline.FormatJSON:
		content = string(mustJSON(result.Doc))
	}
	response := withResponseMeta(withEscalation(map[string]any{"url": target, "ok": true, "content": content}, result.Meta), result.Meta)
	warnings := r.scanFetchedHTML(result.SourceHTML, content, patternsFile, scanInjection)
	if len(warnings) > 0 {
		response["warnings"] = warnings
	}
	if withBoundaries {
		if err := addFetchBoundary(response, format, result.Meta.FinalURL, false); err != nil {
			return map[string]any{"url": target, "ok": false, "error": err.Error(), "code": ErrorOperationFailed, "retryable": false}
		}
	}
	addFetchCacheHint(response, result.Output, args.RetrievalSurface)
	return response
}

// waybackSnapshotsArgs is the wayback.snapshots frame payload (SymFetch
// wayback_snapshots contract).
type waybackSnapshotsArgs struct {
	URL       string `json:"url"`
	From      string `json:"from"`
	To        string `json:"to"`
	Limit     int    `json:"limit"`
	MatchType string `json:"match_type"`
}

func (r *FetchRuntime) handleWaybackSnapshots(ctx context.Context, frame Frame) (any, []Warning, error) {
	var args waybackSnapshotsArgs
	if err := decodeOptionalArgs(frame, &args); err != nil {
		return nil, nil, err
	}
	if args.URL == "" {
		return nil, nil, NewError(ErrorMalformedRequest, "wayback.snapshots requires a url argument")
	}
	if args.MatchType != "" && args.MatchType != "exact" && args.MatchType != "prefix" && args.MatchType != "host" {
		return nil, nil, NewError(ErrorMalformedRequest, "match_type must be exact, prefix, or host")
	}
	if err := fetch.CheckAllowlist(args.URL, r.allowlist); err != nil {
		return nil, nil, fetchError(err)
	}

	client := archive.NewCDXClient("", nil)
	snapshots, err := client.Lookup(ctx, archive.CDXQuery{
		URL:       args.URL,
		From:      args.From,
		To:        args.To,
		Limit:     args.Limit,
		MatchType: args.MatchType,
	})
	if err != nil {
		return nil, nil, fetchError(err)
	}

	// Contract-true field mapping (SymFetch wayback_snapshots response):
	// timestamp, url, status, mime_type, digest.
	entries := make([]any, 0, len(snapshots))
	for _, snap := range snapshots {
		entries = append(entries, map[string]any{
			"timestamp": snap.Timestamp,
			"url":       snap.Original,
			"status":    snap.StatusCode,
			"mime_type": snap.MimeType,
			"digest":    snap.Digest,
		})
	}
	return entries, nil, nil
}

func (r *FetchRuntime) pipelineOptions(f pipelineFields, format pipeline.Format) pipeline.Options {
	opts := pipeline.Options{
		Format:           format,
		StoreCache:       r.outputCache,
		Frontmatter:      f.Frontmatter,
		CSSSelector:      f.CSSSelector,
		Query:            f.Query,
		SchemaPath:       f.SchemaPath,
		TopK:             f.TopK,
		StoreFullText:    f.StoreFullText,
		CharLimit:        f.CharLimit,
		WaybackFallback:  f.WaybackFallback,
		WaybackTimestamp: f.WaybackTimestamp,
		Security: pipeline.SecurityOptions{
			AllowPrivate: r.allowPrivate,
			Robots:       r.robots,
			UserAgent:    r.userAgent,
			Allowlist:    r.allowlist,
		},
		Content: pipeline.ContentOptions{
			MaxChars:     f.MaxChars,
			IncludeLinks: f.IncludeLinks,
		},
	}
	noCache := r.noCache
	if f.NoCache != nil {
		noCache = *f.NoCache
	}
	opts.Cache.NoCache = noCache
	if r.robots {
		opts.Security.RobotsChecker = robots.NewChecker().WithPrivate(r.allowPrivate)
	}
	if r.cacheDir != "" {
		opts.Cache.Dir = r.cacheDir
		if r.cacheTTL > 0 {
			opts.Cache.TTL = r.cacheTTL
		}
	}
	return opts
}

// pipelineFields is the shared subset of pipeline options accepted by both
// fetch.url and fetch.batch frames.
type pipelineFields struct {
	MaxChars         int
	CharLimit        int
	CSSSelector      string
	Frontmatter      bool
	IncludeLinks     bool
	Query            string
	SchemaPath       string
	StoreFullText    bool
	NoCache          *bool
	TopK             int
	WaybackTimestamp string
	WaybackFallback  bool
}

func (a fetchURLArgs) pipelineFields() pipelineFields {
	return pipelineFields{
		MaxChars:         a.MaxChars,
		CharLimit:        a.CharLimit,
		CSSSelector:      a.CSSSelector,
		Frontmatter:      a.Frontmatter,
		IncludeLinks:     a.IncludeLinks,
		Query:            a.Query,
		SchemaPath:       a.SchemaPath,
		StoreFullText:    a.StoreFullText,
		NoCache:          a.NoCache,
		TopK:             a.TopK,
		WaybackTimestamp: a.WaybackTimestamp,
		WaybackFallback:  a.WaybackFallback,
	}
}

func (a fetchBatchArgs) pipelineFields() pipelineFields {
	return pipelineFields{
		MaxChars:      a.MaxChars,
		CharLimit:     a.CharLimit,
		Frontmatter:   a.Frontmatter,
		IncludeLinks:  a.IncludeLinks,
		StoreFullText: a.StoreFullText,
		NoCache:       a.NoCache,
	}
}

func batchConcurrency(requested int) int {
	if requested <= 0 {
		return 4
	}
	if requested > 8 {
		return 8
	}
	return requested
}

func mustJSON(v any) []byte {
	data, err := json.MarshalIndent(v, "", "  ")
	if err != nil {
		slog.Debug("marshal fetch batch entry", "error", err)
		return []byte("{}")
	}
	return data
}
