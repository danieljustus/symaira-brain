from pathlib import Path
import base64,gzip,hashlib,json,re,subprocess
repo=Path('/workspace/symaira-memory759-mcp');head='08ffb3e90ff3e562bd9f5f164fab20ee64e44736';source='2f5a59d09b9acfde4eee78ea95d57fe1e064adef';root=repo/'migration/evidence/memory-mcp-759';digest=lambda b:hashlib.sha256(b).hexdigest()
def git(*a):return subprocess.check_output(['git',*a],cwd=repo)
v=json.loads((root/'final-2f5a59/validation.json').read_bytes());h=json.loads(Path('/tmp/symaira-memory759-catalog-final-handoff.json').read_bytes());assert v==h
assert git('rev-parse','HEAD').decode().strip()==head and not git('status','--porcelain')and v['source']==source
for ancestor in [v['main'],v['approved_memory_parent']]:subprocess.run(['git','merge-base','--is-ancestor',ancestor,head],cwd=repo,check=True)
assert not git('diff',source,head,'--','rust','scripts','.github','Cargo.toml','Cargo.lock')
for name,sha in v['candidate_source_sha256'].items():assert digest((repo/name).read_bytes())==sha,name
for name,item in v['retained'].items():
 compressed=(repo/name).read_bytes();assert digest(compressed)==item['tracked_sha256'];raw=gzip.decompress(compressed);assert len(raw)==item['original_bytes']and digest(raw)==item['original_sha256'];original=Path(item['original_path'])
 if original.exists():assert original.read_bytes()==raw,name
baseline=root/'catalog-baseline';b=json.loads((baseline/'retention.json').read_bytes());assert len(b['artifacts'])==33 and len(b['go_source_sha256'])==289
for name,item in b['artifacts'].items():
 raw=(baseline/(name+'.gz')).read_bytes();assert digest(raw)==item['tracked_sha256'];decoded=gzip.decompress(raw);assert len(decoded)==item['bytes']and digest(decoded)==item['sha256'];original=Path(item['original_path'])
 if original.exists():assert original.read_bytes()==decoded,name
for name,sha in b['go_source_sha256'].items():assert digest(git('show','dcddcef0df5789123c7c9a7ebe6e01f10e941f2c:'+name))==sha,name
br=json.loads(gzip.decompress((baseline/'receipt.json.gz').read_bytes()));assert len(br['rows'])==6
for row in br['rows']:
 for label in ['go','rust']:
  value=row[label];assert bytes.fromhex(value['stdout_hex'])==gzip.decompress((baseline/(row['case']+'-'+label+'.stdout.gz')).read_bytes());assert bytes.fromhex(value['stderr_hex'])==gzip.decompress((baseline/(row['case']+'-'+label+'.stderr.gz')).read_bytes())
 assert row['go']['exit']==row['rust']['exit']==0
first=baseline/'first-855';f=json.loads((first/'retention.json').read_bytes());assert not f['strict_clippy']and f['actual_wire_pairs']==32 and f['actual_mutants_rejected']==4
for name,item in f['retained'].items():
 compressed=(first/(name+'.gz')).read_bytes();assert digest(compressed)==item['tracked_sha256'];raw=gzip.decompress(compressed);assert len(raw)==item['bytes']and digest(raw)==item['original_sha256']
assert b'struct_excessive_bools'in gzip.decompress((first/'symaira-memory759-catalog-clippy.log.gz').read_bytes())
archive=json.loads(Path(v['archive_receipt']).read_bytes());assert len(archive['executables'])==107 and len(archive['unique'])==75 and not archive['users']and archive['roundtrip_verified']
for sha,item in archive['unique'].items():
 compressed=Path(item['archive']).read_bytes();assert len(compressed)==item['compressed_size'];raw=gzip.decompress(compressed);assert len(raw)==item['original_size']and digest(raw)==sha
for item in archive['executables']:
 p=Path(item['original_path'])
 if p.exists():assert digest(p.read_bytes())==item['sha256'],str(p)
for name,sha in [('/workspace/oracles/symbrain-go-dcddcef0',v['actual_go_cli_sha256']),('/workspace/toolchains/go1.26.7/bin/go',v['actual_sdk_sha256']),(str(repo/'target/debug/symbrain'),v['actual_cli_sha256'])]:assert digest(Path(name).read_bytes())==sha,name
changed=git('diff','--name-only',v['approved_memory_parent'],source,'--','rust').decode().splitlines();assert changed==['rust/symbrain-gateway/src/embedded.rs','rust/symbrain-gateway/src/embedded/catalog.rs','rust/symbrain-gateway/src/embedded/memory_catalog.json','rust/symbrain-gateway/src/embedded/memory_catalog.rs'];assert not git('diff',v['approved_memory_parent'],source,'--','Cargo.toml','Cargo.lock','rust/symbrain-cli','rust/symbrain-memory','rust/symbrain-mcp','rust/symbrain-policy','rust/symbrain-activity')
result={'head':head,'source':source,'candidate_source_hashes':len(v['candidate_source_sha256']),'final_retained_files':len(v['retained']),'baseline_profiles':len(br['rows']),'baseline_raw_inputs_outputs':len(b['artifacts']),'frozen_Go_hashes':len(b['go_source_sha256']),'original855_files':len(f['retained']),'original855_lint_failure_retained':True,'actual_binary_paths':len(archive['executables']),'actual_unique_binary_roundtrips':len(archive['unique']),'runtime_cli_sha256':v['actual_cli_sha256'],'main_and_approved_Memory_ancestors':True,'only_four_gateway_production_files_changed':True,'CLI_store_transport_policy_Activity_and_manifests_unchanged':True,'no_native_Windows_macOS_claim':True}
Path('/tmp/symaira-memory759-catalog-independent-provenance.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
