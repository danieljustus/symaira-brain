#!/usr/bin/env bash
set -euo pipefail
umask 022
. /home/agent/.cargo/env
export PATH=/workspace/toolchains/go1.26.7/bin:$PATH
export CARGO_TARGET_DIR=/workspace/symaira-memory759-mcp/target CARGO_INCREMENTAL=0 CARGO_PROFILE_DEV_DEBUG=0 CARGO_PROFILE_TEST_DEBUG=0 CARGO_BUILD_JOBS=2 PYTHONDONTWRITEBYTECODE=1
cargo test --locked --all-targets --all-features -p symbrain-gateway -p symbrain-mcp -p symbrain-cli > /tmp/symaira-memory759-catalog-independent-tests.log 2>&1
cargo clippy --locked --all-targets --all-features -p symbrain-gateway -p symbrain-mcp -p symbrain-cli -- -D warnings > /tmp/symaira-memory759-catalog-independent-clippy.log 2>&1
cargo fmt --all -- --check > /tmp/symaira-memory759-catalog-independent-fmt.log 2>&1
/workspace/toolchains/bin/actionlint > /tmp/symaira-memory759-catalog-independent-actionlint.log 2>&1
python3 scripts/memory-mcp-oracle/catalog.py --go /workspace/oracles/symbrain-go-dcddcef0 --rust "$CARGO_TARGET_DIR/debug/symbrain" --report /tmp/symaira-memory759-catalog-independent-process.json > /tmp/symaira-memory759-catalog-independent-process.log 2>&1
python3 scripts/mcp-differential.py /workspace/oracles/symbrain-go-dcddcef0 "$CARGO_TARGET_DIR/debug/symbrain" > /tmp/symaira-memory759-catalog-independent-parent.log 2>&1
