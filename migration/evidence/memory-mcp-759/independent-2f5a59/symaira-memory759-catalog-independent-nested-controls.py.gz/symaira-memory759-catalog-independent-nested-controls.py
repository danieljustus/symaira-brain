from pathlib import Path
import base64,copy,hashlib,importlib.util,json,os,subprocess,sys,tempfile
ROOT=Path('/workspace/symaira-memory759-mcp');GO=Path('/workspace/oracles/symbrain-go-dcddcef0');RUST=ROOT/'target/debug/symbrain'
spec=importlib.util.spec_from_file_location('independent_nested_catalog',ROOT/'scripts/memory-mcp-oracle/catalog.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
rows=[]
with tempfile.TemporaryDirectory(prefix='memory759-nested-controls-')as temp:
 root=Path(temp);profile=root/'profile.toml';profile.write_text(m.PROFILE.format(memory='enabled=true\nmode="read_write"\ntools_allow='+json.dumps(m.ALL)))
 for framing in ['line','content-length']:
  left=m.wire(GO,root/('go-'+framing),profile,framing,'mcp');right=m.wire(RUST,root/('native-'+framing),profile,framing,'mcp');assert left==right and left['exit']==0
  for mode,tool,path in [('temporal-schema','memory_search',['inputSchema','properties','from']),('activity-hint','activity_status',['annotations','idempotentHint']),('relationship-description','entity_relate',['description'])]:
   # Execute an actual second native child; mutate only one observed JSON value.
   actual=m.wire(RUST,root/(mode+'-'+framing),profile,framing,'mcp');assert actual==left
   frames=m.protocol.frames(base64.b64decode(actual['stdout']),framing);values=[value for _,value in frames];original=copy.deepcopy(values)
   target=next(x for x in values[1]['result']['tools']if x['name']==tool);obj=target
   for part in path[:-1]:obj=obj[part]
   if mode=='relationship-description':obj[path[-1]]='owned incorrect description'
   else:del obj[path[-1]]
   mutant=dict(actual,stdout=base64.b64encode(m.protocol.encode_requests(tuple(values),framing)).decode())
   assert mutant!=left and mutant['exit']==0 and mutant['stderr']==left['stderr']
   # Restore that one exact path and require complete decoded values equal.
   restored=copy.deepcopy(values);newtarget=next(x for x in restored[1]['result']['tools']if x['name']==tool);oldtarget=next(x for x in original[1]['result']['tools']if x['name']==tool)
   for part in path[:-1]:newtarget=newtarget[part];oldtarget=oldtarget[part]
   newtarget[path[-1]]=oldtarget[path[-1]];assert restored==original
   rows.append({'mode':mode,'framing':framing,'tool':tool,'exact_only_mutated_path':path,'actual_child_exit':actual['exit'],'rejected':True,'go':left,'actual_native':actual,'mutant':mutant})
r={'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),'go_sha256':m.digest(GO.read_bytes()),'rust_sha256':m.digest(RUST.read_bytes()),'runner_sha256':m.digest(Path(__file__).read_bytes()),'cases':rows,'scope':'6 independently executed real native children; one targeted field mutation per literal observed output; full decoded restoration proves no second field changed. Both framing modes, exact full Go/native catalog values.'}
Path('/tmp/symaira-memory759-catalog-independent-nested-controls.json').write_text(json.dumps(r,indent=2)+'\n');print('Six real-child nested schema/Activity hint/relationship-description mutations rejected')
