from pathlib import Path
import base64,hashlib,importlib.util,json,os,re,subprocess
root=Path('/workspace/symaira-memory759-mcp');prefix='/tmp/symaira-memory759-catalog-independent-';head='08ffb3e90ff3e562bd9f5f164fab20ee64e44736';source='2f5a59d09b9acfde4eee78ea95d57fe1e064adef';digest=lambda b:hashlib.sha256(b).hexdigest()
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()==head and not subprocess.check_output(['git','status','--porcelain'],cwd=root)
spec=importlib.util.spec_from_file_location('verified_catalog_frames',root/'scripts/mcp-differential.py');protocol=importlib.util.module_from_spec(spec);spec.loader.exec_module(protocol)
original=json.loads(Path(prefix+'process.json').read_text());novel=json.loads(Path(prefix+'profiles.json').read_text())
for r,count in [(original,32),(novel,76)]:
 assert r['cases']==r['passed']==len(r['records'])==count and r['candidate_revision']==head and not r['candidate_dirty'];assert r['rust_binary_sha256']=='7c843a52f3a8175f852b493a80988653ee5dcf239c2abec7e9a2668d18bd5ec6'and r['go_binary_sha256']=='a68dce5b6f34d10ed568d2a89fab880c889e5ff578735c7bf2ad0535285eda41'
 assert len(r['controls'])==5 and all(x['rejected']and x['actual_child_exit']==0 and x['mutant']!=x['go']for x in r['controls'])
 for row in r['records']:assert row['match']and row['go']==row['rust']and row['go']['exit']==0
 for name,sha in r['candidate_source_sha256'].items():assert digest((root/name).read_bytes())==sha,name
metadata=json.loads((root/'rust/symbrain-gateway/src/embedded/memory_catalog.json').read_text());names=[x['name']for x in metadata];assert len(names)==len(set(names))==11
allrow=next(x for x in original['records']if x['case']=='explicit-all-line-mcp');frames=protocol.frames(base64.b64decode(allrow['go']['stdout']),'line');listed=frames[1][1]['result']['tools'];listed={x['name']:x for x in listed}
for entry in metadata:assert entry==listed[entry['name']],entry['name']
expected=['memory_get','memory_set','memory_search','memory_list','entity_list','entity_relate','entity_resolve','graph_neighbors','activity_search','activity_get','activity_status'];assert [x for x in allrow['names']if x not in ['bootstrap','patterns']]==expected
for name in expected[:8]:assert 'idempotentHint'not in listed[name]['annotations']
for name in expected[8:]:assert listed[name]['annotations']['readOnlyHint']and listed[name]['annotations']['idempotentHint']
assert listed['entity_relate']['annotations']['destructiveHint']and listed['memory_set']['annotations']=={'title':'Save Memory'}
assert {'from','to'}<=set(listed['memory_search']['inputSchema']['properties'])and 'as_of'in listed['graph_neighbors']['inputSchema']['properties']
for row in novel['records']:
 assert not set(row['names'])&{'memory_promote','memory_reject','memory_candidates','query_log','owned-unknown'}
 if row['case'].startswith('singleton-'):
  selected=row['case'].removeprefix('singleton-').split('-line-')[0].split('-content-length-')[0]
  assert row['names']==['bootstrap','patterns',selected],row['case']
nested=json.loads(Path(prefix+'nested-controls.json').read_text());assert len(nested['cases'])==6 and nested['head']==head and all(x['rejected']and x['actual_child_exit']==0 and x['actual_native']==x['go']and x['mutant']!=x['go']for x in nested['cases'])
log=Path(prefix+'tests.log').read_text();summaries=[tuple(map(int,x))for x in re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;',log)];assert len(summaries)==35 and tuple(map(sum,zip(*summaries)))==(316,0,0)
assert 'Finished'in Path(prefix+'clippy.log').read_text()
for name in ['fmt','actionlint']:assert not Path(prefix+name+'.log').read_bytes()
parentlog=Path(prefix+'parent.log').read_text()
for text in ['embedded-memory','foreign stdio child','URL-only','malformed frame','--profile/--profile-file','SIGTERM lifecycle']:assert text in parentlog,text
bins={str((root/name).resolve()if not name.startswith('/')else Path(name)):digest((root/name).read_bytes()if not name.startswith('/')else Path(name).read_bytes())for name in re.findall(r'Running [^\n]+ \(([^\n]+)\)',log)};bins[str(root/'target/debug/symbrain')]=digest((root/'target/debug/symbrain').read_bytes());assert len(bins)==36
users=[];target=str(root/'target')
for p in Path('/proc').iterdir():
 if not p.name.isdigit()or int(p.name)==os.getpid():continue
 for item in [p/'exe',p/'cwd']+list((p/'fd').glob('*')):
  try:
   link=os.readlink(item)
   if link.startswith(target):users.append({'pid':p.name,'link':link})
  except OSError:pass
assert not users,users
receipt={'source':source,'publication':head,'disposition':'APPROVE bounded Memory MCP catalog correction; full759/native threeOS/protected gates remain pending','tests':{'passed':316,'failed':0,'ignored':0,'summaries':35},'strict_combined_Clippy_fmt_actionlint':True,'full_original_MCP_process_suite_pass':True,'original_catalog_pairs':32,'novel_profile_pairs':72,'additional_explicit_all_control_pairs':4,'genuine_original_mutator_children_rejected':5,'additional_mutator_children_same_five_modes_rejected':5,'nested_one_field_controls_from_real_child_observations_rejected':6,'complete_eleven_descriptors_match_actual_Go':True,'registration_order':expected,'profile_exposure_unchanged':True,'binary_sha256':bins,'provenance':json.loads(Path(prefix+'provenance.json').read_text()),'target_users':users,'target_released':True,'default11434_released':True,'native_Windows_macOS_runtime':False,'full_tools_call_authorization_historicalDB_startup_files_not_claimed':True,'initial_novel_profile_control_anchor_StopIteration_retained':True}
Path(prefix+'review-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps({k:receipt[k]for k in ['disposition','tests','original_catalog_pairs','novel_profile_pairs','target_users']},indent=2))
