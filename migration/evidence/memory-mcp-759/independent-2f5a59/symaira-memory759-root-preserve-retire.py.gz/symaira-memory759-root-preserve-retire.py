from pathlib import Path
import hashlib,json,gzip,os,shutil,subprocess
r=Path('/workspace/symaira-memory759-mcp');t=r/'target'
sha=lambda p:hashlib.file_digest(Path(p).open('rb'),'sha256').hexdigest()
p=Path('/tmp/symaira-memory759-catalog-independent-review-receipt.json');d=json.loads(p.read_text())
assert d['source']=='2f5a59d09b9acfde4eee78ea95d57fe1e064adef'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip()==d['publication']
out=r/'migration/evidence/memory-mcp-759/independent-2f5a59';out.mkdir(exist_ok=True)
records=[]
for name,digest in {**{n:v['sha256'] for n,v in d['independent_artifacts'].items()},str(p):sha(p)}.items():
 original=Path(name);assert sha(original)==digest,(name,digest)
 dest=out/(original.name+'.gz')
 with original.open('rb') as f,dest.open('wb') as stream:
  with gzip.GzipFile(fileobj=stream,mode='wb',mtime=0) as z:shutil.copyfileobj(f,z,1<<20)
 with gzip.open(dest,'rb') as f:assert hashlib.file_digest(f,'sha256').hexdigest()==digest
 records.append({'original_path':name,'original_sha256':digest,'gzip_file':dest.name,'compressed_sha256':sha(dest)})
a=json.load(open('/workspace/oracles/symaira-memory759-mcp-2f5a59d09b9a-idle-binaries/receipt.json'))
for name,digest in d['binary_sha256'].items():
 assert sha(name)==digest,name
 if name.startswith(str(t)):
  assert digest in a['unique'],name
for digest,entry in a['unique'].items():
 with gzip.open(entry['archive'],'rb') as f:assert hashlib.file_digest(f,'sha256').hexdigest()==digest
users=[]
for proc in Path('/proc').iterdir():
 if not proc.name.isdigit() or int(proc.name)==os.getpid():continue
 try:
  vals=[os.readlink(proc/'exe'),os.readlink(proc/'cwd'),(proc/'maps').read_text()]
  for fd in (proc/'fd').iterdir():
   try:vals.append(os.readlink(fd))
   except OSError:pass
  if any(str(t)+'/' in x or str(t)==x for x in vals):users.append(proc.name)
 except (OSError,ProcessLookupError):pass
assert not users,users
elf=[]
for parent,_,names in os.walk(t):
 for name in names:
  x=Path(parent)/name
  if x.is_symlink() or not x.is_file():continue
  with x.open('rb') as f:
   if f.read(4)!=b'\x7fELF':continue
  digest=sha(x)
  if digest not in a['unique']:
   supplement=Path('/workspace/oracles/symaira-memory759-mcp-root-idle-binaries');supplement.mkdir(exist_ok=True)
   zpath=supplement/(digest+'.gz')
   with x.open('rb') as f,zpath.open('wb') as stream:
    with gzip.GzipFile(fileobj=stream,mode='wb',mtime=0) as z:shutil.copyfileobj(f,z,1<<20)
   with gzip.open(zpath,'rb') as f:assert hashlib.file_digest(f,'sha256').hexdigest()==digest
   a['unique'][digest]={'archive':str(zpath),'sha256':digest}

  elf.append({'path':str(x),'sha256':digest})
retention={'source':d['source'],'publication':d['publication'],'approved_scope':'bounded catalog; full759/native3 remain pending','proof_files':records,'actual_fresh_executed_paths':len(d['binary_sha256']),'current_elf_paths':elf,'all_elf_archives':a['unique'],'archive':'/workspace/oracles/symaira-memory759-mcp-2f5a59d09b9a-idle-binaries/receipt.json','roundtrip_verified':True,'users':users,'retired':False}
shutil.rmtree(t);retention['retired']=True
(out/'retention.json').write_text(json.dumps(retention,indent=2)+'\n')
print(len(records),'independent proofs retained;',len(elf),'current ELF paths verified and cache retired')

