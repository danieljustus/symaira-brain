import subprocess,json,tempfile,os,hashlib
from pathlib import Path
root=Path(tempfile.mkdtemp(prefix='memory759-catalog-full-'))
base='[profile]\nname="mcp-oracle"\n[servers.vault]\nenabled=false\n[servers.memory]\n{memory}\n[servers.skills]\nenabled=false\n[servers.usage]\nenabled=false\n[audit]\nenabled=false\n'
names=['entity_list','entity_relate','entity_resolve','graph_neighbors','memory_candidates','memory_get','memory_list','memory_promote','memory_reject','memory_search','memory_set','query_log','activity_get','activity_search','activity_status']
cases=[('read-only','enabled=true\nmode="read_only"'),('read-write','enabled=true\nmode="read_write"'),('explicit-all','enabled=true\nmode="read_write"\ntools_allow='+json.dumps(names)),('explicit-one','enabled=true\nmode="read_write"\ntools_allow=["memory_get"]'),('deny-writes','enabled=true\nmode="read_write"\ntools_deny=["memory_set","entity_relate"]'),('disabled','enabled=false')]
requests=[{'jsonrpc':'2.0','id':1,'method':'initialize','params':{'protocolVersion':'2024-11-05','capabilities':{},'clientInfo':{'name':'owned-oracle','version':'1'}}},{'jsonrpc':'2.0','id':2,'method':'tools/list'}];data=b''.join(json.dumps(x,separators=(',',':')).encode()+b'\n' for x in requests);rows=[]
for case,memory in cases:
 profile=root/(case+'.toml');profile.write_text(base.format(memory=memory));pair={}
 for label,binary in [('go','/workspace/oracles/symbrain-go-dcddcef0'),('rust','/tmp/symaira-memory759-approved-parent-cli')]:
  home=root/case/label;home.mkdir(parents=True);env={k:v for k,v in os.environ.items() if k in ('SystemRoot','windir','ComSpec')};env.update(HOME=str(home),XDG_CONFIG_HOME=str(home/'config'),XDG_DATA_HOME=str(home/'data'),XDG_STATE_HOME=str(home/'state'),XDG_CACHE_HOME=str(home/'cache'),PATH='',SYMBRAIN_GO_FALLBACK_BIN=str(home/'missing-go'))
  p=subprocess.run([binary,'mcp','--profile-file',str(profile)],input=data,capture_output=True,cwd=root,env=env,timeout=15)
  (root/(case+'-'+label+'.stdout')).write_bytes(p.stdout);(root/(case+'-'+label+'.stderr')).write_bytes(p.stderr);frames=[json.loads(line) for line in p.stdout.splitlines()];tools=next((x.get('result',{}).get('tools') for x in frames if x.get('id')==2),None)
  pair[label]={'exit':p.returncode,'stdout_hex':p.stdout.hex(),'stderr_hex':p.stderr.hex(),'frames':frames,'tools':tools,'binary':binary,'sha256':hashlib.sha256(Path(binary).read_bytes()).hexdigest()}
 rows.append({'case':case,'profile':profile.read_text(),**pair});print(case,[(s,pair[s]['exit'],len(pair[s]['tools']) if pair[s]['tools'] is not None else None) for s in ['go','rust']])
(root/'receipt.json').write_text(json.dumps({'frozen_go':'dcddcef0df5789123c7c9a7ebe6e01f10e941f2c','native_source':'458e8fa5dc752ee2eed6446cc279649ad3d2b879','native_publication':'27001b1bd6948cd7985773655f3a43bc41e947b3','rows':rows},indent=2)+'\n');print('retained',root)
