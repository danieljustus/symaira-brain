from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import os
import shutil
import stat
import struct
import subprocess
import gzip

ROOT = Path('/workspace/symaira-brain')
OUT = Path(__file__).resolve().parent / 'retirement-third'
OUT.mkdir(exist_ok=True)
PLAN = Path(__file__).resolve().parent / 'prioritized-remaining-2.json'
plan = json.loads(PLAN.read_bytes())
CHECKPOINTS = json.loads((PLAN.parent / 'manifest.json').read_bytes())['checkpoints']
TARGET_FREE = int(2.5 * 2**30)
baseline_free = shutil.disk_usage('/workspace').free
records = []


def event(value):
    value = dict(at=datetime.now(timezone.utc).isoformat(), **value)
    with (OUT / 'journal.jsonl').open('ab') as stream:
        stream.write((json.dumps(value, sort_keys=True) + '\n').encode())
        stream.flush()
        os.fsync(stream.fileno())


def run(argv, *, cwd=ROOT):
    event(dict(phase='command-start', argv=list(map(str, argv)), cwd=str(cwd),
               free_before=shutil.disk_usage('/workspace').free))
    p = subprocess.run(list(map(str, argv)), cwd=cwd, capture_output=True, timeout=120)
    event(dict(phase='command-finish', argv=list(map(str, argv)), cwd=str(cwd), exit=p.returncode,
               stdout_hex=p.stdout.hex(), stderr_hex=p.stderr.hex(),
               free_after=shutil.disk_usage('/workspace').free))
    if p.returncode:
        raise RuntimeError(('failed command retained; stopped', argv, p.returncode))
    return p.stdout


def visible_users(path):
    users = []
    unverified = []
    needle = os.fsencode(str(path))
    def contains(value):
        start = 0
        while (at := value.find(needle, start)) >= 0:
            end = at + len(needle)
            if end == len(value) or value[end:end+1] in (b'/', b'\0', b':', b' ', b'\n'):
                return True
            start = end
        return False
    for proc in Path('/proc').iterdir():
        if not proc.name.isdigit() or int(proc.name) == os.getpid():
            continue
        try:
            fields = dict(line.split(':', 1) for line in (proc / 'status').read_text().splitlines() if ':' in line)
            if fields['State'].strip().startswith('Z '):
                continue
            refs = []
            for key in ('exe', 'cwd'):
                try:
                    refs.append((key, os.fsencode(os.readlink(proc / key))))
                except FileNotFoundError:
                    pass
            for fd in (proc / 'fd').iterdir():
                try:
                    refs.append(('fd:' + fd.name, os.fsencode(os.readlink(fd))))
                except FileNotFoundError:
                    pass
            for item in (proc / 'environ').read_bytes().split(b'\0'):
                if b'=' in item:
                    key, value = item.split(b'=', 1)
                    refs.append(('env:' + key.decode(errors='replace'), value))
            matching = sorted({key for key, value in refs if contains(value)})
            if matching:
                users.append(dict(pid=int(proc.name), references=matching))
        except FileNotFoundError:
            continue
        except PermissionError:
            item = dict(pid=int(proc.name), name=fields['Name'].strip(), state=fields['State'].strip(),
                        UIDs=fields['Uid'].strip().split())
            if not ((item['pid'], item['name']) in ((198, 'dockerd'), (249, 'containerd')) and item['UIDs'] == ['0'] * 4):
                raise RuntimeError(('new unverified live process; stopped', item))
            unverified.append(item)
    return users, unverified


event(dict(phase='authorized-plan', authorized='Root approved exactly remaining DoctorWindows343 and Usageargv eea; concurrent SourceGuard cleanup may interfere with disk readings; no isolated gain claim',
           plan_sha256=hashlib.sha256(PLAN.read_bytes()).hexdigest(), target_free=TARGET_FREE,
           baseline_free=baseline_free, privileged_services='PID198/PID249 remain UNVERIFIED; no global zero claim'))
try:
    for selected in plan['selected']:
        if shutil.disk_usage('/workspace').free >= TARGET_FREE:
            event(dict(phase='budget-stop', available=shutil.disk_usage('/workspace').free))
            break
        path = Path(selected['worktree'])
        assert path.parent == Path('/workspace') and path.name.startswith('symaira-')
        assert path.is_dir() and not path.is_symlink() and path.resolve() == path
        assert path != ROOT
        assert not (path / 'target').exists() and not (path / 'target').is_symlink()
        head, branch = selected['HEAD'], selected['branch']
        assert run(['git', 'rev-parse', 'HEAD'], cwd=path).decode().strip() == head
        assert run(['git', 'symbolic-ref', 'HEAD'], cwd=path).decode().strip() == branch
        assert run(['git', 'rev-parse', '--verify', branch]).decode().strip() == head
        admitted = [label for label in selected['strict_ancestor_checkpoints'] if not label.startswith('prepared-')]
        assert admitted
        for label in admitted:
            assert CHECKPOINTS[label] != head
            run(['git', 'merge-base', '--is-ancestor', head, CHECKPOINTS[label]])
        status = run(['git', 'status', '--porcelain=v1', '-z', '--ignored', '--untracked-files=normal'], cwd=path)
        derivatives = []
        for item in status.split(b'\0'):
            if item:
                assert item.startswith(b'!! '), ('dirty/untracked tree; stopped', item)
                rel = os.fsdecode(item[3:])
                assert '__pycache__' in Path(rel).parts, ('unknown ignored runtime; stopped', rel)
                derivatives.append(path / rel)
        manifest_path = PLAN.parent / selected['tracked_file_manifest']
        manifest_bytes = manifest_path.read_bytes()
        files = json.loads(manifest_bytes)
        tracked = {os.fsdecode(bytes.fromhex(f['path_bytes_hex'])) for f in files}
        for entry in files:
            file = path / os.fsdecode(bytes.fromhex(entry['path_bytes_hex']))
            info = file.lstat()
            if entry['mode'] == '120000':
                assert stat.S_ISLNK(info.st_mode)
                data = os.fsencode(os.readlink(file))
            else:
                assert stat.S_ISREG(info.st_mode) and file.resolve().is_relative_to(path)
                data = file.read_bytes()
            assert len(data) == entry['bytes'] and hashlib.sha256(data).hexdigest() == entry['sha256']
            assert stat.S_IMODE(info.st_mode) == entry['native_mode']
            assert hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest() == entry['blob']
        users, unknown = visible_users(path)
        assert not users, ('visible source consumers; stopped', users)
        assert not run(['docker', 'ps', '-q', '--no-trunc']).strip(), 'Docker mount precondition changed; stopped'
        record = dict(path=str(path), head=head, branch=branch, checkpoint_labels=admitted,
                      tracked_manifest=str(manifest_path), tracked_manifest_sha256=hashlib.sha256(manifest_bytes).hexdigest(),
                      full_tracked_files=len(files), exact_bytes_and_native_modes_rechecked=True,
                      visible_consumers=users, privileged_services_UNVERIFIED=unknown,
                      restore_argv=['git', '-C', str(ROOT), 'worktree', 'add', str(path), branch],
                      native_mode_restoration='apply each native_mode from full tracked manifest after Git checkout',
                      free_before=shutil.disk_usage('/workspace').free, derivative_cleanup=[])
        event(dict(phase='pre-remove-verification', **record))
        for cache in derivatives:
            assert cache.is_dir() and not cache.is_symlink()
            for file in cache.rglob('*'):
                if file.is_dir():
                    continue
                assert not file.is_symlink() and stat.S_ISREG(file.lstat().st_mode)
                data = file.read_bytes()
                source = file.parent.parent / (file.name.split('.cpython-', 1)[0] + '.py')
                assert file.name.endswith('.pyc') and '.cpython-' in file.name and len(data) >= 16
                assert data[2:4] == b'\r\n' and struct.unpack('<I', data[4:8])[0] in (0, 1, 3)
                assert str(source.relative_to(path)) in tracked
                payload = hashlib.sha256(data).hexdigest()
                archive = OUT / (payload + '.pyc.gz')
                packed = gzip.compress(data, mtime=0)
                archive.write_bytes(packed)
                assert gzip.decompress(packed) == data
                event(dict(phase='derivative-unlink-start', operation='Path.unlink', argv=[str(file)],
                           sha256=payload, archive=str(archive), archive_sha256=hashlib.sha256(packed).hexdigest(),
                           bytes=len(data), native_mode=stat.S_IMODE(file.lstat().st_mode)))
                file.unlink()
                event(dict(phase='derivative-unlink-finish', argv=[str(file)], exit=0))
                record['derivative_cleanup'].append(str(file))
            for directory in sorted([q for q in cache.rglob('*') if q.is_dir()], key=lambda q: len(q.parts), reverse=True):
                event(dict(phase='derivative-rmdir-start', operation='Path.rmdir', argv=[str(directory)]))
                directory.rmdir()
                event(dict(phase='derivative-rmdir-finish', argv=[str(directory)], exit=0))
            event(dict(phase='derivative-rmdir-start', operation='Path.rmdir', argv=[str(cache)]))
            cache.rmdir()
            event(dict(phase='derivative-rmdir-finish', argv=[str(cache)], exit=0))
        assert not run(['git', 'status', '--porcelain=v1', '-z', '--ignored', '--untracked-files=normal'], cwd=path)
        users, unknown = visible_users(path)
        assert not users
        assert run(['git', 'rev-parse', 'HEAD'], cwd=path).decode().strip() == head
        run(['git', 'worktree', 'remove', str(path)])  # Normal operation; never --force.
        assert not path.exists()
        assert run(['git', 'rev-parse', '--verify', branch]).decode().strip() == head
        run(['git', 'cat-file', '-e', head + '^{tree}'])
        record.update(exit=0, free_after=shutil.disk_usage('/workspace').free,
                      branch_and_commit_preserved=True, directory_absent=True)
        records.append(record)
        event(dict(phase='retirement-complete', **record))
        (OUT / 'completed.json').write_text(json.dumps(records, indent=2) + '\n')
        print(json.dumps(dict(retired=path.name, free_MiB=round(record['free_after']/2**20, 1),
                              observed_gain_MiB=round((record['free_after']-record['free_before'])/2**20, 1))), flush=True)
    result = dict(baseline_free=baseline_free, final_free=shutil.disk_usage('/workspace').free,
                  target_free=TARGET_FREE, observed_available_increase=shutil.disk_usage('/workspace').free-baseline_free,
                  retired=records, remaining_authorized_paths=[s['worktree'] for s in plan['selected'] if s['worktree'] not in {r['path'] for r in records}],
                  branch_or_Git_object_deletion=False, force_used=False,
                  privileged_services_UNVERIFIED=[198, 249], global_zero_user_claim=False,
                  compiler_target_port_or_product_execution=False, concurrent_cleanup_possible=True, isolated_deletion_gain_claim=False)
    (OUT / 'result.json').write_text(json.dumps(result, indent=2) + '\n')
    event(dict(phase='finished', final_free=result['final_free'], retired=len(records), observed_available_increase=result['observed_available_increase']))
except BaseException as error:
    event(dict(phase='FAIL_STOP', exception=type(error).__name__, error=str(error), retired=len(records), free=shutil.disk_usage('/workspace').free))
    raise
