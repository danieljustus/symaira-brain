from pathlib import Path
import os,json,gzip,hashlib,subprocess
root=Path('/workspace/symaira-doctor806-owned-paths');source='c6723ab21a3bfe73e84d715695b3d5ea45c661d1';assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()==source;assert not subprocess.check_output(['git','status','--porcelain'],cwd=root)
changed=subprocess.check_output(['git','diff','--name-only','f9447c5e01bd8c3d78df5115fd62636ac807cbd0',source],cwd=root,text=True).splitlines();assert all(p=='.gitattributes' or p.startswith(('scripts/doctor-stdout-oracle/','docs/','migration/evidence/doctor-owned-paths-806/')) for p in changed),changed
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
archive=Path('/workspace/oracles/symaira-doctor765-sixth-independent-fb6-binaries');owned=Path('/tmp/symaira-doctor806-root-owned-bin');owned.mkdir(exist_ok=False);bindings=[]
for name,digest in [('symbrain','256e5efe3d05b9fe5c8afa41d9821a13ee2dee32de9719a4acd7e79364fde8ee'),('doctor_embedded_output','50f7528fe3a505bfc7997a0a4a11750b39aaff93fa693279624d129f856bdf4b')]:
 p=owned/name;data=gzip.decompress((archive/(digest+'.gz')).read_bytes());assert hashlib.sha256(data).hexdigest()==digest;p.write_bytes(data);p.chmod(0o700);bindings.append({'role':name,'actual_sha256':digest,'archive':str(archive/(digest+'.gz')),'compiled_source':'58fe50b9d275f0cc8a7ab6a8252a6595a58e52ab','scope':'reused actual reviewed compiled executable; unchanged production, no new compilation claim'})
assert not subprocess.check_output(['git','diff','--name-only','58fe50b9d275f0cc8a7ab6a8252a6595a58e52ab',source,'--',':(glob)rust/**/src/**',':(glob)rust/**/Cargo.toml','Cargo.toml','Cargo.lock'],cwd=root)
env=dict(os.environ,PATH='/workspace/toolchains/go1.26.7/bin:/workspace/toolchains/bin:'+os.environ['PATH'],GOTOOLCHAIN='local');go=owned/'symbrain-go'
with Path('/tmp/symaira-doctor806-root-owned-go-build.log').open('wb') as log:subprocess.run(['bash','scripts/run-go-oracle.sh','dcddcef0df5789123c7c9a7ebe6e01f10e941f2c','build','-o',str(go),'./cmd/symbrain'],cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
bindings.append({'role':'frozen Go CLI','actual_sha256':sha(go),'source':'dcddcef0df5789123c7c9a7ebe6e01f10e941f2c','sdk':'Go1.26.7','build_log':'/tmp/symaira-doctor806-root-owned-go-build.log'})
env.update(DOCTOR_STDOUT_GO=os.path.relpath(go,root),DOCTOR_STDOUT_RUST=os.path.relpath(owned/'symbrain',root),DOCTOR_STDOUT_EMBEDDED=os.path.relpath(owned/'doctor_embedded_output',root))
Path('/tmp/symaira-doctor806-root-owned-runtime-bindings.json').write_text(json.dumps({'source':source,'changed_paths':changed,'bindings':bindings,'relative_input_env':{k:v for k,v in env.items() if k.startswith('DOCTOR_STDOUT_')},'scope':'new harness uses explicit relative executable inputs; actual retained unchanged production ELF plus freshly built frozen Go; actual children change to owned PROJECT; no fresh Rust build/native Windows/macOS claim'},indent=2)+'\n')
for name in ['process','fix','embedded','controls']:
 env['DOCTOR_STDOUT_REPORT']='/tmp/symaira-doctor806-root-owned-'+name+'.json'
 with Path('/tmp/symaira-doctor806-root-owned-'+name+'.log').open('wb') as log:subprocess.run(['python3','scripts/doctor-stdout-oracle/'+name+'.py'],cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=450)
 print(name,'PASS',flush=True)
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()==source;assert not subprocess.check_output(['git','status','--porcelain'],cwd=root)
