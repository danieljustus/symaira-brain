from pathlib import Path
import hashlib
import json
import os
import subprocess
import sys

OUT = Path(__file__).resolve().parent
ROOT = Path('/workspace/symaira-memory758-cli-fixes')
CHECKER = ROOT / 'scripts/memory-historical-oracle/checker.py'
observations = []


def run(label, argv, *, env=None, data=None):
    actual_env = dict(os.environ, TMPDIR=str(OUT / 'tmp'), PYTHONDONTWRITEBYTECODE='1')
    if env:
        actual_env.update(env)
    result = subprocess.run(list(map(str, argv)), input=data, capture_output=True,
                            timeout=30, cwd=OUT, env=actual_env)
    (OUT / (label + '.stdout')).write_bytes(result.stdout)
    (OUT / (label + '.stderr')).write_bytes(result.stderr)
    row = dict(label=label, argv=list(map(str, argv)), exit=result.returncode,
               stdout_hex=result.stdout.hex(), stderr_hex=result.stderr.hex(),
               private_TMPDIR=actual_env['TMPDIR'], LD_LIBRARY_PATH=actual_env.get('LD_LIBRARY_PATH'),
               input_sha256=hashlib.sha256(data).hexdigest() if data else None)
    observations.append(row)
    (OUT / 'observations.json').write_text(json.dumps(observations, indent=2) + '\n')
    return result


sql = 'SELECT sqlite_version();PRAGMA integrity_check;SELECT importance,typeof(importance) FROM memories;'
read = 'import sqlite3,sys,json; c=sqlite3.connect(Path(sys.argv[1]).as_uri()+"?immutable=1",uri=True); print(json.dumps(dict(version=sqlite3.sqlite_version,integrity=list(c.execute("PRAGMA integrity_check")),rows=list(c.execute("SELECT importance,typeof(importance) FROM memories")))))'
read = 'from pathlib import Path; ' + read
before = {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in OUT.glob('*.db')}
for owner in ('go', 'native'):
    result = run(owner + '-sqlite345', [OUT / 'sqlite345', '-readonly', OUT / (owner + '.db'), sql])
    assert result.returncode == 0 and result.stdout == b'3.45.1\nNULL value in memories.importance\n0.5|real\n'
    for label, python in [('system', '/usr/bin/python3'), ('root', sys.executable)]:
        result = run(owner + '-' + label, [python, '-c', read, OUT / (owner + '.db')])
        assert result.returncode == 0
        data = json.loads(result.stdout)
        assert data['integrity'] == [['ok']] and data['rows'] == [[0.5, 'real']]
after = {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in OUT.glob('*.db')}
assert before == after
result = run('minimal-sqlite345', [OUT / 'sqlite345'], data=(OUT / 'minimal.sql').read_bytes())
assert result.returncode == 0 and b'NULL value in historical.importance' in result.stdout

for label, python in [('system', '/usr/bin/python3'), ('root', sys.executable)]:
    result = run('checker-' + label, [python, CHECKER, '--output', OUT / (label + '-checker.json')])
    assert result.returncode == 0
    receipt = json.loads((OUT / (label + '-checker.json')).read_bytes())
    assert receipt['historical_default']['integrity'] == [['ok']]
    assert receipt['real_null_control'] == [['NULL value in damaged.importance']]
    assert receipt['fts5_porter_and_integrity'] == 'passed'

legacy = dict(LD_LIBRARY_PATH=str(OUT))
result = run('legacy-version', ['/usr/bin/python3', '-c', 'import sqlite3; print(sqlite3.sqlite_version)'], env=legacy)
assert result.returncode == 0 and result.stdout == b'3.45.1\n'
result = run('checker-legacy', ['/usr/bin/python3', CHECKER, '--output', OUT / 'legacy-checker.json'], env=legacy)
assert result.returncode == 1 and b'SQLite checker misreports' in result.stderr
assert not (OUT / 'legacy-checker.json').exists()

for label, original, mutation in [
    ('wrong-default', 'DEFAULT 0.5;', 'DEFAULT 0.6;'),
    ('unseeded-porter', "VALUES ('running')", "VALUES ('unmatched')"),
    ('no-real-corruption', 'importance REAL NOT NULL)\' WHERE', 'importance REAL)\' WHERE'),
]:
    source = CHECKER.read_text()
    assert source.count(original) == 1
    mutant = OUT / (label + '-checker.py')
    mutant.write_text(source.replace(original, mutation))
    result = run(label, [sys.executable, mutant, '--output', OUT / (label + '-result.json')])
    assert result.returncode == 1 and b'AssertionError' in result.stderr
    assert not (OUT / (label + '-result.json')).exists()

assert not list((OUT / 'tmp').iterdir()), 'checker temporary databases leaked'
print(json.dumps(dict(observations=len(observations), unchanged_database_SHA256=before,
                     actual_product_Go_Rust_or_compiler_execution=False,
                     pinned_Python3137_native_three_OS_execution=False), indent=2))
