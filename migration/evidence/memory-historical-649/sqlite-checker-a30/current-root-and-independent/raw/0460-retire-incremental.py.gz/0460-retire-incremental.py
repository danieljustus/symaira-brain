from pathlib import Path
import os,json,hashlib,struct,stat,shutil,subprocess,datetime
source=Path('/workspace/symaira-brain/target/debug/incremental');owned=Path('/workspace/review-proof/root-resource-audit');receipt=owned/'original-incremental-retirement.json';assert not receipt.exists();assert source.is_dir() and not source.is_symlink();root=source.resolve();entries=[]
def users():
 found=[]
 for p in Path('/proc').iterdir():
  if not p.name.isdigit() or int(p.name)==os.getpid():continue
  for x in (p/'exe',p/'cwd',*(p/'fd').glob('*')):
   try:
    y=Path(os.readlink(x).removesuffix(' (deleted)'))
    if y==root or y.is_relative_to(root):found.append(dict(pid=p.name,ref=str(x),path=str(y)))
   except (OSError,ValueError):pass
 return found
assert not users(),users()
for p in sorted(source.rglob('*')):
 st=p.lstat();assert not p.is_symlink(),p
 if p.is_dir():continue
 assert stat.S_ISREG(st.st_mode),p
 data=p.read_bytes();kind=None
 if data.startswith(b'\x7fELF'):
  assert data[5] in (1,2);kind=struct.unpack('<H' if data[5]==1 else '>H',data[16:18])[0];assert kind==1,(p,kind)
 entries.append(dict(path=str(p.relative_to(source)),bytes=len(data),sha256=hashlib.sha256(data).hexdigest(),mode=stat.S_IMODE(st.st_mode),ELF_type=kind))
assert entries and not users();before=shutil.disk_usage('/workspace').free
r=dict(timestamp=datetime.datetime.now(datetime.timezone.utc).isoformat(),original_target='/workspace/symaira-brain/target',removed_subdirectory=str(source),repository_head=subprocess.check_output(['git','rev-parse','HEAD'],cwd='/workspace/symaira-brain',text=True).strip(),repository_status=subprocess.check_output(['git','status','--porcelain'],cwd='/workspace/symaira-brain',text=True),files=entries,bytes=sum(x['bytes'] for x in entries),ELF_admission='Every ELF is ET_REL=1, never an executable/shared object; cache graph/work-product data are derivative compiler inputs',proc_exe_cwd_FD_users_before=users(),preserved='all source, all target executable/build/deps files, all other worktrees, every runtime/archive/proof',free_before=before,status='audited before removal')
receipt.write_text(json.dumps(r,indent=2)+'\n');assert not users();quarantine=source.with_name('incremental-root-retire-20261004');assert not quarantine.exists();source.rename(quarantine);shutil.rmtree(quarantine);r.update(status='completed',free_after=shutil.disk_usage('/workspace').free,original_cache_exists=source.exists());receipt.write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({k:r[k] for k in ('status','bytes','free_before','free_after','original_cache_exists')}))
