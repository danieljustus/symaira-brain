from pathlib import Path
import gzip
import hashlib
import importlib.util
import json
import sys
import subprocess

ROOT = Path('/workspace/symaira-memory758-cli-fixes')
RUNTIME = Path('/workspace/oracles/symaira-memory803-checker-root-runtime')
OUT = Path(__file__).resolve().parent
sys.dont_write_bytecode = True
sys.path.insert(0, str(ROOT / 'scripts/memory-historical-oracle'))
spec = importlib.util.spec_from_file_location('review_replay', ROOT / 'scripts/memory-historical-oracle/replay.py')
replay = importlib.util.module_from_spec(spec)
spec.loader.exec_module(replay)
binding = json.loads((RUNTIME / 'source-binary-binding.json').read_bytes())
assert binding['current_source'] == '64cba2895839b94bd51668ff3a5d9962d0a36d62'
source = binding['original_compiled_source']
assert len(binding['byte_identical_original_rust_and_Cargo']) == 549
for path, expected in binding['byte_identical_original_rust_and_Cargo'].items():
    before = subprocess.check_output(['git', 'show', source + ':' + path], cwd=ROOT)
    assert hashlib.sha256(before).hexdigest() == expected
    assert hashlib.sha256((ROOT / path).read_bytes()).hexdigest() == expected
cli = binding['original_executed_CLI']
archive = cli['archive']
packed = Path(archive['gzip']).read_bytes()
assert hashlib.sha256(packed).hexdigest() == archive['gzip_sha256']
unpacked = gzip.decompress(packed)
assert len(unpacked) == archive['bytes']
assert hashlib.sha256(unpacked).hexdigest() == cli['sha256']

verified_files = {}
for name in ('historical', 'controls'):
    root = RUNTIME / name
    receipt = json.loads((root / 'receipt.json').read_bytes())
    for path, expected in receipt['files'].items():
        assert hashlib.sha256((root / path).read_bytes()).hexdigest() == expected
    verified_files[name] = len(receipt['files'])
    for path, expected in receipt['binaries'].items():
        assert hashlib.sha256(Path(path).read_bytes()).hexdigest() == expected

historical = json.loads((RUNTIME / 'historical/receipt.json').read_bytes())
assert historical['source'] == binding['current_source'] and not historical['dirty_source']
assert len(historical['cases']) == 37
for case in historical['cases']:
    root = RUNTIME / 'historical' / case['version']
    go = json.loads((root / 'go/result.json').read_bytes())
    native = json.loads((root / 'native/result.json').read_bytes())
    assert go['before'] == native['before']
    bindings = replay.compare(go['before'], go['after'], native['after'], go['process'], native['process'])
    assert bindings == case['bindings']
    assert case['checks'] == {label: dict(run_ids=['legacy-memory'], foreign_key_errors=[]) for label in ('go', 'native')}
    reopened = json.loads((root / 'native/reopen.json').read_bytes())
    assert reopened['process']['exit'] == 0
    assert all(reopened['process'][key] == native['process'][key] for key in ('stdout_hex', 'stderr_hex'))
    assert reopened['after'] == native['after']

controls = json.loads((RUNTIME / 'controls/receipt.json').read_bytes())
assert len(controls['cases']) == 9
native_exits = []
for case in controls['cases']:
    root = RUNTIME / 'controls' / case['name']
    go = json.loads((root / 'go/result.json').read_bytes())
    native = json.loads((root / 'native/result.json').read_bytes())
    assert go['process']['exit'] == case['go_exit'] == 0
    assert native['process']['exit'] == case['native_exit']
    native_exits.append(native['process']['exit'])
    assert go['before'] == native['before']
    if case['native_exit']:
        assert native['after'] == native['before']
        assert case['effect'].lower() in bytes.fromhex(native['process']['stderr_hex']).decode().lower()
    elif case['effect'] == 'repair-provenance':
        tables = native['after']['tables']
        assert sum(row['updated_at'] == row['created_at'] for row in tables['rules']['rows']) == 1
        rows = tables['entity_relations']['rows']
        assert len(rows) == 2 and len({row['id'] for row in rows}) == 2
        for row in rows:
            assert replay.UUID4.fullmatch(row['id'])
            assert row['created_at'] == row['updated_at'] == replay.CREATED
            assert row['valid_from'] is None and row['valid_until'] is None
    elif case['effect'] == 'repair-fts':
        definition = native['after']['tables']['memories_fts']['sql']
        assert "tokenize='porter unicode61'" in replay.canonical(definition)
        import sqlite3
        from contextlib import closing
        database = root / 'native/memory.db'
        digest_before = hashlib.sha256(database.read_bytes()).hexdigest()
        with closing(sqlite3.connect(database.as_uri() + '?immutable=1', uri=True)) as db:
            assert list(db.execute("SELECT id FROM memories_fts WHERE memories_fts MATCH 'run'")) == [('legacy-memory',)]
            assert not list(db.execute('PRAGMA foreign_key_check'))
        assert hashlib.sha256(database.read_bytes()).hexdigest() == digest_before
    else:
        assert case['effect'] == 'preserve-null'
        tables = native['after']['tables']
        assert sum(row['updated_at'] is None for row in tables['rules']['rows']) == 1
        rows = tables['entity_relations']['rows']
        assert sum(row['updated_at'] is None and row['valid_from'] is None and row['valid_until'] is None for row in rows) == 2
        assert rows == native['before']['tables']['entity_relations']['rows']
assert native_exits.count(0) == 3 and native_exits.count(1) == 6

original = ROOT / 'migration/evidence/memory-historical-649/sqlite-checker-a30/raw'
raw = gzip.decompress((original / '026-minimal.sql.gz').read_bytes())
proof = json.loads(gzip.decompress((original / '028-proof.json.gz').read_bytes()))
assert raw.endswith(b'\n') and hashlib.sha256(raw[:-1]).hexdigest() == proof['minimal']['input_sha256']
result = dict(source=binding['current_source'], reused_compiled_source=source,
              original_source_bindings=549, original_CLI_archive_roundtrip=True,
              verified_runtime_files=verified_files, pairs_exit0=37, native_reopens_exit0=37,
              source_current_comparator_recomputed_on_original_full_state=True,
              controls_go_exit0=9, controls_native_exit0=3, controls_native_exit1=6,
              historical_minimal_input_exact_bytes='retained file minus final newline matches original stdin SHA',
              native_new_pinned_Python_other_OS_claim=False, reviewer_product_or_compiler_execution=False)
(OUT / 'root-runtime-verification.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result, indent=2))
