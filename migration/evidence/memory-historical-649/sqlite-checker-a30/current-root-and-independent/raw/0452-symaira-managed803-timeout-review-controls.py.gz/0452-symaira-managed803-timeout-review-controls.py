import ast,gzip,hashlib,json,re,subprocess
from pathlib import Path
ROOT=Path('/workspace/symaira-managed803-timeout-diagnostic')
OUT=Path('/workspace/symaira-managed803-timeout-independent-static')
source=ROOT/'rust/symbrain-managed/tests/install_tests.rs'
text=source.read_text();marker='fn installed_version_timeout_is_bounded_and_reaps_descendants()'
script=Path('/workspace/symaira-managed803-timeout-review-verify.py')
t=ast.parse(script.read_bytes());funs=[n for n in t.body if isinstance(n,ast.FunctionDef) and n.name=='assertions']
token=re.compile(r'"(?:\\.|[^"\\])*"|[A-Za-z_][A-Za-z0-9_]*|\d+|::|->|=>|&&|\|\||==|!=|[^\s]')
ns={'tokens':lambda s:token.findall(s),'marker':marker};exec(compile(ast.Module(body=funs,type_ignores=[]),str(script),'exec'),ns)
parse=ns['assertions'];original=parse(text)
observations=[]
for name,old,new in [('error-predicate','error.to_string().contains("timed out")','error.to_string().contains("out")'),('budget','started.elapsed() < Duration::from_secs(5)','started.elapsed() < Duration::from_secs(50)'),('liveness','        !alive,','        true,')]:
 changed=text.replace(old,new);assert changed!=text and parse(changed)!=original
 observations.append({'case':name,'actual_source_predicate_scanner_rejects_mutation':True})
changed=text.replace('unexpected probe error:', 'different diagnostic only:')
assert parse(changed)==original
observations.append({'case':'message-only-preserves-predicates','passed':True})
old=subprocess.check_output(['git','show','5931cce3:rust/symbrain-managed/src/install.rs'],cwd=ROOT).decode()
new=(ROOT/'rust/symbrain-managed/src/version_probe.rs').read_text()
start='    let output = tempfile::NamedTempFile::new()'
end='\n// Go checks the original file'
oldbody=old[old.index(start,old.index('pub fn installed_version')):old.index('\n#[must_use]\npub fn versions_match',old.index('pub fn installed_version'))]
newbody=new[new.index(start):new.index(end)]
assert oldbody==newbody
oldtest=subprocess.check_output(['git','show','5931cce3:rust/symbrain-managed/tests/install_tests.rs'],cwd=ROOT).decode()
base=subprocess.check_output(['git','show','729184d8:rust/symbrain-managed/tests/install_tests.rs'],cwd=ROOT).decode()
assert oldtest[oldtest.index(marker):]==base[base.index(marker):]
observations.append({'case':'historical-applicable-Unix-probe-and-timeout-fixture-exact','passed':True,'comparison':'literal byte equality, excluding newly added Windows resolution before NamedTempFile and unrelated versions_match function'})
log=(OUT/'decoded/original/coverage-ci-job-111389667920.log').read_text()
assert 'assertion failed: error.to_string().contains("timed out")' in log
assert '6 passed; 1 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.04s' in log
assert 'Merge a30bba8bbd52323fa5e000207f1c391d576ac86c into 5e232700bb9031fc34d4995465a4037837540abb' in log
assert 'probe tool:' not in log
observations.append({'case':'original-coverage-failure-preserved-without-returned-error','passed':True,'current-CI-ELF-provenance-from-filename':False})
records=[]
commands=[('rustfmt',['/home/agent/.rustup/toolchains/1.98.0-x86_64-unknown-linux-gnu/bin/rustfmt','--edition','2024','--check',str(source)]),('diff-check',['git','diff','--check','729184d8addbe94db7d1d172186afa4616565889','HEAD'])]
for name,argv in commands:
 p=subprocess.run(argv,cwd=ROOT,capture_output=True)
 for label,b in [('stdout',p.stdout),('stderr',p.stderr)]: (OUT/(name+'.'+label)).write_bytes(b)
 records.append({'command':argv,'exit':p.returncode,'stdout_sha256':hashlib.sha256(p.stdout).hexdigest(),'stderr_sha256':hashlib.sha256(p.stderr).hexdigest()});assert p.returncode==0
report={'candidate':'a7faefd8b0d218dc20baa5c651bfa8f7fbea1732','portable_source_controls':observations,'static_gates':records,'new_Rust_source_compiled_or_executed':False,'product_executions':0,'target_access':False,'ports':False,'TMPDIR_policy':'All review outputs are owned workspace paths; no /tmp fixture creation.'}
(OUT/'controls.json').write_text(json.dumps(report,indent=2)+'\n')
print('Six portable source/provenance observations and two static gates PASS; no product/compiler/target/port.')
