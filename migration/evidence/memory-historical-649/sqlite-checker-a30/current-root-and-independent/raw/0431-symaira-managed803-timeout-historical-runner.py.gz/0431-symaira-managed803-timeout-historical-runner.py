import hashlib
import json
import os
from pathlib import Path
import shutil
import signal
import subprocess
import time

os.umask(0o022)
root = Path('/workspace/oracles/symaira-managed803-timeout-diagnostic-runs')
exe = root / 'managed-install-tests-5931'
records = []
for label, args in [('focused', ['--exact', 'installed_version_timeout_is_bounded_and_reaps_descendants', '--nocapture']), ('full-historical-six', ['--nocapture'])]:
    assert shutil.disk_usage(root).free >= 700 * 1024 * 1024
    work = root / label
    work.mkdir()
    for name in ['home', 'config', 'data', 'cache', 'tmp', 'profiles']:
        (work / name).mkdir()
    env = {'HOME': str(work / 'home'), 'XDG_CONFIG_HOME': str(work / 'config'), 'XDG_DATA_HOME': str(work / 'data'), 'XDG_CACHE_HOME': str(work / 'cache'), 'TMPDIR': str(work / 'tmp'), 'PATH': '/workspace/toolchains/go1.26.7/bin:/usr/bin:/bin', 'LLVM_PROFILE_FILE': str(work / 'profiles' / '%m-%p.profraw'), 'RUST_BACKTRACE': '1', 'LANG': 'C.UTF-8'}
    argv = ['/usr/bin/strace', '-ff', '-ttt', '-s', '512', '-yy', '-o', str(work / 'trace'), '-e', 'trace=process,desc,file', str(exe), *args]
    started = time.monotonic()
    with (work / 'stdout').open('wb') as out, (work / 'stderr').open('wb') as err:
        process = subprocess.Popen(argv, cwd=work, env=env, stdout=out, stderr=err, start_new_session=True)
        timeout = False
        try:
            status = process.wait(timeout=15)
        except subprocess.TimeoutExpired:
            timeout = True
            os.killpg(process.pid, signal.SIGKILL)
            status = process.wait()
    records.append({'label': label, 'argv': argv, 'env': env, 'cwd': str(work), 'status': status, 'timeout': timeout, 'elapsed_seconds': time.monotonic() - started, 'historical_source': '5931cce3e4fe3e090b361fb3f9aca7e07b7ad49b', 'binary_sha256': hashlib.sha256(exe.read_bytes()).hexdigest(), 'current_CI_reproduction': False})
    (root / 'runs.json').write_text(json.dumps(records, indent=2) + '\n')
    print(json.dumps(records[-1]), flush=True)
