import gzip,hashlib,json,re,subprocess,tomllib
from pathlib import Path
ROOT=Path('/workspace/symaira-managed803-timeout-diagnostic')
OUT=Path('/workspace/symaira-managed803-timeout-independent-static')
OUT.mkdir(exist_ok=False)
E=ROOT/'migration/evidence/managed-timeout-803'
sha=lambda b:hashlib.sha256(b).hexdigest()
git=lambda rev,path:subprocess.check_output(['git','show',rev+':'+path],cwd=ROOT)
handoff=Path('/tmp/symaira-managed803-timeout-final-handoff.json')
h=json.loads(handoff.read_bytes()); head=h['source_and_publication_head'];base=h['base'];hist=h['historical_tests']['archive_source']
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT).decode().strip()==head
assert not subprocess.check_output(['git','status','--porcelain'],cwd=ROOT)
changed=[]
for name in h['changed_paths']:
 b=(ROOT/name).read_bytes();p=OUT/'candidate'/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)
 changed.append({'path':name,'bytes':len(b),'sha256':sha(b)})
for row in h['tracked_maps']:assert sha(Path(row['path']).read_bytes())==row['sha256']
c=json.loads((E/'source-controls.json').read_bytes())
for row in c['unchanged_protected_sources']:
 b=(ROOT/row['path']).read_bytes();assert sha(b)==row['sha256'] and b==git(base,row['path']),row['path']
decoded={}; raw=[]
for name in ['original','historical-runs']:
 ret=json.loads((E/name/'retention.json').read_bytes())
 for row in ret['records']:
  archive=E/name/row['archive'] if 'archive' in row else E/row['path']
  compressed=archive.read_bytes();b=gzip.decompress(compressed)
  assert sha(compressed)==row['archive_sha256'] and sha(b)==row['sha256'] and len(b)==row['bytes'],archive
  rel=str(archive.relative_to(E)).removesuffix('.gz');p=OUT/'decoded'/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)
  decoded[rel]=b;raw.append({'path':str(archive),'compressed_sha256':sha(compressed),'sha256':sha(b),'bytes':len(b)})
for name in ['Cargo.lock','rust-toolchain.toml','rust/symbrain-managed/Cargo.toml','rust/symbrain-managed/src/install.rs','rust/symbrain-managed/src/version_probe.rs','rust/symbrain-managed/src/lib.rs','rust/symbrain-managed/src/manifest.rs','rust/symbrain-managed/tests/install_tests.rs']:
 assert git(base,name)==git(h['CI_publication'],name),name
def closure(lock):
 packages=tomllib.loads(lock.decode())['package'];selected={};pending=[next(p for p in packages if p['name']=='symbrain-managed')]
 while pending:
  p=pending.pop();key=(p['name'],p['version'],p.get('source',''))
  if key in selected:continue
  selected[key]=p
  for dep in p.get('dependencies',[]):
   words=dep.split();match=[v for v in packages if v['name']==words[0] and (len(words)<2 or v['version']==words[1])]
   assert len(match)==1,(dep,match)
   pending.append(match[0])
 return sorted(selected.values(),key=lambda p:(p['name'],p['version'],p.get('source','')))
oldclosure=closure(git(hist,'Cargo.lock'));newclosure=closure((ROOT/'Cargo.lock').read_bytes())
assert oldclosure==newclosure==json.loads((E/'managed-lock-closure.json').read_bytes())['packages']
assert git(hist,'rust/symbrain-managed/Cargo.toml')==(ROOT/'rust/symbrain-managed/Cargo.toml').read_bytes()
assert git(hist,'rust-toolchain.toml')==(ROOT/'rust-toolchain.toml').read_bytes()
path='rust/symbrain-managed/tests/install_tests.rs';current=(ROOT/path).read_text();parent=git(base,path).decode()
marker='fn installed_version_timeout_is_bounded_and_reaps_descendants()'
assert current[:current.index(marker)]==parent[:parent.index(marker)]
assert len(current.splitlines())==374
# A lexer sufficient for the changed ordinary-string Rust function; strings
# are atomic so diagnostic format braces cannot affect statement boundaries.
token=re.compile(r'"(?:\\.|[^"\\])*"|[A-Za-z_][A-Za-z0-9_]*|\d+|::|->|=>|&&|\|\||==|!=|[^\s]')
tokens=lambda s:token.findall(s)
def assertions(text):
 ts=tokens(text[text.index(marker):]);result=[]
 for i in range(len(ts)-2):
  if ts[i:i+3]!=['assert','!','(']:continue
  depth=0;j=i+3;condition=[]
  while j<len(ts):
   t=ts[j]
   if depth==0 and t in [',',')']:break
   if t in ['(','[','{']:depth+=1
   elif t in [')',']','}']:depth-=1
   condition.append(t);j+=1
  result.append(condition)
 return result
assert assertions(current)==assertions(parent)
before='    let error = installed_version(temp.path(), "tool").unwrap_err();'
assert current[current.index(marker):current.index(before)+len(before)]==parent[parent.index(marker):parent.index(before)+len(before)]
alive='    let alive = Command::new("/bin/kill")'
assert current[current.index(alive):current.index('    assert!(',current.index(alive))]==parent[parent.index(alive):parent.index('    assert!(',parent.index(alive))]
receipt=json.loads(decoded['original/historical-coverage-receipt.json'])
role='llvm-cov-target/debug/deps/install_tests-a2623068a0289a0a';r=receipt['files'][role]
archive=Path(r['gzip_path']);compressed=archive.read_bytes();assert sha(compressed)==r['gzip_sha256'];elf=gzip.decompress(compressed)
assert len(elf)==r['original_bytes'] and sha(elf)==r['original_sha256']==h['historical_tests']['binary_sha256']
assert elf[:4]==b'\x7fELF' and b'installed_version_timeout_is_bounded_and_reaps_descendants' in elf
assert b'rust/symbrain-managed/tests/install_tests.rs' in elf and b'rust/symbrain-skills/tests/install_tests.rs' not in elf
finger='llvm-cov-target/debug/.fingerprint/symbrain-managed-a2623068a0289a0a/test-integration-test-install_tests.json';f=receipt['files'][finger];fb=Path(f['gzip_path']).read_bytes();fd=gzip.decompress(fb)
assert sha(fb)==f['gzip_sha256'] and sha(fd)==f['original_sha256'] and len(fd)==f['original_bytes']
(OUT/'historical-managed-fingerprint.json').write_bytes(fd)
runs=json.loads(decoded['historical-runs/runs.json']);assert len(runs)==2
for run in runs:
 assert run['status']==0 and not run['timeout'] and not run['current_CI_reproduction']
 assert run['binary_sha256']==sha(elf)
 output=decoded['historical-runs/'+run['label']+'/stdout'].decode()
 assert ('1 passed; 0 failed' if run['label']=='focused' else '6 passed; 0 failed') in output
for facts in json.loads((E/'historical-process-facts.json').read_bytes()):
 for row in facts['selected_exact_lines']:
  key='historical-runs/'+facts['label']+'/'+Path(row['trace']).name
  assert row['line'] in decoded[key].decode().splitlines(),row
for name in ['initial-floor-stop','second-floor-stop']:
 d=json.loads(decoded['historical-runs/'+name+'.json']);assert d['free_bytes']<d['required_bytes'];assert not d.get('product_or_strace_started',d.get('product_started'))
summary={'candidate':head,'base':base,'source_clean':True,'changed_files':len(changed),'changed_rust_files':[r['path'] for r in changed if r['path'].endswith('.rs')],
 'protected_files':len(c['unchanged_protected_sources']),'raw_archives':len(raw),'managed_lock_closure':len(newclosure),'timeout_predicates':assertions(current),
 'fixture_setup_unchanged':True,'all_other_test_functions_unchanged':True,'liveness_call_unchanged':True,'historical_ELF':{'bytes':len(elf),'sha256':sha(elf),'archive':str(archive),'archive_sha256':sha(compressed)},
 'historical_runs_verified':2,'actual_current_source_runtime_executed':False,'compiler_target_port_product_access':False}
(OUT/'provenance.json').write_text(json.dumps(summary,indent=2)+'\n');(OUT/'raw-map.json').write_text(json.dumps(raw,indent=2)+'\n');(OUT/'changed-map.json').write_text(json.dumps(changed,indent=2)+'\n');(OUT/'handoff.json').write_bytes(handoff.read_bytes())
print(json.dumps(summary,indent=2))
