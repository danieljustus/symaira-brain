"""Full source/archive verifier; no SQLite/SDK/product/target execution."""
import ast
import gzip
import hashlib
import io
import json
from pathlib import Path
import subprocess
import tarfile
import zipfile

ROOT = Path('/workspace/symaira-memory803-provider-admission')
OUT = Path('/workspace/review-artifacts/memory803-a5c65-provider-review-doctor')
HEAD = 'a5c65c706ac4cb271fde26d9063b0f4afff1b420'
PARENT = 'c310cb54bb4f6d871eb6ba419da5e37740a377f2'
BASE = 'f428a866d7817c269cdfc32b6affc50dfe014418'
bound = {}; counts = {}


def sha(data):
    return hashlib.sha256(data).hexdigest()


def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT)


def file(path, expected=None):
    path = Path(path)
    digest = hashlib.sha256()
    with path.open('rb') as stream:
        for part in iter(lambda: stream.read(1024 * 1024), b''):
            digest.update(part)
    value = digest.hexdigest()
    if expected is not None:
        assert value == expected, str(path)
    bound[str(path)] = value
    return value


def blob(path, revision=HEAD):
    value = git('show', revision + ':' + path)
    bound[revision + ':' + path] = sha(value)
    return value


def bundle(path, manifest):
    with tarfile.open(path, 'r:gz') as archive:
        rows = archive.getmembers()
        assert len(rows) == len(manifest) and {r.name for r in rows} == set(manifest)
        output = {}
        for row in rows:
            assert row.isfile() and not row.issym() and not row.islnk()
            value = archive.extractfile(row).read()
            expected = manifest[row.name]
            assert len(value) == expected['bytes'] and sha(value) == expected['sha256'], row.name
            if 'native_mode' in expected:
                assert row.mode == expected['native_mode'], row.name
            output[row.name] = value
    return output


assert git('rev-parse', 'HEAD').decode().strip() == HEAD
assert not git('status', '--porcelain')
handoff_path = Path('/workspace/review-proof/review-pr800-memory803-provider-admission/final-handoff.json')
file(handoff_path, 'f5b3ecf63d834194cf043c2beabd9e3a969705d871a21fa9fbcfb6638134cb1e')
handoff = json.loads(handoff_path.read_bytes())
for name, row in handoff['changed_files'].items():
    file(ROOT / name, row['sha256'])
    assert (ROOT / name).stat().st_size == row['bytes']
assert set(git('diff', '--name-only', PARENT, HEAD).decode().splitlines()) == set(handoff['changed_files'])
counts['new_changed_files'] = len(handoff['changed_files'])
old_receipt_path = Path('/workspace/review-artifacts/memory803-c310-provider-review-doctor/independent-review-receipt.json')
file(old_receipt_path, '9df7fd760e1c1fc62e61dd2ab73adf9d26e24643be8e2dd984879f6b8cefa155')
old = json.loads(old_receipt_path.read_bytes())
for path, expected in old['files_sha256'].items():
    file(path, expected)
counts['all_previous_review_bindings'] = len(old['files_sha256'])
assert counts['all_previous_review_bindings'] == 130
# Full c310 original source/evidence delta; successor modifies only the13 named paths.
old_handoff_path = Path('/workspace/review-proof/review-pr800-ci794-803-current/memory803-provider-final-handoff.json')
old_handoff = json.loads(old_handoff_path.read_bytes())
for row in old_handoff['all75_changed_files']:
    assert sha(blob(row['path'], PARENT)) == row['sha256']
    if row['path'] not in handoff['changed_files']:
        assert blob(row['path']) == blob(row['path'], PARENT)
counts['all_original_changed_file_bindings'] = 75
provider_dir = ROOT / 'migration/evidence/memory-historical-649/provider-admission-c310'
original_manifest = json.loads((provider_dir / 'original-file-manifest.json').read_bytes())
provider_raw = bundle(provider_dir / 'full-admission-proof.tar.gz', original_manifest)
counts['admission_original_members'] = len(provider_raw)
with tarfile.open(fileobj=io.BytesIO(provider_raw['complete-independent-review.tar.gz']), mode='r:gz') as archive:
    rows = archive.getmembers()
    assert len(rows) == 22
    for row in rows:
        value = archive.extractfile(row).read()
        path = old_receipt_path.parent / row.name
        assert path.read_bytes() == value, row.name
counts['complete_old_review_members'] = 22
resource_dir = ROOT / 'migration/evidence/resource-archive-dedup-2026-10-04'
resource_manifest = json.loads((resource_dir / 'original-file-manifest.json').read_bytes())
resource_raw = bundle(resource_dir / 'full-resource-proof.tar.gz', resource_manifest)
counts['all_resource_original_members'] = len(resource_raw)
assert counts['all_resource_original_members'] == 52
for name, row in resource_manifest.items():
    file(row['original_path'], row['sha256'])
# Compiled product tree identities and native Git modes, without materialization.
protected = json.loads(blob('migration/evidence/memory-historical-649/sqlite-provider-f428/unchanged-product-tree-map.json'))
tree = {line.split(b'\t', 1)[1].decode(): line.split(b'\t', 1)[0].decode() for line in git('ls-tree', '-r', HEAD).splitlines()}
for row in protected['protected']:
    assert tree[row['path']] == row['tree_entry'], row['path']
counts['protected_product_tree_entries'] = len(protected['protected'])
assert counts['protected_product_tree_entries'] == 1513
# Full AST bodies and assertions, not just rewritten comparison snippets.
criteria = {}
for name in ('replay.py', 'controls.py', 'checker.py'):
    path = 'scripts/memory-historical-oracle/' + name
    current = ast.parse(blob(path)); original = ast.parse(blob(path, BASE)); parent = ast.parse(blob(path, PARENT))
    assert ast.dump(current, include_attributes=False) == ast.dump(parent, include_attributes=False), name
    predicates = lambda module: [ast.dump(n.test, include_attributes=False) for n in ast.walk(module) if isinstance(n, ast.Assert)]
    assert predicates(current) == predicates(original), name
    if name != 'checker.py':
        functions = lambda module: [ast.dump(n, include_attributes=False) for n in module.body if isinstance(n, ast.FunctionDef)]
        assert functions(current) == functions(original), name
    criteria[name] = {'functions': sum(isinstance(n, ast.FunctionDef) for n in current.body),
                      'assert_predicates': sum(isinstance(n, ast.Assert) for n in ast.walk(current)), 'entire_AST_identical_to_c310': True,
                      'assert_tests_identical_to_f428': True, 'all_function_AST_identical_to_f428': name != 'checker.py'}
resources = [p for p in git('ls-tree', '-r', '--name-only', HEAD, 'rust/symbrain-memory/src/migration/sql').decode().splitlines() if p.endswith('.sql')]
assert len(resources) == 37
for path in resources:
    assert blob(path) == blob('internal/memory/db/migrations/' + Path(path).name, 'dcddcef0df5789123c7c9a7ebe6e01f10e941f2c')
counts['frozen_SQL_resources'] = 37
# All original raw payloads/distributions and full298 Windows members.
prefix = 'migration/evidence/memory-historical-649/sqlite-provider-f428/'
raw = json.loads(blob(prefix + 'raw-bindings.json'))
for row in raw['all_retained']:
    value = blob(prefix + row['retained'])
    if 'gzip_sha256' in row:
        assert sha(value) == row['gzip_sha256']; value = gzip.decompress(value)
    assert sha(value) == row['sha256'] and len(value) == row['bytes']
counts['original_raw_payloads'] = len(raw['all_retained'])
for row in raw['full_owned_external_distribution_archives']:
    if row['retained_original'] is not None:
        file(row['retained_original'], row['sha256'])
        assert Path(row['retained_original']).stat().st_size == row['bytes']
    else:
        assert Path(row['primary_archive_original']).is_file()
        file(row['derivative_retirement_receipt'])
counts['primary_distribution_archives'] = 2
manifest = json.loads(gzip.decompress(blob(prefix + 'downloaded-windows803-artifact-manifest.json.gz')))
original_zip = gzip.decompress(blob(prefix + 'pr803-memory-cli-windows.zip.gz'))
assert sha(original_zip) == manifest['zip_sha256']
with zipfile.ZipFile(io.BytesIO(original_zip)) as archive:
    assert {r.filename for r in archive.infolist() if not r.is_dir()} == {r['name'] for r in manifest['members']}
    for row in manifest['members']:
        value = archive.read(row['name'])
        assert sha(value) == row['sha256'] and len(value) == row['bytes']
counts['full_Windows_ZIP_members'] = len(manifest['members'])
assert counts['full_Windows_ZIP_members'] == 298
# Old first13 full source-backed journal remains independently accessible.
first13 = blob('migration/evidence/resource-retirement-2026-10-04/full-audit.tar.gz', '5081205bbc27264bc0c701b92330410fcbe56c02')
assert sha(first13) == '35d1f96301584554808f0092069bc73541c05a8b927201b4f02fe1f583ca0296'
with tarfile.open(fileobj=io.BytesIO(first13), mode='r:gz') as archive:
    counts['first13_full_audit_members'] = len(archive.getmembers())
# All source Python ASTs; no SQLite import/execution during validation.
for path in (ROOT / 'scripts/memory-historical-oracle').glob('*.py'):
    ast.parse(path.read_bytes())
assert not git('status', '--porcelain')
result = {'source': HEAD, 'parent': PARENT, 'base': BASE, 'counts': counts, 'original_criteria': criteria,
          'bound': bound, 'SDK_C_Go_Rust_SQLite_Product_Target_Port_execution': False}
(OUT / 'verification.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({'counts': counts, 'criteria': criteria}))
