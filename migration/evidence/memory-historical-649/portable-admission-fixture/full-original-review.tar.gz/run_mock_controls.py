"""Fresh actual Python source mutations and owned simulated-loader controls."""
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import sys

ROOT = Path('/workspace/symaira-memory803-provider-admission/scripts/memory-historical-oracle')
OUT = Path('/workspace/review-artifacts/memory803-a5c65-provider-review-doctor')
sha = lambda value: hashlib.sha256(value).hexdigest()
original = (ROOT / 'provider.py').read_bytes()
mutations = {
    'skip-process-admission': (b'    identity()\n', b'    # owned source mutant deliberately skips admission\n'),
    'skip-extension-address-predicate': (b'        assert actual_address == expected_address, "extension bound another SQLite library"\n', b'        # owned source mutant deliberately skips actual extension predicate\n'),
}
rows = []
for name, (before, after) in mutations.items():
    assert original.count(before) == 1
    directory = OUT / name
    directory.mkdir()
    for filename in ('provider.py', 'checker.py', 'replay.py', 'controls.py', 'test_provider_admission.py'):
        value = (ROOT / filename).read_bytes()
        if filename == 'provider.py':
            value = value.replace(before, after)
        (directory / filename).write_bytes(value)
    args = [sys.executable, '-m', 'unittest', 'discover', '-s', str(directory), '-p', 'test_provider_admission.py', '-v']
    environment = dict(os.environ, PYTHONDONTWRITEBYTECODE='1', TMPDIR=str(OUT / 'tmp'))
    result = subprocess.run(args, env=environment, capture_output=True, check=False)
    (directory / 'stdout.log').write_bytes(result.stdout)
    (directory / 'stderr.log').write_bytes(result.stderr)
    assert result.returncode != 0 and b'FAILED (' in result.stderr
    for filename in ('test_provider_admission.py', 'checker.py', 'replay.py', 'controls.py'):
        assert (directory / filename).read_bytes() == (ROOT / filename).read_bytes()
    rows.append({'name': name, 'argv': args, 'exit': result.returncode, 'original_sha256': sha(original),
                 'mutant_sha256': sha((directory / 'provider.py').read_bytes()), 'stdout_sha256': sha(result.stdout),
                 'stderr_sha256': sha(result.stderr), 'unchanged_tests_and_entrypoints': True})
# Use the exact current Fixture callbacks, without loading a library, SQL or a child.
sys.path.insert(0, str(ROOT))
spec = importlib.util.spec_from_file_location('owned_admission_tests', ROOT / 'test_provider_admission.py')
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
additional = []
for entrypoint in ('checker', 'replay', 'controls'):
    for label, kwargs, trace in (
        ('wrong-version', {'version': '3.45.1'}, ['verified-library-handle', 'actual-extension-handle']),
        ('wrong-source-id', {'source_id': 'different'}, ['verified-library-handle', 'actual-extension-handle', 'identity-database', 'identity-SQL-callback', 'identity-close']),
    ):
        directory = OUT / ('additional-' + entrypoint + '-' + label)
        directory.mkdir()
        fixture = module.AdmissionFixture(directory, **kwargs)
        try:
            fixture.run(entrypoint)
        except AssertionError as error:
            assert fixture.trace == trace
            additional.append({'entrypoint': entrypoint, 'control': label, 'error': str(error), 'trace': fixture.trace})
        else:
            raise AssertionError('unhealthy provider reached consumer')
(OUT / 'mock-controls.json').write_text(json.dumps({'actual_python_source_mutants': rows, 'additional_mock_controls': additional,
                                                 'actual_SQLite_SDK_or_product_execution': False}, indent=2) + '\n')
print(json.dumps({'actual_source_mutants_rejected': len(rows), 'additional_mock_controls': len(additional)}))
