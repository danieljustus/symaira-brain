"""Portable simulated Windows os API boundary; not native Windows execution."""
import os
from pathlib import Path
import sys
import unittest

ROOT = Path('/workspace/symaira-memory803-provider-admission/scripts/memory-historical-oracle')
sys.path.insert(0, str(ROOT))
assert hasattr(os, 'RTLD_NOW'), 'the host source control expects Unix'
del os.RTLD_NOW
# The exact candidate tests spoof sys.platform but do not supply this Unix API.
# CDLL and SQLite are mocked by their unchanged fixtures; no real loader/SQL.
suite = unittest.defaultTestLoader.discover(str(ROOT), pattern='test_provider_admission.py')
result = unittest.TextTestRunner(verbosity=2).run(suite)
assert not result.wasSuccessful()
assert result.errors and all("module 'os' has no attribute 'RTLD_NOW'" in text for _, text in result.errors)
print('owned missing-constant control: all failures are exact pre-CDLL AttributeError; no native Windows claim')
sys.exit(0)
