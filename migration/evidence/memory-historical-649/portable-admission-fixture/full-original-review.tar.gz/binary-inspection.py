"""Read ELF/MachO bytes without invoking or loading an SDK image."""
import gzip,json,struct
from pathlib import Path
R=Path('/workspace/symaira-memory803-sqlite-provider');E=R/'migration/evidence/memory-historical-649/sqlite-provider-f428';O=Path('/workspace/review-artifacts/memory803-a5c65-provider-review-doctor')
def cstr(data,at):return data[at:data.index(b'\0',at)].decode('ascii')
el=gzip.decompress((E/'_sqlite3.cpython-313-x86_64-linux-gnu.so.gz').read_bytes());assert el[:6]==b'\x7fELF\x02\x01';offset=struct.unpack_from('<Q',el,40)[0];entry_size,num,string_index=struct.unpack_from('<HHH',el,58)
sections=[struct.unpack_from('<IIQQQQIIQQ',el,offset+i*entry_size) for i in range(num)];needed=[]
for sec in sections:
 if sec[1]!=6:continue
 strings=sections[sec[6]];pool=el[strings[4]:strings[4]+strings[5]]
 for pos in range(sec[4],sec[4]+sec[5],16):
  tag,val=struct.unpack_from('<QQ',el,pos)
  if tag==1:needed.append(cstr(pool,val))
assert 'libsqlite3.so.0' in needed
mo=gzip.decompress((E/'darwin-_sqlite3.cpython-313-darwin.so.gz').read_bytes());assert mo[:4]==b'\xca\xfe\xba\xbe';n=struct.unpack_from('>I',mo,4)[0];arches=[]
for i in range(n):
 cpu,sub,at,size,alignment=struct.unpack_from('>IIIII',mo,8+20*i);part=mo[at:at+size];assert part[:4]==b'\xcf\xfa\xed\xfe';cmds=struct.unpack_from('<I',part,16)[0];pos=32;loads=[]
 for _ in range(cmds):
  cmd,length=struct.unpack_from('<II',part,pos)
  if cmd in [0xc,0x80000018,0x8000001f,0x80000023]:loads.append(cstr(part,pos+struct.unpack_from('<I',part,pos+8)[0]))
  pos+=length
 assert loads==['/usr/lib/libSystem.B.dylib'],loads
 sid=b'2025-07-30 19:33:53 4d8adfb30e03f9cf27f800a2c1ba3c48fb4ca1b08b0f5ed59a4d5ecbf45e20a3';assert sid in part
 arches.append({'cpu':cpu,'bytes':size,'loaded_dylibs':loads,'official3504_source_ID_present':True})
assert len(arches)==2
result={'ELF_needed':needed,'MachO_architectures':arches,'scope':'pure image inspection only; no SDK/native load/execution; semantic runtime still required'}
(O/'binary-inspection.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
