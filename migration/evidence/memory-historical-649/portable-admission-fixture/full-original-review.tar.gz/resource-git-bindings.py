"""Verify all retained4502 source blobs through Git; no target/retirement access."""
import gzip
import hashlib
import json
from pathlib import Path
import subprocess
import tarfile
import threading

ROOT = Path('/workspace/symaira-memory803-provider-admission')
OUT = Path('/workspace/review-artifacts/memory803-a5c65-provider-review-doctor')
archive = ROOT / 'migration/evidence/resource-archive-dedup-2026-10-04/full-resource-proof.tar.gz'
with tarfile.open(archive) as bundle:
    rows = json.loads(bundle.extractfile('sixteenth-retirement/full-tracked-manifest.json').read())
    receipt = json.loads(bundle.extractfile('sixteenth-retirement/receipt.json').read())
    result = json.loads(bundle.extractfile('sixteenth-retirement/retirement-result.json').read())
    derivatives = receipt['only_ignored_derivatives']
    for row in derivatives:
        data = bundle.extractfile('sixteenth-retirement/' + Path(row['archive']).name).read()
        assert hashlib.sha256(data).hexdigest() == row['archive_sha256']
        assert hashlib.sha256(gzip.decompress(data)).hexdigest() == row['sha256']
assert len(rows) == 4502
revision = receipt['HEAD']
raw = subprocess.check_output(['git', 'ls-tree', '-r', '-z', revision], cwd=ROOT)
entries = {}
for item in raw.split(b'\0'):
    if item:
        header, name = item.split(b'\t', 1)
        mode, kind, oid = header.split()
        entries[name] = (mode.decode(), oid.decode())
assert set(entries) == {bytes.fromhex(row['relative_path_hex']) for row in rows}
requests = b''.join(row['blob'].encode() + b'\n' for row in rows)
process = subprocess.Popen(['git', 'cat-file', '--batch'], cwd=ROOT,
                           stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
def write():
    process.stdin.write(requests)
    process.stdin.close()
writer = threading.Thread(target=write)
writer.start()
for row in rows:
    name = bytes.fromhex(row['relative_path_hex'])
    assert entries[name] == (row['git_mode'], row['blob'])
    assert row['original_native_mode'] == row['surviving_native_mode'] and row['survivor_full_bytes_equal']
    oid, kind, length = process.stdout.readline().split()
    assert kind == b'blob' and oid.decode() == row['blob'] and int(length) == row['bytes']
    remaining = int(length); digest = hashlib.sha256()
    while remaining:
        chunk = process.stdout.read(min(remaining, 1024 * 1024))
        assert chunk
        digest.update(chunk); remaining -= len(chunk)
    assert digest.hexdigest() == row['sha256']
    assert process.stdout.read(1) == b'\n'
writer.join(); assert process.stdout.read() == b''; assert process.wait() == 0
assert not process.stderr.read()
value = {'retained_source': revision, 'all_Git_blob_mode_SHA_bindings': len(rows),
         'original_native_modes_and_equality_records': len(rows), 'full_derivative_roundtrips': len(derivatives),
         'retirement_result': result, 'actual_target_access_or_retirement': False,
         'scope': 'all immutable source Git bytes and retained metadata; no fresh liveness/global zero-reader claim'}
(OUT / 'resource-git-bindings.json').write_text(json.dumps(value, indent=2) + '\n')
print(json.dumps({k: v for k, v in value.items() if k != 'retirement_result'}))
