"""Independent complete source/metadata/archive review; no target checks."""
import ast,gzip,hashlib,io,json
from pathlib import Path
import subprocess,tarfile
R=Path('/workspace/symaira-memory803-portable-admission-fixture')
O=Path('/workspace/review-artifacts/memory803-c3ccc-portable-review-doctor')
HEAD='c3ccc7ccba6f4b6a0e459adad5c87a41c10a111d'
PARENT='a5c65c706ac4cb271fde26d9063b0f4afff1b420'
def sha(b):return hashlib.sha256(b).hexdigest()
def git(*a):return subprocess.check_output(['git','-C',str(R),*a])
def tree(ref):
 out={}
 for line in git('ls-tree','-r','-z',ref).split(b'\0'):
  if line:
   meta,name=line.split(b'\t',1);out[name.decode()]=meta.decode()
 return out
assert git('rev-parse','HEAD').decode().strip()==HEAD and git('status','--porcelain')==b''
old,new=tree(PARENT),tree(HEAD)
assert len(old)==4829 and len(new)==4835 and set(old)<=set(new)
changed=[p for p in old if old[p]!=new[p]];assert changed==['scripts/memory-historical-oracle/test_provider_admission.py']
paths=git('diff','--name-only',PARENT,HEAD).decode().splitlines();assert len(paths)==7
manifest=json.loads(Path('/workspace/symaira-memory803-portable-admission-final-manifest.json').read_bytes())
assert set(paths)=={str(Path(x['path']).relative_to(R)) for x in manifest}
for row in manifest:
 p=Path(row['path']);b=p.read_bytes();assert sha(b)==row['sha256'] and len(b)==row['bytes'];assert b==git('show',HEAD+':'+str(p.relative_to(R)))
ret=json.loads((R/'migration/evidence/memory-historical-649/portable-admission-fixture/original-retention.json').read_bytes())
assert ret['own_records']==58 and ret['prior_input_bindings']==422
physical=ret['physical_records'];immutable=ret['immutable_Git_records'];assert len(physical)==256 and len(immutable)==225
for row in physical:
 p=Path(row['original_path']);b=p.read_bytes();assert sha(b)==row['sha256'] and len(b)==row['bytes'];s=p.lstat()
 assert (s.st_mode,s.st_uid,s.st_gid,s.st_mtime_ns)==(row['mode'],row['uid'],row['gid'],row['mtime_ns']),str(p)
 if 'archive'in row:
  z=Path(row['archive']).read_bytes();assert sha(z)==row['archive_sha256'] and gzip.decompress(z)==b
 else:assert row['retained_existing_original_payload']==str(p)
for row in immutable:
 b=git('show',row['git_reference']);assert sha(b)==row['sha256'] and len(b)==row['bytes']
 ref,name=row['git_reference'].split(':',1);meta=git('ls-tree',ref,'--',name).decode().split('\t')[0].split();assert meta==[row['mode'],'blob',row['blob']]
archive=R/ret['own_full_review_tar'];raw=archive.read_bytes();assert sha(raw)==ret['own_full_review_tar_sha256']
with tarfile.open(fileobj=io.BytesIO(raw),mode='r:gz')as t:
 members=t.getmembers();assert len(members)==59
 for row in physical[:59]:
  name=row['original_path'].removeprefix('/workspace/review-artifacts/memory803-a5c65-provider-review-doctor/');m=t.getmember(name);b=t.extractfile(m).read();assert sha(b)==row['sha256'] and len(b)==row['bytes']
  assert (m.mode,m.uid,m.gid)==(row['mode']&0o7777,row['uid'],row['gid'])
  assert m.pax_headers['mtime']==f"{row['mtime_ns']//10**9}.{row['mtime_ns']%10**9:09d}"
def methods(raw):
 return {node.name+'.'+m.name:ast.dump(m,include_attributes=False)for node in ast.parse(raw).body if isinstance(node,ast.ClassDef)for m in node.body if isinstance(m,ast.FunctionDef)and m.name.startswith('test_')}
count=0
for name in ['test_provider.py','test_provider_admission.py']:
 p='scripts/memory-historical-oracle/'+name;a=methods(git('show',PARENT+':'+p));b=methods(git('show',HEAD+':'+p));assert a==b;count+=len(a)
assert count==14 and len(methods(git('show',HEAD+':scripts/memory-historical-oracle/test_provider_platform.py')))==3
for p in (R/'scripts/memory-historical-oracle').glob('*.py'):
 ast.parse(p.read_bytes());assert len(p.read_text().splitlines())<400
assert git('diff','--check',PARENT,HEAD)==b''
result={'source':HEAD,'parent':PARENT,'full_parent':len(old),'full_current':len(new),'unchanged_parent':len(old)-len(changed),'changed_parent':changed,'deltas':len(paths),'physical_metadata':len(physical),'immutable_Git':len(immutable),'original_tar_members':59,'original_method_AST_unchanged':count,'additional_methods':3,'C_SDK_SQLite_Product_Target_Port_runs':0}
(O/'successor-verification.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
