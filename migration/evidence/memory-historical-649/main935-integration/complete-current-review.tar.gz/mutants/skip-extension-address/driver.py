"""Unchanged test source; hard guards against actual loaders/SQL/product children."""
import sys
sys.dont_write_bytecode = True
import ctypes
import importlib.abc
import os
from pathlib import Path
import subprocess
import unittest
ROOT = Path('/workspace/review-artifacts/memory803-c3ccc-portable-review-doctor/mutants/skip-extension-address')
sys.path.insert(0, str(ROOT))
class NoSqlite(importlib.abc.MetaPathFinder):
    def find_spec(self, fullname, path, target=None):
        if fullname in ('sqlite3', '_sqlite3'):
            raise AssertionError('unallocated actual SQLite import: ' + fullname)
sys.meta_path.insert(0, NoSqlite())
def no_runtime(*args, **kwargs):
    raise AssertionError('unallocated real loader/SDK/product subprocess')
ctypes.CDLL = no_runtime
subprocess.run = no_runtime
assert 'sqlite3' not in sys.modules and '_sqlite3' not in sys.modules
suite = unittest.defaultTestLoader.discover(str(ROOT), pattern='test_provider*.py')
assert suite.countTestCases() == 17, suite.countTestCases()
result = unittest.TextTestRunner(verbosity=2).run(suite)
assert 'sqlite3' not in sys.modules and '_sqlite3' not in sys.modules
assert result.testsRun == 17
print('top-level17; added absent-host suite also checks six nested original methods; actual SDK/SQL/load/children0')
sys.exit(0 if result.wasSuccessful() else 1)
