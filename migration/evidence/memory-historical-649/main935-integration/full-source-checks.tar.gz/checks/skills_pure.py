"""Inherited pure Skills checks; only local Git children, no SDK/product/ports."""
import sys
sys.dont_write_bytecode=True
from pathlib import Path
import subprocess,unittest,shutil
ROOT=Path('/workspace/symaira-memory803-main935-integration');OUT=Path('/workspace/review-proof/memory803-main935-integration/checks');sys.path.insert(0,str(ROOT/'scripts/skills-argv-oracle'))
original=subprocess.Popen;git=Path(shutil.which('git')).resolve()
def guarded(argv,*a,**kw):
    assert Path(str(argv[0])).resolve()==git,('unallocated SDK/product child',argv)
    return original(argv,*a,**kw)
subprocess.Popen=guarded
suite=unittest.defaultTestLoader.discover(str(ROOT/'scripts/skills-argv-oracle'),pattern='test_build_go.py')
result=unittest.TextTestRunner(verbosity=2).run(suite);assert result.wasSuccessful() and result.testsRun==7
import novel
plan=OUT/'skills-original-plan.json';raw=subprocess.check_output([str(git),'-C',str(ROOT),'show','HEAD:'+str(novel.PLAN.relative_to(ROOT))]);plan.write_bytes(raw);assert novel.digest(raw)==novel.PLAN_SHA;novel.PLAN=plan
suite=unittest.defaultTestLoader.discover(str(ROOT/'scripts/skills-argv-oracle'),pattern='test_novel.py');result=unittest.TextTestRunner(verbosity=2).run(suite);assert result.wasSuccessful() and result.testsRun==4
print('seven source-admission/four plan tests PASS; only local Git children; no SDK/product runtime')
