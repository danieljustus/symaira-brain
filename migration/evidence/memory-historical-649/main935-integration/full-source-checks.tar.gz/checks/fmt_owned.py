"""Formatting only, exact merged Rust bytes in an owned source copy; no compiler."""
from pathlib import Path
import subprocess,hashlib,json
ROOT=Path('/workspace/symaira-memory803-main935-integration');OUT=Path('/workspace/review-proof/memory803-main935-integration/checks');FMT=Path('/home/agent/.rustup/toolchains/1.98.0-x86_64-unknown-linux-gnu/bin/rustfmt')
names=subprocess.check_output(['git','-C',str(ROOT),'diff','--name-only','c3ccc7ccba6f4b6a0e459adad5c87a41c10a111d','HEAD','--','rust/**/*.rs'],text=True).splitlines()
rows=[];paths=[]
for name in names:
 raw=subprocess.check_output(['git','-C',str(ROOT),'show','HEAD:'+name]);p=OUT/'fmt-owned'/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(raw);paths.append(str(p));rows.append({'path':name,'sha256':hashlib.sha256(raw).hexdigest()})
argv=[str(FMT),'--check','--edition','2024','--config','skip_children=true',*paths]
r=subprocess.run(argv,capture_output=True,timeout=30);(OUT/'rustfmt.stdout').write_bytes(r.stdout);(OUT/'rustfmt.stderr').write_bytes(r.stderr);assert r.returncode==0,(r.returncode,r.stdout,r.stderr)
(OUT/'rustfmt-source-binding.json').write_text(json.dumps({'formatter':str(FMT),'formatter_sha256':hashlib.sha256(FMT.read_bytes()).hexdigest(),'argv':argv,'source_files':rows,'exit':r.returncode,'scope':'format-only; no Cargo/compiler/target/SDK product execution'},indent=2)+'\n');print('format-only files',len(paths),'PASS')
