"""Full immutable parent union, exact CI/criteria and source-only checks."""
from pathlib import Path
import subprocess,json,yaml,ast
ROOT=Path('/workspace/symaira-memory803-main935-integration');OUT=Path('/workspace/review-proof/memory803-main935-integration/checks');OURS='c3ccc7ccba6f4b6a0e459adad5c87a41c10a111d';MAIN='9353520a34c5819c7d0a6cd58d3bfaa2b22b045b'
def git(*a):return subprocess.check_output(['git','-C',str(ROOT),*a])
def tree(ref):return {x.split(b'\t',1)[1].decode():x.split(b'\t',1)[0].decode() for x in git('ls-tree','-r',ref).splitlines()}
a,b,c=map(tree,[OURS,MAIN,'HEAD']);base_ref=git('merge-base',OURS,MAIN).decode().strip();base=tree(base_ref);bothdifferent=[]
for name in set(a)|set(b):
 if name in a and name in b and a[name]!=b[name]:
  if a.get(name)!=base.get(name) and b.get(name)!=base.get(name):bothdifferent.append(name)
  elif a.get(name)==base.get(name):assert c[name]==b[name],name
  elif b.get(name)==base.get(name):assert c[name]==a[name],name
 else:assert c[name]==a.get(name,b.get(name)),name
assert set(bothdifferent)=={'.github/workflows/ci.yml','MIGRATION-RUST.md','migration/contract-matrix.csv'}
# The third path merged automatically. Reproduce exactly Git's ordinary text merge.
merge_paths=[]
for ref,label in [(OURS,'ours'),(base_ref,'base'),(MAIN,'main')]:
 path=OUT/('migration-rust.'+label);path.write_bytes(git('show',ref+':MIGRATION-RUST.md'));merge_paths.append(str(path))
result=subprocess.run(['git','merge-file','-p',*merge_paths],capture_output=True)
assert result.returncode==0 and result.stdout==git('show','HEAD:MIGRATION-RUST.md')
path='.github/workflows/ci.yml';oa,ma,ca=[yaml.safe_load(git('show',ref+':'+path))for ref in [OURS,MAIN,'HEAD']]
for doc in [oa,ma]:
 for key,value in doc.items():
  if key!='jobs':assert ca[key]==value,key
 for job,value in doc['jobs'].items():
  for key,x in value.items():
   if key!='steps':assert ca['jobs'][job][key]==x,(job,key)
  for step in value['steps']:
   if step in ca['jobs'][job]['steps']:continue
   assert step['name']=='Go/Rust executable parity on native Windows'
   current=next(s for s in ca['jobs'][job]['steps']if s.get('name')==step['name'])
   assert all(current[k]==x for k,x in step.items()),step
w=ca['jobs']['rust-migration-windows']['steps'];names=[s.get('name')for s in w]
assert len(w)==23 and len([x for x in names if x is not None])==len(set(x for x in names if x is not None))
for step in [s for s in w if s.get('uses','').startswith('actions/upload-artifact')]:
 assert step['if']=='always()' and step['with']['if-no-files-found']=='error' and step['with']['retention-days']==14,step
assert git('show','HEAD:.github/workflows/memory-cli-native.yml')==git('show',OURS+':.github/workflows/memory-cli-native.yml')
lines=lambda ref:git('show',ref+':migration/contract-matrix.csv').decode().splitlines()
current={x.split(',',1)[0]:x for x in lines('HEAD')}
for x in lines(MAIN):
 if x.startswith(('SKL-005,','SKL-006,','SKL-007,','ACT-')):assert current[x.split(',',1)[0]]==x
for x in lines(OURS):
 if x.startswith('ACT-'):assert current[x.split(',',1)[0]]==x
py=0
for directory in ['scripts/memory-historical-oracle','scripts/skills-argv-oracle']:
 for p in (ROOT/directory).glob('*.py'):ast.parse(p.read_bytes());assert len(p.read_text().splitlines())<400,p;py+=1
sql=[p for p in c if p.startswith('rust/symbrain-memory/src/migration/sql/') and p.endswith('.sql')];assert len(sql)==37
for p in sql:assert c[p]==a[p]
protected=['scripts/memory-historical-oracle','rust/symbrain-memory','rust/symbrain-cli/src/memory','rust/symbrain-cli/tests/memory','scripts/memory-cli-oracle','.github/workflows/memory-cli-native.yml']
protected_count=sum(any(p.startswith(prefix)for prefix in protected)for p in a)
for p in a:
 if any(p.startswith(prefix)for prefix in protected):assert c[p]==a[p],p
result={'source':git('rev-parse','HEAD').decode().strip(),'ours':OURS,'main':MAIN,'full_files':len(c),'two_sided_changes':sorted(bothdifferent),'actual_conflicts':['.github/workflows/ci.yml','migration/contract-matrix.csv'],'automatic_MIGRATION_RUST_merge_reproduced':True,'whole_tree_owner_union_except_recorded_three_metadata_paths':True,'all_parent_CI_steps_and_conditions_preserved':True,'windows_step_count':23,'Memory_CI_exact_original':True,'main_SKL005_006_007_exact':True,'all_Activity_rows_exact':True,'Python_AST_files_under400':py,'memory_original37_SQL_exact':True,'unchanged_memory_owner_files':protected_count,'actual_compiler_SDK_SQLite_Product_Target_Port':0}
(OUT/'source-union.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
