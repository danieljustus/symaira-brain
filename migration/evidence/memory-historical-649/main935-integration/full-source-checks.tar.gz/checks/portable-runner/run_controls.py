"""Owned actual Python-source mutants. No native loader, SQL, SDK or product."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
BASE = Path(__file__).parent
SOURCE = BASE / 'runner-tree/scripts/memory-historical-oracle'
DRIVER = (BASE / 'run_portable.py').read_text()
# Exact current provider statements, not invented output expectations.
raw = (SOURCE / 'provider.py').read_text()
flags = 'mode=ctypes.RTLD_GLOBAL | os.RTLD_NOW'
mutants = {
    'missing-global': raw.replace(flags, 'mode=os.RTLD_NOW'),
    'missing-now': raw.replace(flags, 'mode=ctypes.RTLD_GLOBAL'),
    'zero-mode': raw.replace(flags, 'mode=0'),
    'explicit-extension-mode': raw.replace('ctypes.CDLL(_sqlite3.__file__)', 'ctypes.CDLL(_sqlite3.__file__, mode=ctypes.RTLD_GLOBAL | os.RTLD_NOW)'),
    'skip-process-admission': raw.replace('    identity()\n', '    # actual mutant: no interpreter admission\n'),
    'skip-extension-address': raw.replace('assert actual_address == expected_address, "extension bound another SQLite library"', 'assert True, "extension bound another SQLite library"'),
}
records=[]
for name, body in mutants.items():
    assert body != raw
    folder = BASE / 'mutants' / name
    folder.mkdir(parents=True)
    for path in SOURCE.glob('*.py'):
        (folder / path.name).write_bytes(path.read_bytes())
    (folder / 'provider.py').write_text(body)
    # Each unchanged test's SDK archive reference selects the same retained bytes.
    test = folder / 'test_provider.py'
    original = test.read_text()
    original = original.replace('SDK = ROOT / "migration/evidence/memory-historical-649/sqlite-provider-f428/sqlite-amalgamation-3500400.zip"', 'SDK = Path(' + repr(str(BASE / 'runner-tree/migration/evidence/memory-historical-649/sqlite-provider-f428/sqlite-amalgamation-3500400.zip')) + ')')
    test.write_text(original)
    driver = DRIVER.replace("ROOT = Path(__file__).parent / 'runner-tree/scripts/memory-historical-oracle'", 'ROOT = Path(' + repr(str(folder)) + ')')
    (folder / 'driver.py').write_text(driver)
    env={'PATH':os.environ.get('PATH',''),'PYTHONDONTWRITEBYTECODE':'1','TMPDIR':str(BASE / 'tmp')}
    result=subprocess.run([sys.executable,str(folder/'driver.py')],env=env,capture_output=True,timeout=30)
    (folder/'stdout').write_bytes(result.stdout);(folder/'stderr').write_bytes(result.stderr)
    assert result.returncode != 0, name
    assert b'Ran 17 tests' in result.stderr, name
    assert b'unallocated' not in result.stderr, (name,result.stderr)
    records.append({'name':name,'exit':result.returncode,'provider_source_sha256':hashlib.sha256(body.encode()).hexdigest(),'full17_tests_executed':True,'rejects':True})
# The exact current original six methods pass when both host constants are absent.
probe = BASE / 'missing-host-current.py'
script = DRIVER.split('suite = unittest.defaultTestLoader.discover')[0] + '''
import test_provider_admission as admission
from unittest.mock import patch
before = ('RTLD_NOW' in os.__dict__, os.__dict__.get('RTLD_NOW'), 'RTLD_GLOBAL' in ctypes.__dict__, ctypes.__dict__.get('RTLD_GLOBAL'))
with patch.dict(os.__dict__), patch.dict(ctypes.__dict__):
    os.__dict__.pop('RTLD_NOW',None)
    ctypes.__dict__.pop('RTLD_GLOBAL',None)
    suite=unittest.defaultTestLoader.loadTestsFromTestCase(admission.ProviderAdmission)
    result=unittest.TextTestRunner(verbosity=2).run(suite)
    assert result.testsRun==6 and result.wasSuccessful()
    assert 'RTLD_NOW' not in os.__dict__ and 'RTLD_GLOBAL' not in ctypes.__dict__
after = ('RTLD_NOW' in os.__dict__, os.__dict__.get('RTLD_NOW'), 'RTLD_GLOBAL' in ctypes.__dict__, ctypes.__dict__.get('RTLD_GLOBAL'))
assert after == before
print('exact six current methods pass; both absent host constants restored exactly; simulated boundary only')
'''
probe.write_text(script)
result=subprocess.run([sys.executable,str(probe)],env={'PATH':os.environ.get('PATH',''),'PYTHONDONTWRITEBYTECODE':'1','TMPDIR':str(BASE/'tmp')},capture_output=True,timeout=30)
(BASE/'missing-host-current.stdout').write_bytes(result.stdout);(BASE/'missing-host-current.stderr').write_bytes(result.stderr)
assert result.returncode==0
(BASE/'source-controls.json').write_text(json.dumps({'source_mutants':records,'missing_host_control_methods':6,'missing_host_pass':True,'native_runtime':False},indent=2)+'\n')
print(json.dumps(records))
