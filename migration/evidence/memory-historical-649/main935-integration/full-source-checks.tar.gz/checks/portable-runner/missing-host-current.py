"""Unchanged test source; hard guards against actual loaders/SQL/product children."""
import sys
sys.dont_write_bytecode = True
import ctypes
import importlib.abc
import os
from pathlib import Path
import subprocess
import unittest
ROOT = Path(__file__).parent / 'runner-tree/scripts/memory-historical-oracle'
sys.path.insert(0, str(ROOT))
class NoSqlite(importlib.abc.MetaPathFinder):
    def find_spec(self, fullname, path, target=None):
        if fullname in ('sqlite3', '_sqlite3'):
            raise AssertionError('unallocated actual SQLite import: ' + fullname)
sys.meta_path.insert(0, NoSqlite())
def no_runtime(*args, **kwargs):
    raise AssertionError('unallocated real loader/SDK/product subprocess')
ctypes.CDLL = no_runtime
subprocess.run = no_runtime
assert 'sqlite3' not in sys.modules and '_sqlite3' not in sys.modules

import test_provider_admission as admission
from unittest.mock import patch
before = ('RTLD_NOW' in os.__dict__, os.__dict__.get('RTLD_NOW'), 'RTLD_GLOBAL' in ctypes.__dict__, ctypes.__dict__.get('RTLD_GLOBAL'))
with patch.dict(os.__dict__), patch.dict(ctypes.__dict__):
    os.__dict__.pop('RTLD_NOW',None)
    ctypes.__dict__.pop('RTLD_GLOBAL',None)
    suite=unittest.defaultTestLoader.loadTestsFromTestCase(admission.ProviderAdmission)
    result=unittest.TextTestRunner(verbosity=2).run(suite)
    assert result.testsRun==6 and result.wasSuccessful()
    assert 'RTLD_NOW' not in os.__dict__ and 'RTLD_GLOBAL' not in ctypes.__dict__
after = ('RTLD_NOW' in os.__dict__, os.__dict__.get('RTLD_NOW'), 'RTLD_GLOBAL' in ctypes.__dict__, ctypes.__dict__.get('RTLD_GLOBAL'))
assert after == before
print('exact six current methods pass; both absent host constants restored exactly; simulated boundary only')
