"""Original source-level host patch controls in the merged owned copy."""
import json,os,subprocess,sys
from pathlib import Path
ROOT=Path(__file__).parent/'portable-runner';SOURCE=ROOT/'runner-tree/scripts/memory-historical-oracle';driver=(ROOT/'run_portable.py').read_text();body=(SOURCE/'test_provider_admission.py').read_text();rows=[]
for name,line in [('omit-now-host-patch','            stack.enter_context(patch.object(os, \'RTLD_NOW\', LINUX_RTLD_NOW, create=True))\n'),('omit-global-host-patch','            stack.enter_context(patch.object(provider.ctypes, \'RTLD_GLOBAL\', LINUX_RTLD_GLOBAL, create=True))\n')]:
 assert line in body;folder=ROOT/'mutants'/name;folder.mkdir()
 for p in SOURCE.glob('*.py'):(folder/p.name).write_bytes(p.read_bytes())
 (folder/'test_provider_admission.py').write_text(body.replace(line,''))
 p=folder/'test_provider.py';text=p.read_text();text=text.replace('SDK = ROOT / "migration/evidence/memory-historical-649/sqlite-provider-f428/sqlite-amalgamation-3500400.zip"','SDK = Path('+repr(str(ROOT/'runner-tree/migration/evidence/memory-historical-649/sqlite-provider-f428/sqlite-amalgamation-3500400.zip'))+')');p.write_text(text)
 (folder/'driver.py').write_text(driver.replace("ROOT = Path(__file__).parent / 'runner-tree/scripts/memory-historical-oracle'",'ROOT = Path('+repr(str(folder))+')'))
 r=subprocess.run([sys.executable,str(folder/'driver.py')],capture_output=True,timeout=30,env={'PATH':os.environ.get('PATH',''),'PYTHONDONTWRITEBYTECODE':'1','TMPDIR':str(ROOT/'tmp')});(folder/'stdout').write_bytes(r.stdout);(folder/'stderr').write_bytes(r.stderr);assert r.returncode==1 and b'Ran 17 tests' in r.stderr and b'AttributeError' in r.stderr and b'unallocated' not in r.stderr;rows.append({'name':name,'exit':r.returncode,'missing_constant_control_rejected':True})
(Path(__file__).parent/'host-patch-controls.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps(rows))
