set -euo pipefail
umask 022
. /home/agent/.cargo/env
export PATH=/workspace/toolchains/go1.26.7/bin:$PATH
export CARGO_TARGET_DIR=/workspace/symaira-setup765-source/target CARGO_PROFILE_DEV_DEBUG=0 CARGO_PROFILE_TEST_DEBUG=0 CARGO_INCREMENTAL=0
cargo build --locked -p symbrain-cli --bin symbrain --example setup_embedded_output > /tmp/symaira-doctor765-output-final-build.log 2>&1
for family in source doctor repair; do
 output_family="$family"
 if [ "$family" = repair ]; then output_family=setup; fi
 script_family="$family"
 if [ "$family" = source ]; then script_family=setup-source; elif [ "$family" = doctor ]; then script_family=doctor-repair; else script_family=setup-repair; fi
 scripts/"$script_family"-oracle/run.sh "/tmp/symaira-doctor765-output-final-$output_family.json" > "/tmp/symaira-doctor765-output-final-$output_family.log" 2>&1
done
scripts/guard-standalone-oracle/run.sh /tmp/symaira-doctor765-output-final-guard.json > /tmp/symaira-doctor765-output-final-guard.log 2>&1
scripts/setup-output-oracle/run.sh /tmp/symaira-doctor765-output-final-process > /tmp/symaira-doctor765-output-final-output.log 2>&1
for probe in findings lookup raw-signals eight-extra eight-home boundaries symlink consumers fix-consumers windows-managed-join windows-lexical; do
 python3 "/tmp/symaira-doctor765-output-final-$probe.py" > "/tmp/symaira-doctor765-output-final-$probe.log" 2>&1
done
python3 scripts/memory-cli-oracle/replay.py --go /workspace/oracles/symbrain-go-dcddcef0 --rust "$CARGO_TARGET_DIR/debug/symbrain" --report /tmp/symaira-doctor765-output-final-memory-read.json > /tmp/symaira-doctor765-output-final-memory-read.log 2>&1
python3 scripts/memory-cli-oracle/controls.py --go /workspace/oracles/symbrain-go-dcddcef0 --rust "$CARGO_TARGET_DIR/debug/symbrain" --report /tmp/symaira-doctor765-output-final-memory-read-controls.json > /tmp/symaira-doctor765-output-final-memory-read-controls.log 2>&1
python3 scripts/memory-cli-oracle/write_gate.py --go /workspace/oracles/symbrain-go-dcddcef0 --rust "$CARGO_TARGET_DIR/debug/symbrain" --report-dir /tmp/symaira-doctor765-output-final-memory-write > /tmp/symaira-doctor765-output-final-memory-write.log 2>&1
