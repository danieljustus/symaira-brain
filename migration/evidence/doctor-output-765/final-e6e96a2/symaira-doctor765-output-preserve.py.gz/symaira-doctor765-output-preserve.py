from pathlib import Path
import base64,gzip,hashlib,json,os
source=Path('/workspace/symaira-doctor765-json');target='/workspace/symaira-setup765-source/target'
sha=lambda data:hashlib.sha256(data).hexdigest()
users=[]
for entry in os.scandir('/proc'):
 if not entry.name.isdigit():continue
 for part in ['exe','cwd']:
  try:
   path=os.readlink(entry.path+'/'+part)
   if path.startswith(target+'/') or path==target:users.append([entry.name,part,path])
  except OSError:pass
 try:
  for fd in os.scandir(entry.path+'/fd'):
   try:
    path=os.readlink(fd.path)
    if path.startswith(target+'/'):users.append([entry.name,'fd',path])
   except OSError:pass
 except OSError:pass
assert not users,users
author=json.loads((source/'migration/evidence/doctor-windows-765/final-280/validation.json').read_bytes())
dest=Path('/workspace/oracles/symaira-doctor765-280-binaries');dest.mkdir(exist_ok=False)
records=[]
for name,item in author['actual_test_cli_executables'].items():
 raw=Path(name).read_bytes();assert raw.startswith(b'\x7fELF') and sha(raw)==item['sha256'] and len(raw)==item['bytes']
 out=dest/(item['sha256']+'.elf.gz');compressed=gzip.compress(raw,compresslevel=6,mtime=0)
 if not out.exists():out.write_bytes(compressed)
 assert sha(gzip.decompress(out.read_bytes()))==item['sha256']
 records.append(dict(original=name,sha256=item['sha256'],bytes=len(raw),archive=str(out),archive_sha256=sha(out.read_bytes()),archive_bytes=out.stat().st_size))
assert len(records)==50
(dest/'receipt.json').write_text(json.dumps(dict(source=author['source_head'],publication='3f92a768e2a19c1a5533262663d6f85b4ce0b591',target_users_before_archive=users,records=records),indent=2)+'\n')
review=Path('/tmp/symaira-doctor-source-independent-fourth-review-receipt.json');r=json.loads(review.read_bytes());assert len(r['artifacts'])==91
proof=Path('/tmp/symaira-doctor765-output-retained');proof.mkdir(exist_ok=False);retained={}
originals={**r['artifacts'],str(review):dict(sha256=sha(review.read_bytes()),bytes=review.stat().st_size)}
report=Path('/tmp/symaira-doctor-source-independent-fourth-review.md');originals[str(report)]=dict(sha256=sha(report.read_bytes()),bytes=report.stat().st_size)
for name,item in originals.items():
 p=Path(name);raw=p.read_bytes();assert sha(raw)==item['sha256'] and len(raw)==item['bytes'],name
 out=proof/(p.name+'.gz');assert not out.exists();out.write_bytes(gzip.compress(raw,compresslevel=6,mtime=0));assert gzip.decompress(out.read_bytes())==raw
 retained[name]=dict(**item,retained=out.name,encoding='gzip',retained_sha256=sha(out.read_bytes()))
assert len(author['artifacts'])==39
for name,digest in author['artifacts'].items():assert sha((source/'migration/evidence/doctor-windows-765/final-280'/name).read_bytes())==digest
(proof/'retention.json').write_text(json.dumps(dict(original_source=author['source_head'],original_publication='3f92a768e2a19c1a5533262663d6f85b4ce0b591',original_files=retained,all39_author_artifacts_verified=author['artifacts'],all50_executable_bytes_archived=str(dest/'receipt.json')),indent=2)+'\n')
print(json.dumps(dict(executables=len(records),unique_archives=len(list(dest.glob('*.gz'))),archive_gzip_bytes=sum(p.stat().st_size for p in dest.glob('*.gz')),review_artifacts=len(retained),author_artifacts=len(author['artifacts']),target_users=users)))
