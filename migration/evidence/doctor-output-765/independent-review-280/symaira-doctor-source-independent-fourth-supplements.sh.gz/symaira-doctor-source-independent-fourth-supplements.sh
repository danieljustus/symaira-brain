#!/usr/bin/env bash
set -euo pipefail
umask 022
. /home/agent/.cargo/env
export PATH=/workspace/toolchains/go1.26.7/bin:$PATH
export CARGO_TARGET_DIR=/workspace/symaira-setup765-source/target
export CARGO_INCREMENTAL=0 CARGO_PROFILE_DEV_DEBUG=0 CARGO_PROFILE_TEST_DEBUG=0 CARGO_BUILD_JOBS=2 PYTHONDONTWRITEBYTECODE=1
for label in findings lookup raw-signals eight-extra eight-home boundaries symlink consumers fix-consumers; do
  python3 "/tmp/symaira-doctor-source-independent-fourth-$label.py" > "/tmp/symaira-doctor-source-independent-fourth-$label.log" 2>&1
done
