from pathlib import Path
import base64,hashlib,json,os,re,subprocess
repo=Path('/workspace/symaira-doctor765-json');prefix='/tmp/symaira-doctor-source-independent-fourth-';digest=lambda b:hashlib.sha256(b).hexdigest();head='3f92a768e2a19c1a5533262663d6f85b4ce0b591';source='280914bc6bc9c3b3faac404dcd5d84856a424ed7'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()==head and not subprocess.check_output(['git','status','--porcelain'],cwd=repo)
gates={};controls=[];manifests={}
for family,total,modes in [('source',111,['wrong-exit','wrong-source']),('doctor',285,['wrong-exit','missing-header','missing-core-event']),('setup',201,[])]:
 p=Path(prefix+family+'.json');r=json.loads(p.read_text());assert r['candidate_head']==head and not r['candidate_dirty']and r['total']==total and r['exit']==0
 if family=='setup':assert r['matches']and len(r['cases'])==total and len(r['observations'])==total*2
 else:assert r['complete_observations']==r['matched']==total and not r['failures']
 manifests[family]={}
 for key in ['candidate_source_sha256','go_source_sha256']:
  manifests[family][key]=len(r[key])
  for name,sha in r[key].items():
   data=(repo/name).read_bytes()if key.startswith('candidate')else subprocess.check_output(['git','show','dcddcef0df5789123c7c9a7ebe6e01f10e941f2c:'+name],cwd=repo)
   assert digest(data)==sha,(family,name)
 gates[family]={'total':total,'go_sha256':r['go_binary_sha256'],'rust_sha256':r['rust_binary_sha256']}
 for mode in modes:
  q=json.loads(Path(prefix+family+'.json.'+mode+'.json').read_text());field={'wrong-exit':'exit','wrong-source':'stdout_base64','missing-header':'stdout_base64','missing-core-event':'logs'}[mode]
  assert q['total']==q['complete_observations']==1 and q['matched']==0 and q['exit']==1 and q['failures']==[{'case':'explicit-browse-json'if family=='source'else'correct','fields':[field]}]
  controls.append({'family':family,'mode':mode,'failure':q['failures']})
original_pairs=0
for label in ['findings','lookup','raw-signals','eight-extra','eight-home','boundaries','symlink']:
 r=json.loads(Path(prefix+label+'.json').read_text());assert r.get('head',r.get('candidate_head'))==head and not r.get('dirty',r.get('candidate_dirty',False))
 for value in r.values():
  if isinstance(value,list):
   for row in value:
    if isinstance(row,dict)and('mismatched_fields'in row or'differences'in row):assert not row.get('mismatched_fields',row.get('differences'));original_pairs+=1
 if label=='raw-signals':assert len(r['actual_cancellation'])==2 and all(not x['descendant_active']and x['actual_cli_exit']==1 for x in r['actual_cancellation'])
assert original_pairs==35
for label in ['consumers','fix-consumers']:
 r=json.loads(Path(prefix+label+'-setup.json').read_text());assert r['total']==8 and r['matches']and r['exit']==0 and r['candidate_head']==head and not r['candidate_dirty'];assert len(r['observations'])==16
for family,count in [('source',4),('doctor',3)]:
 r=json.loads(Path(prefix+'consumers-'+family+'.json').read_text());assert r['head']==head and not r['dirty']and len(r['cases'])==count and all(not x['differences']for x in r['cases'])
log=Path(prefix+'tests.log').read_bytes();summaries=[tuple(map(int,x))for x in re.findall(rb'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;',log)];assert len(summaries)==48 and tuple(map(sum,zip(*summaries)))==(451,0,0)
assert b'Finished' in Path(prefix+'clippy.log').read_bytes()
for label in ['fmt','actionlint','whitespace-correction','whitespace-production']:assert not Path(prefix+label+'.log').read_bytes()
bins={name:digest(Path(name).read_bytes())for name in re.findall(r'Running [^\n]+ \(([^\n]+)\)',log.decode())};cli='/workspace/symaira-setup765-source/target/debug/symbrain';bins[cli]=digest(Path(cli).read_bytes());bins['/workspace/symaira-setup765-source/target/debug/symguard']=digest(Path('/workspace/symaira-setup765-source/target/debug/symguard').read_bytes());assert len(bins)==50
v=json.loads((repo/'migration/evidence/doctor-windows-765/final-280/validation.json').read_text());assert bins=={name:r['sha256']for name,r in v['actual_test_cli_executables'].items()}
guard=json.loads(Path(prefix+'guard.json').read_text());raw=json.loads(Path(prefix+'guard-raw-paths.json').read_text());gc=json.loads(Path(prefix+'guard-controls.json').read_text());assert guard['total']==124 and guard['matched']==121 and len(guard['remaining_native_diagnostic_states'])==3 and not guard['audit_diagnostic_deviations'];assert raw['total']==raw['matched']==63 and len(raw['controls'])==2 and all(x['rejected']for x in raw['controls']);assert gc['rejected']==3 and all(x['rejected']for x in gc['controls'])
for key in ['candidate_source_sha256','candidate_manifest_sha256','go_source_sha256']:
 for name,sha in guard[key].items():
  data=(repo/name).read_bytes()if key.startswith('candidate')else subprocess.check_output(['git','show','dcddcef0df5789123c7c9a7ebe6e01f10e941f2c:'+name],cwd=repo)
  assert digest(data)==sha,('guard',name)
output=[]
for family,count in [('output-probes',4),('source-output',2),('pipe-probes',6)]:
 for baseline in [False,True]:
  r=json.loads(Path(prefix+('baseline-'if baseline else'')+family+'.json').read_text());assert len(r['cases'])==count;assert r['rust_sha256']==('a2f9be69dbf324e12a20b5ed3e573f06bb9c66750fec2c3a2a16bd4716bdfc52'if baseline else bins[cli])
  for row in r['cases']:
   assert row['go']['before']==row['rust']['before']and row['go']['after']==row['rust']['after']
   if family=='pipe-probes':assert row['go']['exit']==-13 and row['rust']['exit']==1 and row['differences']==['exit','stderr_base64']
   else:assert row['go']['exit']==row['rust']['exit']==1 and row['differences']==['stderr_base64']
   output.append({'baseline':baseline,'case':row['case'],'mismatches':row['differences'],'full_owned_state_same':True})
windows=json.loads(Path(prefix+'windows-managed-join.json').read_text());assert windows['cases']==189679 and windows['differences']==[{'input_hex':'','sdk_hex':'2e73796d616972615c62696e','rust_hex':'5c2e73796d616972615c62696e'}];assert '.filter(|home| !home.is_empty())?'in(repo/'rust/symbrain-cli/src/managed_home.rs').read_text()
users=[];target='/workspace/symaira-setup765-source/target'
for p in Path('/proc').iterdir():
 if not p.name.isdigit()or int(p.name)==os.getpid():continue
 for item in [p/'exe',p/'cwd']+list((p/'fd').glob('*')):
  try:
   actual=os.readlink(item)
   if actual.startswith(target):users.append({'pid':p.name,'path':actual})
  except OSError:pass
assert not users,users
result={'head':head,'source':source,'gates':gates,'five_source_doctor_controls':controls,'fresh_tests':{'passed':451,'failed':0,'ignored':0,'summaries':48},'manifest_counts':manifests,'binary_sha256':bins,'original35_pairs_match':True,'SIGINT_SIGTERM_cleanup_match':True,'third23_consumer_pairs_match':True,'original8JSON_failures_closed':True,'original8human_controls_preserved':True,'guard124_121full_3approved':True,'guard_raw63_and5controls_pass':True,'additional_current_json_output_pairs':12,'additional_actual_a66_baseline_pairs':12,'additional_json_output_details':output,'admitted_windows_HOME_algorithm_matches':189678,'empty_HOME_gap_rejected_by_actual_filter':True,'nativeWindowsMacRuntime':False,'provenance':json.loads(Path(prefix+'provenance.json').read_text()),'whitespace':json.loads(Path(prefix+'whitespace.json').read_text()),'target_users':users,'disposition':'REQUEST CHANGES: inherited JSON output error diagnostics and actual stdout SIGPIPE behavior; exact additional human pipe observations retained separately.'}
Path(prefix+'review-receipt.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:result[k]for k in ['head','fresh_tests','gates','original35_pairs_match','third23_consumer_pairs_match','target_users','disposition']},indent=2))
