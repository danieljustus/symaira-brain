from pathlib import Path
import base64,gzip,hashlib,json,subprocess,zipfile
repo=Path('/workspace/symaira-doctor765-json');digest=lambda b:hashlib.sha256(b).hexdigest()
publication='3f92a768e2a19c1a5533262663d6f85b4ce0b591';source='280914bc6bc9c3b3faac404dcd5d84856a424ed7'
def git(*args):return subprocess.check_output(['git',*args],cwd=repo)
assert git('rev-parse','HEAD').decode().strip()==publication and not git('status','--porcelain')
assert not git('diff',source,publication,'--','rust','scripts','.github','Cargo.toml','Cargo.lock')
for ancestor in ['e3dbda6cbb95429237d15a9b176209b7d107792c','8e3b21b4fa649847f5b9a26a80f0c24fa172e1a0']:subprocess.run(['git','merge-base','--is-ancestor',ancestor,publication],cwd=repo,check=True)
assert not git('diff','8e3b21b4fa649847f5b9a26a80f0c24fa172e1a0',source,'--','rust/symguard-cli','rust/symbrain-cli/src/guard_cli.rs','rust/symbrain-core/src/go_text.rs','rust/symbrain-core/src/json_string.rs')
final=repo/'migration/evidence/doctor-windows-765/final-280';v=json.loads((final/'validation.json').read_bytes())
assert digest((final/'validation.json').read_bytes())=='cb4bfab22465ccdee43aaf7d5609648c414918dd6a96e86ef0b97c2247222717'
assert v['source_head']==source and v['rust_binary_sha256']=='44468313653a364c28aedde3aa9536cbe0e27980b5cebe1d61f6e91aae1e764b'
for name,sha in v['artifacts'].items():assert digest((final/name).read_bytes())==sha,name
logs=json.loads((final/'logs.json').read_bytes())
for name,item in logs.items():
 b=base64.b64decode(item['original_bytes_base64']);assert digest(b)==item['sha256']
 original=Path('/tmp')/name
 if original.exists():assert original.read_bytes()==b,name
for name,item in v['actual_test_cli_executables'].items():
 b=Path(name).read_bytes();assert digest(b)==item['sha256'] and len(b)==item['bytes'],name
assert digest(Path(v['preserved_actual_cli']).read_bytes())==v['rust_binary_sha256']
counts={};archives={}
for root,key,expected in [(repo/'migration/evidence/doctor-windows-765/independent-review-a66','original_files',68),(repo/'migration/evidence/doctor-windows-765/independent-review-a301','original_files',46),(repo/'migration/evidence/doctor-windows-765/independent-review-0b56','original_files',35),(repo/'migration/evidence/setup-source-765/independent-review-86ea','originals',24)]:
 retained=json.loads((root/'retention.json').read_bytes())[key];assert len(retained)==expected
 for name,item in retained.items():
  p=root/name;b=p.read_bytes()if p.exists()else base64.b64decode(json.loads((root/(name+'.json')).read_bytes())['original_bytes_base64'])
  assert digest(b)==item['sha256'],name
  if 'bytes'in item:assert len(b)==item['bytes']
  original=Path('/tmp')/name
  if original.is_file():assert original.read_bytes()==b,name
 counts[str(root)]=len(retained)
for label,count in [('a66',38),('a301',38),('0b56',41)]:
 root=repo/f'migration/evidence/doctor-windows-765/independent-review-{label}';receipt=json.loads((root/f'binary-retention-{label}.json').read_bytes())
 records=receipt['records']if 'records'in receipt else list(receipt['executables'].values());assert len(records)==count
 for item in records:
  compressed=Path(item.get('archive',item.get('gzip_archive'))).read_bytes();assert digest(compressed)==item['archive_sha256']
  b=gzip.decompress(compressed);assert digest(b)==item.get('sha256',item.get('original_sha256'))and len(b)==item.get('bytes',item.get('original_bytes'))
 archives[label]=len(records)
windows=repo/'migration/evidence/doctor-windows-765/original-windows-1288';w=json.loads((windows/'receipt.json').read_bytes())
for name,item in w.items():
 if not isinstance(item,dict)or'sha256'not in item:continue
 p=windows/item.get('stored_path',name);b=base64.b64decode(json.loads(p.read_bytes())['original_bytes_base64'])if item.get('stored_encoding')else p.read_bytes();assert digest(b)==item['sha256'],name
original=json.loads((windows/'windows-process.json').read_bytes());five=json.loads((windows/'five-full-failure-records.json').read_bytes());assert len(five['failures'])==5 and five['failures']==original['failures']and five['observations']==[x for x in original['observations']if not x['matches']]
with zipfile.ZipFile(windows/'doctor-windows-failure.zip')as z:assert any(z.read(name)==(windows/'windows-process.json').read_bytes()for name in z.namelist()if name.endswith('.json'))
named={};manifests={}
for family in ['source','doctor','setup']:
 new=json.loads((final/f'symaira-doctor765-json-final-{family}.json').read_bytes());old=json.loads((repo/'migration/evidence/doctor-windows-765/final-a66'/f'symaira-doctor765-owner-a66-{family}.json').read_bytes())
 oldnames=set(old['cases']if family=='setup'else[x['case']for x in old['observations']]);newnames=set(new['cases']if family=='setup'else[x['case']for x in new['observations']]);assert oldnames<=newnames
 named[family]={'original':len(oldnames),'new':len(newnames),'retained':True};manifests[family]={}
 for key in ['candidate_source_sha256','go_source_sha256']:
  manifests[family][key]=len(new[key])
  for name,sha in new[key].items():
   b=(repo/name).read_bytes()if key.startswith('candidate')else git('show','dcddcef0df5789123c7c9a7ebe6e01f10e941f2c:'+name)
   assert digest(b)==sha,(family,name)
for name,item in json.loads((final/'signature-stub-harness.json').read_bytes())['files'].items():assert digest(item['text'].encode())==item['sha256'],name
old=json.loads((repo/'migration/evidence/doctor-windows-765/final-a66/validation.json').read_bytes())
for name,sha in old['SDK_path_and_mkdir_inputs'].items():assert digest((Path('/workspace/toolchains/go1.26.7/src')/name).read_bytes())==sha,name
result=dict(head=publication,source=source,author_artifacts=len(v['artifacts']),author_logs=len(logs),current_executables=len(v['actual_test_cli_executables']),retained_original_files=counts,actual_archive_roundtrips=archives,original_windows_five_failures_retained=True,named_corpus_retained=named,author_manifests_verified=manifests,accepted_guard_core_source_identical=True,SDK_inputs_verified=5,stub_hashes_verified=True,native_windows_macos_executed=False)
Path('/tmp/symaira-doctor-source-independent-fourth-provenance.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
