#!/usr/bin/env bash
set -euo pipefail
umask 022
. /home/agent/.cargo/env
export PATH=/workspace/toolchains/go1.26.7/bin:$PATH
export CARGO_TARGET_DIR=/workspace/symaira-setup765-source/target
export CARGO_INCREMENTAL=0 CARGO_PROFILE_DEV_DEBUG=0 CARGO_PROFILE_TEST_DEBUG=0 PYTHONDONTWRITEBYTECODE=1
python3 /tmp/symaira-doctor-source-independent-fourth-output-probes.py > /tmp/symaira-doctor-source-independent-fourth-output-probes.log 2>&1
if python3 /tmp/symaira-doctor-source-independent-fourth-windows-managed-join.py > /tmp/symaira-doctor-source-independent-fourth-windows-managed-join.log 2>&1; then
  echo 'unexpected absence of retained empty HOME precondition discrepancy' >&2
  exit 1
fi
python3 - <<'PY'
from pathlib import Path
import json
p=Path('/tmp/symaira-doctor-source-independent-fourth-windows-managed-join.json');r=json.loads(p.read_text());assert r['cases']==189679 and r['differences']==[{'input_hex':'','sdk_hex':'2e73796d616972615c62696e','rust_hex':'5c2e73796d616972615c62696e'}]
assert '.filter(|home| !home.is_empty())?' in Path('/workspace/symaira-doctor765-json/rust/symbrain-cli/src/managed_home.rs').read_text()
Path('/tmp/symaira-doctor-source-independent-fourth-windows-admitted.json').write_text(json.dumps({'nonempty_admitted_HOME':189678,'mismatches':0,'one_empty_HOME_actual_filter_rejects':True,'failed_original_probe_log_preserved':True,'native_windows_runtime':False},indent=2)+'\n')
PY
