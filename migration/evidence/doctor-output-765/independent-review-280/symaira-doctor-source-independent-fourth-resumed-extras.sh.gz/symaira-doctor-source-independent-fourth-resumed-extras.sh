set -euo pipefail
umask 022
. /home/agent/.cargo/env
export PATH=/workspace/toolchains/go1.26.7/bin:$PATH
export PYTHONDONTWRITEBYTECODE=1
for family in output-probes source-output; do
 if python3 "/tmp/symaira-doctor-source-independent-fourth-baseline-$family.py" > "/tmp/symaira-doctor-source-independent-fourth-baseline-$family.log" 2>&1; then exit 1; fi
done
if python3 /tmp/symaira-doctor-source-independent-fourth-windows-managed-join.py > /tmp/symaira-doctor-source-independent-fourth-windows-managed-join.log 2>&1; then exit 1; fi
python3 - <<'PY'
from pathlib import Path
import json
r=json.loads(Path('/tmp/symaira-doctor-source-independent-fourth-windows-managed-join.json').read_text());assert r['cases']==189679 and r['differences']==[{'input_hex':'','sdk_hex':'2e73796d616972615c62696e','rust_hex':'5c2e73796d616972615c62696e'}]
assert '.filter(|home| !home.is_empty())?' in Path('/workspace/symaira-doctor765-json/rust/symbrain-cli/src/managed_home.rs').read_text()
Path('/tmp/symaira-doctor-source-independent-fourth-windows-admitted.json').write_text(json.dumps({'nonempty_admitted_HOME':189678,'mismatches':0,'one_empty_HOME_actual_filter_rejects':True,'failed_original_probe_log_preserved':True,'native_windows_runtime':False},indent=2)+'\n')
PY
