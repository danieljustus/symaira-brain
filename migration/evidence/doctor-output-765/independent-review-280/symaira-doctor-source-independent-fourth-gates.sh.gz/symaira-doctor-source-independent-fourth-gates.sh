#!/usr/bin/env bash
set -euo pipefail
umask 022
. /home/agent/.cargo/env
export PATH=/workspace/toolchains/go1.26.7/bin:$PATH
export CARGO_TARGET_DIR=/workspace/symaira-setup765-source/target
export CARGO_INCREMENTAL=0 CARGO_PROFILE_DEV_DEBUG=0 CARGO_PROFILE_TEST_DEBUG=0 CARGO_BUILD_JOBS=2
cargo test --locked --all-targets --all-features -p symbrain-cli -p symbrain-managed -p symbrain-core -p symbrain-guard-core -p symguard-cli > /tmp/symaira-doctor-source-independent-fourth-tests.log 2>&1
cargo clippy --locked --all-targets --all-features -p symbrain-cli -p symbrain-managed -p symbrain-core -p symbrain-guard-core -p symguard-cli -- -D warnings > /tmp/symaira-doctor-source-independent-fourth-clippy.log 2>&1
cargo fmt --all -- --check > /tmp/symaira-doctor-source-independent-fourth-fmt.log 2>&1
/workspace/toolchains/bin/actionlint > /tmp/symaira-doctor-source-independent-fourth-actionlint.log 2>&1
scripts/setup-source-oracle/run.sh /tmp/symaira-doctor-source-independent-fourth-source.json > /tmp/symaira-doctor-source-independent-fourth-source.log 2>&1
scripts/doctor-repair-oracle/run.sh /tmp/symaira-doctor-source-independent-fourth-doctor.json > /tmp/symaira-doctor-source-independent-fourth-doctor.log 2>&1
scripts/setup-repair-oracle/run.sh /tmp/symaira-doctor-source-independent-fourth-setup.json > /tmp/symaira-doctor-source-independent-fourth-setup.log 2>&1
scripts/guard-standalone-oracle/run.sh /tmp/symaira-doctor-source-independent-fourth-guard.json > /tmp/symaira-doctor-source-independent-fourth-guard.log 2>&1
