# Full independent fourth Doctor/Source review

**REQUEST CHANGES: exactly two P2 output-contract findings.** The original eight Setup JSON escape failures are closed. No additional owner, MkdirAll, raw-byte, source-worker, protection or integration blocker was found in the reviewed scope.

Immutable clean publication `3f92a768e2a19c1a5533262663d6f85b4ce0b591`, validated source `280914bc6bc9c3b3faac404dcd5d84856a424ed7`, worktree `/workspace/symaira-doctor765-json`. Main `e3dbda6c` and independently approved Core/Guard `8e3b21b4` are normal ancestors. Publication changes evidence only. Actual CLI SHA256 `44468313653a364c28aedde3aa9536cbe0e27980b5cebe1d61f6e91aae1e764b` and all 50 actual executables match the source-bound author receipt and fresh test selection. No candidate source, Go oracle, fixture, GitHub or other target changes occurred.

## P2: retain the actual JSON write failure diagnostic

`rust/symbrain-cli/src/setup_cli.rs:359–365` drops the serialization/write error and emits only `symbrain setup[ --fix]: encode JSON`. `rust/symbrain-cli/src/setup_source.rs:236–242` reports Rust's generic I/O spelling instead of Go's stream operation/path. Actual owned install and repair, both successful and obstructed, to `/dev/full` produce four strict pairs; Source success/ancestor obstruction adds two. All six have matching exit1 and complete filesystem/type/mode/byte state, but differ in stderr:

- Go: `symbrain setup[ --fix| --from-source]: encode JSON: write /dev/stdout: no space left on device`.
- Native install/repair omits `write /dev/stdout` and the OS cause entirely; Source emits `No space left on device (os error 28)` with Rust formatting.

The portable broken-writer test currently asserts the incomplete message, so it proves detection but cannot establish Go diagnostic parity. Preserve the actual error through rendering and test the exact operation/path/cause spelling for supported real OS errors while keeping embedded injected-writer behavior coherent. Completed installation/publication must remain committed when JSON output subsequently fails.

Exact inputs, raw stderr, exits and complete before/after state are retained in `fourth-output-probes.{py,json,log}` and `fourth-source-output.{py,json,log}`. Actual archived a66 CLI, SHA `a2f9be69dbf324e12a20b5ed3e573f06bb9c66750fec2c3a2a16bd4716bdfc52`, reproduces all six differences under `fourth-baseline-*`. This is inherited from the reviewed a66 renderers, not caused by the shared-text or escaping correction.

## P2: preserve Go's actual stdout SIGPIPE boundaries

Actual pipes with their reader closed before spawn give Go SIGPIPE (-13), versus native exit1 plus a JSON-write diagnostic for install, repair and Source. An actual 4KiB pipe, a >4KiB owned ancestor-error JSON report and a reader that consumes exactly 128 bytes before closing produces the same three differences. Every JSON pair has identical received prefix and full committed filesystem/type/mode/byte state.

Three additional human closed-reader cases give Go -13 versus native0. For install and repair the first write is the `symcockpit 0.6.2 (unsupported platform)` row. Go terminates there before later installs; native ignores that error, then installs symdesk and symvault plus both provenance sidecars. Source has matching already-published state but a different terminal status at human output. Three actual partial-reader human controls match exactly, including 128 received bytes, stderr, exit1 and full state; they remain positive controls rather than being dropped.

Keep the Unix signal policy at the actual process stdout write boundaries, including early human output. A change only at the final JSON encoder cannot close the two extra-installation cases. Do not reset SIGPIPE globally, signal on arbitrary injected writers, or roll back state already committed before an output failure. The pinned Go SDK's `os.File.Write` calls `epipecheck`, and Unix raises SIGPIPE only on an EPIPE from stdout/stderr; Windows has no such signal action. These native Linux observations do not establish Windows behavior.

All six JSON pipe pairs and six human pipe pairs are preserved in `fourth-{pipe-probes,human-pipe-probes}.{py,json,log}`. The actual archived a66 executable reproduces every same difference and the three matching human controls. Both findings are inherited supported output-contract gaps, not escaping regressions. Full raw observations precede any correction.

## Fresh full verification and source review

451 Rust tests pass,0 failed/ignored,48 result summaries; locked all-target/all-feature Clippy for CLI/Managed/Core and both integrated Guard crates passes. Workspace fmt and all-workflow actionlint pass. All 50 current executable hashes match the author receipt. Source 111/111, Doctor 285/285 and Setup 201/201 match frozen Go with full literal process/state comparison. Five actual Source/Doctor controls fail their exact expected field. Guard 124 cases retain121 full matches plus the same three explicitly approved diagnostic states; raw paths 63/63 and five actual Guard controls pass. No acceptance classification or state/output normalization was weakened.

All 35 original supplementary pairs and both actual SIGINT/SIGTERM owned-builder cleanup probes pass. All 23 third-review consumers pass:16 Setup install/repair pairs (eight JSON failures now closed, eight human controls matching), four Source and three Doctor. Every old107/282/169 named corpus case remains in the expanded111/285/201 gates.

Reviewed the scoped production and harness delta, existing managed owner/MkdirAll/release/local install/version/provenance behavior, Source parsing/worker lookup/process capture/cleanup, report consumers, workflows and decision/scope documentation. Core GoText/json and integrated Guard source are byte-identical to approved 8e3. Managed mechanically reexports Core without a Guard dependency. The whole serialized Setup document escapes ordinary String fields as well as byte-valued GoText; raw preescaped values are not double-escaped. Source's existing final escape helper is extracted without a behavior change. Changed production modules remain below 400 lines.

Fresh additional output proof:18 current actual pairs,15 mismatches in the two groups above and three matching partial-reader human controls;18 actual a66 baseline pairs establish inheritance. Every JSON mismatch preserves full before/after state. The two human extra-installation state differences are recorded explicitly, not normalized away.

## Evidence, Windows limits and release

Independently verified 39 author artifacts,24 encoded original raw logs, all 50 current executables, all 68/46/35/24 retained prior original files and gzip roundtrips of 38 a66,38 a301 and 41 original0b56 actual executables. The original Windows ZIP and all five original failure observations remain exact. Fresh candidate/Go manifests verify Source 186/4, Doctor 101/108 and Setup 14/108 entries, plus the integrated Guard manifest. Frozen Go source remains dcddcef0.

A fresh extracted actual Windows Go1.26.7 Join/Clean/FromSlash versus actual managed-path assembly comparison matches all 189678 admitted nonempty HOME values. The one empty-HOME difference and original assertion-failed log remain literal; production rejects that value before assembly. The prior 101 generic Clean exploratory differences remain retained and are not rewritten into passes. SDK source hashes and all signature-stub source hashes verify. This Linux-hosted algorithm comparison and the narrow cross-target signature stubs are not native Windows/macOS runtime, filesystem or ACL acceptance.

Production/integration whitespace checks pass. The initial broad evidence-range check, including already accepted Guard raw proof whitespace, remains retained. The current correction range has exactly one receipt-SHA-bound original blank-at-EOF script; only that exact artifact is excluded in the narrow evidence check, which passes. No original proof bytes were edited.

Native Windows/macOS exact-head CI, protected-source workflows, historical Go Browse/Swift source workers and full #765/#783 acceptance remain open. Root's separate nine base-Setup typed-configuration inventory deviations and Store migration/backfill inventory are outside this focused correction; this review does not claim those are resolved or that all invalid-config routes delegate. Broader invalid-config work must stay a distinct follow-up, not an exception to the output findings.

The candidate is unchanged. All independent compiler/replay/probe processes finished; `/proc` executable/cwd/fd inspection shows zero users of `/workspace/symaira-setup765-source/target`. That existing target is explicitly RELEASED to the parent/author after this immutable report. Before another rebuild, preserve the current 50 source-bound executable bytes and these original failed proof files. Full receipt: `/tmp/symaira-doctor-source-independent-fourth-review-receipt.json`.
