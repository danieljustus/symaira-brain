import ast,gzip,hashlib,json,pathlib,subprocess
r=pathlib.Path('/workspace/symaira-skills794-cache-preparation');o=pathlib.Path('/tmp/symaira-skills794-cache-root-review');o.mkdir()
h=lambda b:hashlib.sha256(b).hexdigest()
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip();assert head=='d2f0047faf5837b85dd1bb842bd67814ea7a0094';assert not subprocess.check_output(['git','status','--porcelain'],cwd=r)
p=r/'migration/evidence/skills-cache-preparation-794/original-cec81-windows';d=json.loads((p/'receipt.json').read_bytes());maps=[]
for row in d['files']:
 b=(p/row['archive']).read_bytes();a=gzip.decompress(b);assert h(b)==row['archive_sha256'];assert len(a)==row['bytes'] and h(a)==row['sha256'];maps.append(dict(path=row['archive'],bytes=len(a),sha256=h(a)))
assert len(maps)==57
b=json.loads(gzip.decompress((p/'skills-artifact/go-build.json.gz').read_bytes()));failure=b['commands'][11];assert failure['exit']==1 and failure['argv'][-2:]==['mod','verify'];assert bytes.fromhex(failure['stderr_hex'])==b'go: github.com/aymanbagabas/go-osc52/v2@v2.0.1: module lookup disabled by GOPROXY=off\n'
rows=b['source_before'];assert len(rows)==2438
proc=subprocess.Popen(['git','cat-file','--batch'],cwd=r,stdin=subprocess.PIPE,stdout=subprocess.PIPE)
for row in rows:
 proc.stdin.write((row['blob']+'\n').encode());proc.stdin.flush();header=proc.stdout.readline().split();payload=proc.stdout.read(int(header[2]));assert proc.stdout.read(1)==b'\n';assert h(payload)==row['sha256'] and len(payload)==row['bytes']
proc.stdin.close();assert proc.wait()==0
f='scripts/skills-argv-oracle/build_go.py';old=ast.parse(subprocess.check_output(['git','show','cec81:'+f],cwd=r));new=ast.parse((r/f).read_bytes());a={x.name:ast.dump(x,include_attributes=False) for x in old.body if isinstance(x,ast.FunctionDef)};z={x.name:ast.dump(x,include_attributes=False) for x in new.body if isinstance(x,ast.FunctionDef)};same=[k for k in a if a[k]==z[k]];assert set(same)=={'digest','floor','output_path','stop_child','run','source_map'}
unchanged=[]
for name in subprocess.check_output(['git','ls-files','rust','internal','cmd','Cargo.toml','Cargo.lock','go.mod','go.sum'],cwd=r,text=True).splitlines():
 current=(r/name).read_bytes();prior=subprocess.check_output(['git','show','cec81:'+name],cwd=r);assert current==prior;unchanged.append(dict(path=name,sha256=h(current)))
assert len(unchanged)==1739
for name in ['compare.py','novel.py','verify_control.py','verify_novel_control.py','build_parent.py','test_novel.py']:
 f='scripts/skills-argv-oracle/'+name;assert (r/f).read_bytes()==subprocess.check_output(['git','show','cec81:'+f],cwd=r)
commands=[['python3','-m','unittest','discover','-s','scripts/skills-argv-oracle','-p','test_build_go.py','-v'],['python3','-m','unittest','discover','-s','scripts/skills-argv-oracle','-p','test_novel.py','-v'],['/workspace/toolchains/bin/actionlint','-shellcheck=','.github/workflows/ci.yml'],['git','diff','--check','cec81','HEAD']];results=[]
for i,argv in enumerate(commands):
 v=subprocess.run(argv,cwd=r,capture_output=True,check=False);(o/f'{i}.stdout').write_bytes(v.stdout);(o/f'{i}.stderr').write_bytes(v.stderr);results.append(dict(argv=argv,exit=v.returncode,stdout_sha256=h(v.stdout),stderr_sha256=h(v.stderr)));assert v.returncode==0
sdk=pathlib.Path('/workspace/toolchains/go1.26.7/src/cmd/go/internal/modcmd');sdkmap={n:h((sdk/n).read_bytes()) for n in ['download.go','verify.go']}
result=dict(source=head,full_originals=maps,frozen_blob_count=len(rows),same_helpers=same,unchanged_protected=unchanged,SDK=sdkmap,actual_portable=results,download_mocked=True,actual_corrected_SDK_or_native_product=False,source_publication_ready=True,native_OS_and_protected_merge_acceptance=False)
(o/'receipt.json').write_text(json.dumps(result,indent=2)+'\n');print('FULL ROOT SOURCE REVIEW checks PASS',len(maps),len(rows),len(unchanged))
