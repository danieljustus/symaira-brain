from pathlib import Path
import datetime,hashlib,json,subprocess,time
ROOT=Path('/tmp/symaira-pr794-cec81-ci-follow');endpoint='repos/danieljustus/symaira-brain/actions/jobs/111390294303'
previous=None
for attempt in range(30):
 stamp=datetime.datetime.now(datetime.UTC).strftime('%Y%m%dT%H%M%SZ')
 cmd=['gh','api',endpoint];r=subprocess.run(cmd,capture_output=True,timeout=45)
 (ROOT/f'windows-{stamp}.json').write_bytes(r.stdout);(ROOT/f'windows-{stamp}.stderr').write_bytes(r.stderr)
 if r.returncode:
  print(json.dumps(dict(time=stamp,api_exit=r.returncode)),flush=True);time.sleep(60);continue
 value=json.loads(r.stdout);state=(value['status'],value['conclusion'],[(s['name'],s['status'],s['conclusion']) for s in value['steps'] if s['status']!='pending'])
 if state!=previous:
  print(json.dumps(dict(time=stamp,status=state[0],conclusion=state[1],completed_or_running=state[2])),flush=True);previous=state
 if value['status']=='completed':
  logcmd=['gh','api',endpoint+'/logs'];log=subprocess.run(logcmd,capture_output=True,timeout=60)
  (ROOT/'windows-complete-job.logs.raw').write_bytes(log.stdout);(ROOT/'windows-complete-job.logs.stderr').write_bytes(log.stderr)
  (ROOT/'windows-complete-job-log-command.json').write_text(json.dumps(dict(command=logcmd,exit=log.returncode,time=stamp,raw_sha256=hashlib.sha256(log.stdout).hexdigest(),bytes=len(log.stdout),job=value),indent=2)+'\n')
  print(json.dumps(dict(time=stamp,complete_logs_saved=True,log_exit=log.returncode,raw_bytes=len(log.stdout))),flush=True);break
 time.sleep(60)
