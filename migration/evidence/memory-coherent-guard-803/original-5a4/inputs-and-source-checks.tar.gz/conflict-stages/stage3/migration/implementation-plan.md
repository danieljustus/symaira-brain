# Symaira Brain Go-to-Rust Migration Implementation Plan

## Guard generated configuration ownership repair — 2026-10-04

Immutable 4d78/fb2844 independent review requested one P2: generated XDG/HOME
paths must clean lexically before the OS resolves symlink/.. pairs and before
warning filenames are rendered. Explicit SYMGUARD_CONFIG retains raw OS
semantics. The isolated successor normally integrates main2b and shares a small
Guard-only lexical helper with scan. Windows volume/device/postClean and raw
UTF16 rules are pinned to actual Go SDK source, with a portable source-reference
gate distinct from native runtime acceptance. Windows config text that cannot
be emitted exactly remains delegated. Original92 proofs/180 raw-state paths and
69/46 ELF byte mappings remain retained; all inherited gates remain required.
[ADR](../docs/adr/guard-generated-config-path-ownership.md). New path process/
mutation cases pass on clean source5bb: 177 ordinary tests and an overlapping
41-test kernel graph, strict/fmt/actionlint, 124/63/78/54/25 actual process cases,
386 portable Windows SDK comparisons, all13 inherited controls plus the actual
wrong-owner mutant. The original25 before-fix inputs, 20+10 owner-history pairs,
80/94 original inputs, prior parent/raw/ordered gates and nine original Scan
fixtures are explicitly accounted for. Failures and exact executable bytes
remain retained. SDK source-reference is not Windows runtime proof; independent
review and native3 protected checks remain pending. Full770/769 remain open.

## Guard Doctor ordered warning slice — 2026-10-04

The successor normally includes approved PR805 publication1c04 and ports the
fourteen healthy unknown-key configurations observed against actual frozen Go.
It reuses immutable TOML source spans and Core GoText/Go quoting; warnings are
buffered after typed decode and emitted once only after full native admission.
The new54-case Linux gate requires46 complete comparisons and8 explicit
remaining typed/alias/discovery/map-order refusals, ten Go warning repeats and
five real mutations. The three specifically proved original unknown-key inputs
now require equality, yielding122/124 and67/78 comparisons with the remaining
original refusals unchanged. All prior raw/kernel/process controls and the
original50/two invalid-default Go reports remain mandatory and unchanged.
[ADR](../docs/adr/guard-doctor-ordered-config-warnings.md) explains output and
ownership. Independent review/native3/protected checks are pending; full770/769
and the other Brain configuration consumers remain open.

## Guard doctor equivalent config/Unicode slice — 2026-10-04

The successor to approved PR805 admits nine baseline healthy Go-only TOML
representations and five healthy anchor Unicode/key forms, using the existing
TableLike and Guard Go JSON primitive. The additive78 actual process cases
retain65 full comparisons and13 explicit TOML gates; baseline and final clean-
source receipts under `migration/evidence/guard-doctor-boundaries-770` bind the
implementation. All previous exact process/raw/state/kernel tests remain
required. Three original selected TOML gates, broad discovery/filesystem/output
boundaries and native macOS/Windows acceptance remain open. The50 actual Go
runs with two different invalid-default reports stay evidence, not an exception.
See the linked [ADR](../docs/adr/guard-doctor-equivalent-config-and-anchor-unicode.md)
and [remaining inventory](guard-doctor-boundary-inventory-770.md). This does not
close #770/#769 or claim full standalone/Brain cutover.

## Additional native init, Swift and fuzz evidence — 2026-09-29

Candidate `f1263bea237e99ff9a297fe3146170ce5f2ad4a4` passes the exact
20-case init differential on Darwin/arm64 and Linux/arm64. The comparator
verifies and builds immutable Go oracle `9c0e2b259753901a372ed5a688382bb6d4fadd18`.
Fourteen comparator controls pass; one Windows-only process-tree check is
explicitly skipped on these Unix hosts. Its optional disposable work directory
supports read-only source mounts and explicit Go caches are reused.

The real Swift `ConfiguredBinaryContractTests` suite passes separately with
Go and Rust: one test, zero failures, zero skips each. Xcode builds the current
source and exact-pinned AppKit dependency, then executes with isolated HOME/XDG
roots and a PATH excluding installed Symaira binaries. Result bundles and
`gui-receipt-f1263bea.json` bind both executable hashes and native summaries.

Both MCP fuzz targets pass 10,000 runs each on Darwin/arm64 using installed
nightly-2026-09-20 and cargo-fuzz 0.13.2, retained Go seeds copied into private
runtime directories, max input 1,048,577 bytes and RSS limit 2,048 MiB. The
tracked corpora are unchanged. `fuzz-receipt-f1263bea.json` and both native
`init-receipt-f1263bea.json` receipts retain logs, hashes and exact parameters.

Only documentation and the init comparator/control test changed since the
`b1fa75df` root gate; Go/Rust/Swift runtime source is unchanged. These receipts
do not replace remaining Browse, Linux fuzz or native Windows/other target
acceptance. Linux lacks the required nightly/fuzz tools; their installation
was not started before the requested session close. Migration remains open.


## Integrated root gates and usage deadlines — 2026-09-29

Candidate `b1fa75df5be9c871c5715913cefb316733300460` passes independent
native Darwin/arm64 and Linux/arm64 root gates: 882/881 outer Rust tests,
504 exact CLI comparisons, seven MCP comparison groups and nine Guard scan
cases. Go oracle freshness, the 11-case skills install/status oracle, 44 offline
distribution assertions, workspace formatting/check/strict Clippy and doc tests
pass. Two ignored child entrypoints are executed by their parent tests; nested
child summaries are not counted twice. Darwin also passes audit/deny with the
cached advisory database `ef03605143a913024f864d2edf476adad5720c93`
(2026-09-28; no freshness-to-current claim).

The integrated changes avoid Claude Keychain enumeration when OAuth environment
credentials already determine routing, preserve the no-cookie OpenCode workspace
case, check cancellation between provider batches and cap HTTP timeouts to the
absolute gateway report deadline. Actual 30-second exhaustion and a bounded
local TLS-stall exercise that deadline. The Go usage oracle's shared request
recorder is synchronized; its concurrent regression and actual oracle pass the
race detector. Adapter metadata applies final permissions after xattrs, matching
native macOS set-id semantics. The failed-doctor child fixture consumes initialize
and closes stdout before waiting for stdin closure, eliminating Go write/exit and
Wait/StdoutPipe races without normalizing away diagnostics.

The Darwin main gate uses private HOME/XDG/TMP and verified sandbox denial of
`security`, `ps` and `lsof`. Two exact tests run separately outside that sandbox:
the filesystem-only special-mode/xattr check and the lifecycle fixture's own
child-process check. Linux runs three original compiled relative-CWD tests in a
private writable runtime, since its source mount is read-only. Each is actually
executed; only those exact tests are filtered from the later workspace run.

`whole-brain-receipt-b1fa75df.json` in the existing Brain and native-linux build
roots binds candidate, manifest paths, counts, exceptions and logs. Log SHA-256:
Darwin `34aa0ce9832dc22d9c7ea9d05d4c36f1148ccfddbd1e6aaf3536c4fa5c0c3ca8`;
Linux `607e77394177867ac9a86483f878ea0f95d5979b6326cc59b06d92f8211b6fd0`.
These are local native root gates, not whole-ledger completion. Swift consumer,
dedicated init comparator, fuzz, Browse harnesses and remaining native targets
still require final-candidate acceptance. Live credential/host integration is not
proved; synchronous usage HTTP cannot immediately interrupt an already-blocked
read on arbitrary cancellation. Distribution signatures, archive/SBOM bytes and
installed package-manager artifacts remain outside the offline naming gate.
No publication, installed cutover or Go removal occurred.

## Corrected isolated usage gate — 2026-09-29

Candidate `7a6a66ad3e0cc659625b8bd0ae2c6e8f847b5e22` repairs the two test
isolation paths identified below. The Go registry-count test uses private
HOME/XDG and existing injected Keychain/process probes. The real CLI MCP
report uses a deliberately missing env reference, so Claude reports a
configuration error before Keychain or HTTP; assertions require every
credential-based provider to remain unconfigured and all snapshots absent.
Antigravity remains configured by design, but empty PATH must yield its
unavailable-process error. CLI usage routing tests get a synthetic default
Claude file only on true absence; their invalid flags return before fetching.
Existing files and symlinks are preserved, and other metadata errors fail.

Independent Darwin/arm64 and Linux/arm64 gates pass actual Go usage and
Gateway lifecycle tests plus usage/OpenCode freshness. Rust passes3+9+4
Gateway tests,62+9+9 usage tests on Darwin /62+8+9 on Linux, and20 CLI tests
on each, zero failures/ignored. Worker formatting and strict targeted Clippy
pass. Receipts `usage-isolation-receipt-7a6a66ad.json` retain candidate/test
hashes, metadata, logs and explicit isolation controls. Historical logs and
their corrections remain preserved; these reruns supersede their unsupported
no-host-isolation claims for the affected gates.

Real host integration, actual30s exhaustion, production OAuth-env routing's
unnecessary Keychain enumeration, required other targets and whole-ledger
acceptance remain open. No installed cutover or publication occurred.


## Evidence correction: usage test host isolation — 2026-09-29

The whole-gate review found that the existing CLI test
usage_subprocess_lists_and_calls_native_tool_without_go_fallback can reach
the absolute macOS security executable through Claude credential discovery.
A private HOME and empty PATH do not isolate that command. Earlier eager
Gateway construction could also discover credentials before an injected
fixture Service replaced it. Consequently, earlier assertions below that the
complete CLI/Gateway suites did not access host Keychain state are unsupported.
The synthetic parser/report tests remain separate from this discovery path. The Go registry-count test also directly constructs AllProviders(nil), so the full Go usage package requires the same isolation correction.

Historical execution logs are preserved. Darwin receipts now carry a later
isolation-review annotation; passing suite counts do not establish credential
isolation. A safe synthetic configuration that blocks both Keychain and live
provider requests is required before rerunning the integrated whole gate.
No whole-ledger or host-isolation completion is claimed.


## Integrated lazy per-call usage discovery — 2026-09-29

Candidate `7a5cd70f156e60a6c00a2f8a23f91e87d7239d9b` constructs the production
usage Service inside each allowed get_ai_usage dispatch instead of at Gateway
startup. Actual Go New/handleAIUsage and Rust Gateway/Service tests use an
isolated home, synthetic credentials and fake ps to prove no startup probe,
per-call discovery and newly written credential-file visibility. Pre-cancelled
reports return before spawning authenticated requests. The handler's 30-second
budget starts before discovery; elapsed-budget exhaustion was not separately
exercised in this slice.

Independent native Darwin/arm64 and Linux/arm64 gates pass Go usage tests,
actual Go gateway lifecycle and usage/OpenCode fixture freshness. Rust passes
3+9+4 Gateway tests, 62+9+9 usage tests on Darwin / 62+8+9 on Linux, and20 CLI
MCP tests on each, zero failures or ignored. Worker strict Clippy/fmt also pass.
`gateway-lazy-receipt-7a5cd70f.json` in both build roots binds clean candidate
metadata and log hashes. The Make rust-check gate includes the Go lifecycle.

USE-001 remains open for real host integration, elapsed deadline exhaustion,
remaining native targets and final whole-ledger acceptance. No real Keychain,
process table, provider, installed cutover or publication was used.


## Integrated Claude Keychain parser and report parity — 2026-09-29

Candidate `c9cd446079252ae67c74db8a6df67058f4fbc355` preserves Go's typed
Claude subscription credential parsing for 25 source-generated cases. These
cover ASCII and Unicode field folding, duplicate object merges, null handling,
wrong types, expiry, bytewise malformed UTF-8 replacement and paired/unpaired
UTF-16 escapes. The pure Go parser moved from the Darwin file without changing
its implementation; a fake-security Darwin test still reaches the production
reader. Rust reuses its existing production credential/report construction.

Four authenticated report cases compare actual Go allProviders/BuildReport
with a synthetic Keychain callback against Rust claude_from_resolved and
Service::with_transport. Both receive the same response status, body and
Retry-After header. Only fetched_at is fixed; output errors are not normalized.

Independent clean Darwin/arm64 and Linux/arm64 gates pass Go1.26.7 usage tests
and usage/OpenCode oracle freshness. Rust passes 62+9+8 usage tests on Darwin,
62+8+8 on Linux and all 20 CLI tests on both, zero failed or ignored. Worker
strict Clippy/fmt and Go vet pass. `keychain-parity-receipt-c9cd4460.json` in
both existing build roots retains source metadata and fixture/log hashes.

USE-001 remains open. The real host Keychain and installed service enumeration
were not exercised. CLI needs_go_fallback remains conservative; MCP Gateway
constructs Service::new directly, and that startup/discovery path was not
invoked by these synthetic tests. Required Windows/other native targets and
whole-ledger acceptance remain pending. No live credentials/provider access,
publication, installed cutover or Go removal occurred.


## Integrated active Antigravity usage probe — 2026-09-29

Candidate `ec6da43e84d2e4d85cab342714107c4f6ae3d400` routes Antigravity usage
through the native provider. It preserves Go's candidate/port traversal,
GetUnleashData handshake, CSRF/header/body contract and three-endpoint quota
fallback. Actual Go production constructors and BuildReport receive synthetic
process/port observations and canned HTTP replies; Rust replays the same inputs
through its production fetch path and compares reports plus request traces.

The reference generator rejects missing fixture bodies and validates intended
success/failure and request sequences before saving its observed output. Cases
cover a later listening port, another candidate, malformed-summary fallback,
no running process and all endpoints failing. Subprocess discovery reuses the
bounded runner with output limits during execution, kill/wait on errors,
absolute PATH resolution matching Go ErrDot rejection, and a PID ceiling.
A real Unix CLI regression uses a private synthetic ps executable; it never
reads the installed process table or Keychain.

Independent clean Darwin/arm64 and Linux/arm64 gates pass Go1.26.7 usage tests
and usage/OpenCode oracle freshness. Rust usage passes 60+9+8 on Darwin and
60+8+8 on Linux, with all20 CLI tests passing on each, zero failed/ignored.
Worker strict Clippy and fmt pass. Both build roots contain
`antigravity-receipt-ec6da43e.json` with source metadata and fixture/log hashes.

USE-001 remains open: installed Antigravity/its real TLS endpoint was not
exercised, Windows/other native targets remain pending, and Claude Keychain-only
or unproven credential shapes still use Go. No live credential/provider access,
publication, installed cutover or Go removal occurred.


## Integrated usage home overrides and canonical Nous JWT — 2026-09-29

Candidate `49c1905b175b078b43c6533c445462dd1bf8058f` enables proven Codex,
Kimi Code and Hermes credential-file shapes under explicit CODEX_HOME,
KIMI_CODE_HOME and HERMES_HOME. Empty overrides follow Go's default paths.
Canonical live Nous JWTs use Go's float64-to-int64 whole-second expiry behavior;
expired, malformed, padded/noncanonical or ambiguous claims remain on Go.

Actual Go cases include both orders of case-aliased and duplicate exp fields.
A raw serde map would hide typed Go decode failures; the production Rust visitor
now rejects duplicate/aliased expiry fields before native routing. Unrelated
claims remain ignored. Real Go NewNousPortalProvider/BuildReport and Rust's
production file-auth assembly compare success, 401, 429 and malformed responses.
The real CLI covers all three overrides without reading Keychain or live providers.

Independent clean-candidate Go1.26.7 usage package plus usage/OpenCode oracle
checks pass on Darwin/arm64 and Linux/arm64. Rust usage tests pass 55+9+8 on
Darwin and 55+8+8 on Linux; all 19 CLI tests pass on each, zero failures/ignored.
Worker strict usage/CLI Clippy and workspace fmt pass. Receipts
`home-jwt-receipt-49c1905b.json` in Brain/native-linux build roots retain source
metadata and log hashes. The source-bound CLI help literal remains unchanged.

USE-001 remains open for local provider routes and required native targets,
including Windows HOME/USERPROFILE mismatch execution. No publication, installed
cutover, Go removal, real credential access or live provider request occurred.

## Integrated remaining native usage routes — 2026-09-29

Candidate `b9cf5f62b9b6949ee3379170272a6272f68f468a` integrates the preceding
production assembly with strict default Kimi and plain-token Nous files,
KIMI_AUTH_TOKEN, supported provider combinations, Moonshot cn, canonical OpenCode
workspace overrides and bounded public HTTPS base overrides. Unknown fields,
case aliases, duplicates, secret references, custom homes and Nous JWT files
remain on Go. Kimi device_id files must be readable and valid header values.

Actual Go constructors and BuildReport now cover the combined five-provider
report, Kimi API-to-CLI-to-web fallback and Nous environment-over-file precedence.
These fixtures exposed timestamp defects: Rust now preserves reset offsets and
Go RFC3339Nano trailing-zero behavior. No reset values are masked in comparisons.
Two real CLI routing cases replace stale expectations and verify the widened
route before any live request; unsupported shapes still select Go.

Independent clean-candidate Go1.26.7 package plus usage and OpenCode oracle checks
pass on Darwin/arm64 and Linux/arm64. Rust usage tests pass 54+9+8 on Darwin and
54+8+8 on Linux, with all 18 CLI tests on each; zero failed/ignored. Receipts
`remaining-usage-receipt-b9cf5f62.json` in the Brain/native-linux build roots retain
log hashes and Cargo metadata proving this worktree's source paths.

USE-001 remains open for remaining routes and required native targets, including
Windows home routing. No real credentials, live provider requests, publication,
installed cutover or Go removal occurred.


## Integrated production provider assembly — 2026-09-29

Candidate `f99f13c6c7bb9dde4041b7a9186ec7285f5ac2fe` includes code `6d5d6056`
and all preceding usage file/routing slices. Nine authenticated direct-provider
replays now use the constructors called by production: Claude Admin, Codex,
Copilot, Cursor, Kimi, Moonshot, Nous, OpenRouter and OpenCode. Each active Rust
report row is compared to the corresponding actual Go BuildReport row. Expected
Go configuration/auth state is no longer copied into those test providers.
Inactive rows from older report fixtures are not claimed as assembly evidence.

This exposed and fixed an actual Claude Admin defect: the strategy and snapshot
source is `api`, while AuthStatus retains resolved credential provenance `env`.
The complete active-row regression now detects that difference. Existing success,
provider-error, request and workspace checks remain in place. No routing was widened.

Independent clean-candidate Go1.26.7 usage package/oracle checks and Rust tests pass
on Darwin/arm64 (46+9+8 usage) and Linux/arm64 (46+8+8), with all16 CLI MCP tests on
each; zero failed/ignored. Worker strict Clippy passed; parent workspace fmt passed
on the candidate after formatting one earlier Nous test assertion. Receipts
`provider-assembly-receipt-f99f13c6.json` in the Brain/native-linux build roots retain
native toolchain identity, log hashes and metadata proving this worktree's sources.

USE-001 remains open for other configured routes and required native platforms,
including the Windows home-routing regression. No real credentials, live provider
requests, publication, installed cutover or Go removal occurred.


## Integrated usage file-routing guards — 2026-09-29

Candidate `246cbc1be691f9060d3540054bfea81764464ff8` fixes an existing routing
hole without enabling Nous files natively. Any possibly present default Hermes
`auth.json` keeps Go, including malformed/unrecognized files, metadata errors
and symlinks. A production-Go seven-case parser oracle proves that case-insensitive
Nous field names can provide a token where the Rust best-effort parser sees none;
missing/empty/malformed/wrong-typed/unrelated cases are also recorded. CLI checks
prove present files stay on Go and an absent file preserves native routing.

A Windows-only guard keeps the entire usage report on Go when HOME and USERPROFILE
differ, replacing the narrower Copilot-only probe. Its real CLI regression is
committed under cfg(windows), but was not executed on the available native hosts.
This is an explicit remaining Windows acceptance gap.

Independent clean-candidate Go1.26.7 package/oracle and Rust tests pass on
Darwin/arm64 (46+9+8 usage) and Linux/arm64 (46+8+8), with all16 CLI MCP tests on
each; zero failed/ignored. Receipts `usage-guards-receipt-246cbc1b.json` are retained
in the existing Brain/native-linux build roots. USE-001 remains open for direct-env
production-constructor evidence, remaining provider routes and native platforms.
No live providers, real credentials, publication, installed cutover or Go removal.


## Integrated Copilot default-file evidence — 2026-09-29

Candidate `4d4042c62184d28a337d0eb686673dedf592850d` adds a sole deterministic
Copilot token from default `~/.config/github-copilot/apps.json`, or `hosts.json`
when apps is absent, to the native usage route. Unknown/ambiguous/malformed
existing file shapes, mixed sources and secret-reference tokens stay on Go.
The provider's existing parser is preserved; strict eligibility fences routing.

Sixteen real Go parser cases include apps precedence, hosts fallback, duplicate
root keys, case-insensitive fields, typed errors, unknown metadata, references,
and map-order ambiguity. Ambiguous Go choices use allowed sets, not frozen winners.
The authenticated success/401/429/malformed reports compare actual single-provider
Go and Rust production constructors with canned transport; only fetched_at is fixed.
Rust auth/configuration is not copied from the expected fixture for these cases.

Independent clean-candidate Go1.26.7 package/oracle checks and Rust tests pass on
Darwin/arm64 (45+9+8 usage tests) and Linux/arm64 (45+8+8), plus all15 CLI MCP tests
on each; zero failed/ignored. Receipts `copilot-file-receipt-4d4042c6.json` live in
the existing Brain and native-linux build roots. Other target platforms remain open.

Review identified further work: unrecognized existing Nous files and divergent
Windows HOME/USERPROFILE roots can evade current fallback detection. Also older
direct-env report tests seed configured/auth_status from the expected oracle and
therefore do not independently prove production assembly. These remain explicit
USE-001 gaps; this file-only slice does not close the row. No real credentials,
live provider, publication, installed cutover or Go removal occurred.


## Integrated Claude file compatibility evidence — 2026-09-29

Candidate `cbfc46a94e5c6f8aa15730130ed2dd33590d35a9` includes code `14a54551`
and the preceding Codex/Claude/Browse slices. Typed candidate parsing now keeps
ambiguous account selection, alternate field casing, duplicate root fields,
wrong-typed siblings, malformed input and unknown metadata on Go before a
Keychain probe. Exact default selection, a sole nondefault token and Go-equivalent
duplicate same-account keys remain native. Unknown metadata is a deliberate
conservative limit, not a claim that Go rejects it.

Ten real Go `readClaudeFileToken` cases exercise these differences without
constructing a provider or reading a Keychain. Nondeterministic map selection
is checked against its two-token allowed set; no single random winner is frozen.
Independent clean-candidate Go1.26.7 usage package/oracle and Rust tests pass on
Darwin/arm64 (43+9+8 usage tests) and Linux/arm64 (43+8+8), plus all 14 CLI MCP
tests on each; zero failed or ignored. Receipts `claude-compat-receipt-cbfc46a9.json`
are retained under the existing Brain and native-linux build roots.

This resolves the parser-routing defect described below. USE-001 remains open
for remaining provider paths and required native targets. No real credentials,
live provider requests, publication, installed cutover or Go removal occurred.


## Integrated Codex default-file evidence — 2026-09-29

Candidate `d634d71b24825073be565e1c0fdf9fd692d44437` includes `bad314a2`
and prior Claude/Browse slices. A sole token from default `~/.codex/auth.json`
now selects native reporting. Top-level token precedence, nested token shape,
invalid-file status, env-over-file precedence and reference/override/mixed-source
fallback are checked. `CODEX_HOME` overrides remain on Go.

The actual Go provider/BuildReport oracle compares success, 401, 429 and malformed
responses with the real Rust provider builder. Only fetched-at is pinned;
provider-derived reset timestamps are preserved. Independent exact-clean-HEAD
Go1.26.7 package/oracle and Rust gates pass on Darwin/arm64 (42+9+8 usage tests)
and Linux/arm64 (42+8+8); both pass all 13 CLI MCP tests, zero failed/ignored.
Receipts are `../builds/symaira-brain/claude-oauth-usage-20260929/codex-file-receipt-d634d71b.json`
and `../builds/native-linux-20260929/codex-file-receipt-d634d71b.json`.

Source review also identified an open limitation of the prior Claude file gate:
Go typed JSON accepts alternate field casing and merges structured duplicates,
rejects invalid typed siblings, and chooses arbitrarily among non-default
accounts. Rust's existing Value parser does not have the same behavior. A
follow-on conservative eligibility fix keeps unproven forms on Go. Prior
canonical default-file evidence does not establish parity for those forms.
The fix is now covered by the integrated Claude compatibility evidence above;
USE-001 remains open for remaining providers and other native targets.
No live provider/Keychain access, publication, cutover or Go removal.


## Integrated Claude env/file OAuth evidence — 2026-09-29

- Implementation candidate `732412fe2dab303ae56987937b595f8582290511`
  includes the prior Browse daemon and direct OAuth slices. A sole valid
  default Claude credential file now selects the native report path. Mixed
  sources, references and provider overrides still select Go.
- Production Go `NewClaudeProvider` plus `BuildReport` provides success,
  401, 429 and malformed-response fixtures for environment and file sources.
  Rust invokes its real provider builder: AuthStatus retains `env` or `file`,
  while the OAuth snapshot reports `oauth`. The differential caught and fixed
  that distinction. Valid synthetic files avoid any real Keychain read.
- Independent coordinator checks on clean exact HEAD passed the Go1.26.7
  oracle, all usage tests (Darwin/arm64: 39+9+8; Linux/arm64: 39+8+8), and all
  12 CLI MCP integration tests, with zero failures or ignored tests.
  Darwin log: `../builds/symaira-brain/claude-oauth-usage-20260929/coordinator-file-732412fe.log`.
  Linux receipt: `../builds/native-linux-20260929/brain-file-oauth-receipt-732412fe.json`.
  Cargo metadata and compiler source paths bind both runs to this worktree.
- USE-001 remains open for other native targets and remaining provider paths.
  These checks do not complete the full integrated migration ledger. No real
  provider call, release, installed cutover or Go removal occurred.


## Resume checkpoint — 2026-09-29 (local integrated OAuth candidate)

- Candidate `7390afb944893bc8c2a5a573942a39212caff346` includes the Browse daemon
  gate slice `78723fef` and direct Claude OAuth reporting `5a2bcb31`. Go remains
  production; no publication, cutover or Go removal occurred.
- USE-001 now dispatches a sole direct `ANTHROPIC_OAUTH_TOKEN` natively. Secret
  references, credential files/keychain, mixed credentials and configured
  overrides retain the existing Go gate. The oracle invokes production Go
  `NewClaudeProvider` and `BuildReport` with synthetic credentials and a canned
  transport: success, 401, 429 and malformed JSON, with request authentication
  asserted. Only dynamic `fetched_at` is normalized; reset timestamps are compared.
- Parent acceptance at this exact candidate on Darwin/arm64: pinned Go1.26.7
  `make usage-oracle-check` passed; `cargo test -p symbrain-usage --locked`
  passed 37 unit, 9 secret and 8 report tests. The CLI test
  `direct_claude_oauth_routes_usage_to_native_parser_without_provider_request`
  passed once and proves routing before a provider request. Parent review
  required removal of reset-timestamp normalization, fixed by `7390afb`.
  A first parent suite attempt used a nonexistent isolated TMPDIR and failed;
  it is not acceptance evidence. The rerun used an explicitly created secure
  runtime directory and passed. Worker fmt and strict Clippy also passed.
- Receipts: external `builds/symaira-brain/claude-oauth-usage-20260929/`, including
  `coordinator-go-oracle-7390afb.log`, `coordinator-usage-7390afb-rerun.log`,
  `coordinator-cli-oauth-7390afb.log` and source-bound Cargo metadata. Required
  native target receipts for this integrated candidate remain pending. The
  historical green rows below do not establish acceptance of these new changes.

## Resume checkpoint — 2026-09-24 (native SEC-005 candidate)

- **Integrated base:** `main` is `d8ccd31c` after PR #674; post-merge CI [35927186139](https://github.com/danieljustus/symaira-brain/actions/runs/35927186139) passed. Draft PR [#677](https://github.com/danieljustus/symaira-brain/pull/677) reached `e07a651d`; [CI 35935398952](https://github.com/danieljustus/symaira-brain/actions/runs/35935398952) passed 25 jobs with one intentional coverage-publish skip, including the full Linux/macOS gates and native Windows Go/Rust CLI differential and workspace tests. [Rust guard 35935398958](https://github.com/danieljustus/symaira-brain/actions/runs/35935398958) passed on the same SHA. The first PR attempt exposed strict Clippy findings, corrected at `ab305716`. Windows CLI differential then exposed mixed separators in the shared Guard source path helper, corrected at `620e8625`; `e07a651d` additionally cleans slash-form and parent-containing base paths. No release, cutover, Go removal, paid provider or destructive cleanup is authorized.
- **SEC-005 candidate:** the existing Go-compatible JSON syntax scanner now handles malformed audit anchors natively; a narrow TOML missing-equals class handles the invalid-config scenario natively. Unsupported parser/type/read errors still gate before output. The frozen Go doctor oracle has nine cases, all nine pass through the native Rust binary on macOS. Independent read-only reviews found no actionable parity defects.
- **Local executable receipts:** pinned Go 1.26.7 oracle `-check` reports zero drift across nine cases; the focused Rust integration and six doctor unit tests pass; the full CLI differential reports 459 passing cases on macOS, including both newly native doctor errors. `cargo fmt --check`, `gofmt`, Python syntax and `git diff --check` pass. An unpinned Go 1.27.1 differential run produced two unrelated harness JSON-diagnostic differences and is discarded; the repository-pinned Go 1.26.7 run passed.
- **Ledger reconciliation:** SEC-005 is promoted from five of seven native cases to nine of nine on Linux, macOS, and Windows. The independent review's suspected `foo/..` path defect did not reproduce; a direct Rust `PathBuf::pop` probe confirmed the behavior and a regression assertion now covers the full cleaner input. The matrix has 72 rows: 70 green and only DIST-001/002 pending.
- **Windows broker gate:** CI on ledger commit `4b7cb469` passed the Windows doctor oracle, CLI differential, and Rust workspace, but `internal/broker.TestClient_CallAfterClose_ReturnsClosedError` timed out in the portable broker step. The Go read loop exposed `Done()` before setting `pending = nil`, letting a new call block writing to an unconsumed pipe. The close-state ordering is fixed; pinned Go 1.26.7 passes 100 focused repetitions and the full broker race suite locally. The final candidate still needs all target gates.
- **Remaining gates:** run CI on the broker fix, integrate PR #677, then verify the exact merged `main` SHA. DIST-001/002 still require a real current release with signed assets, SBOM, Homebrew and install receipts; `v0.12.0` is absent. Preserve the existing worktrees and build caches. Storage exhausted during this slice: the internal data volume rejected small source writes, so follow-up work uses the isolated external worktree `.worktrees/codex-sec005-path-clean-20260924` from `620e8625`; no cache was removed.

## Resume checkpoint — 2026-09-23 (final integrated candidate)

- **Mode:** execute; goal active. Draft PR [#674](https://github.com/danieljustus/symaira-brain/pull/674) uses `codex/migration-integrated-20260923`. The branch includes source fixes, the reconciled matrix and two Guard fallback differential cases. `main` remains untouched. No publication, cutover, Go removal, paid provider, or destructive cleanup is authorized.
- **Integrated source receipts:** [CI 35908259861](https://github.com/danieljustus/symaira-brain/actions/runs/35908259861) passed every job on `4c699b46`, including Linux/macOS Rust gates, native Linux/macOS/Windows differential gates, the GoReleaser snapshot and GUI Go/Rust binary contracts (one passed, zero failed/skipped for each binary on Xcode 26.6). The native Windows `symbrain-managed` suite executed six install tests, including `.exe` version and timeout probes, with zero skips.
- **Ledger reconciliation:** `migration/contract-matrix.csv` has 72 distinct rows. Edits record target-platform receipts for CLI-006A/007/009/010, MCP-001..005, SEC-001, SET-001, GUI-001, INS-002, ADR-001..004, SKL-002/003 and USE-001. SEC-005 has five native Go-oracle matches out of seven; malformed TOML and JSON anchor diagnostics deliberately gate to Go before output because exact parser error text has no native port. The new two-case CLI differential proves the fallback's exact bytes and exit status locally; native CI on the final SHA is still required.
- **External boundaries:** DIST-001/002 have an offline `dist-oracle` (44/44) and six staged GoReleaser archives/checksums, while current signed release assets, SBOM, Homebrew and install receipts require a real release. External NVMe free space fluctuated from roughly 30 MiB to 5 GiB; preserve all worktrees and build data.
- **Next gate:** the two new Guard cases pass locally against the existing binaries; rebuilding Rust locally hit `ENOSPC` on the external target volume, so native CI must verify them on fresh binaries at the current integrated HEAD. SEC-005 remains partial native and release-only rows stay non-green without separate authorization.

## Resume checkpoint — 2026-09-23 (integrated evidence audit in progress)

- **Mode:** execute; goal active. `origin/main` and local `main` are `2c7eac6034c15cc0d785bc309b263d92b64cb2fa`. This branch starts at PR #654 (`2731787d`) and merges that exact `main` as its second parent. The working-tree source under `rust/` and `scripts/secret-oracle/` is identical to `origin/main`; the ledger edits are not acceptance evidence themselves.
- **Verified at `2c7eac60`:** CI runs `35864722105` (CI) and `35864722125` (Rust guard) concluded success for that exact SHA. Linux and macOS `rust-migration` execute `make rust-check parity-smoke`; Windows currently runs audit/guard, init and selected skills tests, not the whole ledger. Locally, `go run ./scripts/secret-oracle -check` passed **30** Go cases on this candidate source, and `cargo test -p symbrain-usage --test secret_oracle_tests --locked` passed **9** Rust tests. `make usage-oracle-check usage-opencode-check`, `cargo test -p symbrain-usage --locked` (**25 + 9 + 8** tests) and strict all-target usage Clippy passed. All local commands used `scripts/run-external-env.sh` on the mounted NVMe. A first filtered cargo invocation executed zero tests and is explicitly discarded.
- **MCP row correction at the same SHA:** `make gateway-oracle-check mcp-oracle-check` passed **8** gateway and **20** framing cases; `cargo test -p symbrain-gateway --locked` and `cargo test -p symbrain-mcp --locked` exercised the matching Rust suites. MCP-001/002/004 previously cited `scripts/mcp-oracle`, whose 20 cases only cover framing. Their actual initialize/list/stdout Go black-box fixture is `scripts/gateway-oracle`, now named in the matrix. MCP-003 remains partial because the Go fixture covers routing/errors while connection cancellation and Windows runtime are not jointly proven.
- **Active isolated lanes:** GUI-001 in `.worktrees/codex-gui-001-20260923` (base `2c7eac60`); DIST-001/002 in `.worktrees/codex-dist-001-20260923` (open PR #659 head `702eede9`, merged `2c7eac60` as `c12953c4`). DIST's offline oracle was independently rerun: **44/44** assertions, while v0.12.0 has no published release and the latest v0.11.0 release has 40 captured assets. Live byte/signature checks are in progress. A separate Windows target-evidence audit is in progress. None of these lanes is promoted on its own branch result.
- **Residuals:** SEC-001 and USE-001 have no native Windows runtime receipt for their full rows. The `all`-platform matrix rows need a row-by-row current-candidate target audit. DIST signing/SBOM/Homebrew asset checks and GUI integration remain open. Authenticated live Usage paths still use the Go fallback; no real credentials or paid endpoints are authorized for this run. Release, cutover, Go removal and destructive cleanup are outside scope.
- **Next:** integrate independently reviewed lanes, run affected checks and the complete applicable ledger gates on the integrated candidate, obtain native target evidence, then update row statuses from receipts. Preserve all pre-existing worktrees and WIP.

## Resume checkpoint — 2026-09-22 (wave results): SEC-002 merged, SEC-001 slice 1 in review, #621 verdict + fix slice

- **SEC-002 merged as #650** (squash `85d528c4`; CI green on linux/macos/windows incl. `rust-migration`, `rust-migration-macos`, `rust-init-native` (ubuntu+windows), `stdio-hygiene`, `rust-windows-audit-guard`). Coordinator verification, not worker claims: `go run ./guard/scripts/guard-oracle -check` x2 -> `0 drift on 164 cases`; `go test ./guard/...` ok; `gofmt -l`/`go vet` clean; `cargo test -p symbrain-guard-core` 41 pass; `cargo test -p symbrain-cli guard` 14 pass; `cargo clippy --all-targets -- -D warnings` 0 on both crates; `cargo fmt --all --check` clean; scope = 12 files (oracle generator + guard-core + one cli test); base-checked. Matrix row SEC-002 promoted: `go_oracle` corrected to `guard/scripts/guard-oracle` (the generator that actually pins the bytes), `rust_test` now names the two real test paths, comparison set to `exact-json-and-errors` (no file-manifest test exists in this slice).
- **Dispatch lesson, confirmed twice in one session:** the first wave's SEC-001 and #621 children spent their whole budget in read-only discovery and wrote nothing; the narrowed re-dispatch (transcript findings pre-seeded into the brief, commit-first instruction) delivered both. Future briefs must fold prior-transcript findings in and demand an early commit.
- **SEC-001 slice 1 (resolution) -> PR #652 open.** New `scripts/secret-oracle` (27 cases; drives the real `internal/memory/secrets` + corekit `secretref` against a fake `symvault` on PATH, throwaway HOME/XDG) plus the native match in `symbrain-usage`. Coordinator reran every acceptance gate before and after rebase onto `85d528c4` (oracle x2, 36 cargo tests, clippy, fmt, gofmt, vet). Redaction = slice 2. Recorded boundaries: lossy non-UTF-8 secret stdout (now issue **#653**), Rust stdout cap (hardening), `keychain://` fixture exclusion. The matrix row stays `pending` until #652 merges.
- **#621 verdict: still-broken.** All five reported symptoms reproduced on post-#647 main; evidence comment posted on the issue. The Rust-parity part (native sync resolves `symbrain/skills` while Go's `internal/paths.resolve` prefers the legacy `symskills` root when it exists — regression new since #647) is dispatched as a fix slice in `.worktrees/i621-drift`. Go-side design gaps stay owner decisions on the issue: no `pull` verb behind the `use symskills pull` hint, `--force` undefined on Go and silently ignored in the shipped binary, base snapshots never advance, no render->library import.
- **Closeout:** superseded provisioned worktrees (`sec001-secret`, `sec002-guard`) and the dead first-wave child worktrees/branches without commits are removed; `subagent-sa-0-453f1033` (PR #652) and the #621 evidence worktree are kept while their PRs/issues are open; the fix child's worktree stays until integration.
- **Promotion gates run on `85d528c4`** (disjoint crates; the run predated the `1ee25ba8` merge and is unaffected by it): `go test ./internal/harness/...` ok; guard/instructions/adapters/skills/skills-install oracles `-check` all PASS (164/32/25/-/11 cases); `cargo test -p symbrain-harness -p symbrain-instructions -p symbrain-adapter -p symbrain-skills` all suites ok; the tree stayed clean (generators wrote nothing). 13 `fixture-ready` rows promoted (HAR-001..006, SEC-003, SEC-004, INS-001, ADR-005, SKL-001..003) after verifying each row's `rust_test` path exists; `DOC-001` stays fixture-ready until the `scripts/rust-differential.py` doctor cases run (`make parity-smoke` in flight).
### Resume checkpoint — 2026-09-22 evening (manual stop requested)

**Merged today, coordinator-verified:** #650 SEC-002 (`85d528c4`) · #652 SEC-001 slice 1 (`1ee25ba8`, merged red — see correction above) · #656 secret-oracle compiled fake (`918f9eb0`) · (externally) #657 CoreKit evidence (`7ea853d3`). Main was CI-green at `7ea853d3`.

**Dispatch wave `deleg_8c94acdb` results (all three children verified by the coordinator, not by their claims):**
- **Slice 2 / SEC-001 redaction — DONE, PR #658 open** (`be2578b4`): value_leaks object per failed case from real Go runs, generation fails loud if any channel carries a plaintext (pins `resolve.go:44`), +2 post-value failure probes, counts 27->29. My runs: oracle -check x2 PASS (29), gofmt/vet/security ok, usage tests+clippy+fmt clean, scope exactly 3 files. Side finding: `provider_errors.rs::redact()` has no Go twin in repo or corekit — Rust-only hardening, out of this row's scope, recorded here.
- **DIST-001/002 — DONE, PR #659 open** (`702eede9`): offline `scripts/dist-oracle -check` gate, golden manifest of the real v0.11.0 release (40 assets), static goreleaser assertions. My runs: check exit 0, corrupted-manifest self-test exit 1, restored 0, gofmt/vet/security ok, scope only `scripts/dist-oracle/**`. Six honest `not-run:` lines (cosign bytes, rebuild, syft regen, brew install, digest recompute, live fetch).
- **GUI-001 — DONE, verified, NOT pushed, NO PR** (`25709be7`, base `7ea853d3`): only `Tests/SymBrainCoreTests/ModelTests.swift` +114; child found NO Rust schema gap (version/doctor/profile/sync JSON byte-identical Go vs Rust after path normalization; env switch `SYMBRAIN_TEST_BINARY` else `$HOME/.symbrain-test-binary` because xcodebuild drops env to xctest). My runs: scope/forbidden/tree clean; full SymBrainCore suite against the Rust binary `TEST SUCCEEDED` exit 0 in 38.9s. First GUI dispatch died mid-research empty; this is the re-dispatch (`deleg_7ce9d4cd`).
- Also today: issue #621 comment (item 4 fix in #655, item 3 reclassified as Go design), issue #480 comment (skills_targets_native /private/var evidence), issue #653 (non-UTF-8 secret bytes), matrix CSV structural repair, all 14 fixture-ready rows promoted, DOC-001 green (parity-smoke 457/457 incl. doctor cases).

**Exact next actions on resume (in order):**
1. `git fetch` on main; for each of #654 (head `a0496d28`), #655 (`87b44e25`), #658, #659: `gh pr checks <n> | grep -v $'\tpass\t'` must be empty; if BEHIND, `git merge origin/main` in that branch again (up-to-date rule blocked merges once today), rerun focused gates, push; then squash-merge, read back, `git pull --ff-only` on main. CI runs continue server-side — the four local watches were stopped at the manual stop.
2. Push `hermes-subagent/subagent-sa-0-1e4cc990` (25709be7), open PR, watch, merge (already coordinator-verified).
3. Promotions on this docs branch after the respective merges: SEC-001 -> `green-29-oracle-cases-resolution-and-redaction`; DIST-001/002 -> green with the not-run list kept in the status/ledger; GUI-001 -> `green-115-swift-tests-both-binaries-json-byte-identical`; note #621 item 4 closed via #655.
4. Closeout: remove merged/dead worktrees+branches (i621-drift unused, subagent-sa-1-8e033e27 evidence worktree after #621 follow-up, sa-1-c48b1172 already merged), then Phase 12 / remaining gaps (GCLI-PLAT-01 row state, open promise: usage row #620 Teil 2 OpenCode gaps per ledger).

**Session lessons already written into this skill:** CI watches must run unpiped; children don't push — push their branches yourself; `gh pr merge` fails behind the up-to-date rule — integrate main first.

- **Wave dispatched (`deleg_8c94acdb`, base `origin/main@918f9eb0`):** (A) SEC-001 slice 2 redaction — child `sa-0-893cc031`: Go-generated value-leak invariant on `scripts/secret-oracle`, plus a report-not-invent hunt for the Go origin of `rust/symbrain-usage/src/provider_errors.rs::redact()` (exact-phrase greps of repo+corekit already negative). (B) DIST-001+002 — child `sa-1-e59964aa`: golden artifact manifest pinned from the real v0.11.0 release (40 assets) + `scripts/dist-oracle -check` gate over `.goreleaser.yml`; `not-run` lines mandatory for anything requiring cosign/builds. (C) GUI-001 — child `sa-2-6d42f3b3`: SymBrainCore test suite against BOTH Go and Rust binaries for version/command JSON schemas; Rust-side fixes only, no weakened Swift assertions. All three write only in their runtime worktrees; no file overlap; no GitHub writes by children.
- **Correction (same day, factual):** #652 was merged with `go-test-shard (2)` RED. `internal/security.TestNoShellInterpolation` flagged `scripts/secret-oracle/main.go:86` (the shell-script fake symvault); the CI watch had been piped through `tail`, so `gh pr checks --watch --fail-fast`'s own exit status was masked and only `tail`'s 0 was observed. Main's push run for `1ee25ba8` (`35739040256`) was `failure`. Fixed in **#656** (compiled fake helper with JSON sidecar; the 27-case fixture stayed byte-identical), merged as `918f9eb0`; the verifiable facts are: `go test -count=1 ./internal/security/` ok on the fix branch, `gh pr checks 656` all-pass unpiped before merge, and the push run for `918f9eb0` on main. Standing rule now recorded in the skill: never pipe a CI watch; print non-pass checks before merging.
- **DOC-001 promoted:** `make parity-smoke` exited 0 with `457 parity cases passed`; its recipe runs `python3 scripts/rust-differential.py <go> <rust>`, whose corpus contains the `doctor_*` JSON/human/flag cases (16 doctor mentions: `doctor_empty_json`, `doctor_empty_human`, `doctor_global_json`, `doctor_help`, ...). Row is now `green-457-parity-cases-doctor-json-and-human`. With that, no `fixture-ready` row remains.
- **Update same day:** #652 merged after green CI on all platforms (squash `1ee25ba8`); SEC-001 promoted to `partial-resolution-native-27-oracle-cases-redaction-pending` with its real oracle/test paths.
- **Next:** merge #652 -> promote SEC-001 as `partial` (resolution native, redaction pending); integrate the #621 fix slice; run the 14 `fixture-ready` promotion gates; Phase 11 (`DIST-001`, `DIST-002`, `GUI-001`) untouched.

## Resume checkpoint — 2026-09-22 (reconciled): skills Slices A+B are on main; next open rows SEC-001/SEC-002

**Base: main `fadfdab9`** (2026-09-21 22:51, `#647`), coordinator checkout clean at session start.

- **Reconciled, not rediscovered.** The skills-runner slices landed as `#644` (runner port), `#645` (on-disk freeze), `#646` (render-dir symlink target) and `#647` (native `sync`), so the "verify Slice A, then Slice B" next action and the `guard doctor` next action are both complete on this revision; `#624` (atime flake) is closed. Go SEC-001 baseline measured here: `go test ./internal/memory/secrets/...` passes.
- **Stale worktree retired with evidence.** `.worktrees/w-install-disk` (`migration/install-disk-oracle-20260921`) was verified fully superseded: its committed content is a subset of main (squash-merged as `#645`/`#646`) and its uncommitted diff held only the pre-refinement `match` form of the `render_dir` fix that main carries as `if let`. Diff archived to the session scratch dir; worktree and branch removed.
- **Task order for this session (dependency order):**
  1. `SEC-001` secret-reference resolution and redaction — Go oracle from `internal/memory/secrets/resolve.go` + `internal/memory/security/jwt.go`; existing ad-hoc Rust `symvault://` handling lives in `rust/symbrain-usage/src/provider_config.rs`, `rust/symbrain-cli/src/doctor_cli.rs`, `rust/symbrain-cli/src/doctor_links.rs`.
  2. `SEC-002` guard decisions/grants/audit chain — `guard/internal/{approval,grant,audit}`, oracle generator `guard/scripts/guard-oracle`, Rust side `rust/symbrain-guard-core` (`tests/oracle_tests.rs` already exists for SEC-003/004 — extend it, do not fork it).
  3. `#621` skills-status drift: re-verify against post-`#647` main before any fix; close with evidence or fix in its own slice.
  4. Promote `fixture-ready` rows only by running their gates (`DOC-001`, `SEC-003/004`, `HAR-001..006`, `INS-001`, `ADR-005`, `SKL-001..003`); the coordinator edits the matrix.
  5. Phase 11 (`DIST-001`, `DIST-002`, `GUI-001`) remains the largest open block.
- **Loaded this session — do not reload:** `go-to-rust-migration` + `references/worker-dispatch.md`, `go-rust-port-parity` + `references/workflow.md`, `guard-repo`, `autonomous-coding-agents`, `parallel-repo-agents`, `code-editing`.
- **Wave 20260922:** three isolated worktrees off `fadfdab9` — `migration/sec001-secret-resolution-20260922` (`.worktrees/sec001-secret`), `migration/sec002-guard-decisions-20260922` (`.worktrees/sec002-guard`), `migration/i621-skills-drift-20260922` (`.worktrees/i621-drift`). `make rust-check` measured GREEN on `fadfdab9` (exit 0, 415 s wall, ends `advisories ok, bans ok, licenses ok, sources ok`). Matrix: only a CSV-structural repair in this checkpoint — lines 13 (`CLI-006B`) and 38 (`CFG-001`) had unquoted commas inside `fixture_or_input`, so strict parsers shifted columns (e.g. `CFG-001.status` read as `scripts/xdg-oracle`); both fixture fields are now quoted, content byte-identical to HEAD, verified: 72 rows x 8 fields, 0 malformed, status census unchanged (14 fixture-ready, 5 pending). No row status was promoted.
- **Still not authorized:** Go removal, tag/publish/release, pushing unverified work, claiming `fixture-ready` rows green.

## Resume checkpoint — 2026-09-21 (symlink target): the install divergence is closed, not documented

**Branch `fix/symlink-target-render-dir` (base: main `b8668f3f`).** This removes the last open divergence between the Rust skills install path and Go.

**The fix.** `InstallOptions` gains an optional `render_dir`. In symlink mode the stable tree is now written to and linked at `<render_dir>/<target>/<name>` — exactly the `item.Path` Go's `render.RenderAll` produces and `install_ops.go` links to — instead of the hardcoded per-user cache. A caller with no render root (the gateway's in-memory install path) keeps the cache and says so in a comment; the option defaults to `None`, so no existing caller changes behaviour silently.

**Proof, not assertion.** `rust/symbrain-skills/tests/runner_env_tests.rs::installed_symlinks_match_the_frozen_go_layout` runs the real runner over a throwaway root and asserts every installed symlink's resolved target against the layout frozen in `runner_oracle.json`. It fails before the fix and passes after, for all four targets (claude, codex, hermes, opencode).

**Three defects surfaced while closing it, all fixed here:**

1. `match` on a single `Some` pattern kept `cargo clippy --all-targets` red (3 errors); it is an `if let … else` now. Clippy --all-targets = 0.
2. The new field broke a full-literal constructor in a **different** crate — `symbrain-gateway/src/embedded/skills.rs` failed with `missing field render_dir` and `cargo test -p symbrain-cli` exited 101. Per-crate testing never sees this; `cargo build --workspace --all-features` does.
3. My own test resolved fixture paths wrongly (paths are relative, only targets carry `$ROOT`); it reported "not installed" for a target that was installed.

**Gates measured on this branch:** `cargo fmt --all --check` clean; `cargo build --workspace --all-features` no errors; `cargo clippy -p symbrain-skills --all-targets` 0 errors; `cargo test -p symbrain-skills` 108 passed / 0 failed; `cargo test -p symbrain-cli` 216 passed / 0 failed; `cargo test -p symbrain-gateway` 13 passed / 0 failed; `go run ./scripts/skills-runner-oracle -check` passes.

**Slice B is now unblocked.** The Go fallback in `sync_cli.rs` can drop once this lands: the runner's result messages (#644), its on-disk layout (#645) and now its symlink target are each frozen against real Go behaviour.

## Resume checkpoint — 2026-09-21 (install disk): the install divergence is now measured, not assumed

**Branch `migration/install-disk-oracle-20260921` @ `276cd051` (base: main `d6f81c99`).**

The runner's result messages were proven in the previous slice; what a real run leaves **on disk** was not. `scripts/skills-runner-oracle` now also runs the genuine Go `skillsrunner.Run` over a throwaway root and records every file and symlink relative to `$ROOT`, with `-check` comparing them too. 26 entries, measured in this session:

- The four installed symlinks point **straight at the configured render dir**: `.claude/skills/demo → $ROOT/rendered/claude/demo`, `.hermes/skills/symaira/demo → $ROOT/rendered/hermes/demo`, `.agents/skills/demo → $ROOT/rendered/codex/demo`, `.config/opencode/skills/demo → $ROOT/rendered/opencode/demo`. This is `install_ops.go`'s `os.Symlink(item.Path, tmp)` where `item.Path` is what `RenderAll` set to `<RenderDir>/<target>/<name>`.
- `rendered/<target>/demo/` holds the generated `SKILL.md` (codex additionally `agents/openai.yaml`), plus a `.symskills-lock-<name>` entry per target.
- `base/<target>/demo/` holds the snapshot the install writes.

**Two oracle defects found and fixed here, both of which would have produced a silently wrong fixture:**

1. `-check` reported drift on identical data because `diskEntry.Marker` is a pointer-to-map, so the struct `!=` compared addresses. Now compared field-by-field with `reflect.DeepEqual`; two consecutive checks pass.
2. The marker file an install writes embeds `installed: <RFC3339 now>` (`install_ops.go`), so hashing its bytes drifts by construction. The volatile field is dropped and every path value in the marker has the temp root rewritten to `$ROOT`. Two generations now hash identically (`38bc9ff31a9fcce4`).

**Why Slice B is still gated.** The Rust install layer cannot reach the Go symlink target as it stands, and that is structural, not a slip: `InstallOptions` (`rust/symbrain-skills/src/install/core.rs`) carries no render-directory field, `Rendered` (`rust/symbrain-skills/src/render.rs`) carries no `path`, and symlink mode materializes into a hardcoded `home/.local/share/symskills/rendered/...` before linking there. Closing it means giving the install layer the same `Rendered.Path` concept Go has, then re-deriving the symlink target under this oracle. Until then the Go fallback in `sync_cli.rs` stays.

**Gates measured on `276cd051`:** `go run ./scripts/skills-runner-oracle -check` passes twice; generator output hash stable across generations; `gofmt -l` empty; `go vet` clean; `cargo test -p symbrain-skills` 107 passed / 0 failed / 2 ignored; `cargo test -p symbrain-cli` 216 passed / 0 failed.

## Resume checkpoint — 2026-09-21 (skills-runner): crate-side port proven, five measured gaps closed, Slice B gated

**Branch `migration/skills-runner-delta-20260921` @ `acf4e69e` (base: main `14f9d0ee`).** Every claim below came from a command run in this session, not from a worker report.

- `cargo fmt --all --check` clean. `cargo clippy -p symbrain-skills --all-targets` **0 errors** — it was red before: `unnecessary_wraps` in the library plus pedantic lints in the worker's test files (`uninlined_format_args`, `field_reassign_with_default`, `doc_markdown`).
- `cargo test -p symbrain-skills` green, including the new differential suites: `runner_tests` 6 tests asserting all seven fixture cases, `runner_env_tests` 2 parents plus their child cases, alongside the pre-existing install/render/lock suites.
- `go run ./scripts/skills-runner-oracle -check` prints "fixture matches Go (check passed)". The fixture now holds seven cases, five default-resolution scenarios and provenance (Go revision, generator command, toolchain).
- Closed gaps, each traceable to the Go source it was derived from:
  - **Result wrapper.** Go's `syncTarget` (`internal/skillsrunner/runner.go`) returns only its result, so the Rust port returns `TargetResult` directly.
  - **Timeout.** Go wraps each target in `context.WithTimeout(ctx, opts.Timeout)` and formats `sync timed out: ` plus `ctx.Err()`; Rust takes the deadline from the option and picks the same two texts. Remaining limit, documented as a `ponytail:` comment: with a single cancellation snapshot a caller that cancels *after* our deadline also reads as "deadline exceeded".
  - **Render error bytes.** Go's `render/materialize.go` wraps each per-target error as `target %s: %w` **unconditionally** on the RenderAll path, while the dry-run path (`render.RenderTarget`) carries no such prefix. Both shapes are frozen (`failure_visible_and_reported`, `dry_run_failure_names_target`) and asserted byte-for-byte; the earlier "Rust differs from Go" note is gone.
  - **Defaults.** `internal/paths.resolve`: `$XDG_DATA_HOME` only when absolute, else `$HOME/.local/share`, then `symbrain/skills` unless that directory is absent and legacy `symskills` exists. `config.Defaults()` builds library, render and base from that one data root — `RenderDir` is **not** the cache, contrary to the comment this branch inherited. Five scenarios are frozen with `$ROOT` placeholders and the marker directories each one creates; a Rust test rebuilds exactly that state and compares all three paths.
  - **Provenance.** The fixture records the Go revision, generator command and toolchain; `-check` still compares cases and defaults only.
- **Test-environment constraint.** This crate denies `unsafe_code`, so a test may not mutate its own environment. The env-dependent scenarios therefore run in child processes prepared with `Command::env` (`runner_env_tests.rs`), and the two child cases are `#[ignore]`d.
- **Oracle-scenario pitfall (measured here).** Scenarios that share one temporary root leak state: the first case that creates the "current" directory hides the legacy fallback from every later case. Each scenario needs its own root, and the fixture must record which marker directories it created.
- **Open divergence — deliberately not fixed, and a precondition for Slice B.** Go's runner renders through `RenderAll(bundle, opts.RenderDir, [target])`, which writes `<RenderDir>/<target>/<name>` and installs a symlink pointing at that path. The Rust path renders in memory and, in symlink mode, keeps a stable tree at a hardcoded `home/.local/share/symskills/rendered/...` (`rust/symbrain-skills/src/install/core.rs`) which the symlink then points at. Result messages and error text match Go; the symlink target and the contents of the configured render dir do not. Do not remove the Go fallback in `sync_cli.rs` (Slice B) before an install-side oracle covers this.
- **Dispatch note.** Every delegated run for this slice died on provider limits (free-model quota, then a subscription limit) and left either nothing or uncommitted work in a nested worktree. The work above was done in the coordinator's own hands; a child that dies on a provider error says nothing about the slice.

## Resume checkpoint — 2026-09-21 (gates): MCP/GW rows promoted on fixtures, skills-runner rescued with a real Go oracle

**Verified on `main` @ `804f30ff`, commands and output recorded, not inferred:**
`make mcp-oracle-check` → `PASS: MCP oracle deterministic check passed (20 cases)`; `make gateway-oracle-check` → `PASS … (8 cases)`; `make rust-fuzz-smoke` → `Done 10000 runs`, exit 0; `cargo test -p symbrain-mcp` → 16 protocol tests + 2 differential tests green; `cargo test -p symbrain-gateway` → 8 tests, of which `fixture_is_the_complete_gateway_black_box_contract` iterates **all eight** fixture cases and asserts stdout bytes, the error classifications and `stdout_non_protocol_bytes == 0`.

**What the fixtures actually contain was checked, not assumed.** The 20 MCP oracle cases are framing/model level only (`line_ping`, `line_*`, `framed_*`, `invalid_length_*`, `missing_length`, `partial_body`, `oversized_line`, `max_framed`, malformed/null-id/notification) — they do **not** exercise initialize, tools/list or tools/call. So MCP-001…MCP-004 are *not* promoted on "the tests pass": they now read `partial-native-16-protocol-tests-no-go-byte-fixture`, because their semantics are covered by Rust protocol tests with no Go byte fixture behind them. GW-001…GW-004 do cover those semantics (`initialize-capabilities`, `tools-list-catalog`, `tools-call-routing`, `tools-call-tool-error`, `tools-call-hidden`, `tools-call-bootstrap`, `tools-call-patterns`, `stdout-hygiene`) and are promoted to `green-native-8-of-8-go-oracle-black-box-cases` (GW-004 additionally on CI `stdio-hygiene`). MCP-000 → `green-native-20-of-20-go-oracle-cases-byte-exact`, MCP-FUZZ → `green-native-10000-fuzz-runs-both-targets`.

**Decision row:** a row may only be promoted on a byte-level or black-box fixture comparison against Go; a green native test suite by itself marks the row `partial`, never `green`.

**Two traps recorded so they are not mistaken for findings:** (1) `rust/symbrain-mcp/tests/gateway_protocol_tests.rs` is 16 lines with zero `#[test]` attributes — it `include!`s `fixtures/gateway_protocol_tests_part1.rs` (10 tests) and `part2.rs` (6), so grepping the top-level file undercounts coverage to zero; (2) the 20-case MCP oracle is a Go-side determinism check (`scripts/run-go-oracle.sh HEAD run ./scripts/mcp-oracle -check`), so it proves the fixture still matches Go but says nothing about the Rust implementation on its own — the Rust side is the differential test in `oracle_differential_tests.rs`.

**Hygiene defect, not fixed here:** `migration/contract-matrix.csv` rows on lines 13 and 38 carry unquoted commas and therefore 10 and 12 fields instead of 8; editing that file with a positional rewrite must use the last field, never field 3 (a mistaken run overwrote a description and had to be restored from git). A tool that parses this file by column position will mis-read those two rows.

**skills-runner slice rescued.** The third dispatch again ended without a report and without committing; its worktree was created *nested* inside the previous worktree (`.worktrees/subagent-sa-0-a86ad2aa/.worktrees/subagent-sa-0-d2d36f7a`). The work is real this time and was preserved: committed as `37a759fb`, replayed onto `main` with the module declaration restored as `3e01d0af` on branch `migration/skills-runner-delta-20260921` in worktree `.worktrees/w-skills-runner`. It brings a genuine oracle — `scripts/skills-runner-oracle` drives the real Go `skillsrunner.Run` in isolated temp `HOME`/XDG roots, freezes six cases into `rust/symbrain-skills/tests/fixtures/runner_oracle.json`, and passes its own `-check` — plus `runner_tests.rs` with 5 green tests, three of which compare target/status/message triples against that fixture, including the 1 ns timeout case.

**Still open in that slice, dispatched as a delta (`deleg_38069bd8`) with Go line references:** `cargo clippy -p symbrain-skills --all-targets` fails with `clippy::unnecessary_wraps` on `sync_target` (a bare `cargo test` hides it); the timeout message is hardcoded instead of deriving Go's `ctx.Err()` text from a deadline built out of `opts.Timeout` (Go: `runner.go:138,163,204`); the `failure_visible_and_reported` case is asserted by shape with a comment admitting the divergence instead of matching Go's bytes; `no_legacy_binary_processes_targets` and `binary_presence_changes_nothing` have no Rust assertion; the unsupported-harness assertion uses an `||` fallback instead of Go's exact string; the fixture records no provenance.

## Resume checkpoint — 2026-09-21 (later): #626 closed, two skills-runner worker attempts rejected on measurement, Slice A re-dispatched

**#626 is closed — verified, not asserted.** On `main` @ `15d4bbad`, `cargo test -p symbrain-memory` under `scripts/run-external-env.sh` gives 21 passed / 0 failed with all seven `db_oracle_tests` green (`tables`, `memories_columns`, `indexes`, `triggers_and_views`, `lock_pragmas`, `constraint_cases`, `ordering_cases`), and `make db-memory-oracle-check` reports `PASS … (29 tables, 4 negative cases, 2 ordering cases)` — so the fixture still matches Go rather than having been tuned to the native output. `rust/symbrain-memory/tests/store_contract_tests.rs` also covers the upgrade path (`missing_shipped_columns_are_added_to_an_existing_database`, `a_native_row_reaches_the_shipped_fts_index`). The fix arrived with `2f5a5868` (#628); a dispatched worker that reported "nothing to do" was right, and the issue is now closed with that evidence.

**Skills-runner slice (Phase 7.2/7.3/7.4): two leaf-dispatch attempts, both rejected.** Both returned `status=completed` with no report block; both were verified from the worktree, not from their summaries.

- Attempt 1 (`eb50210f`, branch `hermes-subagent/subagent-sa-0-8819ebc5`): uncommitted at hand-back, and it did not compile — `sync_cli.rs` called `sync_skills()`, which was never defined (E0425).
- Attempt 2 (`c419167b`, branch `hermes-subagent/subagent-sa-0-a86ad2aa`): compiles under `cargo test`, but (a) **`cargo clippy --all-targets` is red** — this crate denies `clippy::all` + `pedantic`, so the failure is clippy-only and a bare `cargo test` hides it; (b) **no differential test was added**, while the `skills_library_has_entries()` gate was removed for the populated-library cases, i.e. the native surface was expanded with zero bytes compared to Go — the pre-existing `sync_native` tests still pass only because they exercise `claude` and `--project`, which still fall back; (c) defaults were hardcoded to `$HOME/.local/share/symskills/{library,rendered,base}` **under a doc comment claiming XDG awareness**, while Go resolves `internal/paths.SkillsDataDir()` = `$XDG_DATA_HOME/symbrain/skills` (legacy `…/symskills` only when the current dir is absent and the legacy one exists) — with `XDG_DATA_HOME` set, as every harness sets it, the native path reads the wrong library; (d) `install_skill` kept `render_target` + `install_rendered` with a comment *noting* that Go uses `RenderAll(opts.RenderDir)` + `install.Install` instead of matching it; (e) the timeout is unreachable — `Options.timeout` is stored and never used, the context is a `NoopContext` whose `is_cancelled()` is always false, so Go's `context.WithTimeout(target, 30s)` and its `sync timed out: <ctx.Err()>` message cannot be reproduced even though `internal/skillsrunner/runner_test.go`'s `TestRunTimeoutSurfacesAnError` (Timeout = 1ns) covers exactly that case.

**Failure class, named:** the leaf worker produces a structurally plausible module and documents divergences as comments instead of resolving them against the Go source; "all checks pass" referred only to `cargo test`, never to clippy, the differential, or a byte comparison. Two consequences recorded as process rules: (1) a Go fallback gate may only be removed for a case a *differential test* proves — never on the strength of a port that merely looks right; (2) every dispatch must name `cargo clippy --all-targets` explicitly, because this crate's `pedantic` denials fail clippy while `cargo test` still passes.

**Slice A re-dispatched** (`deleg_326a9291`), deliberately narrowed so a third failure stays cheap: port `Run`/`syncTarget`/`planSkill`/`installSkill`/`installOptions`/`withDefaults` into `rust/symbrain-skills` **only**, and prove it with a new frozen Go oracle (`scripts/skills-runner-oracle`, generate + `-check`) that drives the real `skillsrunner.Run` in isolated temp HOME/XDG roots and writes `rust/symbrain-skills/tests/fixtures/runner_oracle.json`, consumed by a new `tests/runner_tests.rs`. `rust/symbrain-cli/**` is explicitly out of scope: the CLI keeps its Go fallback until the fixture exists (Slice B). The brief carries the measured Go line references for the paths rule, the `RenderAll` + symlink-mode sequence, and the timeout contract.

**Next action for a resumed session:** verify Slice A from its branch (not its summary) — fixture generated by Go, `-check` clean, `runner_tests` green, clippy/fmt clean — then do Slice B: wire `sync_cli.rs` to the proven runner and delete the gate only for the cases the fixture covers, regenerating the CLI oracle fixture in the same change.

## Resume checkpoint — 2026-09-21 (verified): `GUARD-DOCTOR-FULL` merged as #639 and re-verified on the merged revision

**Reconciliation.** `origin/main` is `5c12f12d` — PR #639 ("feat(rust): port guard doctor — 5 of 7 frozen oracle cases native", merged 2026-09-21T13:11:33Z) squash-merged the slice the next checkpoint dispatched. Branch `migration/guard-doctor-full-20260921` is content-identical to `origin/main` (`git diff --stat origin/main <branch>` empty). Local `main` fast-forwarded `b8665928 → 5c12f12d`; the previous checkpoint's "Dispatched: GUARD-DOCTOR-FULL" row is closed.

**Independently verified by the coordinator (not from the worker's summary)**, worktree `.worktrees/guard-doctor` at `d9c54d56` (the branch plus a merge of `b8665928`):
- `make guard-doctor-oracle-check` → `PASS … 0 drift on 7 cases` (Go vs frozen fixture); `make cli-oracle-check` → `PASS … 81 cases`.
- `cargo fmt --all --check` exit 0; `cargo clippy --workspace --all-targets --all-features --locked -- -D warnings` exit 0.
- `cargo test --workspace --all-features --locked` under `scripts/run-external-env.sh`: **777 passed, 0 failed, 0 ignored** — the previously `#[ignore]`d `cli_tree_fixture_matches_native_binary` is now counted and green (78 of the 81 frozen CLI cases byte-native, 3 accepted divergences: `go skills list --help`, `go skills list --unknown`, `go memory serve`). `cargo test --workspace --doc` exit 0; `cargo audit` and `cargo deny` (advisories/bans/licenses/sources) ok; `make rust-check` reached its final step.
- **Invocation trap, recorded so it is not re-learned:** running `cargo test` in this repo *without* `scripts/run-external-env.sh` on macOS fails `symbrain-audit`'s `raw::tests::rejects_non_regular_targets_without_blocking` with "SYMAIRA_EXTERNAL_RUNTIME_ROOT is required on local macOS runs". That is a harness requirement, not a defect — use the Makefile targets or `bash scripts/run-external-env.sh cargo test …`.
- The first `cargo test -p symbrain-cli` on the branch (pre-merge) failed only `skills_status_opencode_tests::opencode_project_status_matches_go_bytes` (`/private/var` vs `/var`). `b8665928` (#638) fixed exactly that, and the failure class is gone after the merge: #480/#622 are closed by #638, not by this slice.
- `make cli-oracle-check` prints `cli-oracle: 127.0.0.1:8787 already in use; relying on the existing listener` on this host. Investigated, not a defect: `holdServePort` (`scripts/cli-oracle/main.go:52`) binds the port only to reproduce a "port already in use" transcript case, and the holder here is Daniel's own `ssh` forward (`lsof -nP -iTCP:8787 -sTCP:LISTEN` → `ssh` pid 930, `[::1]:8787`). Freed or held, the recorded transcript is the same; CI binds it itself. Do not "fix" this by hardcoding a free port — that would drop the case.

**Claim spot-checked in the source:** `printSecretRisks` (`guard/cmd/symguard/doctor/checks.go:104`) never reads `Allowed`, so the previous checkpoint's correction of the oracle README stands — `discovered_server_secret_risk` was never a blocker.

**Scope boundary kept, not a silent gap:** 5 of the 7 frozen scenarios are native (`empty_machine`, `healthy_config`, `audit_log_without_anchor`, `discovered_server_denied`, `discovered_server_secret_risk`); `config_error` and `audit_log_corrupt_anchor` gate to Go *before any byte is written*, because both print another library's error text verbatim (BurntSushi's TOML parser, `encoding/json`). `rust/symbrain-cli/tests/guard_doctor_oracle_tests.rs` proves nativeness structurally — empty `PATH`, no `SYMBRAIN_GO_BINARY`, and `native == [5 cases]` / `gated == [2 cases]` asserted explicitly.

**Dispatched this session, both off `5c12f12d`:** (a) Phase 7.2/7.3/7.4 — port `internal/skillsrunner.Run` into `rust/symbrain-skills` and wire the populated-library `sync` path natively; (b) issue **#626** — the native memory store's 16 missing tables, 16 indexes and `memories` column facts. The delegation runtime created its own per-child worktrees (`.worktrees/subagent-sa-*`) on base `b8665928`; the pre-created `w-skills-sync`/`w-db-schema` worktrees went unused and are pruned. Integration must therefore take the **children's own branches**, not those names.

**Loaded skills this session:** `go-to-rust-migration`, `parallel-repo-agents`, `go-to-rust-migration/references/worker-dispatch.md`.

## Resume checkpoint — 2026-09-21 (resumed): `guard doctor` full port dispatched, one stale ledger claim corrected

**Reconciliation at resume.** `main` is `f9a52c30` — PR #636 squash-merged, so
every "uncommitted" note in the checkpoints below is historical. The branch
`migration/rust-sync-guard-doctor-20260921` was content-identical to `main`
after the squash and has been deleted locally; the remote delete was refused
and is left for the repository owner. `docs/intern/rust-cut-20260917/brain/STATUS.md`
(dated 2026-09-18, PR #611) is superseded by this file for anything in the
brain CLI line and should be read as history only.

**One named blocker turned out not to exist.** Every checkpoint since wave 4
has carried the full `guard doctor` port forward with "its own oracle-defect
fix (`discovered_server_secret_risk`, noted in
`guard/scripts/guard-doctor-oracle/README.md`)" as a prerequisite. The README
claims that case "currently produces the same `[DENIED]` line as
`discovered_server_denied`" and that the plaintext-secret warning "appears to
require a server that is on the spawn allowlist." Both are wrong, measured
against the frozen fixture itself: `discovered_server_secret_risk` already
emits the full `Plaintext secret risk:` block, the per-server env line, and
the symvault advisory. `printSecretRisks` in
`guard/cmd/symguard/doctor/checks.go` never reads `Allowed`. The corpus is
sound; the stale README paragraph is being corrected as part of the port
rather than treated as a gate.

**Dispatched: GUARD-DOCTOR-FULL**, branch `migration/guard-doctor-full-20260921`
in worktree `.worktrees/guard-doctor`, base `f9a52c30`. Scope: replace the
empty-machine-only native slice with all seven frozen scenarios, which means
porting `guard/internal/config` (Load/ConfigPath/DataDir/Rules/Spawn),
`guard/internal/spawn`, `guard/internal/discovery` (+`result.go`,
`secrets.go`), and `audit.DefaultAnchorPath`/`ReadCheckpoint`. Two constraints
carried into the dispatch verbatim, both from earlier waves' scars: doctor
must NOT reuse `guard_scan.rs`'s corekit `mcpcfgkit` discovery (different
client list, different path resolution — a false "none discovered" would hide
real allowlist and secret findings), and the `Go:` line stays a permanent
accepted difference (a fabricated Go version string was already rejected once
in wave 4). Any state not byte-reproducible must gate to Go before any output
is written.

**Still open, not part of this slice:** #480/#622 (macOS `/var` vs
`/private/var` TempDir flake in `skills_status_opencode_tests`, reproduces
locally, explicitly scoped as its own task), #626 (native memory store missing
16 tables/16 indexes), #625 (`setup` cannot install symcockpit), and the
Phase 8.5/8.6 Browse rows, which are unchanged.


## Resume checkpoint — 2026-09-21 (final): PR #636 merged the whole slice, CI green on every platform

**Committed, pushed, PR opened and CI-green — the "uncommitted" note in every
checkpoint below is now historical.** Branch
`migration/rust-sync-guard-doctor-20260921`, four commits, opened as
[PR #636](https://github.com/danieljustus/symaira-brain/pull/636) against
`main`, not yet merged (that's Daniel's call). Every job passed on the
**first fully green run** after two rounds of fixes — this is exactly the
"first real run on a runner" #631 warns about, and it found real, previously
invisible gaps:

- **Round 1** (commit `c022b3be`): CI's very first run found three things
  local macOS testing never could. (1) `sync -h`/`--help` was rejected as an
  ordinary unknown flag instead of Go's special-cased bare-usage response —
  caught by `scripts/rust-differential.py`'s `sync_help` case, which
  `make rust-check` alone never runs (only `make parity-smoke` does; that gap
  in my own local verification is exactly why it went unnoticed). (2)
  `guard-doctor-oracle`'s `normalize()` tokenized the Go-toolchain line but
  never the `OS/Arch:` line, so the committed fixture baked in the recording
  machine's literal `darwin/arm64` — invisible until run on a non-macOS
  runner. (3) `cli_tree_expectations.json` bakes in the macOS-specific
  Claude Desktop path (`Library/Application Support/Claude`); two independent
  Go packages resolve a different, platform-correct XDG fallback on Linux for
  the same harness (`internal/harness`: `.config/Claude`; corekit's
  `mcpcfgkit`, used by `guard scan`: `.config/claude`, lowercase) — both
  correct for their package, neither matching the fixture. All three fixed
  and verified on both macOS and a real Linux environment (Docker,
  `golang:1.26`) before pushing, not guessed.
- **Round 2** (commit `eab40fda`): fixing round 1 by hand-editing
  `cli_tree_expectations.json` directly (bypassing the oracle's own
  normalization) missed that `scripts/cli-oracle/main.go`'s own
  `normalizeStdout` needed the *same* claude-desktop-dir fix independently —
  its self-check (fresh Go vs. frozen fixture, entirely independent of any
  Rust code) still failed on Linux. Fixing that and regenerating properly
  surfaced a second, unrelated latent gap: `cli-oracle`'s toolchain/platform
  regexes only match `version`'s row shape, never `guard doctor`'s
  differently-shaped capitalized header — the same gap already fixed in
  `guard-doctor-oracle`'s own `normalize()` and in `cli_tree_tests.rs`, but
  never in `cli-oracle`'s. A first regeneration attempt (accidentally built
  with local `go1.27.1` instead of the pinned `go1.26.7`) produced an
  unrelated-looking diff on that exact line — proof it was silently unpinned
  to whatever toolchain built the reference binary, not a genuine accepted
  difference. Fixed the same way as the other two: normalized, not papered
  over with a lucky toolchain match.
- **Verification method, both rounds:** every fix was reproduced and
  confirmed against a real `golang:1.26` Docker container before pushing —
  not inferred from reading code, not assumed from the macOS-only local
  result. One apparent fourth failure (`external_decision_review`'s
  git-history provenance check, inside a from-scratch `cargo test --workspace`
  Linux run) was investigated and ruled out as an artifact of the Docker
  reproduction itself (a `relativeworktrees` git repository extension the
  container's older git can't parse) — confirmed by running `git show`
  directly against the pinned commit on the host (succeeds) and by attempting
  a plain `git clone` inside the same container (fails identically, proving
  it's the container's git version, not the code or the platform).

**Final CI result, this run:** every job green — both `rust-migration`
variants (ubuntu, macOS), `Rust guard and pinned Go oracle` (the job running
`cargo test --workspace`, which is what actually exercises the now-unignored
`cli_tree_fixture_matches_native_binary`), all four `go-test-shard`s, and the
Windows jobs (`rust-init-native (windows-2025)`, `rust-windows-audit-guard`,
`browse-windows-daemon`). This is the first time `cli-oracle-check`,
`guard-doctor-oracle-check`, and the un-ignored CLI parity test have ever
been proven on any runner other than the machine that authored them.

**Issue disposition, backed by this run's evidence, left for Daniel to close
on merge (not closed automatically by this checkpoint):**
- **#630** (isolation-root symlink shape) — fixed in both the Go oracle and
  the Rust consumer test; `make cli-oracle-check` 81/81 on macOS and Linux.
- **#629** (missing case timeout) — confirmed not applicable to the sibling
  oracles; already closed by the existing cli-oracle fix on `main`.
- **#627** (PATH leak) — already fixed on `main`; nothing left in this PR.
- **#631** (wire a new gate only once proven on a runner) — this PR *is* that
  proof: cli-oracle, xdg-oracle, db-memory-oracle, and guard-doctor-oracle
  all ran green on ubuntu-latest and macos-15 CI runners for the first time,
  in the same change that wired them into `rust-check`, exactly the practice
  #631 asks for.

**Nothing further is scoped or pending from this slice.** The full 7-scenario
`guard doctor` port (config parsing, spawn allowlist, discovery, secret
redaction beyond the empty-machine case) remains open Phase 8.5/8.6 work with
its own oracle-defect fix (`discovered_server_secret_risk`, noted in
`guard/scripts/guard-doctor-oracle/README.md`) — not started, not blocking
anything in this PR, and deliberately left for its own dedicated slice.

## Resume checkpoint — 2026-09-21 (later still): `guard doctor` empty-machine ported, 81/81 un-ignored — uncommitted

**Not committed**, same standing rule. `git status` now additionally shows
`rust/symbrain-cli/src/{guard_cli,guard_scan}.rs` and
`rust/symbrain-cli/tests/cli_tree_tests.rs` modified and
`rust/symbrain-cli/src/guard_doctor.rs` untracked (new file); nothing else
untracked.

**The last residual (`go guard doctor`) is closed, conservatively scoped to
exactly the "empty machine" fixture case, per this file's own prior
checkpoint's scoping note.** New module `rust/symbrain-cli/src/guard_doctor.rs`
(wired into `guard_cli.rs` via `#[path = "guard_doctor.rs"] mod guard_doctor;`,
same pattern as `guard_scan`/`guard_grants`). `guard_cli.rs`'s `"doctor" =>
None,` line now reads `"doctor" => guard_doctor::run(stdout),`; Go's own
dispatcher (`cmd/symbrain/cmd_guard.go`) calls `doctor.Run(stdout)` with no
arguments at all, so anything after `doctor` is ignored on both sides.

Read in full before porting, per the prior checkpoint's instruction:
`guard/cmd/symguard/doctor/{command,checks}.go`,
`guard/internal/config/config.go`, `guard/internal/audit/chain.go`, and
`guard/internal/discovery/discovery.go`. The highest-risk piece — discovery's
exact client-path list — turned out to resolve one level deeper than
`discovery.go` itself: it's a thin adapter over
`github.com/danieljustus/symaira-corekit@v0.17.0`'s `mcpcfgkit.DefaultSources()`
(version pinned exactly in this repo's `go.mod`/`go.sum`). Read that function
directly from the pinned module in the local Go module cache rather than
trusting the wrapper's doc comment. It is also, byte-for-byte, the same
five-source list (hermes, cursor, vscode, opencode, claude-desktop with the
darwin/XDG branch) that `guard_scan.rs`'s own `SOURCES`/`source_path` already
implement natively — a coincidence worth flagging for a reviewer (see below),
not an assumption: both were checked independently against the pinned
`mcpcfgkit` source, and `guard_scan.rs`'s existing `source_path` was reused
rather than re-implemented a second time (it and its `Source`/`SOURCES` are
now `pub(crate)` for this reuse; ladder: don't duplicate a list this
security-sensitive when a verified-identical one already exists in the same
crate).

**The conservative three-condition gate is exactly what the prior checkpoint
scoped:** native handling only when (1) `guard/internal/config.ConfigPath()`'s
file is absent, (2) `filepath.Join(config.DataDir(), "audit.log")` is absent,
(3) none of the five discovery paths above exist. Any one present falls back
to Go untouched. The gate itself (`guard_doctor::requires_go_fallback`) takes
plain `&Path`/`bool` arguments rather than reading the environment itself, so
it has its own unit test (`gate_flips_on_any_of_the_three_conditions`) with
real temp-dir paths — no env-mutation trick needed here, unlike `sync_cli`'s
equivalent case, because this gate doesn't read `$HOME`/XDG vars internally;
the env-dependent production wiring (`guard_doctor::run`) is covered by the
subprocess-isolated `cli_tree_tests.rs` instead, same reasoning as before.
`config_path()` mirrors `config.ConfigPath()`/`DefaultPath()` directly
(`$SYMGUARD_CONFIG`, else `$XDG_CONFIG_HOME/symguard/config.toml`, else
`~/.config/symguard/config.toml`); the audit-log path reuses `guard_cli.rs`'s
existing `audit_path()` (now `pub(crate)`), already unit-tested and already
matching `config.DataDir()/audit.log` exactly — not a second implementation.

**Never fabricated the Go version.** The frozen fixture's `Go: go1.26.7` line
is pinned to the recording machine, exactly like `guard version`'s toolchain
row already was. Same fix as that row: the native line is now labeled
`Rust:` and prints the real `rustc_version()`; `OS/Arch:` prints the real
platform. `cli_tree_tests.rs`'s `normalize_accepted_differences` gained two
new narrowly-scoped patterns for this block's different shape (capitalized
`Label:` + colon + run of spaces, vs. `guard version`'s lowercase
`label<space>value` shape) — verified by grep that `OS/Arch:` and `  Go:`
appear nowhere else across the 81 fixture cases, so this cannot swallow a
real difference elsewhere. `ACCEPTED_DIVERGENCES` did not list `go guard
doctor` (checked, per the prior checkpoint's own instruction to verify
rather than assume).

**`cli_tree_fixture_matches_native_binary`'s `#[ignore]` is removed.**
Verified: `cargo test -p symbrain-cli --test cli_tree_tests` (no `--ignored`
flag needed) → 81/81 cases match, 0 diverged. `cargo test -p symbrain-cli
--lib` → 94 passed (net +1 from before this checkpoint: +2 new tests, the
gate test and `empty_machine_report_matches_frozen_shape`, -1 for removing
`guard_cli::tests::doctor_remains_on_go_fallback`, which asserted the
now-false "doctor always falls back" and read the real ambient
`$HOME`/XDG env rather than an isolated one — stale by construction once
`doctor` became conditionally native, so deleted rather than patched), 0
failed.

**Wiring into the gate needed no Makefile change — verified, not assumed.**
`make rust-check`'s dependency line (`rust-check: ... $(EXTERNAL_RUN) cargo
test --workspace --all-features --locked ...`, `Makefile` line 237) already
runs `cargo test --workspace`, which sweeps up every non-ignored test in
every crate, `cli_tree_tests` included. Confirmed directly: `cargo test
--workspace --all-features --locked -- --list` lists
`cli_tree_fixture_matches_native_binary: test` (unignored). CI's Rust job
(`.github/workflows/ci.yml`) runs `make rust-check parity-smoke`, so this
test is now a real CI gate with zero Makefile edits. (A prior checkpoint on
this same page speculated `rust-check`'s chain "does NOT appear to invoke
`cargo test --workspace` directly" — that speculation does not hold against
the Makefile as it exists now; whether it was ever accurate or the Makefile
changed since is not something this checkpoint can determine, and is not
worth chasing further.)

**Verified locally, this checkpoint:** `cargo build -p symbrain-cli --bin
symbrain`; `cargo test -p symbrain-cli --lib` (94/94); `cargo test -p
symbrain-cli --test cli_tree_tests` (81/81, unignored); `make
guard-doctor-oracle-check` (7/7, unaffected — the Go side was not touched);
`cargo clippy -p symbrain-cli --all-targets -- -D warnings` (clean); `cargo
fmt --all --check` (clean); `git status --short` (no stray untracked
artifacts). Full `make rust-check` (all oracles) was not run end-to-end this
session for time; `cargo test --workspace --all-features --locked -- --list`
was used instead to confirm the specific wiring claim above without paying
for the full oracle chain.

**Deliberately out of scope, unchanged, matching the prior checkpoint's
scoping:** the other 6 `guard-doctor-oracle` scenarios (healthy config,
invalid TOML, audit anchor variants, discovered-server allow/deny, secret
risk) still have no Rust consumer and stay on Phase 8.5/8.6 — they need
`guard/internal/config`'s TOML schema, `guard/internal/audit.ReadCheckpoint`,
`guard/internal/spawn` allowlist matching, and secret-redaction logic, none
of which exist in `symbrain-guard-core` yet. The oracle's own pre-existing
`discovered_server_secret_risk` defect (documented in
`guard/scripts/guard-doctor-oracle/README.md`) is untouched — it only
matters once that later slice discovers servers, which this slice's gate
guarantees it never does.

**Open question for a reviewer:** whether `guard_scan.rs`'s discovery path
list and `discovery.DiscoverAll()`'s (via `mcpcfgkit.DefaultSources()`) are
guaranteed to stay identical going forward, or whether that's a coincidence
of the current `symaira-corekit` pin that could silently drift on a future
`go.mod` bump without a Rust-side signal. Today they were verified to match
by reading both sources directly, and `guard_doctor` now depends on that
match via direct reuse (not just similarity) — so a `guard_scan.rs` change
alone (e.g. adding a client) also changes `guard_doctor`'s gate, which is the
intended coupling. A `go.mod` bump of `symaira-corekit` that adds or moves a
client source without a corresponding `guard_scan.rs`/`guard_doctor` update
is the one drift path this port does not detect automatically.

Everything in this checkpoint is uncommitted — review the diff first
(`git diff`), then commit/push, since #631 needs an actual CI run to close.

**Not committed.** Everything below is verified in the working tree only; no
commit/push per the standing rule to leave Git actions to Daniel. `git status`
at this checkpoint: `Makefile`, `rust/symbrain-cli/src/{skills_cli,sync_cli}.rs`,
`rust/symbrain-cli/tests/cli_tree_tests.rs`, `scripts/cli-oracle/main.go`
modified; nothing untracked (a stray `scripts/cli-oracle/cli-oracle` build
artifact from a local `go build ./...` check was removed).

**#630 (isolation-root symlink shape) is fixed in both places it appears, not
just the one the issue named.** The issue only measured the Go oracle
(`scripts/cli-oracle`'s `os.MkdirTemp` root), but the Rust consumer
(`rust/symbrain-cli/tests/cli_tree_tests.rs`) hits the identical defect
independently: it builds its own `TempDir` and never resolves it, so on
macOS (`/var` → `private/var`) the native binary's no-follow capability opens
fail with `ENOTDIR` for *any* harness/instructions read — not a fixture
artifact, a real symlink-ancestor bug in the test harness. Both are fixed:
`scripts/cli-oracle/main.go` now resolves its root with `filepath.EvalSymlinks`
right after `MkdirTemp`; `cli_tree_tests.rs` gained a `real_root()` helper
(`root.path().canonicalize()`) used everywhere the old code read `root.path()`
for env/cwd construction. `normalize_stdout` needed no change — it already
special-cased the `/private` prefix duality.
Verified: `make cli-oracle-check` → **81/81, 0 drift** (previously this command
was never actually run against the fix; the frozen fixture's `go sync`
expectation turned out to already assume a symlink-free root, so the Go-side
fix alone made the tracked fixture reproducible, no regeneration needed).

**#629 remainder does not apply.** The issue speculated that
`db-memory-oracle` and `guard-doctor-oracle` "invoke the binary the same way"
as `cli-oracle` and might need the same timeout bound. Checked: neither
imports `os/exec` at all — both call Go packages in-process. #629 is fully
closed by the fix already on `main` (cli-oracle's 20s `context.WithTimeout` +
`WaitDelay`); there is no sibling-oracle gap to fix.

**#627 (PATH leak) has nothing left to do either.** Fixed for cli-oracle
already (`emptyPath`, on `main`); the sibling oracles don't exec anything so
can't leak PATH. Both #627 and #630 close with this checkpoint's evidence
once someone reviews and commits it.

**All four previously-excluded oracles pass locally and are wired back into
`make rust-check`** (`xdg-oracle-check`, `guard-doctor-oracle-check`,
`db-memory-oracle-check`, `cli-oracle-check` added to the dependency list,
with the Makefile comment rewritten to explain why). This is the practice
#631 itself sanctions: "add the gate in the same change that first pushes
it" — so CI proves them before merge instead of a separate two-step dance.
Verified locally end-to-end: `make rust-check` exit 0, including
`cargo-deny` (`advisories ok, bans ok, licenses ok, sources ok`). **Not yet
proven on a CI runner** — that only happens once this is pushed; #631 stays
open until then.

**`symbrain sync` is now native for its two previously-unported fixture
cases** (`rust/symbrain-cli/src/sync_cli.rs`):
- Bare `sync` (implicit all-harness selection) now runs natively. The
  instruction-target loop already worked generically over all harnesses; the
  gap was the `Skills:` section, hardcoded to `skipped` for every harness.
  Ported from the Go reference (`internal/skillsrunner/runner.go`): a harness
  with no `SkillTarget` is `skipped`/`"no skill target for harness …"`; a
  harness with a `SkillTarget` and an empty-or-missing skills library is
  `ok`/`"no skills rendered"` — which is *all* `skillsrunner.Run` ever does
  before touching the render/install pipeline (`os.ReadDir` returns
  `ErrNotExist` or zero entries, short-circuits before any rendering).
  **Scope boundary, deliberate:** a *non-empty* skills library still forces
  the Go fallback (`skills_library_has_entries()` gate in
  `requires_go_fallback`) — actually rendering and installing skills is
  Phase 7.2/7.3 territory (not ported), and guessing its output instead of
  falling back would be exactly the "invented behavior" the project's rules
  forbid. This is conservative by construction: it only ever defers to Go
  *more* than necessary, never claims a result it can't prove.
- `sync --unknown` (and any other unrecognized flag) is now rejected natively
  with the Go flag package's own message shape (`flag provided but not
  defined: -X` + `Usage of sync:` + the two real flags, alphabetical), exit 2.
  Previously any unrecognized flag silently went to the Go fallback.
- Unit test added: `sync_cli::tests::unknown_flag_matches_go_flag_package_rejection`
  (byte-exact against the frozen fixture text). The env-dependent all-harness
  path is covered by the existing subprocess-isolated `cli_tree_tests.rs`
  instead of a new env-mutating unit test (this crate has no established
  pattern for isolating env vars across parallel `#[test]`s, and one shouldn't
  be invented for a single case).
- `rust/symbrain-cli/src/skills_cli.rs::resolve_skills_dirs` made `pub(crate)`
  so `sync_cli` could reuse the same library-dir resolution instead of a
  second implementation.

**`cli_tree_fixture_matches_native_binary` residual: 9 → 4 of 81** (still
`#[ignore]`d — see below for why it isn't wired in yet). Fixed by the above:
`harness list`, `harness health`, `skills log` (all three were the #630
symlink bug, not unported surfaces — `harness_cli.rs` was already fully
implemented), `sync`, `sync --unknown`. Remaining 4, unchanged by this
checkpoint:
- `guard doctor` — genuinely unported (`guard_cli.rs:90` hard-codes
  `"doctor" => None`). Every other guard verb (`version`, `decide`, `scan`,
  `grants`) is already native, so this is the last one standing.
  **Scoped and NOT started**: read `guard/cmd/symguard/doctor/{command,checks}.go`
  in full. It needs its own config load (guard's `internal/config`, TOML
  rules + spawn allowlist — distinct from `symbrain-harness`'s config, and
  nothing in `symbrain-guard-core` covers it yet), an audit-log/anchor probe
  (`guard/internal/audit.ReadCheckpoint`), and MCP discovery + allowlist
  cross-check + plaintext-secret detection (`guard/internal/discovery`,
  `guard/internal/spawn` — **not** the same discovery `guard_scan.rs` already
  has natively in Rust; that one is self-contained with its own client list
  and doesn't share a module with doctor's Go-side `discovery.DiscoverAll()`).
  The oracle's own README documents a known pre-existing defect worth reading
  before porting: the `discovered_server_secret_risk` case currently produces
  the same `[DENIED]` line as `discovered_server_denied` (the plaintext-secret
  warning appears to need an *allowlisted* server to show separately) — fix
  or rename that case as part of this slice, it's a real gap in the acceptance
  oracle itself, not something to port around.
  This is real Phase 8.5/8.6 work (last Guard verb before full cutover), not
  a small fix, and deserves its own dispatched slice with fresh review rather
  than being rushed onto the end of this one.
- `memory serve` — accepted, environment-dependent (port-availability
  transcript), not a parity target. Unchanged, no action needed.
- `skills list --help`, `skills list --unknown` — accepted, deliberate: these
  reproduce the Go `flag` package's own `PrintDefaults` dump verbatim, and
  the project's own prior note says reproducing that without the actual flag
  set would create a second source of truth for the same bytes. Unchanged,
  no action needed.

**Un-ignoring `cli_tree_fixture_matches_native_binary` needs one more thing
beyond closing `guard doctor`:** the 3 "accepted difference" cases above
still show as raw failures in the test (no `normalize_accepted_differences`-
style suppression exists for them today). Whoever closes `guard doctor` should
either extend that normalization to cover exactly these 3 known-permanent
differences, or special-case them in the test's failure collection, before
flipping `#[ignore]` off and adding the test to `rust-check`.

**Update, same session: the accepted-difference exclusion is done, residual is
down to exactly 1.** `cli_tree_tests.rs` gained an `ACCEPTED_DIVERGENCES` list
(`go skills list --help`, `go skills list --unknown`, `go memory serve`) with
the same reasoning as above, skipped before the per-case run (not normalized
after — these are permanent by design, not byte-level noise like the
toolchain row). Verified: `cargo test -p symbrain-cli --test cli_tree_tests --
--ignored` → **1 of 81 diverged: `go guard doctor`**, exit 0 expected got 1.
That is now the *only* thing standing between this test and being un-ignored
and wired into `rust-check`.

**`guard doctor` scoping refined — it's smaller than the full 7-scenario port
if scoped to just this consumer.** `cli_tree_expectations.json` has exactly
one `guard doctor` case, the "empty machine" scenario (no config file, no
audit log, no discovered MCP servers) — the other 6 scenarios (healthy
config, invalid TOML, audit anchor variants, discovered-server allow/deny,
secret risk) only exist in the separate `guard-doctor-oracle` fixture (7
cases, no Rust consumer yet, SEC-005). Closing *this* residual only needs the
empty-machine path, gated conservatively exactly like this session's `sync`
fix: check `guard/internal/config.ConfigPath()` — if the file exists, fall
back to Go (TOML parsing/policy not ported); check the audit log path — if it
exists, fall back to Go (anchor-chain reading not ported); check whether any
of discovery's known MCP-client config paths exist — if any does, fall back
to Go (full discovery/secret-detection not ported). Only when all three are
absent does the native path print the fixed "empty machine" report.

**One more thing this scoping surfaced, not yet handled:** `guard doctor`'s
own output block (`  Version:   dev\n  Go:        go1.26.7\n  OS/Arch:
darwin/arm64\n`) is a *different* shape than the `guard version` command's
row format (`  go      <go>` / `  os/arch <arch>`), which is the only shape
`cli_tree_tests.rs`'s `normalize_stdout`/`normalize_accepted_differences`
currently recognizes. The frozen `go guard doctor` case in
`cli_tree_expectations.json` has the *literal* pinned Go toolchain string
(`go1.26.7`) baked in raw — unlike `guard-doctor-oracle`'s own fixture, which
the oracle normalizes to a `Go: <go>` placeholder itself. Porting `guard
doctor` therefore also needs a second accepted-difference pattern added to
`cli_tree_tests.rs` for this line shape — the native binary must keep
reporting its own real Rust toolchain (never a fabricated Go version string;
the ledger already records one such fabrication being rejected during wave
4), and the test must tokenize the row the same way it already does for
`guard version`'s.

**Why this session stopped here instead of continuing into the port:** the
full command also touches `guard/internal/spawn` (allowlist matching) and
`guard/internal/discovery` (client-config scanning + plaintext-secret
detection) — none of which exist in `symbrain-guard-core` yet, and
`guard_scan.rs`'s existing native discovery is a separate, self-contained
implementation that doesn't share a module with doctor's Go-side
`discovery.DiscoverAll()`. Even the reduced "empty machine only" scope above
needs the exact discovery client-path list read correctly from
`guard/internal/discovery/discovery.go` to avoid a false "none discovered"
on a machine that actually has one configured — worth its own focused slice
with its own review rather than being rushed onto the end of this one.

**Next action for a resumed session:** implement the conservative
"empty machine only" `guard doctor` slice above (config/audit-log/discovery
existence gates, Go fallback otherwise), add the second accepted-difference
normalization for its Version/Go/OS-Arch block, verify
`cli_tree_fixture_matches_native_binary` passes un-ignored, then wire it into
`rust-check`. The full 7-scenario Guard doctor port (config parsing, spawn
allowlist, discovery, secret redaction) stays open as later Phase 8.5/8.6
work with its own oracle-defect fix (the `discovered_server_secret_risk` gap
noted in `guard/scripts/guard-doctor-oracle/README.md`).

Everything in this checkpoint is uncommitted — review the diff first
(`git diff`), then commit/push, since #631 needs an actual CI run to close
and none of this has been pushed yet.

**Unrelated pre-existing flake confirmed while verifying, not touched:**
`cargo test -p symbrain-cli` (the full integration-test run, not something
`make rust-check`/`rust-fast` exercises — they never happened to hit it this
session) deterministically fails
`skills_status_opencode_tests::opencode_project_status_matches_go_bytes` on
this machine: expected `/var/folders/...`, got `/private/var/...` — the same
macOS temp-dir symlink class as #630, tracked separately as **#480**
("test(skills): remove macOS /var path canonicalization flake", still open).
Not fixed here: the file has 19 `TempDir::new()` call sites and #480's own
text cautions the fix must not "hide real path errors," i.e. a blanket
`canonicalize()` on every one (the mechanical fix that worked for
`cli_tree_tests.rs`) needs more care than a drive-by — it's a real, separate,
already-scoped task, not part of this checkpoint's diff.

## Resume checkpoint — 2026-09-21: the migration line is merged, and the oracles are not portable yet

**Merged.** `migration/rust-continue-20260920` was pushed, opened as PR #628 and
squash-merged into `main` as `2f5a5868`. The branch and its `.worktrees/w4-cli`
worktree are gone; `main` is the single reference line. `make rust-check` and
`make parity-smoke` (457/457) are green on ubuntu-latest and macos-15. Two
issues it fixed are closed: #624 (atime-derived `last_used` flake) and #616
(doctor routing reading the real profile directory).

**The first CI run of this branch exposed a class of defect.** The branch had
never been pushed, so four oracles it added to `rust-check`
(`cli-oracle`, `xdg-oracle`, `db-memory-oracle`, `guard-doctor-oracle`) had
never executed on a runner. Every one of them turned out to be calibrated to the
recording machine rather than to a portable environment. Three failures were
diagnosed and fixed before the merge:

| Defect | Cause | Fix |
|---|---|---|
| `cli-oracle` hung >2h, twice, at the same CI step | `runCase` used `cmd.Run()` with no bound; the `memory serve` case starts a listener and never exits when `127.0.0.1:8787` is free — which is every runner. It passed locally only because an unrelated SSH tunnel held the port. | `bdcb1e63`: 20s context + `WaitDelay` per case; a killed case is recorded with exit code `-1` and a `<timeout>` marker. The oracle also binds the serve port itself so the recorded bind-failure transcript is deterministic. |
| Fixture encoded the recorder's harness CLIs | `setupOracleEnv` built the env with `os.Environ()` and never overrode `PATH`; `skills targets` reports `INSTALLED` from harness-CLI detection over `PATH`. | `6a7366d2`: `PATH` pinned to an empty directory. Residual dropped 11 → 9; `vault` and `skills targets` now match. |
| Gate wired before it had ever run on CI | The four new oracles were added to `rust-check` on an unpushed branch. | `639a00b8`: `rust-check` returned to `main`'s dependency list — the set with real CI history. |

**Still open, tracked as issues.** These are not closed by the merge:

- #627 — `PATH` leak (the class above, kept as the parent report).
- #629 — `cli-oracle` runs cases without a bound; the sibling oracles
  (`db-memory-oracle`, `guard-doctor-oracle`) invoke the binary the same way.
- #630 — `cli-oracle` freezes the recording machine's temp-root shape: with a
  symlinked ancestor (`/tmp` → `private/tmp`) the `sync` case fails with
  `secure source parent ...: not a directory`, without one it succeeds.
- #631 — new oracles must not be wired into `rust-check` before passing once on
  a runner.
- #632 — `guard-scan-oracle` includes `go.mod`/`go.sum` in its pinned source set,
  so every Dependabot Go module bump fails `rust-check` by construction (seen on
  PR #609).

The four oracles remain runnable explicitly (`make cli-oracle-check`, …) so the
residual stays visible. Wiring them back into the gate requires making them
portable first; `cli-oracle-check` currently reports 9 of 81 cases diverging.

## Resume checkpoint — 2026-09-20, wave 4: the CLI tree has a consumer

`CLI-006` now has a Rust consumer instead of a fixture nobody read:
`rust/symbrain-cli/tests/cli_tree_tests.rs` runs the native binary once per case
in `rust/symbrain-cli/tests/fixtures/cli_tree_expectations.json` (81 cases,
captured from the shipped binary), each with a throwaway `HOME`/`XDG` root and
its own working directory, and asserts exit code, stdout and stderr after the
same normalizations the oracle applied.

- **70 of 81 match, and the 11 residual have four measured causes.** The verdict
  is the consumer test's (it applies the oracle's normalizations); the cause was
  established by running the native binary per case, not by reading the diff.
  1. **Five command surfaces are not ported** (5 cases): `sync`,
     `sync --unknown`, `harness list`, `harness health`, `guard doctor`. They
     print `symbrain: command "<x>" is not ported yet and no Go fallback was
     found; set SYMBRAIN_GO_BINARY` and exit 1, where the fixture holds the
     shipped exit code. An earlier entry here called the usage-shaped ones "port
     work on the exit code" — wrong: they never reach a usage parser, they stop
     at the unported-command gate, so they close only when the surface is ported.
  2. **Two cases are the flag package's own dump** (2 cases):
     `skills list --help` and `skills list --unknown` print `Usage of skills
     list:` followed by `PrintDefaults` formatting. They stay on Go on purpose:
     reproducing that dump without the flag set would create a second source of
     truth for the same bytes.
  3. **Three cases are artifacts of the consumer's isolation, not port gaps**
     (3 cases) — each verified by running the same command at a different root:
     - `skills log` is native and byte-exact (`No recorded skill operations.`,
       exit 0) when `HOME` has no symlinked ancestor. The consumer's root lives
       under `/var/folders`, and `/var` is a symlink, so the native path
       deliberately hands a log path with symlinked ancestors to Go.
     - `skills targets` diverges in one column only: the fixture records
       `claude`, `codex`, `antigravity` and `hermes` as `INSTALLED true`, the
       consumer's run reports `false` for all six targets. Measured cause: that
       column follows the **PATH** (harness CLI detection), not the root. With
       the recorder's PATH and an isolated root the reference binary reproduces
       the fixture's four `true` values exactly; with an empty PATH it reports
       `false` for all six, like the native binary. The consumer pins `PATH` to
       an empty directory, so its `false` is correct there and the case cannot be
       verified against this recording. The target list itself — six targets,
       order, skill roots — matches.
     - `vault` exits 1 because `symvault` is not on the pinned empty `PATH`.
  4. **One recording is environment-dependent** (1 case): `memory serve` holds a
     port-conflict transcript, so it is not a parity target.
- **The consumer now replays the tree in one shared root** (`1d6b57ba`), like the
  oracle: the recording ran every case in a single throwaway root in fixture
  order, so later cases saw the state earlier ones created. The consumer created
  a fresh root per case, which compared the port against a state the recording
  never had. No case changed verdict from the fix — it removes a false negative
  rather than closing a gap.
- **The wave-4 worktree is folded back and removed** (`84ba434e`): the consumer
  and its supporting usage-text changes were cherry-picked onto this branch, and
  `.worktrees/w4-cli` plus `migration/w4-cli` are gone. This branch is now the
  single reference line for wave 4. The consumer is marked `#[ignore]` with its
  reason (`59d43468`), because `cargo test --workspace` — and therefore
  `make rust-check` — picks it up, and it would turn the incremental entrypoint
  red before the residual above is closed. Run it on demand with
  `cargo test -p symbrain-cli --test cli_tree_tests -- --ignored`; un-ignore it
  and wire it into `rust-check` in the change that closes the residual.
- **The `memory` usage and help shapes are ported** (`ff8bfde9`), the shipped
  `skills` help text is used (`cf0f65e4`), and `guard version` prints the shipped
  four-row block (`3397df22`). All three changes followed the same rule: the text
  is taken from the shipped source, verified against the fixture, and never
  invented. `MEMORY_USAGE` and `MEMORY_LIST_USAGE` are the Go literals verbatim;
  the `memory sync` help is the *rendered* concatenation, because the Go source
  builds its token line from a constant (a first extraction of that literal was
  truncated at an inner backtick and would have been silently wrong).
  `guard version` reports a hard-coded build-time placeholder because the shipped
  `buildTime()` parses a constant date for every build.
- **Rejected: a worker "fix" that faked the toolchain row.** One dispatch
  replaced the native `version` output with `go      go0.0.0` so the fixture would
  match. That is a fabricated user-visible value, so it was reverted; the honest
  handling is the accepted-difference normalization the oracle itself documents
  (the toolchain row is tokenized, its label stays truthful: `rust`, not `go`).
- **The environment question is settled.** With `PATH` pinned to an empty
  directory the native behaviour is deterministic (`skills status` 0/27/0 and
  `skills targets` 0/638/0 across three runs), so the consumer is not flaky. An
  earlier note here called `skills status` environment-sensitive: what it
  actually shows is the *designed* fallback preference — the native binary
  delegates when a Go fallback is reachable and serves the command itself when
  it is not. The consumer pins the no-fallback case, which is the contract it
  means to verify.
- **One worker change was rejected as fabrication.** To satisfy the `version`
  comparison it had replaced the native binary's honest
  `  rust    {rustc_version()}` row with `  go      go0.0.0` — a made-up
  toolchain version in user-facing output. Reverted. The case is now handled in
  the comparison instead: the toolchain row is an accepted difference (the
  oracle says so itself), so both sides reduce it to one token and the row count
  and position stay compared. Its `mcp --unknown` usage fix was correct and was
  kept.
- **The first run reported 52 divergences and 40 of them were the harness, not
  the port.** The consumer's `normalize_stderr` used `str::lines()`, which drops
  a trailing newline, while the oracle's `strings.Split(s, "\n")` keeps the
  trailing empty element — so every stderr expectation came out exactly one byte
  short. Confirmed by running both binaries directly: for `bogus`, `version -h`
  and `profile show` the native and shipped outputs are byte-identical. Lesson:
  when a normalizer is ported, port its split semantics too, and when a run
  reports many one-byte differences, suspect the harness before the code.

## Resume checkpoint — 2026-09-20, wave 3: DB-001 divergence measured

`DB-001`/`DB-002` moved from "no consumer" to "measured divergence": the native
store is now held to the frozen Go facts by an executable differential test,
and that test is red. The row stays `fixture-ready` until it is green.

- **Acceptance test written** (`rust/symbrain-memory/src/db_oracle_tests.rs`,
  inside the crate because `busy_timeout` and `foreign_keys` are
  connection-scoped and can only be read from the store's own connection).
  Passing today: the lock pragmas (`busy_timeout` 5000, `journal_mode` wal,
  `foreign_keys` 1, `secure_delete` 1), the constraint cases (NULL
  `created_at`/`updated_at` rejected, missing table rejected) and the ordering
  cases (ties broken by id DESC, distinct timestamps by `created_at` DESC).
- **Closed** (commit `76a14f3a`, on the integration branch). The port landed
  with the acceptance test, because the test alone was red and the DDL alone
  was unmeasured. `DB-001`/`DB-002` are now `green`:
  1. **16 tables** added to the native schema: `audit_log`,
     `consolidation_runs`, `context_profile_links`, `context_profiles`,
     `entities_aliases`, `import_state`, `jwt_revocations`, `memories_fts`
     (+ its four shadow tables), `memory_associations`, `memory_evidence`,
     `query_log_results`, `sync_state`.
  2. **`memories` column facts** aligned: the shipped order and the shipped
     defaults. The native schema had added `DEFAULT ''` to `scope`, `metadata`
     and `embedding`, which the shipped schema declares NOT NULL without a
     default.
  3. **16 `memories` indexes** added (kind, tier, review_status, expires_at,
     content_hash, embedding_source, consolidation, consolidated_into,
     created_by, importance, lsh, scope_lsh, superseded_by, updated_at,
     valid_from, valid_to) plus the unique autoindex the shipped table carries.
- **Two defects in the worker's port were caught by existing tests, not by the
  worker's own report** — its summary claimed "all three checks pass" and did
  not mention them, and clippy/fmt were red:
  - the 16 new indexes sat inside `SCHEMA`, ahead of the `COLUMN_PARITY`
    repair, so `Store::open` failed on any database written by an older
    version (`no such column: tier`) — the indexes now live in `INDEXES` and
    run after the repair;
  - `COLUMN_PARITY` covered 5 columns while the shipped index set references
    26, so an upgraded database would have kept missing columns a fresh one
    has — it now covers every shipped `memories` column with its shipped
    definition;
  - a third gap **no test could see**: `memories_fts` was created without the
    `memories_ai`/`_ad`/`_au` triggers, so the table existed and never received
    a row. The oracle now records triggers and views (stored SQL; neither has a
    PRAGMA), the differential test holds them to it, and a new contract test
    proves a natively written row reaches the FTS index.
  - the contract test's raw insert omitted `embedding`, which only worked
    while the native schema wrongly gave that column a default.
- **Verification on the integration branch:** `cargo test -p symbrain-memory`
  21 lib + 7 contract, `clippy --all-targets -D warnings` clean,
  `cargo fmt --check` clean, `make rust-check` exit 0 (all oracle checks: xdg
  256, policy 50+30, guard 51, guard-doctor 7, catalog 3, cli 81, db-memory
  29 tables / 4 negative / 2 ordering), `make parity-smoke` 457/457.
- **The oracle was repaired first**, because three of its own cases were
  hollow: the ordering seeds omitted `metadata` (NOT NULL without a default),
  so the inserts failed silently and both expectations were captured as
  `null`; the NULL-timestamp cases were rejected for `metadata` rather than for
  the timestamp they name; and the legacy-migration case was dropped because
  the oracle opened the legacy file with the driver name `sqlite3` while the
  production package registers modernc's `sqlite`. Insert and open errors are
  now fatal. Note that `make db-memory-oracle-check` exercises the **committed**
  oracle (it exports `HEAD`), so an uncommitted oracle change is not covered by
  it — regenerate and commit the fixture explicitly.
- **Reachability, verified with a freshly built native binary and an isolated
  `HOME`:** `symbrain memory …` is gated back to the shipped implementation and
  resolves `<data>/memory/default.db` (it does **not** create a store through
  the native code path), but `symbrain mcp` **is** live: the gateway opens
  `symbrain_memory::Store` on the same `<data>/memory/default.db`
  (`rust/symbrain-gateway/src/lib.rs`). An earlier probe of mine that suggested
  the CLI path was native used a stale binary from 2026-09-17 and was wrong; the
  corrected measurement is in #626, which the port closes.
- **Branch state:** everything above is integrated on
  `migration/rust-continue-20260920` (local, not pushed). The wave-3 worktree
  `migration/w3-db-schema` has served its purpose and is removed. Nothing about
  this slice is outstanding.

## Resume checkpoint — 2026-09-20, wave 2 salvaged

Both wave-2 workers reported `completed` but neither had committed, and one had
derailed mid-task. Their branches were empty; the artifacts were found in the
worktrees (one of them in the **shared coordinator checkout**) and were
verified by hand before anything was kept.

- **`DB-001`/`DB-002` → `fixture-ready`.** `scripts/db-memory-oracle` imports
  `internal/memory/config` and `internal/memory/db`, creates a real store and
  reads the schema, pragmas and constraint behaviour back out of SQLite:
  29 tables, the full `memories` column set, 5 lock pragmas, and the NULL
  timestamp, ordering and tie-break cases. `make db-memory-oracle-check` →
  "0 drift on 29 tables, 3 negative cases, 2 ordering cases". No Rust test
  consumes the fixture yet, so the rows are not green.
- **`CLI-006` → `fixture-ready`.** `scripts/cli-oracle` freezes 81 cases of
  command-tree and flag behaviour (measured stdout, stderr, exit codes,
  including the negative flag cases), with the readable inventory in
  `migration/cli-tree-inventory.md`. `make cli-oracle-check` → "0 drift on
  81 cases".
- **The CLI oracle as the worker left it was unsafe and was rebuilt.** It ran
  the real binary with the ambient environment, so its own run executed
  `setup` (downloading and installing managed binaries into the operator's
  `~/.symaira/bin`), `doctor --fix`, and let `sync` write managed blocks into
  this repository's `AGENTS.md`. It is now isolated (throwaway `HOME`/`XDG`,
  scratch working directory), the two side-effecting cases are dropped, and
  the per-run root, the checkout path, the toolchain line and the host platform
  are placeholders. The fixture also carried 50 self-contradicting
  descriptions (a dead `expectedExit` parameter asserting exit 64/100 while the
  measured code was 2); the dead parameter is gone and the descriptions no
  longer claim an exit code.
- **Side effect on the operator's machine, reported:** `symdesk` v0.12.2 and
  `symvault` v0.22.1 were installed into `~/.symaira/bin` at 14:27 by that
  `setup` run (`symbrowse`/`symoperate`/`symscope` untouched from Sep 13).
- **New defect filed: #625.** `symbrain setup` cannot install the pinned
  `symcockpit` core: `managed: extract symcockpit: unsafe tar entry "./":
  invalid archive path`. Reproduced with an isolated `HOME` so the operator's
  binaries were not touched a second time.
- **Process lesson for the next wave:** a worker's artifact must be inspected
  and its side effects understood *before* it is run; an oracle that mutates
  the machine or the checkout is not evidence. Ask workers to commit as soon as
  the first slice passes, because a cut-off worker leaves nothing on its branch.

## Resume checkpoint — 2026-09-20, wave 1 integrated

Three workers were dispatched in isolated worktrees from `8ca8d2c5`. Two of
them were cut off before committing and their summaries arrived truncated, so
their branches were inspected and salvaged by hand instead of being trusted.

- **`CFG-001` is green.** `scripts/xdg-oracle` is a source-bound Go oracle
  (imports `internal/xdg`, injects HOME/XDG, 256 cases) and
  `rust/symbrain-core/tests/xdg_paths_tests.rs` compares all eight resolution
  functions against the frozen fixture. Verified on the integrated tree by the
  author: `run-go-oracle.sh HEAD run ./scripts/xdg-oracle -check` →
  "0 drift on 256 cases", and `cargo test -p symbrain-core` →
  `xdg_paths_match_go_oracle ... ok`. No divergence was found; no Rust change
  was needed. `make xdg-oracle-check` is wired into `rust-check`.
- **`#624` (atime flake) is addressed in the harness.** The three
  atime-derived cases now capture each runtime's own `SKILL.md` atime
  (`st_atime_ns`, nanosecond-exact) immediately before that runtime runs,
  require the reported `last_used` to be derived from that value (never older,
  absent only where the fixture carries no evidence), and normalize the value
  before the byte comparison. `skills_list_last_used_json` additionally
  requires the value to be present, so the evidence contract is still checked.
- **`guard doctor` stays on the Go fallback, with a frozen corpus.** The Go
  oracle over seven scenarios is committed as `SEC-005` (`fixture-ready`, no
  Rust consumer). Measurement from this wave: the production output is not
  byte-stable even Go-to-Go, because it prints the building toolchain
  (`go1.27.1` locally versus `go1.26.7` under `run-go-oracle.sh`) and absolute
  temp-root paths. The oracle therefore writes `<root>` and `Go: <go>`
  placeholders; the toolchain line is an explicit accepted difference. A Rust
  module that hardcoded those lines was discarded — it is not a port.
  `make guard-doctor-oracle-check` verifies the fixture against the pinned Go
  revision and is wired into `rust-check`.
- **Not authorized by this checkpoint:** Go removal, pushing/publishing,
  release or product cutover, and any claim that the `fixture-ready` rows are
  green.

**Verified revision: `f2d18e3d`** on `migration/rust-continue-20260920`
(local only — not pushed, no PR). Five commits on top of `4ca840c2`:
`9e20d19a` (CFG-001 oracle), `0db1baf7` (guard-doctor fixture), `ca91ffdb`
(gate wiring + SEC-005 row), `3b4526e1` (#624 harness fix), `f2d18e3d`
(this checkpoint). The commit that adds this paragraph is docs-only, so the
verified revision stays `f2d18e3d`.

Verified at that revision: `make rust-check` → exit 0 (workspace fmt, clippy,
tests, `cargo-deny` advisories/bans/licenses/sources ok, and the oracle checks
`policy 0/50+30`, `xdg 0/256`, `guard 0/51`, `guard doctor 0/7`, `catalog 0/3`,
…); `make parity-smoke` → exit 0, 457/457 cases. The wave-1 worker branches
were cherry-picked, then removed; `.worktrees/` is back to the two wave-2
worktrees.

**Wave 2 dispatched** (`deleg_0befee8f`, 2 workers, both from `f2d18e3d`):
`migration/w2-db` in `.worktrees/w2-db` → `DB-001`/`DB-002`; `migration/w2-cli`
in `.worktrees/w2-cli` → `CLI-006`. Neither worker may touch the Makefile,
`scripts/rust-differential.py` or this ledger. Coordinator must verify their
commits and diffs, integrate in dependency order, and only then update rows.
Still open and untouched: `SEC-001`, `SEC-002`, `GCLI-PLAT-01`, `DIST-001`,
`DIST-002`, `GUI-001`.

## Resume checkpoint — 2026-09-20 (session `migration/rust-continue-20260920`)

Base revision: `48568aee` (main, CI green there including the macOS
`rust-check parity-smoke` job). Integration branch:
`migration/rust-continue-20260920`, local only — no push, no PR, no release.

- **Reconciled stale ledger claims.** Section "Latest integration update — guard
  CLI" below is historical. Its stated next action (reproduce
  `{"command":"open"}x`, repair the trailing-JSON diagnostic) is **done and
  verified on this revision**: the pinned Go oracle and the current native
  binary both emit
  `{"decision":"deny","reason":"decide: parse request: invalid character 'x' after top-level value"}`.
  `rust/symbrain-cli/src/guard_cli.rs` already carries the regression test
  `decide_preserves_go_trailing_json_diagnostic`. GCLI-F03 is closed by evidence,
  not by re-implementation. GCLI-PLAT-01 (non-Unix audit path) and Phase 8.5/8.6
  (`guard doctor` still returns `None` → Go fallback) remain open.
- **Fixed and verified: doctor vault-agent routing (#616).** `make rust-check`
  previously failed on any machine that has profiles, because
  `doctor_cli::requires_go_fallback` returned at the first `-vault-agent` and
  read the real XDG profile directory. The predicate now mirrors Go's
  `flag.FlagSet` scan (value consumption, `-h`/`-help`, undefined flag, missing
  value) and the profile precondition is injected
  (`requires_go_fallback_with`). Evidence: `cargo test -p symbrain-cli --lib`
  90 passed; `make rust-check parity-smoke` 458/458 twice; contract row
  `CLI-006B`.
- **Recorded external/new defect: #624.** Three atime-derived skills parity
  cases (`skills_list_managed_installs_json`, `skills_list_last_used_json`,
  `skills_list_target_flag_is_ignored`) flaked once and then passed 458/458 on
  two consecutive re-runs with no source change. `last_used`
  (`last_used_source: install_atime`) is the fixture file's atime, which the
  fixture pins and an ambient reader can bump afterwards, leaving the two
  runtimes reporting their own read clocks. Not a parity regression; the gate
  stays flaky until the fixture compares the atime captured per runtime.
- **Task order after this checkpoint** (dependency order, one writer each):
  1. `CFG-001` — XDG and legacy path precedence: source-bound Go oracle plus
     Rust comparison; row is `pending` while `rust/symbrain-core/src/xdg.rs` is
     already implemented.
  2. `#624` — make the atime-derived parity cases race-free (harness only).
  3. Phase 8.5/8.6 — `guard doctor` native port (the last `guard` verb on the Go
     fallback), then `SEC-001` secret-reference resolution and redaction.
  4. Phase 10 (`DB-001`, `DB-002`) and Phase 11 (`DIST-001`, `DIST-002`,
     `GUI-001`) remain untouched and are the largest open blocks.
- **Not authorized by this checkpoint:** Go removal, pushing/publishing,
  release or product cutover, and any claim that the `fixture-ready` rows are
  green.

## Latest integration update — guard CLI (historical, superseded above)

The previously test-only Unix `guard decide` adapter is now wired into this
local Rust integration candidate. Installed applications are unchanged. Other
guard verbs still use the Go fallback. Worker `sa-0-43ac72fd` has finished;
the coordinator owns this integration worktree and no Brain writer is active.
This update supersedes the earlier decoder checkpoint's pending-CLI statements.

Exact five-file delta, source-before/after hashes and reversible patch:
`/Volumes/1TB_NVMe_SN850X/Dev/Symaira_Dev/Repos/docs/intern/rust-resume-evidence/brain-cli-integration-20260914T074809.707828Z/integration.json`.
The sibling `integrated-parity.json` records the rebuilt integration binary's
23/23 actual Go comparisons (response, exit, stderr, audit). Build, strict CLI
Clippy and workspace formatting passed after integration. Earlier worker tests
remain worker-source evidence until repeated on this candidate.

Independent review `deleg_5239fba0` approved the bounded Unix adapter and closed
GCLI-F01/F02 (help and ignored arguments). GCLI-BUILD-01 was resolved by rebuilding
both the reviewed worker binary and the integrated candidate. GCLI-F03 (trailing
JSON diagnostic) and GCLI-PLAT-01 (non-Unix audit unsupported) remain open; this is
not full guard/Brain parity or native/value/cutover acceptance.

Next concrete action: reproduce `{"command":"open"}x` against the pinned Go and
integrated Rust binaries, add it to the executable differential corpus, repair
the trailing-JSON diagnostic and repeat the affected candidate gates. Retain all
existing WIP, historical Go source and failed evidence. No PR or release.

## Resume checkpoint — 2026-09-14, guard decoder review

- Owner: migration coordinator. `sa-0-d06ca694` stopped without edits: runtime
  auto-isolated it in Vault, not Brain. Replacement `sa-0-43ac72fd`
  (`deleg_686b0cd6`) was dispatched after explicitly setting Brain cwd, with
  instructions to verify its own repository and restore the verified source
  overlay only into its clean private child worktree. Successful isolation and
  implementation remain unverified until the handoff; do not repeat the earlier
  claim that CLI integration is already underway. The integration worktree,
  lockfile, decoder and this register remain coordinator-owned. Worker lifetime
  is session-local, not durable after termination. Integration worktree:
  `/Volumes/1TB_NVMe_SN850X/Dev/Symaira_Dev/Repos/symaira-brain/.worktrees/rust-integration-20260913`,
  branch `migration/rust-integration-20260913`; integration/Go oracle
  `0b585d52915a824664e1377d0a995dff3f5405cd` plus preserved WIP.
- Recovery manifest (main/origin SHAs, full owned file list, byte-verified overlay,
  staged/unstaged binary patches):
  `/Volumes/1TB_NVMe_SN850X/Dev/Symaira_Dev/Repos/docs/intern/rust-resume-evidence/20260914T072304.925477Z/brain/snapshot.json`.
  This retains the earlier Go audit/test changes, Raw-JSONL implementation,
  test-only adapter, fixture generators and this run's decoder changes. Do not
  reset, overwrite or reimplement that WIP.
- Current scope remains **partial**, not a completed vertical slice. The decoder
  now preserves duplicate null scalar/time fields and Go warning-slice reuse,
  folded JSON names, zero times and IPv6 zones. Audit serialization now follows
  the real Go command's `omitempty`; a former mirror-only test expectation was
  corrected against actual pinned-command output. Quoting reuses the existing
  `symbrain-core` implementation rather than a second formatter.
- Verified evidence:
  `/Volumes/1TB_NVMe_SN850X/Dev/Symaira_Dev/Repos/docs/intern/rust-resume-evidence/brain-review-gate-20260914T072140.355630Z/report.json`.
  It binds source-before/after hashes, Rust/Cargo 1.98.0, native host, argv,
  cwd, individual exit codes and logs. Guard-core tests, strict Clippy and
  formatting passed. The new corpus compares 18 actual Go responses and audit
  records; the mutation test uses the real capture validator. Earlier failing
  run directories are retained, not relabeled as successes.
- Reproduce the retained-source Go capture without replacing it:
  `python3 guard/scripts/guard-decide-oracle/review_cases.py --check --output rust/symbrain-guard-core/tests/fixtures/external_decision_review.json`.
  The generator verifies the historical binary hash and full Git-source identity;
  its retained build lives in `target/migration-run/guard-decide-provenancefix`.
- Next executable gate:
  `python3 /Volumes/1TB_NVMe_SN850X/Dev/Symaira_Dev/Repos/docs/intern/brain-review-gate.py`.
  Then promote the existing test-only adapter into the local Rust CLI candidate
  and compare the actual binary against the pinned Go command. `guard` dispatch
  still returns `None` (Go fallback); installed applications are unchanged.
- Still open within Phase 5/guard-decide: full malformed JSON/time diagnostics
  (the time diagnostic helper is only lexically covered, not complete Go time
  parser parity), true binary dispatch, audit error/path/race and cancellation
  differential gates, independent delta review, native foreign-platform gates,
  remaining Brain/Browse/Guard contracts and final value/integration acceptance.
  No PR, merge, release or product cutover is authorized by this checkpoint.


> **For Hermes:** Execute this plan task-by-task with one implementation writer at a time and two-stage review (contract compliance, then code quality). Never remove the Go oracle before Phase 10.

**Goal:** Replace the Go implementation of `symbrain` with safe, idiomatic Rust while preserving CLI, MCP, SQLite, filesystem, Swift-client, security, and release contracts.

**Architecture:** A Rust host owns migrated commands and delegates unmigrated commands to a co-located Go oracle. Each vertical slice moves one externally testable capability behind the Rust dispatcher, adds Go↔Rust differential fixtures, and keeps both runtimes releasable. Domain crates stay under `rust/`; the SwiftUI apps remain Swift.

**Tech stack:** Rust 1.98/edition 2024, Serde, Tokio only at async boundaries, `rusqlite` with bundled SQLite/FTS5, `toml_edit`, official MCP Rust SDK where raw-frame parity permits it, `tracing` to stderr, proptest/fuzzing, cargo-nextest/audit/deny/llvm-cov.

---

## Global rules and gates

1. Keep Go buildable and tested until Phase 10 is complete.
2. Before each Rust port, freeze the Go behavior with a language-neutral fixture generated by the production Go binary or loader.
3. Run Rust and Go with identical argv, stdin, HOME/XDG roots, locale, timezone, and network fakes.
4. Compare exit status, stdout, stderr, file manifests/modes, SQLite state, and raw protocol frames in that order.
5. Treat every unexplained difference as a defect. Do not normalize it away.
6. Use `#![deny(unsafe_code)]`; any exception requires a documented invariant, focused tests, Miri, and review.
7. In MCP mode, stdout contains JSON-RPC frames only. All diagnostics go to stderr.
8. Do not change the Swift models to hide a Rust incompatibility. Rust must first satisfy the current JSON contract.
9. Do not commit, push, or cut over release assets without Daniel explicitly requesting those Git actions.

### Required fast gate after every task

```sh
make rust-check
make parity-smoke
make test
```

### Required phase gate

```sh
cargo nextest run --workspace --all-features
cargo test --workspace --doc --all-features
cargo hack check --workspace --each-feature --no-dev-deps
cargo llvm-cov nextest --workspace --all-features
cargo audit
cargo deny check
```

---

## Phase 0 — Baseline and reversible Rust host

**Status:** implemented on `feat/rust-migration`; retain until final review.

### Task 0.1: Measure and freeze the Go baseline
- Record Go files, packages, source lines, wall time, and memory in `MIGRATION-RUST.md`.
- Run `make test` before any Rust edit.
- Expected: all Go tests pass; baseline is reproducible.

### Task 0.2: Create the pinned Rust workspace
- Create `Cargo.toml`, `Cargo.lock`, `rust-toolchain.toml`, and `deny.toml`.
- Create `rust/symbrain-cli` with `#![deny(unsafe_code)]`.
- Expected: fmt, check, Clippy, tests, audit, and deny pass.

### Task 0.3: Add the dual-runtime dispatcher
- Rust owns no-argument help, help aliases, `version`, and `config path`.
- Unported commands invoke `SYMBRAIN_GO_BINARY` or `symbrain-go` with inherited stdio and exact exit status.
- Expected: a Rust invocation of `guard version` reaches the Go engine unchanged.

### Task 0.4: Add the neutral differential runner
- Maintain cases in `scripts/rust-differential.py` and contracts in `migration/contract-matrix.csv`.
- Build both binaries with the same version.
- Expected: all listed CLI cases match byte-for-byte.

### Task 0.5: Gate the migration in CI
- Add a pinned-action `rust-migration` job to `.github/workflows/ci.yml`.
- Expected: `make rust-check parity-smoke` is mandatory on every code PR.

---

## Phase 1 — Core, output, XDG, config, profiles, and policy

### Task 1.1: Extract `symbrain-core`
- Create `rust/symbrain-core/src/{lib.rs,exit.rs,output.rs,xdg.rs}`.
- Move exit codes, version payload, output format parsing, and XDG resolution out of `symbrain-cli`.
- Port tests from `internal/output`, `internal/paths`, and `internal/xdg`.
- Expected: CLI behavior unchanged; crate has no network/database dependency.

### Task 1.2: Port `config get`
- Add `toml_edit` and read `config.toml` through the production XDG path.
- Cover missing file, whole-file byte output, dotted keys, missing keys, malformed TOML, and extra arguments.
- Add differential cases with isolated fixture homes.
- Expected: exit codes and stdout/stderr match Go exactly.

### Task 1.3: Port `config set`
- Preserve bool/integer/string inference, dotted table creation, type-conflict errors, 0700 parent directory, 0600 file, and atomic replacement.
- Preserve unrelated keys and comments unless the Go oracle demonstrably does not.
- Compare recursive file manifest, mode, and parsed TOML.

### Task 1.4: Create `symbrain-policy`
- Port profile structs, TOML decoding, defaults, validation, server modes, allow/deny evaluation, annotations, and default-deny behavior from `internal/profile` and `internal/policy`.
- Use table-driven Go fixtures plus Rust parameterized tests for every mode matrix.

### Task 1.5: Port profile read/create commands
- Port `profile list`, `show`, and `add`; keep `profile remove` on the Go fallback until the harness-binding registry exists in Phase 6.
- Preserve JSON/table forms, ordering, templates, file modes, errors, and command-local flag placement.
- Run Swift model decoding tests against Go- and Rust-generated profile JSON.

### Phase 1 acceptance
- Every `config` row plus `profile list`, `profile show`, and `profile add` is green natively.
- Go and Rust profile JSON are semantically identical and stable in order where documented.
- Only `profile remove` may still invoke the Go fallback because its safety check depends on Phase 6 harness discovery.

---

## Phase 2 — Catalog, audit, patterns, and activity

### Task 2.1: Create `symbrain-catalog`
**Status:** implemented on `feat/rust-migration`.

- Port namespacing, collision detection, stable sorting, tool annotations, and routing metadata.
- Snapshot exact tool names/descriptions/schemas.

### Task 2.2: Create `symbrain-audit`
**Status:** implemented on `feat/rust-migration`; the frozen Go reader defect is tracked in #462.

- Port JSONL records, redaction, bounded backward tail, profile filters, degradation records, and file permissions.
- Compare bytes for fixed timestamps and semantic records for runtime timestamps.

### Task 2.3: Port `audit tail`
**Status:** implemented on `feat/rust-migration`; chained-envelope correction remains gated on #462.

- Cover small files, files larger than the reverse-scan chunk, missing files, malformed lines, `-n`, profile filters, and JSON/table output.

### Task 2.4: Port patterns and activity
**Status:** deterministic core implemented on `feat/rust-migration`; the DB-backed activity CLI remains on the Go fallback until the memory SQLite layer in Phase 10.

- Port episode recording, promotion thresholds, bounded token output, profile access, and redaction.
- Freeze Unicode truncation and ordering behavior with fixtures.

### Phase 2 acceptance
- Catalog snapshots, audit JSONL, activity fencing, and promoted-pattern decisions match Go.

---

## Phase 3 — MCP protocol and child broker

### Task 3.1: Create `symbrain-mcp`
**Status:** implemented on `feat/rust-migration`.

- Model JSON-RPC request/response/error types with exact snake_case and null/omission semantics.
- Implement both newline-delimited and `Content-Length` framing accepted by the Go server.
- Add malformed, oversized, partial, cancellation, and notification fixtures.

### Task 3.2: Fuzz protocol framing
**Status:** implemented on `feat/rust-migration` with Go-oracle seed drift checks.

- Add cargo-fuzz targets for frame decoding and JSON-RPC envelopes.
- Retain minimized crashes as regression fixtures.

### Task 3.3: Create `symbrain-broker`
**Status:** implemented on `feat/rust-migration`.

- Port child spawn/initialize/tools-list/tools-call, timeout handling, restart/backoff, health state, and stderr capture.
- Use process groups and guaranteed cleanup; verify no child survives cancellation.

### Task 3.4: Port the fake MCP child
**Status:** implemented on `feat/rust-migration`; Go and Rust broker scenarios share one oracle fixture.

- Replace or complement `internal/broker/testdata/fakemcp` with a language-neutral fixture executable/script.
- Run identical lifecycle scenarios against both brokers.

### Phase 3 acceptance
- Raw frames are byte-compatible where IDs and times are fixed.
- Crash/restart and shutdown leave zero child processes.
- Protocol fuzzing completes without crash or hang.

---

## Phase 4 — Managed binaries and passthrough

### Task 4.1: Create `symbrain-managed`
**Status:** implemented on `feat/rust-migration`; corrected unsafe Go archive selection is tracked in #465.

- Port embedded manifest parsing, platform/architecture mapping, release URL construction, SHA-256 verification, archive extraction, and atomic installation.
- Reject traversal, symlink escapes, unknown assets, and checksum mismatches.

### Task 4.2: Port `setup`
**Status:** implemented on `feat/rust-migration`; deterministic ordering, platform skips, and `v`-prefix repair matching were corrected in the Go oracle (#467). A pinned-checksum downgrade path was also closed in both runtimes (#466).

- Reuse HTTP fixtures and local release archives; never test against mutable live releases.
- Compare install/repair output, JSON reports, and installed file modes.

### Task 4.3: Port `vault` passthrough
**Status:** implemented on `feat/rust-migration`; validated by VLT-001/VLT-002 differential cases.

- Preserve opaque platform-native argv, inherited stdin/stdout/stderr and TTY behavior, child exit status/signal behavior, lookup order, and missing-binary diagnostics.
- Resolve in the same order as Go: configured `servers.vault.binary_path` (including its environment override), managed `~/.symaira/bin/symvault`, then executable `PATH` entries.
- Spawn with inherited stdio and mirror Go's signaled-child mapping (`ExitCode() == -1` becomes process status 255); do not alter the executable oracle's signal contract.
- Exercise only fake `symvault` scripts in the differential harness; no live vault or secrets are used.

### Phase 4 acceptance
- Every supported platform selects the same asset as Go.
- Security-negative archive fixtures fail before writing outside the destination.

---

## Phase 5 — MCP gateway and doctor

**Execution dependency:** Build the gateway domain, MCP loop, audit integration,
and doctor foundations in this phase. The native CLI now serves the proven
subset (gateway-owned tools plus configured stdio children), while full-profile
cutover remains blocked until the Skills, Usage, and Memory handler crates from
Phases 7, 9, and 10 are available. The Go gateway exposes those tools
in-process; replacing them with temporary child backends would neither prove
parity nor satisfy the no-fallback acceptance gate. Return to Phase 5 acceptance after those dependencies are green.

### Task 5.1: Create `symbrain-gateway`
- Port profile-bound catalog assembly, namespace rewriting, built-in tools, child/internal routing, errors, identity injection, and policy shaping.

### Task 5.2: Port `mcp` and deprecated `serve`
**Status:** native CLI cutover is implemented for the proven subset: profile loading,
foreign stdio children, the configured vault stdio child, gateway-owned tools,
raw JSON-RPC subprocess coverage, notification/EOF/error behavior, and Unix
signal/process-group cleanup. Embedded Memory, Skills, and Usage handlers are
not ported; enabled profiles fail closed with an explicit stderr blocker rather
than exposing placeholders or falling through to Go. Cross-platform lifecycle
coverage and final Phase 5 acceptance remain blocked on those handlers plus the
corrected corekit oracle.

- Preserve initialization capabilities, tools/list, tools/call, notifications, cancellation, EOF, and stderr-only deprecation warning.
- Keep the Go oracle available for other commands; `mcp` and `serve` never invoke it.

### Task 5.3: Port doctor checks
**Status:** native baseline implemented; isolated empty-state JSON/human output, flag behavior, and non-zero version probes are byte-exact. Subprocesses are hard-bounded and secret-bearing child stderr is redacted in Rust; Go correction is tracked by #473. Complex profile, handshake, malformed-config, `--fix`, and cross-platform fixtures remain before cutover approval.
- Port config/profile/server/harness/link/degradation checks and fix behavior.
- Preserve warning-vs-fatal classification and JSON schema.

### Task 5.4: Rebuild stdio hygiene gate
- Exercise cold start, list, invalid call, child crash, shutdown, and malformed input.
- Parse every stdout line/frame; reject any non-JSON-RPC byte.

### Phase 5 acceptance
- Official MCP conformance and raw Symaira differential fixtures pass.
- Rust `mcp` never invokes the Go fallback.

---

## Phase 6 — Harness registry, adapters, instructions, install, and sync

### Task 6.1: Create `symbrain-harness`
**Status:** H1–H5 implemented in the native `rust/symbrain-harness` workspace crate. The nine-entry registry, injected OS/environment path resolution, Entry/ServerInfo semantics, ordered JSON and TOML document operations, golden round trips, timestamped atomic backups, bounded unified diffs, read-only inventory, and profile bindings are covered by executable tests against the Go golden fixtures and production-derived registry contract. The Windows fallback path intentionally follows the injected target OS rather than reproducing the Go test helper defect tracked in #469; the correction is isolated to path resolution and remains fixture-ready for native Windows verification.
- Port the target registry and all config formats/paths/transports.
- Preserve unknown fields, ordering, comments where supported, and backups.

### Task 6.2: Port adapters
**Status:** implemented in `rust/symbrain-adapter`; the source-bound Go oracle pins production adapter/registry/instruction bytes and covers the four exact rendering adapters plus five explicit registry skips. Existing user bytes, malformed markers, CRLF/non-UTF-8, marker-bearing content, target paths, traversal and absolute-path rejection, capability-rooted parent confinement, nonblocking Unix reads, and durable atomic writes are tested. Unix mode bits, xattrs/POSIX ACL xattrs, and Windows owner/group/DACL preservation are implemented through retained handles; ordinary Windows writes do not request SACL privilege. Go sync emits target statuses before returning a non-zero failure decision.
CLI wiring and skills installation remain deferred.

- Port the actual Go registry contract: Claude, Claude Desktop, Codex, Cursor,
  OpenCode, Antigravity, Agents, Hermes, and OpenClaw. Do not invent adapters
  for Toolbox, Copilot, retired Gemini, Kiro, Zed, or Windsurf unless they first
  become supported Go contracts with fixtures.
- Maintain golden files per harness and platform.

### Task 6.3: Port managed instruction blocks
**Status:** implemented with capability-rooted source parents in Go and Rust. The source-bound Go oracle and `rust/symbrain-instructions` share a 1 MiB per-file / 1.5 MiB merged-source limit, regular-file/no-follow reads, component-wise trusted-root/source-parent walks on Unix and Windows, XDG source-path cases, a true prefix-code sentinel escape with collision proofs, and four deterministic source-error verdicts. Negative source diagnostics now compare exact normalized bytes, including the Go `instructions: read <path>:` wrapper; fixture normalization removes only isolated temporary roots and uses slash separators, without weakening redaction. Unix final opens are nonblocking and FIFO/symlink/late-parent races are covered. Go and Rust atomic replacement preserve complete Unix mode bits and readable xattrs/POSIX ACL xattrs; macOS's OS-owned `com.apple.provenance` is explicitly excluded. Windows adapter replacement preserves owner/group/DACL without requesting SACL privilege; unsupported post-rename directory flushes are nonfatal after file data is flushed.
- Preserve all bytes outside markers; guarantee idempotency and newline behavior.
- Add proptest round trips.

### Task 6.4: Port harness/install/uninstall/sync commands
**Status:** Phase 6.3A install/uninstall is native and green for the exercised macOS/Linux paths, with Windows target compilation verified but native Windows runtime still unclaimed. Trusted roots are opened component-by-component from filesystem anchors without following symlink/reparse ancestors; config reads, JSON/TOML parsing, backup names, temporary names, replacement, rollback, and cleanup are bounded and capability-rooted. A source-bound Go oracle runs the production CLI in isolated HOME/XDG/project roots and freezes entry bytes/semantics, malformed-before-side-effect refusal, dry-run, profile defaults and environment override, Claude project scope, superseded migration, foreign-name protection, no-op cases, collision-safe backup shape/content/modes, rollback on failure, symlink rejection, and parent/file modes. Native Rust routing uses `symbrain-harness` capability paths; unrelated commands retain the Go fallback. Instruction source and adapter reads now retain no-follow root/parent capabilities and use bounded regular-file checks with nonblocking Unix final opens; Go and Rust replacement preserve Unix mode/xattr/POSIX-ACL metadata and Windows owner/group/DACL metadata without requesting ordinary-write SACL privilege. Unsupported Windows directory flushes are nonfatal after the rename has committed and file data has been flushed. Skills sync remains deferred.

Source-bound profile removal is now implemented in `rust/symbrain-cli` and
covered by a 20-case Go oracle. Binding scans fail closed on unreadable,
malformed, symlinked, FIFO, and other special configuration files; confirmation
input is bounded, and `--force` is the explicit override. The profile target
itself is deleted through retained no-follow capabilities, including protection
against a symlinked `profiles` directory. Native Windows runtime remains
unclaimed; Windows target compilation is verified in the matrix.
- Cover global/project scope, dry run, superseded server migration, backups, health probes, partial failures, and JSON summaries.
- Keep the profile remove contract covered by its native harness registry, source-bound oracle, and platform-specific safety tests.

### Phase 6 acceptance
- Sync twice produces a zero-byte diff.
- Every harness golden and Swift `SyncSummary`/`HarnessStatus` decoder passes.

---

## Phase 7 — Skills engine

### Task 7.1A: Create `symbrain-skills` model and variants
**Status:** fixture-ready on `feat/rust-migration`; the Rust crate is implemented and tested against the tracked Go render fixtures, with a deterministic Go loader oracle and Rust source-bound comparison. The complete slice remains fixture-ready rather than green because target rendering is intentionally deferred to Task 7.2.

- Port `SKILL.md` frontmatter and `symskills.toml` manifest parsing, bundle/resource loading, root-contained path checks, validation, render-blocking classification, and deterministic markdown/overlay discovery.
- Port flat `block`, `only`, and `except` markers, target-specific block overrides, term substitution, unscoped mention detection, malformed-marker diagnostics, and cross-file uniqueness/reference checks.
- Keep config, profiles, rendering, installation, VCS, CLI, and MCP behavior for later tasks.

### Task 7.1: Create `symbrain-skills` domain model
- Port config, metadata, frontmatter, variants, profile resolution, discovery, and deterministic ordering.

### Task 7.2: Port rendering
- Freeze every existing `internal/skills/render/testdata` artifact from Go.
- Match generated bytes, permissions, and symlink behavior.

### Task 7.3: Port install/status/restore/VCS
- Preserve three-way drift classification, unmanaged protection, conflict handling, operation log, and Git behavior.

### Task 7.4: Port skills CLI and MCP tools
- Port list/status/targets/log/sync/doctor and all skills MCP schemas/handlers.

### Phase 7 acceptance
- All skill goldens are byte-identical.
- Rust never overwrites harness-changed, conflicting, orphaned, or unmanaged content contrary to Go behavior.

---

## Phase 8 — Guard security module

Go remains the production enforcement path until the full Guard-specific matrix is green. Brain capability shaping must not absorb any per-call approval or risk behavior during the port.

### Task 8.0: Freeze Guard contracts with a source-bound oracle
- Add deterministic fixtures for model validation, policy buckets and precedence, sequence streams, config, capability vectors, audit formats, grants, discovery, spawn, and each CLI command.
- Inject clocks, identifiers, randomness, HOME/XDG roots, and fake network responses. Correct or explicitly record nondeterministic Go behavior before generating fixtures.

### Task 8.1: Port deterministic model and static policy
- Port request/decision models, validation, fail-closed responses, static rule buckets, merge, scope ceilings, marginal capability, risk classification, and deterministic reasons.
- Keep grants, sequence state, capabilities, audit, discovery, and CLI dispatch out of this slice.

### Task 8.2: Port sequence detector and config
- Port bounded repetition/search state with deterministic tie-breaking.
- Port TOML/XDG/defaults/validation and spawn allowlist configuration.

### Task 8.3: Port capability tokens and audit compatibility
- Verify fixed HKDF/HMAC/base64 vectors and expiry boundaries.
- Match both the selected Guard raw-line format and the canonical chained-envelope/anchor contract before consolidation.

### Task 8.4: Port grants, approval, and proposals
- Match expiry, ordering, tombstones, permissions, atomic replacement, human-only durable mutations, and audit sink requirements.

### Task 8.5: Port discovery, spawn, and output
- Preserve corekit-backed client ordering, path/platform behavior, environment redaction, absolute-path/argv gating, and stdout/stderr semantics.

### Task 8.6: Port guard commands and cut over
- Port decide/doctor/grants/scan/version with exact stdin/stdout/stderr and exit semantics.
- Switch the dispatcher only after every Guard row is green; until then Go remains the production path.

### Phase 8 acceptance
- Go and Rust produce identical decisions for the full policy corpus.
- Existing Go audit chains remain verifiable and Rust chains are accepted by Go.

---

## Phase 9 — Usage providers

### Task 9.1: Create `symbrain-usage` common model
- Port provider status, percentages, reset times, errors, ordering, and bounded concurrency.

### Task 9.2: Port file/local-server providers
- Port Antigravity/OpenUsage, Codex, OpenCode, Kimi, Moonshot, Nous, and local JSON/plist readers using fixture files.

### Task 9.3: Port HTTP providers
- Port Claude, Copilot, Cursor, OpenRouter and any remaining APIs using recorded mock servers, explicit timeouts, and redacted errors.

### Task 9.4: Port Darwin Keychain lookup
- Shell out to `/usr/bin/security` with bounded timeout and no secret output. Add macOS-native integration tests that never touch Daniel's real credentials.

### Phase 9 acceptance
- Sanitized provider fixtures produce matching JSON; unsupported/unconfigured states degrade identically.

---

## Phase 10 — Memory core and SQLite

### Task 10.1: Freeze the database contract
- Generate a Go v0.11.0 fixture for every schema version and representative live shape without personal data.
- Record schema, indexes, triggers, pragmas, NULL/time encodings, and ordered query snapshots.

### Task 10.2: Create `symbrain-memory` storage layer
- Use `rusqlite` with bundled FTS5; apply the exact migration sequence and transaction boundaries.
- Match single-connection behavior, busy timeout, WAL, foreign keys, secure delete, locking, rollback, and interrupted migration semantics.

### Task 10.3: Port memory CRUD, entities, temporal data, and rules
- Preserve IDs, timestamps, scopes/kinds, evidence, staged state, soft/hard deletion, entity links, and ordering.

### Task 10.4: Port vector encoding and retrieval math
- Preserve 768-bit LSB-first little-endian sign encoding (`<= 0` means bit 1), Hamming distance, stable tie ordering, FTS tokenization, RRF `k=60`, Sparsemax, and spreading activation.
- Require byte equality for vectors and rank equality; float tolerance at most `1e-6` where bytes are not contractual.

### Task 10.5: Port importers and discovery
- Port each importer as its own reviewed task: Aider, Calendar, Claude Code, Codex, Codex Memory, Curated Memory, Email, Git, GitHub, Hermes, Memory Tool, Obsidian, OpenCode, Paperless, Shell History.
- Give every importer positive, empty, malformed, duplicate, and Unicode fixtures.

### Task 10.6: Port LLM, extraction, consolidation, context, aging, and working memory
- Use fake providers for deterministic tests; preserve prompts/output parsers and failure fallback.

### Task 10.7: Port memory CLI, MCP tools, sync, and HTTP server
- Port list/search/set/delete/rules/query-log/sync/serve and all memory MCP schemas.
- Preserve JWT/secret resolution (`symvault://`, deprecated `vault://`, env fallback), loopback binding, request limits, and encrypted relay compatibility.

### Task 10.8: Preserve reachable Memory interfaces
- Port the embedded web interface with the native HTTP server and preserve its auth/API behavior (#759/#762/#763).
- Retire the unreachable legacy TUI migration target under ADR0003/E010: frozen Go's Brain command dependencies do not include the TUI;12 actual Go/native command probes match. No new terminal UI command is introduced.
- Keep #763 open until the reachable HTTP UI has full native acceptance; Go source remains frozen until its separately gated removal.

### Phase 10 acceptance
- Rust opens and migrates every Go database fixture.
- Go opens Rust-written databases and passes integrity checks.
- Search candidate sets/ranks match; encrypted artifacts round-trip cross-runtime.
- Memory CLI/MCP/HTTP contracts are green without fallback.

---

## Phase 11 — Swift clients and cross-platform release

### Task 11.1: Run Swift contract tests against Rust
- Point `SymBrainCoreTests` at the Rust binary without weakening models or tests.
- Verify macOS app workflows; keep iOS read-only behavior unchanged.

### Task 11.2: Add native target CI
- Run Rust on Ubuntu, macOS, and Windows; use native runners for runtime behavior.
- Add scheduled Miri, fuzz, mutation, coverage, audit, deny, and unsafe-inventory jobs.

### Task 11.3: Build hybrid release artifacts
- During migration, package Rust `symbrain` plus platform-matched Go fallback while presenting one supported command.
- Preserve archive names, checksums, Cosign signatures, CycloneDX SBOMs, Homebrew behavior, GUI DMG embedding, signing, and notarization.

### Task 11.4: Benchmark release candidates
- Compare startup, steady RSS, command latency, MCP throughput, database size, search latency, and final archive size against the baseline.
- Publish only measured gains; record regressions honestly.

### Phase 11 acceptance
- All supported native platforms and Swift tests pass.
- Release artifact manifests match the established contract or an explicitly versioned migration.

---

## Phase 12 — Final cutover and Go removal

### Task 12.1: Prove zero fallback use
- Instrument test builds to fail if any command attempts the Go bridge.
- Run the complete contract matrix, including negative cases and side effects.

### Task 12.2: Ship a reversible Rust prerelease
- Keep the last known-good Go release/tag and documented rollback path.
- Run real harness smoke tests with sanitized user profiles and databases.

### Task 12.3: Remove the fallback bridge
- Remove Go embedding/packaging only after one prerelease cycle has no unexplained parity defects.
- Keep Go source in the repository for one stable Rust release if maintenance cost permits.

### Task 12.4: Remove Go build infrastructure
- In a separate reviewed change, delete Go source/modules, GoReleaser Go builds, and Go CI.
- Update AGENTS.md, README, release workflows, Homebrew, architecture docs, and contributor instructions for Rust.

### Task 12.5: Final release verification
- Rebuild from a clean checkout on all native platforms.
- Verify binary identity, archives, checksums, signatures, SBOMs, Homebrew install/test, macOS signing/notarization, Swift app launch, MCP conformance, database rollback, and documented recovery.

### Completion definition

The migration is complete only when every row in `migration/contract-matrix.csv` is green, no command invokes Go, the supported release matrix passes, Swift clients work unchanged at their public boundary, and the Rust release has a verified rollback to the last Go release.
