"""Read-only source verifier; never starts SDK/compiler/SQL/product/Target/port."""
from pathlib import Path
import ast
import hashlib
import json
import os
import subprocess
import sys

R = Path('/workspace/symaira-memory803-coherent-guard')
O = Path('/workspace/review-proof/memory803-skills-owner-successor')
A = '5a4f0464bc24efefa82e26068276fc747c5b1b11'
B = 'cdb2aca223bd9030f834608fd13cc4e643ebdc68'


def old(name):
    return subprocess.check_output(['git', '-C', str(R), 'show', A + ':' + name])


def dump(value):
    return ast.dump(value, include_attributes=False)


def functions(data):
    return {x.name: x for x in ast.parse(data).body if isinstance(x, ast.FunctionDef)}


novel = 'scripts/skills-argv-oracle/novel.py'
previous = functions(old(novel))
current = functions((R / novel).read_bytes())
assert set(previous) == set(current)
for name in previous:
    if name != 'parent_provenance':
        assert dump(previous[name]) == dump(current[name]), name
# All actual parent archive/build/source/current-binary restoration admission
# statements remain exact; only the subsequent owner qualification differs.
p = previous['parent_provenance'].body
c = current['parent_provenance'].body
before = next(i for i, n in enumerate(p) if isinstance(n, ast.Assign) and any(isinstance(t, ast.Name) and t.id == 'owners' for t in n.targets))
assert [dump(n) for n in p[:before]] == [dump(n) for n in c[:before]]
test = 'scripts/skills-argv-oracle/test_novel.py'
p = next(x for x in ast.parse(old(test)).body if isinstance(x, ast.ClassDef))
c = next(x for x in ast.parse((R / test).read_bytes()).body if isinstance(x, ast.ClassDef) and x.name == p.name)
assert dump(p) == dump(c)
unchanged = ['scripts/skills-argv-oracle/build_go.py', 'scripts/skills-argv-oracle/build_parent.py',
             'scripts/skills-argv-oracle/compare.py', 'scripts/skills-argv-oracle/verify_control.py',
             'scripts/skills-argv-oracle/verify_novel_control.py',
             'scripts/memory-historical-oracle/validate.py']
assert all(old(n) == (R / n).read_bytes() for n in unchanged)
plan = 'migration/evidence/skills-preflight-793/windows-wide-argv/original-70b-static/symaira-skills794-wide-argv-independent-novel-plan.json'
assert old(plan) == (R / plan).read_bytes()
assert hashlib.sha256((R / plan).read_bytes()).hexdigest() == '5478c095a73d0332baa987dfae3dea6d3c3863104841be7b4d689edfba762bce'
assert ast.dump(ast.parse((R / unchanged[-1]).read_bytes())) == ast.dump(ast.parse((Path('/workspace/review-proof/usage-memory803-runtime-preparation-path-fixed') / 'original-validate.py').read_bytes()))
# Read every current Git source body through the object database, with exact
# physical-body checks where sparse materialization exists. No target is read.
index = subprocess.check_output(['git', '-C', str(R), 'ls-files', '-sz'])
rows = []
for row in index.split(b'\0'):
    if not row:
        continue
    meta, path = row.split(b'\t')
    mode, oid, stage = meta.split()
    assert stage == b'0'
    rows.append((path.decode(), mode.decode(), oid.decode()))
proc = subprocess.Popen(['git', '-C', str(R), 'cat-file', '--batch'], stdin=subprocess.PIPE, stdout=subprocess.PIPE)
source = []
for name, mode, oid in rows:
    proc.stdin.write((oid + '\n').encode())
    proc.stdin.flush()
    header = proc.stdout.readline().split()
    assert header[0].decode() == oid and header[1] == b'blob'
    raw = proc.stdout.read(int(header[2]))
    assert proc.stdout.read(1) == b'\n'
    assert hashlib.sha1(b'blob ' + str(len(raw)).encode() + b'\0' + raw).hexdigest() == oid
    physical = R / name
    materialized = physical.exists()
    if materialized:
        assert physical.read_bytes() == raw, name
    source.append({'path': name, 'mode': mode, 'blob': oid, 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest(), 'materialized': materialized})
proc.stdin.close()
assert proc.wait() == 0
(O / 'current-full-git-source-map.json').write_text(json.dumps(source, separators=(',', ':')) + '\n')
result = {'actual_source_rows': len(source), 'physical_rows_checked': sum(x['materialized'] for x in source),
          'all_old_novel_functions_except_provenance_whole_AST_equal': True,
          'parent_binary_admission_prefix_whole_AST_equal': True, 'old_four_preparation_tests_whole_AST_equal': True,
          'unchanged_builders_verifiers_and_historical17_AST': unchanged,
          'immutable152_plan_exact': True, 'frozen_go_current': [], 'SDK_compiler_SQL_product_Target_ports': 0}
# Exact source identities for every Go/source fixture entry retained from A.
for row in source:
    name = row['path']
    if name.endswith(('.go', '.go.txt', '/go.mod', '/go.sum')) or name in ['go.mod', 'go.sum']:
        q = subprocess.run(['git', '-C', str(R), 'rev-parse', A + ':' + name], capture_output=True)
        if q.returncode == 0:
            assert q.stdout.decode().strip() == row['blob'], name
            result['frozen_go_current'].append(name)
(O / 'source-verification.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({k:v for k,v in result.items() if not isinstance(v,list)}, indent=2))
