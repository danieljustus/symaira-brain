from pathlib import Path
import hashlib
import json
import os
import tarfile

O=Path('/workspace/review-proof/memory803-skills-owner-successor')
R=Path('/workspace/symaira-memory803-coherent-guard')
D=R/'migration/evidence/memory-coherent-guard-803/original-5a4'
D.mkdir(parents=True,exist_ok=True)
files=sorted(p for p in O.rglob('*') if p.is_file())
rows=[]
archive=D/'inputs-and-source-checks.tar.gz'
with tarfile.open(archive,'w:gz',format=tarfile.PAX_FORMAT,compresslevel=6) as t:
 for p in files:
  st=p.stat();rel=str(p.relative_to(O));raw=p.read_bytes();info=t.gettarinfo(str(p),arcname=rel)
  info.pax_headers['mtime']=f'{st.st_mtime_ns//10**9}.{st.st_mtime_ns%10**9:09d}'
  with p.open('rb') as f:t.addfile(info,f)
  rows.append({'member':rel,'original_path':str(p),'sha256':hashlib.sha256(raw).hexdigest(),'bytes':len(raw),'mode':st.st_mode,'uid':st.st_uid,'gid':st.st_gid,'mtime_ns':st.st_mtime_ns})
with tarfile.open(archive,'r:gz') as t:
 assert sorted(t.getnames())==sorted(x['member'] for x in rows)
 for row in rows:
  info=t.getmember(row['member']);raw=t.extractfile(info).read();assert hashlib.sha256(raw).hexdigest()==row['sha256']
  assert (info.uid,info.gid,info.mode)==(row['uid'],row['gid'],row['mode']&0o7777)
  assert info.pax_headers['mtime']==f"{row['mtime_ns']//10**9}.{row['mtime_ns']%10**9:09d}"
(D/'retention.json').write_text(json.dumps({'source_checkpoint':'6705284b9adc98ea9bb4a4fa1d7fe8a158e9cbff','original_memory':'5a4f0464bc24efefa82e26068276fc747c5b1b11','normal_guard_parent':'cdb2aca223bd9030f834608fd13cc4e643ebdc68','archive':archive.name,'archive_bytes':archive.stat().st_size,'archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'all_members_full_body_mode_uid_gid_exact_ns_mtime_verified':True,'members':rows,'shared_large_originals':['/workspace/review-proof/root-797-803-windows-wide-originals/receipt.json','/workspace/review-proof/memory803-main5a4-failed-runtime/handoff.json'],'no_SDK_compiler_SQL_product_Target_port_operation':True},indent=2)+'\n')
print('retained files',len(rows),'archive bytes',archive.stat().st_size,'body footprint',sum(p.stat().st_size for root in [O,R] for p in root.rglob('*') if p.is_file()))
