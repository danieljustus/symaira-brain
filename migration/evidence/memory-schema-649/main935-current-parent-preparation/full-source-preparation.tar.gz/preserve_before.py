"""Pure immutable Git/source/archive preservation, no build/product access."""
import gzip,hashlib,io,json,os,stat,subprocess,tarfile
from pathlib import Path
R=Path('/workspace/symaira-memory649-doctor');O=Path('/workspace/review-proof/memory649-main935-parent-integration')
refs={'original':'64b2c6aceaa0d1f7d1550d1398a5a70ec81aa7a0','remote809':'ab4f38d2c88e016be613f5a4b356601232832f8e','main':'9353520a34c5819c7d0a6cd58d3bfaa2b22b045b','memory803':'5a4f0464bc24efefa82e26068276fc747c5b1b11','source806':'d0b58ab03f77e847cd92862f0332f5ebc4952b44'}
def git(*args):return subprocess.check_output(['/usr/bin/git','-c','core.hooksPath=/dev/null','-c','core.fsmonitor=false',*args],cwd=R)
def sha(b):return hashlib.sha256(b).hexdigest()
def chosen(n):return '/' not in n or n.startswith(('rust/','scripts/','.github/','docs/')) or n in ['migration/contract-matrix.csv','migration/implementation-plan.md']
assert git('rev-parse','HEAD').decode().strip()==refs['original'] and not git('status','--porcelain','--untracked-files=all')
result={};payload={};physical=[]
for role,ref in refs.items():
 records=[]
 for row in git('ls-tree','-rz',ref).split(b'\0'):
  if not row:continue
  metadata,name=row.split(b'\t');mode,kind,oid=metadata.decode().split();assert kind=='blob';records.append(dict(path=name.decode(),mode=mode,git_object=oid))
 p=subprocess.Popen(['/usr/bin/git','cat-file','--batch'],cwd=R,stdin=subprocess.PIPE,stdout=subprocess.PIPE)
 for rec in records:
  p.stdin.write((rec['git_object']+'\n').encode());p.stdin.flush();header=p.stdout.readline().split();assert header[1]==b'blob';size=int(header[2]);raw=p.stdout.read(size);assert len(raw)==size and p.stdout.read(1)==b'\n';rec.update(bytes=size,sha256=sha(raw))
  if role=='original':
   path=R/rec['path']
   if path.exists() or path.is_symlink():
    meta=path.lstat();body=os.readlink(path).encode() if stat.S_ISLNK(meta.st_mode) else path.read_bytes();assert sha(body)==rec['sha256'],str(path)
    physical.append(dict(path=rec['path'],sha256=sha(body),bytes=len(body),native_metadata=dict(mode=meta.st_mode,uid=meta.st_uid,gid=meta.st_gid,mtime_ns=meta.st_mtime_ns)))
   if chosen(rec['path']):payload[rec['path']]=(raw,rec['mode'])
 p.stdin.close();assert p.wait()==0
 result[role]=dict(commit=ref,tree=git('rev-parse',ref+'^{tree}').decode().strip(),files=records)
raw=(json.dumps(dict(refs=result,original_physical=physical,scope='complete original and parent Git modes/bytes; no runtime'),indent=2)+'\n').encode();(O/'before-full-git-native-bindings.json.gz').write_bytes(gzip.compress(raw,mtime=0))
with tarfile.open(O/'original-scoped-source.tar.gz','w:gz') as archive:
 for name,(raw,mode) in payload.items():
  info=tarfile.TarInfo(name);info.size=len(raw);info.mode=int(mode,8)&0o777;info.mtime=0;archive.addfile(info,io.BytesIO(raw))
with tarfile.open(O/'original-scoped-source.tar.gz','r:gz') as archive:
 for item in archive:
  raw=archive.extractfile(item).read();assert raw==payload[item.name][0];assert item.mode==(int(payload[item.name][1],8)&0o777)
reviews=[]
for pattern in ['symaira-memory649-doctor-*review.md','symaira-memory649-doctor-*review.json','symaira-doctor806-llvm-env-independent-review*']:
 for path in sorted(Path('/tmp').glob(pattern)):
  if not path.is_file():continue
  raw=path.read_bytes();meta=path.stat();dest=O/(path.name+'.gz');dest.write_bytes(gzip.compress(raw,mtime=0));assert gzip.decompress(dest.read_bytes())==raw
  reviews.append(dict(original=str(path),retained=str(dest),bytes=len(raw),sha256=sha(raw),gzip_sha256=sha(dest.read_bytes()),native_metadata=dict(mode=meta.st_mode,uid=meta.st_uid,gid=meta.st_gid,mtime_ns=meta.st_mtime_ns)))
assert len(reviews)>=8
rec=dict(original=refs['original'],refs={k:v['commit'] for k,v in result.items()},full_git_counts={k:len(v['files']) for k,v in result.items()},original_physical_count=len(physical),scoped_source_files=len(payload),scoped_source_bytes=sum(len(v[0]) for v in payload.values()),source_archive_sha256=sha((O/'original-scoped-source.tar.gz').read_bytes()),complete_maps_sha256=sha((O/'before-full-git-native-bindings.json.gz').read_bytes()),reviews=reviews,no_runtime=True)
(O/'before-preservation-receipt.json').write_text(json.dumps(rec,indent=2)+'\n');print(json.dumps({k:v for k,v in rec.items() if k!='reviews'},indent=2))
