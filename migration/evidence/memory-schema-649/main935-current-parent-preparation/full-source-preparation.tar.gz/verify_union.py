"""Pure Git/AST/YAML owner and comparison-criteria verification."""
import ast,collections,csv,gzip,hashlib,json,os,stat,subprocess
from pathlib import Path
import yaml
R=Path('/workspace/symaira-memory649-main935-current-parents');O=Path('/workspace/review-proof/memory649-main935-parent-integration');BASE='64b2c6aceaa0d1f7d1550d1398a5a70ec81aa7a0';MAIN='9353520a34c5819c7d0a6cd58d3bfaa2b22b045b';MEM='5a4f0464bc24efefa82e26068276fc747c5b1b11';SRC='d0b58ab03f77e847cd92862f0332f5ebc4952b44'
def git(*a):return subprocess.check_output(['/usr/bin/git','-c','core.hooksPath=/dev/null','-c','core.fsmonitor=false',*a],cwd=R)
def tree(ref):return {row.split(b'\t',1)[1].decode():row.split(b'\t',1)[0].decode() for row in git('ls-tree','-rz',ref).split(b'\0') if row}
def raw(ref,name):return git('show',ref+':'+name)
def sha(b):return hashlib.sha256(b).hexdigest()
head=git('rev-parse','HEAD').decode().strip();maps={k:tree(v) for k,v in [('original',BASE),('main',MAIN),('memory',MEM),('source',SRC),('current',head)]};cur=maps['current'];changes=[]
for label,ref in [('original',BASE),('main',MAIN),('memory',MEM),('source',SRC)]:
 assert subprocess.run(['/usr/bin/git','merge-base','--is-ancestor',ref,head],cwd=R).returncode==0
 changes.append(dict(owner=label,missing=[n for n in maps[label] if n not in cur],changed=[n for n in maps[label] if n in cur and maps[label][n]!=cur[n]]))
schema=['rust/symbrain-memory/src/schema_inspection.rs','rust/symbrain-cli/src/doctor_memory.rs','rust/symbrain-cli/src/doctor_core.rs','rust/symbrain-cli/tests/doctor_memory_schema.rs','scripts/memory-schema-oracle/run.sh','scripts/memory-schema-oracle/replay.py','.github/workflows/memory-schema-native.yml']
for name in schema:assert cur[name]==maps['original'][name],name
memory_prefixes=('rust/symbrain-memory/','rust/symbrain-cli/src/memory','rust/symbrain-cli/tests/memory','scripts/memory-cli-oracle/','scripts/memory-historical-oracle/')
memowner=[n for n in maps['memory'] if n.startswith(memory_prefixes) or n=='.github/workflows/memory-cli-native.yml']
for n in memowner:
 if n=='rust/symbrain-memory/src/lib.rs':
  assert raw(head,n).replace(b'mod schema_inspection;\n',b'',1).replace(b'pub use schema_inspection::missing_required_columns;\n',b'',1)==raw(MEM,n)
 elif n=='rust/symbrain-cli/src/memory_cli/write_output.rs':assert cur[n]==maps['source'][n],n # Source owns shared actual stdout boundary.
 else:assert cur[n]==maps['memory'][n],n
sql=[n for n in memowner if n.startswith('rust/symbrain-memory/src/migration/sql/') and n.endswith('.sql')];assert len(sql)==37
srcowner=[n for n in maps['source'] if n.startswith(('rust/symbrain-managed/','rust/symbrain-core/','rust/symbrain-cli/src/setup','rust/symbrain-cli/tests/setup','rust/symbrain-cli/tests/source','rust/symbrain-cli/src/doctor','rust/symbrain-cli/tests/doctor','scripts/setup-','scripts/doctor-'))]
for n in srcowner:
 if n=='rust/symbrain-cli/src/doctor_core.rs':continue # Exact schema extraction retained from original reviewed increment.
 assert cur[n]==maps['source'][n],n
mainowner=[n for n in maps['main'] if n.startswith(('rust/symbrain-skills/','rust/symbrain-cli/src/skills','rust/symbrain-cli/tests/skills','scripts/skills-','rust/symbrain-core/src/config/format.rs','rust/symbrain-core/src/config/bytes_tests.rs','rust/symbrain-cli/src/activity','rust/symbrain-cli/tests/activity','scripts/activity-'))]
for n in mainowner:assert cur[n]==maps['main'][n],n
# Every parent CI setting/complete step retained. Reviewed changes only additive parity journaling and full-history checkout.
ci=yaml.safe_load(raw(head,'.github/workflows/ci.yml'));ci_checks=[]
for label,ref in [('original',BASE),('main',MAIN),('memory',MEM),('source',SRC)]:
 doc=yaml.safe_load(raw(ref,'.github/workflows/ci.yml'));projections=[]
 for k,v in doc.items():
  if k!='jobs':assert ci[k]==v,(label,k)
 for job,v in doc['jobs'].items():
  now=ci['jobs'][job]
  for k,val in v.items():
   if k!='steps':assert now[k]==val,(label,job,k)
  positions=[]
  for step in v['steps']:
   if label=='original' and job=='gui' and step.get('name')=='Patch project.yml for CI (replace local path dependency with pinned URL)':
    assert step not in now['steps']
    assert now==yaml.safe_load(raw(MAIN,'.github/workflows/ci.yml'))['jobs']['gui']
    projections.append(dict(job=job,original=step,current=None,owner='Main935 removes stale local-path rewrite'))
    continue
   candidates=[(i,s) for i,s in enumerate(now['steps']) if (s.get('name')==step.get('name') if 'name' in step else s.get('uses')==step.get('uses'))]
   exact=[(i,s) for i,s in candidates if s==step]
   if exact:i,s=exact[0]
   else:
    assert len(candidates)==1,(label,job,step);i,s=candidates[0]
    if step.get('uses','').startswith('actions/checkout@'):
     before=step.get('with',{});after=s.get('with',{});assert {k:v for k,v in before.items() if k!='fetch-depth'}=={k:v for k,v in after.items() if k!='fetch-depth'}
     assert before.get('fetch-depth') in (None,1,0) and after.get('fetch-depth')==0
     assert {k:v for k,v in step.items() if k!='with'}=={k:v for k,v in s.items() if k!='with'}
    elif step.get('name')=='Upload source setup parity and negative controls':
     assert s==next(x for x in yaml.safe_load(raw(SRC,'.github/workflows/ci.yml'))['jobs'][job]['steps'] if x.get('name')==step['name'])
     assert {k:v for k,v in step.items() if k!='with'}=={k:v for k,v in s.items() if k!='with'}
     assert {k:v for k,v in step['with'].items() if k!='path'}=={k:v for k,v in s['with'].items() if k!='path'}
     assert set(step['with']['path'].splitlines())<=set(s['with']['path'].splitlines())
    else:
     assert step.get('name') in ['Go/Rust executable parity on native Windows','Differential-test portable native Windows CLI cases']
     assert {k:v for k,v in step.items() if k!='env'}=={k:v for k,v in s.items() if k!='env'}
     assert all(s.get('env',{}).get(k)==v for k,v in step.get('env',{}).items())
     assert s.get('env',{})==next(x for x in yaml.safe_load(raw(MEM,'.github/workflows/ci.yml'))['jobs'][job]['steps'] if x.get('name')==step['name']).get('env',{})
    projections.append(dict(job=job,name=step.get('name',step.get('uses')),original=step,current=s))
   positions.append(i)
  assert positions==sorted(positions) and len(set(positions))==len(positions),(label,job,positions)
 ci_checks.append(dict(parent=label,all_complete_steps_retained_with_order=True,reviewed_setting_extensions=projections))
w=ci['jobs']['rust-migration-windows']['steps'];names=[s.get('name') for s in w if s.get('name')];assert len(names)==len(set(names))
assert next(s for s in w if s.get('name')=='Fetch the immutable native Skills comparison parent')['run']=='git fetch --no-tags origin 01f41906e2e021db3c693ec97617bb701e4dad8a'
for s in w:
 if s.get('uses','').startswith('actions/upload-artifact'):
  assert s.get('if')=='always()' and s['with']['if-no-files-found']=='error',s
# Matrix preserves each declared parent owner: schema original, Memory current, Skills/Activity main, Source current.
def matrix(ref):return {row.split(',',1)[0]:row for row in raw(ref,'migration/contract-matrix.csv').decode().splitlines()}
cm=matrix(head);matrix_checks={}
for role,ref,pred in [('schema',BASE,lambda k:k=='DB-005'),('memory',MEM,lambda k:k.startswith(('DB-','MEM-')) and k!='DB-005'),('skills_activity',MAIN,lambda k:k.startswith(('SKL-','ACT-'))),('source',SRC,lambda k:k.startswith(('SRC-','SET-OUT-')) or k=='SEC-007')]:
 for k,v in matrix(ref).items():
  if pred(k):assert cm[k]==v,(role,k);matrix_checks[k]=role
asts={}
for directory in ['scripts/memory-schema-oracle','scripts/memory-historical-oracle','scripts/skills-argv-oracle','scripts/setup-source-oracle','scripts/doctor-stdout-oracle']:
 for p in sorted((R/directory).glob('*.py')):ast.parse(p.read_bytes());asts[str(p.relative_to(R))]=len(p.read_text().splitlines())
assert all(x<400 for x in asts.values())
# Recompute every merged Git blob and materialized byte/mode, not selected source summaries alone.
records=[];physical=[]
p=subprocess.Popen(['/usr/bin/git','cat-file','--batch'],cwd=R,stdin=subprocess.PIPE,stdout=subprocess.PIPE)
for name,record in cur.items():
 mode,kind,oid=record.split();assert kind=='blob';p.stdin.write((oid+'\n').encode());p.stdin.flush();parts=p.stdout.readline().split();size=int(parts[2]);body=p.stdout.read(size);assert len(body)==size and p.stdout.read(1)==b'\n';value=dict(path=name,mode=mode,git_object=oid,bytes=size,sha256=sha(body));records.append(value)
 path=R/name
 if path.exists() or path.is_symlink():
  st=path.lstat();actual=os.readlink(path).encode() if stat.S_ISLNK(st.st_mode) else path.read_bytes();assert sha(actual)==value['sha256'];assert bool(st.st_mode&0o111)==(mode=='100755')
  physical.append(dict(**value,native_metadata=dict(mode=st.st_mode,uid=st.st_uid,gid=st.st_gid,mtime_ns=st.st_mtime_ns)))
p.stdin.close();assert p.wait()==0
full=json.dumps(dict(head=head,files=records,materialized=physical,owner_changes=changes),indent=2).encode();(O/'after-full-git-native-bindings.json.gz').write_bytes(gzip.compress(full,mtime=0))
summary=dict(source=head,normal_parent_ancestries=True,schema7_exact_original=True,memory_owner_files=len(memowner),SQL37_exact_parent=True,source_owner_files=len(srcowner),main_Skills_Activity_owner_files=len(mainowner),CI_full_parent_steps_order=ci_checks,Windows_steps=len(w),matrix_owner_rows=matrix_checks,Python_AST_under400=asts,full_current_Git=len(records),materialized_files=len(physical),materialized_bytes=sum(x['bytes'] for x in physical),prepared_runtime_executions=0,no_target_cache_port_access=True)
assert summary['materialized_bytes']<=20*1024*1024
(O/'source-owner-union.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps({k:v for k,v in summary.items() if k not in ['CI_full_parent_steps_order','Python_AST_under400','matrix_owner_rows']},indent=2))
