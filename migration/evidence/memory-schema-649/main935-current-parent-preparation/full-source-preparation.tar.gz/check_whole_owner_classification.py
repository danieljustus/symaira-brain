import gzip,json,subprocess
from pathlib import Path
R=Path('/workspace/symaira-memory649-main935-current-parents');O=Path('/workspace/review-proof/memory649-main935-parent-integration')
def git(*x):return subprocess.check_output(['/usr/bin/git',*x],cwd=R)
j=json.loads((O/'whole-tree-parent-owner-classification.json').read_bytes())
assert set(j['mixed_or_new_paths'])=={'.gitattributes','.github/workflows/ci.yml','MIGRATION-RUST.md','docs/adr/649-doctor-schema-inspection.md','docs/adr/649-main935-current-parent-integration.md','migration/contract-matrix.csv','rust/symbrain-memory/src/lib.rs'}
refs=json.loads(gzip.decompress((O/'before-full-git-native-bindings.json.gz').read_bytes()))['refs'];now=git('show','HEAD:.gitattributes').decode().splitlines()
attributes=[]
for role,v in refs.items():
 if role=='remote809':continue
 old=git('show',v['commit']+':.gitattributes').decode().splitlines();rules=[s for s in old if s and not s.startswith('#')];positions=[now.index(s) for s in rules];assert all(s in now for s in rules)
 attributes.append(dict(parent=role,rules=rules,current_positions=positions))
adr='docs/adr/649-doctor-schema-inspection.md';assert git('show','HEAD:'+adr).startswith(git('show',refs['original']['commit']+':'+adr))
assert git('show','HEAD:project.yml')==git('show',refs['main']['commit']+':project.yml')
# All parent Go implementation and immutable fixture paths retain a byte/mode selected parent; no Go author edit.
for row in j['files']:
 if row['path'].startswith(('internal/','cmd/','guard/')) or row['path'].endswith(('.go','.go.txt')):assert row['owners'],row
result=dict(source=j['source'],all_Git_files=len(j['files']),single_exact_parent_bodies=len(j['files'])-len(j['mixed_or_new_paths']),mixed_or_new7=j['mixed_or_new_paths'],parent_attributes=attributes,original_schema_ADR_full_prefix_preserved=True,main_GUI_project_exact=True,no_original_Go_author_changes=True)
(O/'whole-owner-classification-verified.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k!='parent_attributes'},indent=2))
