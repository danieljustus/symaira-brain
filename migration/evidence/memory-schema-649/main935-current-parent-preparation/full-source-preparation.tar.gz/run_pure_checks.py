"""Format/lint/syntax tools only; no Cargo/compiler/product/network child."""
import ast,hashlib,json,os,subprocess,time
from pathlib import Path
R=Path('/workspace/symaira-memory649-main935-current-parents');O=Path('/workspace/review-proof/memory649-main935-parent-integration');rows=[]
def run(name,argv):
 p=subprocess.run(argv,cwd=R,capture_output=True,timeout=90)
 for kind,b in [('stdout',p.stdout),('stderr',p.stderr)]: (O/(name+'.'+kind)).write_bytes(b)
 (O/(name+'.exit.json')).write_text(json.dumps(dict(argv=argv,exit=p.returncode),indent=2)+'\n')
 rows.append(dict(name=name,argv=argv,exit=p.returncode,stdout_sha256=hashlib.sha256(p.stdout).hexdigest(),stderr_sha256=hashlib.sha256(p.stderr).hexdigest()))
 return p.returncode
# Only inherited/current changed Rust files, separately checked with child formatting disabled.
names=subprocess.check_output(['/usr/bin/git','diff','--name-only','--diff-filter=ACM','64b2c6aceaa0d1f7d1550d1398a5a70ec81aa7a0','HEAD','--','rust'],cwd=R,text=True).splitlines();rust=[n for n in names if n.endswith('.rs')]
assert all((R/n).is_file() for n in rust)
assert run('rustfmt', ['/home/agent/.cargo/bin/rustfmt','--edition','2024','--check','--config','skip_children=true',*rust])==0
assert run('all-actionlint',['/workspace/toolchains/bin/actionlint','-color'])==0
for i,name in enumerate(['scripts/memory-schema-oracle/run.sh','scripts/setup-source-oracle/run.sh','scripts/doctor-stdout-oracle/run.sh','scripts/memory-historical-oracle/run.sh']):assert run('bash-syntax-'+str(i),['/bin/bash','-n',name])==0
# Preserve original historical whitespace observations, without rewriting evidence.
run('whole-historical-diff-check',['/usr/bin/git','diff','--check','64b2c6aceaa0d1f7d1550d1398a5a70ec81aa7a0','HEAD'])
sourcepaths=['.gitattributes','.github','rust','scripts','docs','migration/contract-matrix.csv','migration/implementation-plan.md','MIGRATION-RUST.md','Cargo.lock','Cargo.toml','project.yml']
assert run('source-diff-check',['/usr/bin/git','diff','--check','64b2c6aceaa0d1f7d1550d1398a5a70ec81aa7a0','HEAD','--',*sourcepaths])==0
py=[]
for p in sorted((R/'scripts').rglob('*.py')):ast.parse(p.read_bytes());py.append(str(p.relative_to(R)))
crit=[]
for name in ['scripts/memory-schema-oracle/replay.py','scripts/memory-schema-oracle/run.sh','rust/symbrain-cli/tests/doctor_memory_schema.rs','rust/symbrain-memory/src/schema_inspection.rs','rust/symbrain-cli/tests/doctor_fix_native.rs']:
 raw=(R/name).read_bytes();current=hashlib.sha256(raw).hexdigest();expected_ref='d0b58ab03f77e847cd92862f0332f5ebc4952b44' if name.endswith('doctor_fix_native.rs') else '64b2c6aceaa0d1f7d1550d1398a5a70ec81aa7a0';old=subprocess.check_output(['/usr/bin/git','show',expected_ref+':'+name],cwd=R);assert raw==old
 item=dict(path=name,owner=expected_ref,sha256=current,bytes=len(raw),full_body_unchanged=True)
 if name.endswith('.py'):item['assertions']=[ast.dump(x,include_attributes=False) for x in ast.walk(ast.parse(raw)) if isinstance(x,ast.Assert)]
 else:item['criterion_lines']=[dict(line=i+1,text=x) for i,x in enumerate(raw.decode().splitlines()) if 'assert' in x or 'LLVM_PROFILE_FILE' in x or 'timeout=' in x]
 crit.append(item)
(O/'full-criterion-map.json').write_text(json.dumps(crit,indent=2)+'\n')
result=dict(source=subprocess.check_output(['/usr/bin/git','rev-parse','HEAD'],cwd=R,text=True).strip(),format_only_Rust_files=len(rust),all_workflow_actionlint=True,syntax_shell4=True,Python_AST=len(py),checks=rows,criterion_files5_exact=True,SDK_compiler_Cargo_product_SQLite_Target_cache_ports_network=0)
(O/'pure-checks.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k!='checks'},indent=2))
