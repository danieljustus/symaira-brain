from pathlib import Path
import gzip,hashlib,json,subprocess,sys,tempfile
repo=Path('/workspace/symaira-guard770-config-paths');old=Path('/workspace/symaira-guard770-doctor-warnings');prefix='/tmp/symaira-guard770-config-paths-5bb-';GO='/tmp/symaira-guard770-config-paths-5bb-process-binaries/go'
selected=['retained-corpora','closure-extra','closure-audit-filesystem','closure-raw-paths','closure-raw-paths-unicode','novel','parent-new32','parent-mixed35','brain-extra']
rows=[]
for name in selected:
 original=Path('/tmp/symaira-guard770-warnings-independent-'+name+'.py');text=original.read_text();transforms=[]
 text=text.replace(str(old),str(repo));transforms.append('bind current worktree/unchanged original cases')
 text=text.replace('/tmp/symaira-guard770-warnings-clean-process-binaries/go',GO);transforms.append('use actually fresh retained Go executable')
 text=text.replace('/tmp/symaira-guard770-warnings-independent-',prefix+'previous-');transforms.append('retain new outputs without replacing original review')
 text=text.replace("'source':'fb2844b02b7c03b7c34650c6d3aed693c47b2997'","'source':'5bbd42774b73760731801ca148663350b9770b47'")
 if name=='brain-extra':
  text=text.replace('doctor_warnings-310215954a7227ca','doctor_warnings-310215954a7227ca')
 helper=Path(prefix+'previous-'+name+'.py');helper.write_text(text);log=Path(prefix+'previous-'+name+'.log')
 with log.open('wb') as stream:process=subprocess.run([sys.executable,str(helper)],cwd=repo,stdout=stream,stderr=subprocess.STDOUT)
 assert process.returncode==0,(name,log.read_text())
 rows.append(dict(id=name,original_helper=str(original),original_sha256=hashlib.sha256(original.read_bytes()).hexdigest(),helper=str(helper),helper_sha256=hashlib.sha256(helper.read_bytes()).hexdigest(),declared_adaptations=transforms,log=str(log),log_sha256=hashlib.sha256(log.read_bytes()).hexdigest(),exit=process.returncode))
 print('PASS',name,flush=True)
# Assertions are stronger than helpers that originally only printed classified rows.
for name,count,matched,gated in [('original80',80,80,0),('original94',94,92,2),('closure-extra',31,27,4),('parent-new32',32,32,0),('parent-mixed35',35,35,0)]:
 d=json.load(open(prefix+'previous-'+name+'.json'));assert d['total']==count and d['matched']==matched
 if 'gated' in d:assert d['gated']==gated and d['failed']==0
novel=json.load(open(prefix+'previous-novel.json'));assert novel['total']==28
for row in novel['results']:
 if row['id']=='novel-10':
  assert row['input_hex']=='6f776e65643d2b307837660a' and row['go']['exit_code']==1
  assert row['native']['exit_code']==1 and not row['native']['stdout_hex']
  assert bytes.fromhex(row['native']['stderr_hex'])==b'symguard doctor: unsupported native diagnostic state; no legacy fallback is available\n'
 else:assert row['disposition']=='matched'
classification=dict(original_current_report_sha256=hashlib.sha256(Path(prefix+'previous-novel.json').read_bytes()).hexdigest(),matched27=True,original_signed_hex_parser_gate_retained=True,no_new_exception=True,reference_original_classification='/tmp/symaira-guard770-warnings-independent-novel-classification.json')
Path(prefix+'previous-novel-classification.json').write_text(json.dumps(classification,indent=2)+'\n')
out=dict(source=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip(),candidate_clean=not subprocess.check_output(['git','status','--porcelain'],cwd=repo),rows=rows,all_original_case_bytes_preserved=True,fresh_bins={p:hashlib.sha256(Path(p).read_bytes()).hexdigest() for p in [GO,'/workspace/symaira-guard770-diagnostics/target/debug/symguard']},full_Brain_CLI_acceptance=False,novel28_signed_hex_prior_refusal_not_reclassified=True)
Path(prefix+'previous-gates.json').write_text(json.dumps(out,indent=2)+'\n')
