from pathlib import Path
import json,sys,subprocess,time,hashlib
repo=Path('/workspace/symaira-guard770-config-paths');sys.path.insert(0,str(repo/'scripts/guard-standalone-oracle'));import replay
GO=Path('/tmp/symaira-guard770-config-paths-5bb-process-binaries/go');NATIVE=Path('/tmp/symaira-guard770-config-paths-5bb-process-binaries/native');root=Path('/tmp/symaira-guard770-config-paths-5bb-history-parent-owner-state');root.mkdir();rows=[]
for index,mode in enumerate(['plain','xdg-dotdot','xdg-symlink-dotdot','home-symlink-dotdot','explicit-raw-symlink-dotdot']):
 pair={}
 for side,binary,native in [('go',GO,False),('native',NATIVE,True)]:
  owned=root/str(index)/side;env=replay.setup(owned,'empty');env.pop('SYMGUARD_CONFIG',None)
  (owned/'physical/anchor').mkdir(parents=True);(owned/'link').symlink_to(owned/'physical/anchor',target_is_directory=True)
  if mode=='home-symlink-dotdot':
   lexical=owned/'home/.config/symguard/config.toml';physical=owned/'physical/home/.config/symguard/config.toml';env.update(HOME=str(owned/'link/../home'),USERPROFILE=str(owned/'link/../home'));env.pop('XDG_CONFIG_HOME',None)
  else:
   lexical=owned/'cfg/symguard/config.toml';physical=owned/'physical/cfg/symguard/config.toml'
   xdg={'plain':str(owned/'cfg'),'xdg-dotdot':str(owned/'cfg/../cfg'),'xdg-symlink-dotdot':str(owned/'link/../cfg'),'explicit-raw-symlink-dotdot':str(owned/'link/../cfg')}[mode];env['XDG_CONFIG_HOME']=xdg
   if mode=='explicit-raw-symlink-dotdot':env['SYMGUARD_CONFIG']=xdg+'/symguard/config.toml'
  for p,key in [(lexical,'lexical_owner'),(physical,'physical_owner')]:p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes((key+'=1\n').encode())
  before={str(p.relative_to(owned)):(p.read_bytes().hex(),p.stat().st_mtime_ns,p.stat().st_mode) for p in owned.rglob('*') if p.is_file()}
  began=time.time();process=subprocess.run([str(binary),'doctor'],cwd=owned/'project',env=env,capture_output=True,timeout=5);ended=time.time()
  after={str(p.relative_to(owned)):(p.read_bytes().hex(),p.stat().st_mtime_ns,p.stat().st_mode) for p in owned.rglob('*') if p.is_file()};assert before==after
  pair[side]=dict(exit_code=process.returncode,stdout_hex=process.stdout.hex(),stderr_hex=process.stderr.hex(),normalized_stdout_hex=replay.normalized_stream(process.stdout,owned,['doctor'],native,True).hex(),normalized_stderr_hex=replay.normalized_stream(process.stderr,owned,['doctor'],native,False).hex(),files=replay.state_files(owned,began,ended,False),read_only=True,config_env={k:v for k,v in env.items() if k in ['HOME','USERPROFILE','XDG_CONFIG_HOME','SYMGUARD_CONFIG']})
 rows.append(dict(id=mode,matched=replay.comparable(pair['go'])==replay.comparable(pair['native']),**pair))
report=dict(head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip(),source='5bbd42774b73760731801ca148663350b9770b47',candidate_dirty=bool(subprocess.check_output(['git','status','--porcelain'],cwd=repo)),binary_sha256={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in [GO,NATIVE]},results=rows)
Path('/tmp/symaira-guard770-config-paths-5bb-history-parent-owner.json').write_text(json.dumps(report,indent=2)+'\n')
for r in rows:print(r['id'],r['matched'],[(s,bytes.fromhex(r[s]['normalized_stderr_hex']).decode()) for s in ['go','native']])
