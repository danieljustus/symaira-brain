import gzip,hashlib,io,json,os,re,subprocess,sys,tarfile
from pathlib import Path
repo=Path('/workspace/symaira-guard770-config-paths')
source='5bbd42774b73760731801ca148663350b9770b47'
oracle='dcddcef0df5789123c7c9a7ebe6e01f10e941f2c'
sha=lambda raw:hashlib.sha256(raw).hexdigest()
def git(*args):return subprocess.check_output(['git',*args],cwd=repo)
assert git('rev-parse','HEAD').decode().strip()==source and not git('status','--porcelain')
for ref in ['4d78b6e52c53d1c273126b0dac3c554915a15438','2b6d49f250a81650eda1b93cec7d859a171873bb']:
 subprocess.run(['git','merge-base','--is-ancestor',ref,source],cwd=repo,check=True)
old=Path('/workspace/symaira-guard770-doctor-warnings')
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=old,text=True).strip()=='4d78b6e52c53d1c273126b0dac3c554915a15438'
assert not subprocess.check_output(['git','status','--porcelain'],cwd=old)
ret=repo/'migration/evidence/guard-doctor-config-paths-770/independent-4d78'
r=json.loads((ret/'retention.json').read_bytes())
assert r['review_files']==92 and r['extra_original_receipts']==2
for item in r['records']:
 raw=Path(item['original']).read_bytes();packed=(ret/item['retained']).read_bytes()
 assert sha(raw)==item['sha256'] and len(raw)==item['bytes'] and gzip.decompress(packed)==raw and sha(packed)==item['gzip_sha256']
states=json.loads((ret/'raw-state-retention.json').read_bytes());assert len(states)==180
for item in states:
 p=Path(item['path']);st=p.lstat()
 if item['kind']=='symlink':assert os.readlink(p)==item['target']
 else:
  raw=p.read_bytes();assert sha(raw)==item['sha256'] and st.st_mode==item['mode'] and st.st_mtime_ns==item['mtime_ns'] and gzip.decompress((ret/item['blob']).read_bytes())==raw
archives=[]
for label,path,live in [
 ('original4d',r['elf_archive'],False),
 ('failed221','/workspace/oracles/symaira-guard770-config-paths-221-first-binaries/receipt.json',False),
 ('intermediate9e9','/workspace/oracles/symaira-guard770-config-paths-9e9-binaries/receipt.json',False),
 ('intermediate3d','/workspace/oracles/symaira-guard770-config-paths-3d-binaries/receipt.json',False),
 ('final5bb','/workspace/oracles/symaira-guard770-config-paths-5bb-binaries/receipt.json',True)]:
 p=Path(path);e=json.loads(p.read_bytes())
 unique=e.get('unique',{item['sha256']:item for item in e['records']})
 for digest,item in unique.items():
  packed=Path(item['archive']).read_bytes();raw=gzip.decompress(packed)
  assert sha(packed)==item['archive_sha256'] and sha(raw)==digest and len(raw)==item['bytes']
 for item in e['records']:
  assert item['sha256'] in unique and item['bytes']==unique[item['sha256']]['bytes']
  if live:assert sha(Path(item['path']).read_bytes())==item['sha256']
 archives.append(dict(label=label,path=path,receipt_sha256=sha(p.read_bytes()),head=e.get('head'),paths=len(e['records']),unique=len(unique),live_paths_verified=live))
assert (archives[0]['paths'],archives[0]['unique'])==(69,46)
names=git('ls-files').decode().splitlines();source_map={}
for name in names:
 if (name.startswith(('rust/symguard-cli/','rust/symbrain-core/','rust/symbrain-audit/','rust/symbrain-guard-core/')) and name.endswith(('.rs','.toml'))) or name.startswith('scripts/guard-standalone-oracle/') or name in ['Cargo.toml','Cargo.lock','.github/workflows/ci.yml','rust/symbrain-cli/src/guard_cli.rs','docs/adr/guard-generated-config-path-ownership.md','migration/contract-matrix.csv','migration/implementation-plan.md']:
  raw=(repo/name).read_bytes();assert raw==git('show',source+':'+name);source_map[name]=sha(raw)
protected=['rust/symbrain-core','rust/symbrain-audit','rust/symbrain-guard-core','rust/symbrain-cli/src/guard_cli.rs','Cargo.toml','Cargo.lock','guard','cmd','internal','go.mod','go.sum','rust/symguard-cli/src/guard_doctor.rs','rust/symguard-cli/src/doctor/config_decode.rs','rust/symguard-cli/src/doctor/config_warnings.rs']
for prefix in protected:assert not git('diff','fb2844b02b7c03b7c34650c6d3aed693c47b2997',source,'--',prefix),prefix
sdkmap=json.loads((repo/'scripts/guard-standalone-oracle/windows-sdk-source.json').read_bytes())
for name,digest in sdkmap.items():assert sha((Path('/workspace/toolchains/go1.26.7')/name).read_bytes())==digest
original=git('show','fb2844b02b7c03b7c34650c6d3aed693c47b2997:rust/symguard-cli/src/guard_scan.rs').decode()
original_body=original[original.index('    let mut result = PathBuf::new();'):original.index('\nfn view(server:')].strip()
new=(repo/'rust/symguard-cli/src/guard_paths.rs').read_text();assert original_body==new[new.index('    let mut result = PathBuf::new();'):].strip()
for name in ['guard_scan.rs','guard_paths.rs','guard_path_windows.rs','doctor/config.rs']:assert len((repo/'rust/symguard-cli/src'/name).read_text().splitlines())<400
prefix=Path('/tmp/symaira-guard770-config-paths-5bb-process')
process=json.loads(prefix.with_suffix('.json').read_bytes());assert process['candidate_head']==source and not process['candidate_dirty']
assert len(process['go_source_sha256'])==1217
with tarfile.open(fileobj=io.BytesIO(git('archive',oracle))) as tar:
 files={m.name:sha(tar.extractfile(m).read()) for m in tar if m.isfile()}
for name,digest in process['go_source_sha256'].items():assert files[name]==digest==sha((Path('/workspace/oracles/daemon772-go-source')/name).read_bytes())
for name in ['go.mod','go.sum','browse/go.mod','browse/go.sum']:assert sha((Path('/workspace/oracles/daemon772-go-source')/name).read_bytes())==files[name]
for field in ['candidate_source_sha256','candidate_manifest_sha256']:
 for name,digest in process[field].items():assert source_map.get(name,sha((repo/name).read_bytes()))==digest==sha(git('show',source+':'+name))
assert process['supplemental_go_entry_sha256']==sha((repo/'scripts/guard-standalone-oracle/main.go.txt').read_bytes())
bins=json.loads(Path(str(prefix)+'-binaries/receipt.json').read_bytes())
for item in bins['records']:assert sha(Path(item['retained']).read_bytes())==item['sha256'] and len(Path(item['retained']).read_bytes())==item['bytes']
actual_bins={item['role']:item['sha256'] for item in bins['records']}
assert actual_bins==dict(go=process['binaries_sha256']['go'],native=process['binaries_sha256']['rust'])
reports={}
for suffix in ['', '-raw-paths','-doctor-boundaries','-config-warnings','-config-paths','-windows-path-reference']:
 p=Path(str(prefix)+suffix+'.json');a=json.loads(p.read_bytes());assert a['candidate_head']==source and not a['candidate_dirty']
 for field in ['source_sha256','candidate_source_sha256','candidate_manifest_sha256']:
  for name,digest in a.get(field,{}).items():assert sha((repo/name).read_bytes())==digest
 if 'binaries_sha256' in a:
  assert a['binaries_sha256']['go']==actual_bins['go'];assert a['binaries_sha256'].get('rust',a['binaries_sha256'].get('native'))==actual_bins['native']
 reports[suffix or 'current124']=dict(path=str(p),sha256=sha(p.read_bytes()),total=a.get('total'),matched=a.get('matched'),gated=a.get('gated'),controls=len(a.get('controls',[])))
for suffix in ['-raw-paths','-doctor-boundaries','-config-warnings','-config-paths']:
 a=json.loads(Path(str(prefix)+suffix+'.json').read_bytes());assert all(c['rejected'] for c in a['controls'])
controls=json.loads(Path(str(prefix)+'-controls.json').read_bytes());assert all(c['rejected'] for c in controls['controls'])
before_path=repo/'migration/evidence/guard-doctor-config-paths-770/before-442a/symaira-guard770-config-paths-before-corrected-process.json.gz'
before=json.loads(gzip.decompress(before_path.read_bytes()));after=json.loads(Path(str(prefix)+'-config-paths.json').read_bytes());assert len(before['results'])==len(after['results'])==25
def normalized_env(o):
 home=bytes.fromhex(o['config_environment_bytes']['HOME'])
 # The isolated root precedes /home or the deliberately raw HOME base.
 roots=[bytes.fromhex(v) for v in o['config_environment_bytes'].values()]
 root=os.fsencode(o['input_state_metadata']['link'][1].split('/physical/')[0])
 return {k:bytes.fromhex(v).replace(root,b'<root>').hex() for k,v in o['config_environment_bytes'].items()}
def input_metadata(o):
 out={}
 for k,v in o['input_state_metadata'].items():
  if v[0]=='symlink':out[k]=['symlink',v[1].split('/physical/')[1]]
  else:out[k]=v[:2] # mtime is independently retained and checked per execution.
 return out
accounting=[]
for old_case,new_case in zip(before['results'],after['results']):
 for key in ['id','family','spelling','contract','explicit','raw','state','empty_xdg']:assert old_case.get(key)==new_case.get(key)
 for side in ['go','native']:
  left,right=old_case[side],new_case[side];assert left['readonly'] and right['readonly']
  for key in ['lexical_input_hex','physical_input_hex']:assert left[key]==right[key]
  assert normalized_env(left)==normalized_env(right),old_case['id']
  assert input_metadata(left)==input_metadata(right)
 assert old_case['go']['exit_code']==new_case['go']['exit_code']
 assert old_case['go']['normalized_stdout_hex']==new_case['go']['normalized_stdout_hex']
 assert old_case['go']['normalized_stderr_hex']==new_case['go']['normalized_stderr_hex']
 assert not new_case['disposition'].startswith('failed')
 accounting.append(dict(id=old_case['id'],original_disposition=old_case['disposition'],final_disposition=new_case['disposition'],same_input_environment_spelling_and_state=True,readonly_before_and_after=True,actual_original_failed=old_case['disposition'].startswith('failed')))
assert sum(a['actual_original_failed'] for a in accounting)==15
Path('/tmp/symaira-guard770-config-paths-5bb-case-accounting.json').write_text(json.dumps(dict(source=source,original_report_sha256=sha(gzip.decompress(before_path.read_bytes())),final_report_sha256=sha(Path(str(prefix)+'-config-paths.json').read_bytes()),rows=accounting,original25_all_accounted=True,original15_failed_now13_full_and2_typed_empty_stream_refusals=True,only_owned_root_and_execution_mtime_differ=True),indent=2)+'\n')
nd=repo/'migration/evidence/guard-doctor-boundaries-770/baseline-8e3/symaira-guard770-doctor-boundary-inventory.json.gz'
assert nd.read_bytes()==git('show','1c04ad92f9537d5b4d552d080433635c5f0c5403:'+str(nd.relative_to(repo)))
d=json.loads(gzip.decompress(nd.read_bytes()));assert len(d['repeated_invalid_defaults'])==50 and d['distinct_invalid_default_reports']==2
sys.path.insert(0,str(repo/'scripts/guard-standalone-oracle'));import config_warnings
baseline=json.loads(gzip.decompress((repo/'migration/evidence/guard-doctor-warnings-770/baseline-1c04/symaira-brain769-positive-slice-probe.json.gz').read_bytes()))
original_cases=[c for c in config_warnings.cases() if c.get('original')];assert len(original_cases)==14
byid={c['id']:c for c in baseline['cases']}
for c in original_cases:assert c['data']==byid[c['id']]['input_utf8'].encode()
assert len(baseline['unknown_warning_repeat']['runs'])==10
fresh=json.loads(Path(str(prefix)+'-config-warnings.json').read_bytes());assert len(fresh['repeated_go_runs'])==10
wr=json.loads(Path(str(prefix)+'-windows-path-reference.json').read_bytes());assert (wr['total'],wr['matched'],wr['sdk_own_clean_cases'],wr['native_windows_runtime_proof'])==(386,386,34,False)
for item in wr['artifacts']:
 raw=gzip.decompress(Path(item['retained']).read_bytes());assert sha(raw)==item['sha256'] and len(raw)==item['bytes']
test_roles=[]
for stem,expected in [('tests',177),('kernel-tests',41)]:
 p=Path('/tmp/symaira-guard770-config-paths-5bb-'+stem+'.log');text=p.read_text();summaries=re.findall(r'test result: ok\. (\d+) passed; 0 failed; 0 ignored;',text);assert sum(map(int,summaries))==expected
 paths=re.findall(r'Running [^\n]+ \(([^\n]+)\)',text);assert len(paths)==len(summaries)
 for path in paths:test_roles.append(dict(role=stem,path=path,sha256=sha(Path(path).read_bytes())))
target=Path('/workspace/symaira-guard770-diagnostics/target');users=[]
for p in Path('/proc').iterdir():
 if not p.name.isdigit():continue
 for kind in ['exe','cwd','fd']:
  for probe in ([p/kind] if kind!='fd' else list((p/kind).glob('*'))):
   try:value=os.readlink(probe)
   except OSError:continue
   if value==str(target) or value.startswith(str(target)+'/'):users.append(dict(pid=p.name,kind=kind,path=value))
assert not users,users
out=dict(source=source,clean=True,source_sha256=source_map,frozen_go_ref=oracle,frozen_go_sha256=process['go_source_sha256'],frozen_module_files4_verified=True,pinned_sdk_sha256=sdkmap,protected_source_unchanged=protected,unix_helper_body_unchanged=True,original92_plus2_proofs_verified=True,original180_state_paths_verified=True,original50_two_reports_unchanged=True,original14_input_bytes_and10_repeats_unchanged=True,current_warning10_runs=fresh['repeated_distinct_stderr'],archives=archives,actual_main_binaries=actual_bins,ordinary177_binaries15_and_kernel41_overlapping_binaries7=test_roles,reports=reports,old_actual_mutants13=True,new_actual_owner_mutant1=True,config_path25_mapping='symaira-guard770-config-paths-5bb-case-accounting.json',target=str(target),target_users=users,native_windows_runtime_proof=False,independent_review_and_native_three_os_pending=True)
Path('/tmp/symaira-guard770-config-paths-5bb-source-verification.json').write_text(json.dumps(out,indent=2)+'\n')
print('PASS final source',len(source_map),'frozen1217/module4/SDK7; original92+2/state180/50+14; currentELF67/45; tests177+overlapping41; original25 mapping including15failures')
