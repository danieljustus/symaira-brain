import gzip,hashlib,json,re
from pathlib import Path
sha=lambda raw:hashlib.sha256(raw).hexdigest()
base=Path('/workspace/oracles/symaira-guard770-config-paths-5bb-binaries')
a=json.loads((base/'receipt.json').read_bytes());records=list(a['records']);unique=dict(a['unique'])
main=json.load(open('/tmp/symaira-guard770-config-paths-5bb-process-binaries/receipt.json'))
for row in main['records']:
 p=Path(row['retained']);raw=p.read_bytes();digest=sha(raw);packed=gzip.compress(raw,mtime=0);archive=base/(digest+'.gz')
 if digest not in unique:
  archive.write_bytes(packed);unique[digest]=dict(archive=str(archive),sha256=digest,bytes=len(raw),archive_sha256=sha(packed))
 assert sha(raw)==row['sha256'] and gzip.decompress(Path(unique[digest]['archive']).read_bytes())==raw
 records.append(dict(path=str(p),role='actual-public-'+row['role'],sha256=digest,bytes=len(raw)))
win=json.load(open('/tmp/symaira-guard770-config-paths-5bb-process-windows-path-reference.json'))
for row in win['artifacts']:
 if row['original'].endswith(('main.go','main.rs')):continue
 packed=Path(row['retained']).read_bytes();raw=gzip.decompress(packed);digest=sha(raw);assert digest==row['sha256'] and raw.startswith(b'\x7fELF')
 unique[digest]=dict(archive=row['retained'],sha256=digest,bytes=len(raw),archive_sha256=sha(packed))
 records.append(dict(path=row['original'],retained_archive=row['retained'],role='actual-portable-source-reference-probe-not-Windows-runtime',sha256=digest,bytes=len(raw),original_temporary_path_removed=True))
executed=[]
for group,count in [('tests',177),('kernel-tests',41)]:
 p=Path('/tmp/symaira-guard770-config-paths-5bb-'+group+'.log')
 for name in re.findall(r'Running [^\n]+ \(([^\n]+)\)',p.read_text()):
  r=next(r for r in records if r['path']==name);executed.append(dict(path=name,role=group,sha256=r['sha256']))
for row in records:
 row['executed_final_gate_roles']=[x['role'] for x in executed if x['path']==row['path']]
for digest,row in unique.items():
 raw=gzip.decompress(Path(row['archive']).read_bytes());assert sha(raw)==digest and len(raw)==row['bytes'] and sha(Path(row['archive']).read_bytes())==row['archive_sha256']
out=dict(source=a['head'],target=a['target'],records=records,unique=unique,total_ELF_paths=len(records),unique_ELF_bytes=len(unique),ordinary_tests177_executed_binaries15=len([x for x in executed if x['role']=='tests']),kernel_tests41_overlapping_executed_binaries7=len([x for x in executed if x['role']=='kernel-tests']),executed_test_roles=executed,cached_inactive_ELFs_not_executed=True,portable_SDK_reference_not_native_Windows_proof=True,roundtrip_all_bytes_verified=True)
(base/'complete-receipt.json').write_text(json.dumps(out,indent=2)+'\n')
print('PASS',len(records),'ELF mappings /',len(unique),'unique /',len(executed),'executed test roles / actualGo+nativeCLI+twoSDKportableprobes')
