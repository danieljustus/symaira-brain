from pathlib import Path
import hashlib,json,re,subprocess,sys
repo=Path('/workspace/symaira-guard770-config-paths');prefix='/tmp/symaira-guard770-config-paths-5bb-history-'
sha=lambda raw:hashlib.sha256(raw).hexdigest()
rows=[]
for role in ['owner','owner-semantic','parent-owner','parent-known-owner','fresh-owner','fresh-owner-semantic']:
 original=Path('/tmp/symaira-guard770-warnings-independent-'+role+'.py');body=original.read_text()
 body=body.replace('/workspace/symaira-guard770-doctor-warnings',str(repo))
 body=re.sub(r"GO=Path\('[^']+'\);NATIVE=Path\('[^']+'\)","GO=Path('/tmp/symaira-guard770-config-paths-5bb-process-binaries/go');NATIVE=Path('/tmp/symaira-guard770-config-paths-5bb-process-binaries/native')",body)
 body=body.replace('/tmp/symaira-guard770-warnings-independent-'+role,prefix+role)
 body=body.replace("source='fb2844b02b7c03b7c34650c6d3aed693c47b2997'","source='5bbd42774b73760731801ca148663350b9770b47'")
 helper=Path(prefix+role+'.py');helper.write_text(body)
 log=Path(prefix+role+'.log')
 with log.open('wb') as output:result=subprocess.run([sys.executable,str(helper)],cwd=repo,stdout=output,stderr=subprocess.STDOUT)
 assert result.returncode==0,role
 report=Path(prefix+role+'.json');output=json.loads(report.read_bytes());assert len(output['results'])==5 and all(c['matched'] for c in output['results'])
 rows.append(dict(role=role,original_helper=str(original),original_helper_sha256=sha(original.read_bytes()),adapted_helper=str(helper),helper_sha256=sha(helper.read_bytes()),report=str(report),report_sha256=sha(report.read_bytes()),log=str(log),log_sha256=sha(log.read_bytes()),same_original_five_inputs=True,current_matches=5,source='5bbd42774b73760731801ca148663350b9770b47',declared_adaptations=['current repo and retained fresh executable pair','new private state/report/log paths','source identity field only; original case/state construction and comparator unchanged']))
 print('PASS actual original',role,'5/5')
Path(prefix+'receipt.json').write_text(json.dumps(dict(source='5bbd42774b73760731801ca148663350b9770b47',original20_plus_later10_owner_pairs_replayed=True,current_all30_full_matches=True,original_parent_comparisons_preserved_not_relabelled= True,rows=rows),indent=2)+'\n')
