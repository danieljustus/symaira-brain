import gzip,hashlib,json,subprocess,sys
from pathlib import Path
repo=Path('/workspace/symaira-guard770-config-paths');head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip();out=Path(sys.argv[1]);out.mkdir(exist_ok=False);known={}
for p in ['/workspace/oracles/symaira-guard770-warnings-independent-4d-binaries/receipt.json','/workspace/oracles/symaira-guard770-config-paths-9e9-binaries/receipt.json']:
 known.update(json.load(open(p))['unique'])
records=[];unique={};sha=lambda raw:hashlib.sha256(raw).hexdigest()
for p in sorted(Path('/workspace/symaira-guard770-diagnostics/target').rglob('*')):
 if not p.is_file():continue
 with p.open('rb') as f:magic=f.read(4)
 if magic!=b'\x7fELF':continue
 raw=p.read_bytes();digest=sha(raw);archive=Path(known[digest]['archive']) if digest in known else out/(digest+'.gz')
 if not archive.exists():archive.write_bytes(gzip.compress(raw,mtime=0))
 packed=archive.read_bytes();assert gzip.decompress(packed)==raw
 unique[digest]=dict(archive=str(archive),sha256=digest,bytes=len(raw),archive_sha256=sha(packed));records.append(dict(path=str(p),sha256=digest,bytes=len(raw)))
(out/'receipt.json').write_text(json.dumps(dict(head=head,current_source=head,target='/workspace/symaira-guard770-diagnostics/target',records=records,unique=unique,roundtrip_verified=True,cached_inactive_binaries_are_not_all_executed=True),indent=2)+'\n')
print(len(records),'ELF mappings/',len(unique),'unique bytes verified')
