import gzip,hashlib,json,os,subprocess
from pathlib import Path
repo=Path('/workspace/symaira-guard770-config-paths');out=repo/'migration/evidence/guard-doctor-config-paths-770/final-5bb';out.mkdir(exist_ok=False)
sha=lambda raw:hashlib.sha256(raw).hexdigest()
paths=list(Path('/tmp').glob('symaira-guard770-config-paths-5bb*'))
paths+=[Path('/tmp/symaira-guard770-config-paths-final-check.py'),Path('/tmp/symaira-guard770-config-paths-archive-elf.py'),Path('/tmp/symaira-guard770-config-paths-previous-gates.py')]
paths+=[Path('/workspace/oracles/symaira-guard770-config-paths-5bb-binaries')/n for n in ['receipt.json','complete-receipt.json']]
records=[];destinations=set()
for p in sorted(set(paths)):
 if p.is_dir():continue
 raw=p.read_bytes();name=p.name
 if p.parent.name=='symaira-guard770-config-paths-5bb-binaries':name='archive-'+name
 assert name not in destinations,name;destinations.add(name)
 packed=gzip.compress(raw,mtime=0);dest=name+'.gz';(out/dest).write_bytes(packed)
 assert gzip.decompress((out/dest).read_bytes())==raw
 records.append(dict(original=str(p),retained=dest,bytes=len(raw),sha256=sha(raw),gzip_sha256=sha(packed)))
for p in sorted(Path('/tmp/symaira-guard770-config-paths-5bb-process-windows-path-reference-artifacts').iterdir()):
 packed=p.read_bytes();raw=gzip.decompress(packed);name='sdk-'+p.name;(out/name).write_bytes(packed)
 records.append(dict(original=str(p),retained=name,bytes=len(raw),sha256=sha(raw),gzip_sha256=sha(packed),original_is_gzip=True))
for p in sorted(Path('/tmp/symaira-guard770-config-paths-5bb-process-binaries').iterdir()):
 raw=p.read_bytes();packed=gzip.compress(raw,mtime=0);name='actual-'+p.name+'.gz';(out/name).write_bytes(packed)
 records.append(dict(original=str(p),retained=name,bytes=len(raw),sha256=sha(raw),gzip_sha256=sha(packed)))
state=[]
for root in sorted(Path('/tmp').glob('symaira-guard770-config-paths-5bb-history-*-state')):
 for p in sorted(root.rglob('*')):
  st=p.lstat()
  if p.is_symlink():state.append(dict(path=str(p),kind='symlink',target=os.readlink(p)))
  elif p.is_file():
   raw=p.read_bytes();digest=sha(raw);dest='state-'+digest+'.gz'
   if not (out/dest).exists():(out/dest).write_bytes(gzip.compress(raw,mtime=0))
   assert gzip.decompress((out/dest).read_bytes())==raw
   state.append(dict(path=str(p),kind='file',bytes=len(raw),sha256=digest,mode=st.st_mode,mtime_ns=st.st_mtime_ns,blob=dest))
(out/'raw-owner-state-retention.json').write_text(json.dumps(state,indent=2)+'\n')
intermediate=json.load(open('/workspace/oracles/symaira-guard770-config-paths-9e9-binaries/receipt.json'))
correction=dict(original_receipt='/workspace/oracles/symaira-guard770-config-paths-9e9-binaries/receipt.json',original_receipt_sha256=sha(Path('/workspace/oracles/symaira-guard770-config-paths-9e9-binaries/receipt.json').read_bytes()),original_source_field=intermediate.get('source'),authoritative_head=intermediate['head'],correction='The preserved source field contains an imprecise shorthand. Its exact full head field is authoritative; original metadata/bytes are unchanged.',not_new_test_evidence=True)
(out/'historical-archive-source-metadata-correction.json').write_text(json.dumps(correction,indent=2)+'\n')
summary=json.load(open('/tmp/symaira-guard770-config-paths-5bb-source-verification.json'))
complete=json.load(open('/workspace/oracles/symaira-guard770-config-paths-5bb-binaries/complete-receipt.json'))
summary.update(retention=records,raw_current_owner_paths=len(state),raw_state_metadata='raw-owner-state-retention.json',actual_ELF_total71_unique48=dict(receipt='/workspace/oracles/symaira-guard770-config-paths-5bb-binaries/complete-receipt.json',receipt_sha256=sha(Path('/workspace/oracles/symaira-guard770-config-paths-5bb-binaries/complete-receipt.json').read_bytes()),paths=complete['total_ELF_paths'],unique=complete['unique_ELF_bytes']),author_validation_not_independent_approval=True,future_native_three_platform_protected_checks_required=True,docs_evidence_only_successor_will_not_change_runtime_source=True)
(out/'validation.json').write_text(json.dumps(summary,indent=2)+'\n')
print('PASS retained',len(records),'final raw proofs/drivers/logs/actual public and SDK binaries;',len(state),'current owner file/link states; ELF71/48 receipt; immutable originals separately retained')
