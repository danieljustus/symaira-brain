from pathlib import Path
import json,sys,subprocess,tempfile,hashlib
repo=Path('/workspace/symaira-guard770-config-paths');sys.path.insert(0,str(repo/'scripts/guard-standalone-oracle'));import config_warnings as warning
GO=Path('/tmp/symaira-guard770-config-paths-5bb-process-binaries/go');NATIVE=Path('/workspace/symaira-guard770-diagnostics/target/debug/symguard')
texts=[
'owned={x.y=1,x.z=2}\n',
'owned={x.y=[{a.b=1},{a.c=2}],x.z={q=1}}\n',
'[[owned]]\nx={y=1}\n[[owned.child]]\nz=2\n[[owned]]\nx={y=3}\n[[owned.child]]\nz=4\n',
'[owned.deep.first]\nx=1\n[owned.deep.second]\nx=2\n[owned.deep]\nx=3\n[owned]\nx=4\n',
'owned=[{x={y=1}},{x=[{y=2},{y=3}]}]\n',
'"a.b"={"c.d"={"e.f"=1}}\n',
'"rules.match.server"=1\n"defaults.custom"="allow"\n',
'owned={defaults={custom="allow"},rules=[{match={server="x"}}]}\n',
'owned=[nan,+inf,-inf,1979-05-27,07:32:00]\n',
'owned="""multiline\ntext\n"""\nowned2="\\u2028"\n',
'owned=+0x7f\n',
'z={y=1,x=2}\naudit={owned=[{z=1},{y=2}]}\n',
'proxy={upstream="",unknown={Upstream=1}}\n',
'spawn={allowlist=[] ,unknown={path=1}}\n',
'rules=[{decision="allow",match={server="x",unknown={capability=1}},extra={match={tool=2}}}]\n',
'remote=[{name="a",owned={name=1}},{name="b",owned={name=2}}]\n',
'owned=1\nsequence={enabled=false,threshold=-9223372036854775808,extra=1}\n',
'owned=1\nsequence={enabled=true,threshold=0,extra=1}\n',
'owned=1\nsequence={enabled=true,threshold=-9223372036854775808,extra=1}\n',
'owned=1\ndefaults={"weird.key"="bad"}\n',
]
for key in ['\\u0000','\\u000b','\\u001b','\\u00ad','\\u0378','\\u202f','\\u2066','\\U0001f4a9']:
 texts.append('"owned'+key+'"=1\n')
rows=[]
with tempfile.TemporaryDirectory(prefix='guard770-novel-warning-') as raw:
 root=Path(raw)
 for i,text in enumerate(texts):
  case=dict(id='novel-'+str(i),data=text.encode(),contract='parity');left=warning.observe(GO,case,root/str(i)/'go',False);right=warning.observe(NATIVE,case,root/str(i)/'native',True)
  try:disposition=warning.compare(case,left,right)
  except AssertionError as e:disposition='failed: '+str(e)
  rows.append(dict(id=case['id'],input_hex=case['data'].hex(),disposition=disposition,go=left,native=right))
r=dict(head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip(),candidate_dirty=bool(subprocess.check_output(['git','status','--porcelain'],cwd=repo)),binaries={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in [GO,NATIVE]},total=len(rows),results=rows)
Path('/tmp/symaira-guard770-config-paths-5bb-previous-novel.json').write_text(json.dumps(r,indent=2)+'\n')
print([(x['id'],x['disposition'],x['go']['exit_code'],x['native']['exit_code']) for x in rows]);print('mismatches',[(x['id'],bytes.fromhex(x['input_hex']).decode()) for x in rows if x['disposition']!='matched'])
