# Independent full Guard Doctor warning review

Candidate clean HEAD `4d78b6e52c53d1c273126b0dac3c554915a15438`; immutable validation source `fb2844b02b7c03b7c34650c6d3aed693c47b2997`, approved normal parent `1c04ad92f9537d5b4d552d080433635c5f0c5403`. Independent reviewer is not the author. No source, frozen Go, fixture, GitHub or published parent edits.

Disposition: **REQUEST CHANGES for one grouped P2**. All required independent process, ordinary/kernel, strict and static gates have completed.

## [P2] Apply Go lexical joining to generated config paths before warning admission

At `rust/symguard-cli/src/doctor/config.rs:22` and `:25`, native generated XDG/HOME configuration paths use OS `PathBuf::join` without Go `filepath.Join`'s lexical cleaning. The new warning path in `load_config` admits successfully typed unknown-key files at those paths. With an owned `link -> physical/anchor` and `XDG_CONFIG_HOME=<root>/link/../cfg`, frozen Go reads `<root>/cfg/symguard/config.toml`, while native reads `<root>/physical/cfg/symguard/config.toml`. The HOME fallback has the same defect.

Actual wrong-owner reports are demonstrated twice: lexical `lexical_owner=1` versus physical `physical_owner=1` selects different warnings; lexical `sequence={enabled=true,threshold=1}` versus physical disabled sequence makes Go exit1/config validation error while native exits0/all-basic-checks-passed. An ordinary XDG `cfg/../cfg` control selects the same file but still emits a different raw warning/semantic path. Plain generated paths match. An explicit `SYMGUARD_CONFIG=<root>/link/../cfg/symguard/config.toml` matches and intentionally keeps OS symlink/.. semantics: Go returns the explicit override unchanged, so globally cleaning every path would introduce another error.

Four original receipts contain 20 real process pairs, plus ten further pairs against the independently rebuilt frozen Go. All raw inputs/files/symlink state and exact warning/report streams are preserved:
- `/tmp/symaira-guard770-warnings-independent-owner{.py,.json,.log}`: five current warning pairs, three mismatches/two matching controls.
- `...-owner-semantic{.py,.json,.log}`: same five paths with the stronger error-vs-healthy owner distinction.
- `...-parent-owner{.py,.json,.log}`: exact archived approved parent refuses all five unknown-key cases; current warning admission is new.
- `...-parent-known-owner{.py,.json,.log}`: exact archived parent's known-only configs reproduce the inherited resolver error. This separates inherited path implementation from newly admitted wrong warning reports.
- `...-owner-state-manifest-final.json`: 180 raw-state paths, including symlink destinations, file bytes/modes/times.

Archived parent native SHA `a39c1c425b9ea7aad75f12ddf9297c6a7dd5afb55171380b19408d387c6d70a9` is bound to actual960 source in `/tmp/symaira-guard770-doctor-final-handoff.json`; parent1c04 is evidence-only. Its storage archive has an e876 name; that name is not claimed as its compiled-source identity. Current native SHA `c64e8406aa246123fc4d5b0fe9401c2bcf9b9855b9c190aea635b691b67c5be7`, frozen actual Go SHA `819b38ddf36bd0eaa9811aca37dcac4174c865704e9191d494fd53d43b40a93b`. Every input is private, all pair state is readonly and candidate remains clean.

Correct generated paths with bounded native Go lexical clean/join and preserve raw OS bytes; leave explicit overrides unchanged. Do not filesystem-canonicalize, which follows symlinks rather than matching Go's lexical contract. Existing Guard-only `guard_scan::clean_native_path` is an acyclic possible owner, but its Windows lossy conversion must be resolved/proved before raw-byte use; do not import Brain/Managed or blindly claim complete volume semantics. Preserve original failures and rerun source-bound full/parent/new owner controls and native platform gates.

Independent freshly built Go SHA `13500aba1a47175268e163aec3b86571f450c451ff775f692b5818ba00761146` repeats both five-case current groups under `...-fresh-owner` and `...-fresh-owner-semantic`; the same two wrong owners and ordinary dotdot path mismatch recur. Fresh exact binaries are retained by the normal gate before its build source expires.

## Full source and architecture inspection

Read all changed production code: immutable TOML document/span parsing, typed config decoder, ordered metadata collector/key renderer, whole-report warning buffer and public/shared/standalone handlers; all new tests and exact Brain-adapter consumer. Followed original Go ConfigPath/Load/Decode/Undecoded/validate and doctor/check/discovery/anchor/audit behavior; reviewed inherited Rust decoder/RawValue/Unicode/first-error handling, allowlist/discovery, audit appender/diagnostic boundaries and Core GoText/Go quoting. Read complete runners/comparators/mutants/source and executable retention, workflows, ADR, exhaustive None inventory and matrix/planning changes.

The warning metadata event model preserves explicit headers, excludes implicit dotted parents and retains repeated array entries; stable source position ordering and TOML segment quoting followed by Core Go quoting match actual new cases. Typed fields are decoded before collecting warnings; only then semantic validation runs. Unproven aliases/type/discovery/read/map-order states remain delegated, with no native stream emitted until whole admission. The exact Brain adapter directly reuses the Guard handler and remains unchanged. No dependency/lockfile/Core/kernel/audit/Go/frozen fixture or authority change. Production modules stay below400 lines. Standalone retains its explicit unsupported state rather than silently invoking Go.

## Fresh independent process gates

All run under owned HOME/XDG/cwd, absent operator credentials and empty PATH, against the actual preserved source-bound Go/native pair, through the subreaper:

- Current124:122 full stream/exit/file comparisons plus two original TOML decoder/map-order refusals.
- Additive78:67 full comparisons/11 retained gates; raw63 full matches.
- Warning54:46 full comparisons/eight type/alias/discovery/map-order gates, exact14 original inputs, ten actual Go repeats/one warning order.
- All13 genuine process mutations reject at intended boundaries: old diagnostic3/raw2/additive3 plus new drop/reorder/deduplicate/leak-before-type/double-delegation5. The controls execute real native/Go processes and preserve both raw outputs; no altered stored receipt substitutes for execution.
- Original80 all full matches; original94=92 full/two original refusals. Every original argv/state/payload is explicitly matched case by case, including the two declared semantic ID promotions.
- Ordered31=27 full/four typed gates, mixed35/raw4/Unicode4/Root32 all full matches. Audit6 safety invariants pass; inherited Go symlink/unsafe-parent writes remain visible as intentional non-equality rather than a blanket parity claim.
- Novel metadata/quoted/control/Unicode/array/error precedence28:27 full pairs and one documented unsupported non-simple parser state. The original too-broad parity attempt on invalid `owned=+0x7f` is retained with its mismatch; Go rejects signed hex and native emits empty stdout/explicit unsupported stderr. A separate classification receipt explains that existing parser gate, not a new production finding or waiver.
- Six additional actual exact-Brain-adapter consumer processes check aliases, deep type errors, map-order, discovery and anchor-read delegation: five require None and both native streams empty; semantic-before-malformed-discovery requires an admitted error and a single warning. These execute the candidate test binary with private custom state; they are not full Brain CLI acceptance.

## Fresh ordinary/strict acceptance

Executed `cargo test --offline --locked -p symbrain-core -p symbrain-guard-core -p symguard-cli --all-targets --all-features` against the sole released267MB target:173passed/0failed/0ignored,14 summaries. The exact Brain adapter parent test includes five actual Linux child roles; nested children are not added to173. Separate guard-core all-target graph41/0/0/seven summaries overlaps kernel coverage and is not added. Both corresponding strict Clippy graphs, workspace fmt and pinned actionlint pass. The initial shell lookup of actionlint was absent from PATH; its literal setup error is preserved, then `/workspace/toolchains/bin/actionlint` passed. No source/comparator/assertion changed for that correction.

The full normal `run.sh` freshly built actual frozen Go1.26.7 and the native standalone command, retained their exact bytes, then passed all124/63/78/54 gates plus all13 controls. This corroborates the existing-binary independent runs; it does not count duplicate executions as additional cases. Current native c64 bytes remain unchanged. All compiler/runtime work finished and the compiler priority was explicitly released to Root before final evidence processing.

## Provenance and retained originals

Independent verifier checks105 current source entries against exactfb Git blobs and current bytes, all1217 frozen Go source/module entries plus all four root/nested module files against dcdd archive, actual supplemental entry, and evidence-only fb→4d. Shared Core/kernel/audit/lock/Go/frozen fixture/Brain adapter bytes remain identical to approved parent. All40 final author retention objects return exact original bytes/length/SHA and current original paths. Author current68 ELF/copy mappings45unique, independently retained current69 mappings46unique, released parent65/43 and historical1c04-storage98 archive mappings all decompress/hash/length verify; storage-head snapshots do not relabel inactive cached binaries as newly executed source. Original14 unknown-warning input bytes and ten baseline repeats are verified case by case; original50 invalid-default runs/two reports are unchanged to approved parent, with no exception or E-002 claim.

`...-independent-provenance.py/.json` and logs preserve these checks. The first additional verifier assumed the baseline repeats were a list rather than a dict containing `runs`; its exact helper/error log are preserved, then corrected shape inspection verified all ten original runs. A later parent validator incorrectly required post-review ADR bytes to equal the compiled-source snapshot; its original helper/error is preserved and the corrected check binds all actual production/Cargo bytes, with 960→1c04 production Gitdiff empty. The original author prototype/compile/lint/provenance-helper failures, checkpoint707, proof-only dirty supplemental attempt and cleanfb rerun remain distinct and unmodified.

## Remaining acceptance

Native Windows/macOS exact-source CI/protected checks remain required. Declared Windows52 warnings skip the two Unix raw-path cases explicitly; no cross-platform runtime inference. Whole Brain executable, broader typed/case-fold/parser/discovery/filesystem/output boundaries and full770/769 remain pending. No issue closure, Go retirement, performance or security-exception claim. The candidate/source remains unchanged. The target is exclusively released to Root after final byte/hash checks and a zero-user /proc executable/cwd/FD scan.
