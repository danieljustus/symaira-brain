from pathlib import Path
import json,hashlib,subprocess,gzip
repo=Path('/workspace/symaira-guard770-doctor-warnings');prefix='symaira-guard770-warnings-independent-';head='4d78b6e52c53d1c273126b0dac3c554915a15438';source='fb2844b02b7c03b7c34650c6d3aed693c47b2997';target='/workspace/symaira-guard770-diagnostics/target'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()==head and not subprocess.check_output(['git','status','--porcelain'],cwd=repo)
validation=json.loads((repo/'migration/evidence/guard-doctor-warnings-770/final-fb2844b/validation.json').read_text())
for n,h in validation['candidate_source_sha256'].items():assert sha(repo/n)==h,n
for row in validation['retention']:
 raw=(repo/row['retained']).read_bytes();raw=gzip.decompress(raw) if row['retained'].endswith('.gz') else raw
 assert hashlib.sha256(raw).hexdigest()==row['sha256']==sha(Path(row['original']))
archive=Path('/workspace/oracles/symaira-guard770-warnings-independent-4d-binaries/receipt.json');a=json.loads(archive.read_text())
for h,row in a['unique'].items():
 p=Path(row['archive']);raw=gzip.decompress(p.read_bytes());assert sha(p)==row['archive_sha256'] and len(raw)==row['bytes'] and hashlib.sha256(raw).hexdigest()==h
for row in a['records']:assert sha(Path(row['path']))==row['sha256'],row['path']
state=Path('/tmp/'+prefix+'owner-state-manifest-final.json');states=json.loads(state.read_text())
for row in states:
 p=Path(row['path'])
 if row['kind']=='symlink':assert str(p.readlink())==row['target']
 else:assert sha(p)==row['sha256'] and p.stat().st_size==row['bytes'] and p.stat().st_mtime_ns==row['mtime_ns'] and p.stat().st_mode==row['mode']
users=[]
for p in Path('/proc').iterdir():
 if not p.name.isdigit():continue
 try:
  links=[p/'exe',p/'cwd',*(p/'fd').iterdir()]
  for link in links:
   try:
    value=str(link.readlink())
    if value==target or value.startswith(target+'/'):users.append(dict(pid=p.name,link=str(link),target=value))
   except OSError:pass
 except OSError:pass
assert not users,users
artifacts={str(p):dict(sha256=sha(p),bytes=p.stat().st_size) for p in sorted(Path('/tmp').glob(prefix+'*')) if p.is_file() and p.name!=prefix+'review-receipt.json'}
full=json.loads(Path('/tmp/'+prefix+'full.json').read_text());provenance=json.loads(Path('/tmp/'+prefix+'provenance.json').read_text());report=Path('/tmp/'+prefix+'review.md')
r=dict(head=head,validated_source=source,approved_parent='1c04ad92f9537d5b4d552d080433635c5f0c5403',candidate_clean=True,reviewer_independent_from_author=True,disposition='REQUEST_CHANGES',findings=[dict(priority='P2',path='rust/symguard-cli/src/doctor/config.rs',lines=[22,25],title='Apply Go lexical joining to generated config paths before warning admission',inherited_resolver=True,newly_admitted_wrong_warning_reports=True,ordinary_dotdot_warning_path_mismatch=True,symlink_dotdot_wrong_config_owner=True,actual_error_vs_healthy_exit1_vs0=True,explicit_SYMGUARD_CONFIG_OS_semantics_control_matches=True,original_owner_history_pairs=20,independently_rebuilt_Go_owner_pairs=10)],gates=dict(current124={'matched':122,'retained_gates':2},raw63={'matched':63},additive78={'matched':67,'retained_gates':11},warning54={'matched':46,'retained_gates':8,'original_inputs':14,'Go_repeats':10,'distinct_orders':1},actual_mutants={'diagnostic':3,'raw':2,'additive':3,'warning':5,'total':13},original80={'matched':80},original94={'matched':92,'retained_gates':2},ordered31={'matched':27,'retained_gates':4},mixed35={'matched':35},raw4={'matched':4},Unicode4={'matched':4},Root32={'matched':32},audit6={'native_invariants':6,'not_blanket_Go_equality':True},novel28={'matched':27,'documented_parser_gate':1,'initial_out_of_scope_equality_attempt_retained':True},novel_exact_Brain_adapter_roles={'actual_children':6,'empty_native_stream_delegation':5,'semantic_before_discovery':1,'not_full_Brain_CLI':True},ordinary={'passed':173,'failed':0,'ignored':0,'summaries':14},separate_kernel={'passed':41,'failed':0,'ignored':0,'summaries':7,'overlaps_ordinary_not_added':True},strict_all_target_all_features=True,separate_kernel_strict=True,fmt=True,actionlint=True,initial_actionlint_PATH_setup_error_retained=True,full_fresh_sdk_runner=True),provenance=provenance,actual_binaries={'native':full['binaries_sha256']['rust'],'fresh_Go':full['binaries_sha256']['go'],'author_actual_Go':'819b38ddf36bd0eaa9811aca37dcac4174c865704e9191d494fd53d43b40a93b','approved_parent_actual_native':'a39c1c425b9ea7aad75f12ddf9297c6a7dd5afb55171380b19408d387c6d70a9'},report_sha256=sha(report),archive={'receipt':str(archive),'sha256':sha(archive),'paths':len(a['records']),'unique':len(a['unique']),'roundtrip_verified':True,'inactive_cache_not_current_executions':True},retained_raw_owner_state={'manifest':str(state),'sha256':sha(state),'paths':len(states)},evidence=artifacts,target=target,target_users=users,target_released=True,compiler_priority_released=True,no_source_GitHub_or_frozen_edits=True,limits=['Exact-source native macOS/Windows protected CI remains required','Full770/769 and whole Brain executable gates remain pending','Original50 defaults/two reports and original14/10 inputs are unchanged; no nondeterminism waiver','Independent reviewer found one P2 and does not approve the implementation'])
Path('/tmp/'+prefix+'review-receipt.json').write_text(json.dumps(r,indent=2)+'\n')
print(json.dumps(dict(head=head,source=source,disposition=r['disposition'],finding_count=1,proof_artifacts=len(artifacts),archive_paths=len(a['records']),archive_unique=len(a['unique']),owner_state_paths=len(states),target_users=users,report_sha256=sha(report),receipt_sha256=sha(Path('/tmp/'+prefix+'review-receipt.json')))))
