from pathlib import Path
import json,hashlib,gzip,re,subprocess
repo=Path('/workspace/symaira-guard770-doctor-warnings');head='4d78b6e52c53d1c273126b0dac3c554915a15438';target=Path('/workspace/symaira-guard770-diagnostics/target')
def digest(raw):return hashlib.sha256(raw).hexdigest()
def sha(p):return digest(p.read_bytes())
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()==head
assert not subprocess.check_output(['git','status','--porcelain'],cwd=repo)
# Exact native parent provenance, rather than infer it from its storage-worktree name.
parent=json.loads(Path('/tmp/symaira-guard770-doctor-final-handoff.json').read_text());assert parent['validated_source']=='9603d24e6749ee67e5eac1b7ddda6900af022cd5'
assert parent['binaries']['/workspace/symaira-guard770-diagnostics/target/debug/symguard']['sha256']=='a39c1c425b9ea7aad75f12ddf9297c6a7dd5afb55171380b19408d387c6d70a9'
assert not subprocess.check_output(['git','diff',parent['validated_source'],'1c04ad92f9537d5b4d552d080433635c5f0c5403','--','rust','Cargo.lock','Cargo.toml'],cwd=repo)
for r in parent['candidate_source_sha256'].items():
 n,h=r;assert digest(subprocess.check_output(['git','show','1c04ad92f9537d5b4d552d080433635c5f0c5403:'+n],cwd=repo))==h,n
logs={}
for name,expected,summaries in [('tests',173,14),('kernel-tests',41,7)]:
 p=Path('/tmp/symaira-guard770-warnings-independent-'+name+'.log');rows=re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored',p.read_text());assert len(rows)==summaries and sum(int(r[0]) for r in rows)==expected and all(r[1]==r[2]=='0' for r in rows);logs[name]=dict(sha256=sha(p),passed=expected,summaries=summaries,actual_binaries=re.findall(r'^     Running .* \(([^)]+)\)$',p.read_text(),re.M))
for name in ['clippy','kernel-clippy','fmt','actionlint-final']:
 p=Path('/tmp/symaira-guard770-warnings-independent-'+name+'.log');assert p.is_file();logs[name]=dict(sha256=sha(p))
by_sha={}
for name in ['/workspace/oracles/symaira-guard770-warnings-fb2844b-binaries/receipt.json','/workspace/oracles/symaira-guard770-diagnostics-e8766e354b4f-idle-binaries/receipt.json']:
 d=json.loads(Path(name).read_text());by_sha.update(d['unique'])
archive=Path('/workspace/oracles/symaira-guard770-warnings-independent-4d-binaries');archive.mkdir(exist_ok=False);records=[];unique={}
paths=list(target.rglob('*'))+list(Path('/tmp/symaira-guard770-warnings-independent-full-binaries').glob('*'))+[Path('/tmp/symaira-guard770-warnings-independent-parent-symguard')]
for p in sorted(paths):
 if not p.is_file():continue
 with p.open('rb') as f:magic=f.read(4)
 if magic!=b'\x7fELF':continue
 raw=p.read_bytes();h=digest(raw)
 if h in by_sha:dest=Path(by_sha[h]['archive'])
 else:
  dest=archive/(h+'.gz')
  if not dest.exists():dest.write_bytes(gzip.compress(raw,compresslevel=6,mtime=0))
 assert gzip.decompress(dest.read_bytes())==raw
 records.append(dict(path=str(p),sha256=h,bytes=len(raw)));unique[h]=dict(archive=str(dest),sha256=h,bytes=len(raw),archive_sha256=sha(dest))
a=dict(snapshot_head=head,source='fb2844b02b7c03b7c34650c6d3aed693c47b2997',target=str(target),records=records,unique=unique,ordinary_logs=logs,roundtrip_verified=True,cached_inactive_artifacts_not_new_executions=True)
(archive/'receipt.json').write_text(json.dumps(a,indent=2)+'\n')
# Update state mapping to retain both original owner failures and independent freshly rebuilt Go corroboration.
state=[]
for name in ['owner-state','owner-semantic-state','parent-owner-state','parent-known-owner-state','fresh-owner-state','fresh-owner-semantic-state']:
 base=Path('/tmp/symaira-guard770-warnings-independent-'+name)
 for p in sorted(base.rglob('*')):
  if p.is_symlink():state.append(dict(path=str(p),kind='symlink',target=str(p.readlink())))
  elif p.is_file():state.append(dict(path=str(p),kind='file',sha256=sha(p),bytes=p.stat().st_size,mode=p.stat().st_mode,mtime_ns=p.stat().st_mtime_ns))
Path('/tmp/symaira-guard770-warnings-independent-owner-state-manifest-final.json').write_text(json.dumps(state,indent=2)+'\n')
full=json.loads(Path('/tmp/symaira-guard770-warnings-independent-full.json').read_text());assert full['candidate_head']==head and not full['candidate_dirty'];assert full['total']==124 and full['matched']==122
for name in ['full-controls','full-raw-paths','full-doctor-boundaries','full-config-warnings']:
 p=Path('/tmp/symaira-guard770-warnings-independent-'+name+'.json');d=json.loads(p.read_text());assert d['candidate_head']==head and not d['candidate_dirty']
print(json.dumps(dict(archive_paths=len(records),archive_unique=len(unique),retained_owned_state_paths=len(state),ordinary_tests=173,overlapping_kernel=41,primary_native_sha256=sha(target/'debug/symguard'),fresh_go_sha256=full['binaries_sha256']['go'])))
