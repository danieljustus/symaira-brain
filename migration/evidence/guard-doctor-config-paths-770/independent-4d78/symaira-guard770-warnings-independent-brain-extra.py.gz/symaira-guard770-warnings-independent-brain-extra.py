from pathlib import Path
import sys,json,subprocess,tempfile,hashlib
repo=Path('/workspace/symaira-guard770-doctor-warnings');sys.path.insert(0,str(repo/'scripts/guard-standalone-oracle'));import replay
binary=Path('/workspace/symaira-guard770-diagnostics/target/debug/deps/doctor_warnings-310215954a7227ca')
cases=[('alias','owned=1\nproxy={Upstream="a"}\n','type'),('deep-type','owned=1\nremote=[{labels=[1]}]\n','type'),('map-order','owned=1\ndefaults={a="bad",b="worse"}\n','type'),('discovery','owned=1\n','type'),('audit-read','owned=1\n','type'),('semantic-before-discovery','owned=1\nsequence={enabled=true,threshold=1}\n','semantic')];rows=[]
with tempfile.TemporaryDirectory(prefix='guard770-brain-consumer-extra-') as tmp:
 for i,(name,text,role) in enumerate(cases):
  root=Path(tmp)/str(i);env=replay.setup(root,'empty');path=root/'home/.config/symguard/config.toml';path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(text.encode());env['SYMGUARD_CONFIG']=str(path);env['OWNED_GUARD_WARNING_ROLE']=role
  if name in ['discovery','semantic-before-discovery']:(root/'home/.cursor/mcp.json').write_bytes(b'{bad')
  if name=='audit-read':
   log=root/'data/symguard/audit.log';log.parent.mkdir();log.write_bytes(b'{}\n');Path(str(log)+'.anchor').mkdir()
  before={str(p.relative_to(root)):(p.read_bytes().hex(),p.stat().st_mtime_ns) for p in root.rglob('*') if p.is_file()};p=subprocess.run([str(binary),'--exact','brain_doctor_warning_admission','--nocapture'],env=env,cwd=root/'project',capture_output=True,timeout=10);after={str(p.relative_to(root)):(p.read_bytes().hex(),p.stat().st_mtime_ns) for p in root.rglob('*') if p.is_file()};assert before==after
  rows.append(dict(id=name,role=role,input_hex=text.encode().hex(),exit=p.returncode,stdout_hex=p.stdout.hex(),stderr_hex=p.stderr.hex(),readonly=True));assert p.returncode==0,(name,p.stdout,p.stderr)
r=dict(head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip(),binary=str(binary),binary_sha256=hashlib.sha256(binary.read_bytes()).hexdigest(),helper_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),actual_exact_brain_adapter_consumer=True,not_full_Brain_CLI=True,results=rows)
Path('/tmp/symaira-guard770-warnings-independent-brain-extra.json').write_text(json.dumps(r,indent=2)+'\n');print('six novel exact-adapter process roles passed; five native None/empty-stream cases, one semantic warning before skipped malformed discovery')
