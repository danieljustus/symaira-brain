from pathlib import Path
import json,gzip,hashlib,subprocess,io,tarfile
repo=Path('/workspace/symaira-guard770-doctor-warnings');source='fb2844b02b7c03b7c34650c6d3aed693c47b2997';head='4d78b6e52c53d1c273126b0dac3c554915a15438';parent='1c04ad92f9537d5b4d552d080433635c5f0c5403';oracle='dcddcef0df5789123c7c9a7ebe6e01f10e941f2c'
def digest(data):return hashlib.sha256(data).hexdigest()
def sha(p):return digest(p.read_bytes())
def git(*args):return subprocess.check_output(['git',*args],cwd=repo)
assert git('rev-parse','HEAD').decode().strip()==head and not git('status','--porcelain')
validation=repo/'migration/evidence/guard-doctor-warnings-770/final-fb2844b/validation.json';v=json.loads(validation.read_text());assert len(v['candidate_source_sha256'])==105
for n,h in v['candidate_source_sha256'].items():assert sha(repo/n)==h==digest(git('show',source+':'+n)),n
assert not git('diff',parent,source,'--','Cargo.toml','Cargo.lock','rust/symbrain-core','rust/symbrain-audit','rust/symbrain-guard-core','guard','internal','cmd','rust/symbrain-cli/src/guard_cli.rs')
assert not git('diff',source,head,'--','rust','scripts','.github','Cargo.toml','Cargo.lock','docs/adr/guard-doctor-ordered-config-warnings.md','migration/contract-matrix.csv')
for r in v['retention']:
 raw=(repo/r['retained']).read_bytes();raw=gzip.decompress(raw) if r['retained'].endswith('.gz') else raw
 assert len(raw)==r['bytes'] and digest(raw)==r['sha256'] and sha(Path(r['original']))==r['sha256'],r['original']
p=Path('/tmp/symaira-guard770-warnings-independent-current124.json');process=json.loads(p.read_text());assert len(process['go_source_sha256'])==1217
with tarfile.open(fileobj=io.BytesIO(git('archive',oracle))) as tar:
 files={m.name:digest(tar.extractfile(m).read()) for m in tar if m.isfile()}
for n,h in process['go_source_sha256'].items():assert files[n]==h,n
assert process['supplemental_go_entry_sha256']==sha(repo/'scripts/guard-standalone-oracle/main.go.txt')
for n,h in process['candidate_source_sha256'].items():assert sha(repo/n)==h,n
archives=[]
for name in ['/workspace/oracles/symaira-guard770-warnings-fb2844b-binaries/receipt.json','/workspace/oracles/symaira-guard770-diagnostics-e8766e354b4f-idle-binaries/receipt.json','/workspace/oracles/symaira-guard770-1c04ad92f953-idle-binaries/receipt.json']:
 p=Path(name);a=json.loads(p.read_text())
 for h,r in a['unique'].items():
  raw=gzip.decompress(Path(r['archive']).read_bytes());assert digest(raw)==h and len(raw)==r.get('bytes',r.get('original_size')),h
 records=a.get('records',a.get('executables'));archives.append(dict(receipt=name,sha256=sha(p),paths=len(records),unique=len(a['unique'])))
 if 'records' in a:
  for r in a['records']:assert sha(Path(r['path']))==r['sha256'],r['path']
nd=repo/'migration/evidence/guard-doctor-boundaries-770/baseline-8e3/symaira-guard770-doctor-boundary-inventory.json.gz';assert nd.read_bytes()==git('show',parent+':'+str(nd.relative_to(repo)));d=json.loads(gzip.decompress(nd.read_bytes()));assert len(d['repeated_invalid_defaults'])==50 and d['distinct_invalid_default_reports']==2
# Preserve original unknown-key inputs case by case against the original Go-only inventory.
import sys
sys.path.insert(0,str(repo/'scripts/guard-standalone-oracle'));import config_warnings
baseline=json.loads(gzip.decompress((repo/'migration/evidence/guard-doctor-warnings-770/baseline-1c04/symaira-brain769-positive-slice-probe.json.gz').read_bytes()))
original=[c for c in config_warnings.cases() if c.get('original')];assert len(original)==14
original_by_id={r['id']:r for r in baseline['cases']}
for c in original:assert c['data']==original_by_id[c['id']]['input_utf8'].encode(),c['id']
assert len(baseline['unknown_warning_repeat']['runs'])==10
print('Original14 input bytes and10 retained repeats verified')
unknown=[r for r in baseline['cases'] if r.get('id','').startswith('unknown-')];print('Unknown original IDs', [r.get('id') for r in unknown])
out=dict(head=head,source=source,approved_parent=parent,source_sha256=v['candidate_source_sha256'],source_count105=True,frozen_go_inputs1217_verified=True,frozen_source_sha256=process['go_source_sha256'],original50_two_reports_sha256=sha(nd),retained_author_objects40_verified=True,archives=archives,source_after_validation_evidence_only=True,shared_core_kernel_audit_lock_Go_fixtures_and_Brain_adapter_unchanged=True)
Path('/tmp/symaira-guard770-warnings-independent-provenance.json').write_text(json.dumps(out,indent=2)+'\n');print('PASS105 source/1217 frozen/40originalproofs/current68+parent65+old98 archives')
