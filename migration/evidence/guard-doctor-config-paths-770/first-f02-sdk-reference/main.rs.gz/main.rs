use std::io::{self,Read};
#[path = "/workspace/symaira-guard770-config-paths/rust/symguard-cli/src/guard_path_windows.rs"] mod windows;
fn bytes(value:&str)->Vec<u8> {value.as_bytes().chunks_exact(2).map(|c|u8::from_str_radix(std::str::from_utf8(c).unwrap(),16).unwrap()).collect()}
fn main() { let mut input=String::new();io::stdin().read_to_string(&mut input).unwrap();
for line in input.lines() { let mut fields=line.split('\t');let mode=fields.next().unwrap();
let base:Vec<u16>=bytes(fields.next().unwrap()).chunks_exact(2).map(|c|u16::from_le_bytes([c[0],c[1]])).collect();
let parts:Vec<String>=fields.map(|v|String::from_utf8(bytes(v)).unwrap()).collect();let refs:Vec<&str>=parts.iter().map(String::as_str).collect();
let out=if mode=="clean" {windows::clean_units(&base)}else{windows::join_units(&base,&refs)};println!("{}",out.iter().flat_map(|u|u.to_le_bytes()).map(|b|format!("{b:02x}")).collect::<String>()); } }
