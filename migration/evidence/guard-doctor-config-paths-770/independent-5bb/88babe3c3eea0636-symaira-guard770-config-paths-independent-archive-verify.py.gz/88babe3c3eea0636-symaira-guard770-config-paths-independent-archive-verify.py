from pathlib import Path
import gzip,hashlib,json
ROOT=Path('/workspace/symaira-guard770-config-paths');FINAL=ROOT/'migration/evidence/guard-doctor-config-paths-770/final-5bb';v=json.loads((FINAL/'validation.json').read_text());verified={};rows=[]
def sha(data):return hashlib.sha256(data).hexdigest()
def verify(rec):
 key=rec['sha256'];p=Path(rec['archive']);compressed=p.read_bytes();assert sha(compressed)==rec['archive_sha256'],str(p)
 if key not in verified:
  raw=gzip.decompress(compressed);assert len(raw)==rec['bytes'] and sha(raw)==key,str(p);assert raw.startswith(b'\x7fELF'),str(p);verified[key]={'bytes':len(raw),'archive':str(p)}
 else:assert verified[key]['bytes']==rec['bytes']
for entry in v['archives']:
 p=Path(entry['path']);assert sha(p.read_bytes())==entry['receipt_sha256'];d=json.loads(p.read_text());unique=d.get('unique',{r['sha256']:r for r in d['records']});
 for rec in unique.values():verify(rec)
 for rec in d['records']:assert rec['sha256'] in unique and rec['bytes']==unique[rec['sha256']]['bytes']
 rows.append({'label':entry['label'],'paths':len(d['records']),'unique':len(unique),'receipt_sha256':sha(p.read_bytes())})
p=Path('/workspace/oracles/symaira-guard770-config-paths-5bb-binaries/durable-complete-receipt.json');d=json.loads(p.read_text());
for rec in d['unique'].values():verify(rec)
for rec in d['records']:assert rec['sha256'] in d['unique'] and rec['bytes']==d['unique'][rec['sha256']]['bytes']
current=[]
for rec in d['records']:
 p=Path(rec['path'])
 if p.is_file():assert p.stat().st_size==rec['bytes'] and sha(p.read_bytes())==rec['sha256'];current.append(str(p))
for rec in v['ordinary177_binaries15_and_kernel41_overlapping_binaries7']:
 p=Path(rec['path']);assert sha(p.read_bytes())==rec['sha256']
old=ROOT/'migration/evidence/guard-doctor-config-paths-770/independent-4d78';data=json.loads((old/'retention.json').read_text());assert data['elf_paths']==69
result={'head':'7f6faa9924b3d25b5c796ee662b4544184c156d5','source':'5bbd42774b73760731801ca148663350b9770b47','original_and_intermediate_archives':rows,'current_complete_paths':len(d['records']),'current_unique':len(d['unique']),'all_unique_across_history':len(verified),'actual_test_roles':len(v['ordinary177_binaries15_and_kernel41_overlapping_binaries7']),'live_current_paths_verified':len(current),'source_sdk_limited_probes_explicit':True,'PASS':True}
Path('/tmp/symaira-guard770-config-paths-independent-archive-verification.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
