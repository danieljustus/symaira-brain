# Immutable Guard generated-config ownership correction

Author handoff for a full review by a different author; this is not independent
approval and does not close issues #770/#769 or establish native Windows runtime
acceptance.

- Worktree: `/workspace/symaira-guard770-config-paths`
- Branch: `issue/770-generated-config-paths`
- Final clean evidence-only HEAD: `7f6faa9924b3d25b5c796ee662b4544184c156d5`
- Actual validated clean runtime/harness source: `5bbd42774b73760731801ca148663350b9770b47`
- Main normally integrated: `2b6d49f250a81650eda1b93cec7d859a171873bb`
- Immutable rejected publication/source: `4d78b6e52c53d1c273126b0dac3c554915a15438` /
  `fb2844b02b7c03b7c34650c6d3aed693c47b2997`
- Frozen Go: `dcddcef0df5789123c7c9a7ebe6e01f10e941f2c`
- Sole target: `/workspace/symaira-guard770-diagnostics/target`

**The sole target is explicitly released to Root for independent review now.**
No author compiler, replay or owned child remains; the final `/proc` exe/cwd/fd
scan found zero users. I will make no further source, target or probe changes.
Do not build/use the old Memory763 target; it is held separately by Root.

The final publication changes only four documentation files and the final
evidence directory from source5bb. All Rust, executable scripts and CI workflow
bytes remain exactly source5bb. The README is the sole changed file under
`scripts/`. Final source maps are historical maps of source5bb, not relabelled
maps of the later documentation commit.

## Correction and boundaries

Generated XDG/HOME config paths use Guard's private Go lexical join/clean before
probe/read/diagnostic rendering. Explicit nonempty `SYMGUARD_CONFIG` stays a raw
OS path. No filesystem canonicalization, Core/Brain/installer dependency or
unrelated text changes. Unix cleaner body/raw bytes are identical to fb.

`guard_paths.rs` and `guard_path_windows.rs` remain Guard-private. The Windows
helper retains native wide units while implementing exact SDK WTF8 byte offsets,
Go volume/UNC/device/verbatim/lazy-buffer/postClean/join behavior. Production
files stay under400 lines. Generated Windows config paths with unpaired units
whose existing Core diagnostic conversion would be lossy are refused before
read/output; a Windows-only exact-adapter child test is defined but was not
executed on Linux. Wider Scan/Windows diagnostics are unproven.

The copied Go1.26.7 reference is a declared source-derived portable process,
not a Windows executable or file-API proof. Its seven source SHA pins and BSD
license are tracked. The initial static assumption about Go replacing lone
surrogates was corrected: this pinned SDK preserves them using WTF8. Production
Core GoText was deliberately left unchanged.

## Full author validation on clean source5bb

- Ordinary affected graph:177 tests, zero failed/ignored,15 executed binaries.
- Separate kernel graph:41 tests, seven binaries; overlaps the ordinary graph,
  never sum these as218 unique tests.
- Both strict Clippy graphs, workspace fmt and actionlint pass.
- Public immutable-Go/native standalone cases124:122 full reports/two refusals.
- Raw-path63:63 full reports, two actual mutations rejected.
- Additive78:67 full reports/11 explicit refusals, three actual mutations.
- Ordered-warning54:46 full reports/eight refusals, ten Go repeats/one observed
  order, five actual mutations.
- Diagnostic controls:three actual mutations, for13 inherited mutants total.
- Config-path25:21 full reports/four explicit typed/discovery refusals, one
  additional actual wrong-owner/canonicalizing process mutant rejected.
- Portable SDK source-reference386/386, including all34 SDK Clean examples.

All25 immutable corrected before442 inputs have explicit case-by-case mapping,
including input bytes, normalized owned root environment spelling, modes and
readonly metadata. Original15 failed comparisons become13 full equal reports
and two correctly empty native typed refusals. The original20 and later10
owner-history pairs are freshly replayed30/30, including inherited parent-known
and newly admitted warning cases, dotdot filenames and explicit raw controls.

Every prior independent helper is preserved unchanged and adapted only to the
current repo/binaries/new output paths for fresh replay: original80/full and
94/92full+two refusals; ordered31/27full+four refusals; six audit filesystem
safety controls; four raw/four Unicode; novel28/27full+the original signed-hex
parser refusal; parent32/35full; six exact Brain adapter children. The novel
raw receipt intentionally retains its prior broad-comparator failed field and
separate classification proves the known native refusal; no input is dropped or
new mismatch normalized. Audit controls preserve inherited Go unsafe writes,
asserting native safety properties rather than universal parity. Adapter
children compile the unchanged real Brain adapter in Guard tests and prove
empty streams/semantic ordering, not a full Brain executable.

All nine original Scan fixtures pass against each current actual public Go and
native executable, including original TTY and repeat settings. A declared argv
exec adapter removes only `guard`; fixture/source binding is unchanged.

## Exact proof and executable retention

Tracked final proof root:
`migration/evidence/guard-doctor-config-paths-770/final-5bb/validation.json`.
It maps110 source files,1217 exact frozen Go files and four module files, seven
SDK sources,89 retained reports/drivers/logs and actual public/portable-probe
bytes. It retains180 new owner file/link states separately from the immutable
original180 states. Original92 proof files plus two receipts, original50 Go
invalid-default runs/two report orders and original14 unknown-key inputs/ten
repeats remain untouched and verified.

Current ELF archive:
`/workspace/oracles/symaira-guard770-config-paths-5bb-binaries/complete-receipt.json`
(71 paths/48 unique). Original exact receipt SHA:
`1d64df3b1b4ed550efa7de5ba04e8fe1948c09bd764a479cdeddddc786e7768e`.
`durable-complete-receipt.json` additionally mirrors the two portable SDK gzip
archives into `/workspace/oracles`; it preserves original receipt linkage.
All48 unique byte sequences gzip-roundtrip/length/SHA verify. Cached inactive
target ELFs are not claimed as executed;22 actual test roles and the actual
public/SDK probe roles are separately recorded.

Actual fresh public binaries:

- Go: `/tmp/symaira-guard770-config-paths-5bb-process-binaries/go`, SHA256
  `292cdfe9f537cd33baba2c6fe68ac726bd07850098f9ec1386e2fe2b7bee3e8c`.
- Native: `/tmp/symaira-guard770-config-paths-5bb-process-binaries/native`, SHA256
  `26f8606cbf4b67cc88ad17529e12f6349746a9644d3f96f66a7e99cab3093e5a`;
  same current target `debug/symguard` bytes.
- Actual portable Go SDK probe SHA256:
  `550513d453123a095fedd21637f7a373db68d3f232c7a55e6b38f99eaff185da`.
- Actual portable production Rust helper probe SHA256:
  `7a52cfbbe4f511e12f4fa6322b27ee21cb5d0268f1d26da48552c3b1eec16efd`.

Current root check:
`/tmp/symaira-guard770-config-paths-final-publication-check.json/.log/.py`.
Complete gate prefix: `/tmp/symaira-guard770-config-paths-5bb-`.
Original25 accounting: `...-5bb-case-accounting.json`.
Original30 owner history: `...-5bb-history-receipt.json` and six raw report/state
groups. Prior full helper replay: `...-5bb-previous-gates.json/.log` and all
individual outputs. Full original Scan: `...-5bb-scan-original9.json/.log/.py`.
Fresh buildinfo: `...-final-go-buildinfo.txt`.

Immutable original independent REQUEST1 review and receipts remain byte-exact
under `independent-4d78`; original69/46 ELF bytes were archived before target
reuse. Failed221 ordinary execution, failedF02 SDK stale-buffer pairs,
failedCFEA Unicode-width pairs and strict failures remain in their historical
tracked directories with original failed actual portable probe binaries.
F02 ordinary log has no complete retained executable binding and is explicitly
not final acceptance evidence. The intermediate9e9 archive's original shorthand
metadata is preserved, with a separate correction pointing to its exact full
`head`. No frozen source, fixture, kernel, audit, lock or Brain adapter changed.

## Reproducible independent commands

Use only this worktree and the explicitly released existing target, no duplicate
target. Stop new stages below700MiB. Set `umask 022`, source
`/home/agent/.cargo/env`, prefix PATH with `/workspace/toolchains/go1.26.7/bin`,
and set `CARGO_TARGET_DIR=/workspace/symaira-guard770-diagnostics/target`,
`CARGO_INCREMENTAL=0 CARGO_PROFILE_DEV_DEBUG=0 CARGO_PROFILE_TEST_DEBUG=0`
`CARGO_BUILD_JOBS=2`. Run subprocess suites under
`python3 /tmp/symaira-subreaper.py` with `bash -c 'set -euo pipefail; ...'`.

```
cargo test --locked -p symbrain-core -p symbrain-guard-core -p symguard-cli --all-targets --all-features
cargo test --locked -p symbrain-guard-core --all-targets --all-features
cargo clippy --locked -p symbrain-core -p symbrain-guard-core -p symguard-cli --all-targets --all-features -- -D warnings
cargo clippy --locked -p symbrain-guard-core --all-targets --all-features -- -D warnings
cargo fmt --all -- --check
/workspace/toolchains/bin/actionlint .github/workflows/ci.yml
bash scripts/guard-standalone-oracle/run.sh /tmp/guard770-root-fresh-process.json
```

Prior helpers and Scan9 drivers retained in final-5bb can be adapted only to
new independent output prefixes, the current immutable repo and freshly copied
actual binaries. Do not rerun an author driver into its original output paths.
The SDK standalone reference script constructs actual tiny portable probes;
its outputs must retain source-reference limitations. Fresh Linux/macOS/Windows
protected CI and independent full-layer review remain necessary before merge.
