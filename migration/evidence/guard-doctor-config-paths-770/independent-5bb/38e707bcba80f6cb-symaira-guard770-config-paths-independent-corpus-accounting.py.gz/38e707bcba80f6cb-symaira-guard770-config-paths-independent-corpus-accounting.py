from pathlib import Path
import gzip,hashlib,json,os,subprocess,sys
ROOT=Path('/workspace/symaira-guard770-config-paths');PREFIX='/tmp/symaira-guard770-config-paths-independent-';REF='dcddcef0df5789123c7c9a7ebe6e01f10e941f2c'
def git(*args):return subprocess.check_output(['git',*args],cwd=ROOT)
for name in ['go.mod','go.sum','browse/go.mod','browse/go.sum']:assert git('show',REF+':'+name)==(ROOT/name).read_bytes(),name
nd=ROOT/'migration/evidence/guard-doctor-boundaries-770/baseline-8e3/symaira-guard770-doctor-boundary-inventory.json.gz';assert nd.read_bytes()==git('show','1c04ad92f9537d5b4d552d080433635c5f0c5403:'+str(nd.relative_to(ROOT)));d=json.loads(gzip.decompress(nd.read_bytes()));assert len(d['repeated_invalid_defaults'])==50 and d['distinct_invalid_default_reports']==2
sys.path.insert(0,str(ROOT/'scripts/guard-standalone-oracle'));import config_warnings
bp=ROOT/'migration/evidence/guard-doctor-warnings-770/baseline-1c04/symaira-brain769-positive-slice-probe.json.gz';assert bp.read_bytes()==git('show','4d78b6e52c53d1c273126b0dac3c554915a15438:'+str(bp.relative_to(ROOT)));b=json.loads(gzip.decompress(bp.read_bytes()));original=[c for c in config_warnings.cases() if c.get('original')];assert len(original)==14;byid={c['id']:c for c in b['cases']};assert all(c['data']==byid[c['id']]['input_utf8'].encode() for c in original);assert len(b['unknown_warning_repeat']['runs'])==10
before=json.loads(gzip.decompress((ROOT/'migration/evidence/guard-doctor-config-paths-770/before-442a/symaira-guard770-config-paths-before-corrected-process.json.gz').read_bytes()));after=json.loads(Path(PREFIX+'process-config-paths.json').read_text());assert len(before['results'])==len(after['results'])==25
rows=[]
def env(o):
 root=os.fsencode(o['input_state_metadata']['link'][1].split('/physical/')[0]);return {k:bytes.fromhex(v).replace(root,b'<root>').hex() for k,v in o['config_environment_bytes'].items()}
def state(o):return {k:['symlink',v[1].split('/physical/')[1]] if v[0]=='symlink' else v[:2] for k,v in o['input_state_metadata'].items()}
for old,new in zip(before['results'],after['results']):
 for key in ['id','family','spelling','contract','explicit','raw','state','empty_xdg']:assert old.get(key)==new.get(key)
 for side in ['go','native']:
  assert old[side]['readonly'] and new[side]['readonly'];assert env(old[side])==env(new[side]);assert state(old[side])==state(new[side]);assert old[side]['lexical_input_hex']==new[side]['lexical_input_hex'];assert old[side]['physical_input_hex']==new[side]['physical_input_hex']
 for key in ['exit_code','normalized_stdout_hex','normalized_stderr_hex']:assert old['go'][key]==new['go'][key]
 rows.append({'id':old['id'],'original':old['disposition'],'current':new['disposition'],'input_bytes_env_spelling_modes_links_preserved':True})
assert sum(x['original'].startswith('failed') for x in rows)==15
result={'head':'7f6faa9924b3d25b5c796ee662b4544184c156d5','source':'5bbd42774b73760731801ca148663350b9770b47','frozen_module_files':4,'original_default_actual_reports':50,'distinct_original_default_reports':2,'original_key_inputs':14,'original_warning_repeats':10,'original25_accounted':True,'original15_failures_now13_full_two_typed_refusals':True,'cases':rows,'PASS':True};Path(PREFIX+'corpus-accounting.json').write_text(json.dumps(result,indent=2)+'\n');print('PASS frozen4 module files, original50/2orders+14inputs/10repeats, all25 original owner case/state/Go report accounting')
