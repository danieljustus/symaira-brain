from pathlib import Path
import base64,hashlib,json,os,subprocess,sys,tempfile
repo=Path('/workspace/symaira-guard770-config-paths');sys.path.insert(0,str(repo/'guard/scripts/guard-scan-oracle'));import oracle,parity
fixture=json.loads(oracle.FIXTURE.read_bytes());oracle.verify_binding(fixture);rows=[]
bins={'go':Path('/tmp/symaira-guard770-config-paths-independent-process-binaries/go'),'native':Path('/tmp/symaira-guard770-config-paths-independent-process-binaries/native')}
with tempfile.TemporaryDirectory(prefix='guard770-original-scan9-') as directory:
 owned=Path(directory)
 for side,binary in bins.items():
  wrapper=owned/(side+'.py');wrapper.write_text('#!'+sys.executable+'\nimport os,sys\nassert sys.argv[1]=="guard"\nos.execv('+repr(str(binary))+',['+repr(str(binary))+',*sys.argv[2:]])\n');wrapper.chmod(0o700)
  for case in fixture['cases']:
   base=owned/side/case['id'];options=parity.case_options(case['id'])
   row=oracle.run_scan_case(wrapper,owned,base,case['id'],case['args'],tty_mode=case['tty'],repeat=case['repeat'],**{k:v for k,v in options.items() if k!='repeat'})
   assert row['exit_code']==case['exit_code'] and row['stdout']==case['stdout'] and row['stderr']==case['stderr'],(side,case['id'],row)
   rows.append(dict(side=side,case=row,wrapper_sha256=hashlib.sha256(wrapper.read_bytes()).hexdigest()))
r=dict(head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip(),source='5bbd42774b73760731801ca148663350b9770b47',original_fixture_sha256=hashlib.sha256(oracle.FIXTURE.read_bytes()).hexdigest(),original_source_binding=fixture['source_files'],actual_sdk_public_Go_vs_original_fixture=True,actual_native_Guard_vs_original_fixture=True,nine_cases_including_TTY_and_original_repeats=True,binary_sha256={side:hashlib.sha256(p.read_bytes()).hexdigest() for side,p in bins.items()},not_full_Brain_executable=True,adapter_scope='Executable argv adapter drops only guard, retains scan/arguments, environment and TTY descriptors; dispatches actual standalone public handlers.',results=rows)
Path('/tmp/symaira-guard770-config-paths-independent-scan-original9.json').write_text(json.dumps(r,indent=2)+'\n');print('PASS original9 Scan fixtures on each fresh actual Go/native binary, including TTY/repeats, source binding unchanged')
