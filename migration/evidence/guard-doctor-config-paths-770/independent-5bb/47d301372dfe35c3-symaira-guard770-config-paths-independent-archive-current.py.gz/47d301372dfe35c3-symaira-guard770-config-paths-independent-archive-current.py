from pathlib import Path
import gzip,hashlib,json,os,re,subprocess
ROOT=Path('/workspace/symaira-guard770-config-paths');TARGET=Path('/workspace/symaira-guard770-diagnostics/target');OUT=Path('/workspace/oracles/symaira-guard770-config-paths-independent-7f-binaries');OUT.mkdir(exist_ok=True)
def sha(raw):return hashlib.sha256(raw).hexdigest()
def users():
 found=[]
 for proc in Path('/proc').iterdir():
  if proc.name.isdigit():
   for obj in [proc/'exe',proc/'cwd',*list((proc/'fd').glob('*'))]:
    try:
     dest=os.readlink(obj)
     if dest.startswith(str(TARGET)+'/'):found.append({'pid':proc.name,'descriptor':str(obj),'destination':dest})
    except (FileNotFoundError,PermissionError,OSError):pass
 return found
assert not users()
roles={}
for stage in ['tests','kernel-tests']:
 for name in re.findall(r'Running .*?\(([^)]+)\)',Path('/tmp/symaira-guard770-config-paths-independent-'+stage+'.log').read_text()):roles.setdefault(name,[]).append(stage)
paths=[]
for p in TARGET.rglob('*'):
 if p.is_file():
  with p.open('rb') as stream: magic=stream.read(4)
  if magic==b'\x7fELF':paths.append(p)
for name in ['go','native']:
 p=Path('/tmp/symaira-guard770-config-paths-independent-process-binaries')/name;paths.append(p);roles.setdefault(str(p),[]).append('all process gates and fresh independent probes')
known={}
validated=json.loads(Path('/workspace/oracles/symaira-guard770-config-paths-5bb-binaries/durable-complete-receipt.json').read_text())
known.update(validated['unique']);records=[];unique={}
for p in paths:
 raw=p.read_bytes();digest=sha(raw);archive=OUT/(digest+'.gz')
 if digest not in unique:
  if digest in known:shutil_raw=Path(known[digest]['archive']).read_bytes();archive.write_bytes(shutil_raw)
  else:archive.write_bytes(gzip.compress(raw,mtime=0))
  assert gzip.decompress(archive.read_bytes())==raw
  unique[digest]={'archive':str(archive),'bytes':len(raw),'sha256':digest,'archive_sha256':sha(archive.read_bytes())}
 records.append({'path':str(p),'bytes':len(raw),'sha256':digest,'actually_executed_roles':roles.get(str(p),[]),'cached_ELF_not_claimed_executed':str(p) not in roles})
for p in Path('/tmp/symaira-guard770-config-paths-independent-process-windows-path-reference-artifacts').glob('*reference.gz'):
 raw=gzip.decompress(p.read_bytes());digest=sha(raw);archive=OUT/(digest+'.gz');archive.write_bytes(p.read_bytes());assert gzip.decompress(archive.read_bytes())==raw
 unique[digest]={'archive':str(archive),'bytes':len(raw),'sha256':digest,'archive_sha256':sha(archive.read_bytes())}
 records.append({'path':str(p),'bytes':len(raw),'sha256':digest,'actually_executed_roles':['declared386 and independent144 portable SDK source-reference'],'not_native_Windows_proof':True})
assert not users();assert not subprocess.check_output(['git','status','--porcelain'],cwd=ROOT).strip()
result={'head':'7f6faa9924b3d25b5c796ee662b4544184c156d5','compiled_source':'5bbd42774b73760731801ca148663350b9770b47','target':str(TARGET),'target_users':[],'paths':len(records),'unique':len(unique),'records':records,'unique_archives':unique,'test_roles':roles,'all_raw_bytes_gzip_roundtrip_verified':True,'no_candidate_edits':True,'originals_untouched':True}
(OUT/'receipt.json').write_text(json.dumps(result,indent=2)+'\n');print('complete archive',len(records),'paths',len(unique),'unique;',len(roles),'executed paths;0users')
