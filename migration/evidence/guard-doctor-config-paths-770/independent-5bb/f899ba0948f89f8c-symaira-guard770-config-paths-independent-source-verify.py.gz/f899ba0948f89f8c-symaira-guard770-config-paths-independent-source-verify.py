from pathlib import Path
import gzip,hashlib,json,subprocess
ROOT=Path('/workspace/symaira-guard770-config-paths')
HEAD='7f6faa9924b3d25b5c796ee662b4544184c156d5';SOURCE='5bbd42774b73760731801ca148663350b9770b47';PARENT='4d78b6e52c53d1c273126b0dac3c554915a15438'
FINAL=ROOT/'migration/evidence/guard-doctor-config-paths-770/final-5bb'
def sha(data):return hashlib.sha256(data).hexdigest()
def git(*args):return subprocess.check_output(['git',*args],cwd=ROOT)
def immutable(ref,mapping):
 for name,expected in mapping.items():assert sha(git('show',ref+':'+name))==expected,(ref,name)
def retained(base,records):
 for record in records:
  p=base/record['retained'];compressed=p.read_bytes();assert sha(compressed)==record['gzip_sha256'],str(p)
  data=gzip.decompress(compressed);assert len(data)==record['bytes'] and sha(data)==record['sha256'],str(p)
 return len(records)
def states(base,name):
 rows=json.loads((base/name).read_text())
 for row in rows:
  if row['kind']=='file':
   data=gzip.decompress((base/row['blob']).read_bytes());assert len(data)==row['bytes'] and sha(data)==row['sha256'],row['path']
  else:assert row['kind']=='symlink' and row['target']
 return len(rows)
assert git('rev-parse','HEAD').decode().strip()==HEAD and not git('status','--porcelain').strip()
d=json.loads((FINAL/'validation.json').read_text());assert d['source']==SOURCE
immutable(SOURCE,d['source_sha256'])
publication_delta=set(git('diff','--name-only',SOURCE,HEAD).decode().splitlines())
current_map={name:expected for name,expected in d['source_sha256'].items() if name not in publication_delta}
immutable(HEAD,current_map)
for name,expected in current_map.items():assert sha((ROOT/name).read_bytes())==expected,name
immutable(d['frozen_go_ref'],d['frozen_go_sha256'])
for name in ['go.mod','go.sum','guard/go.mod','guard/go.sum']:
 exists=subprocess.run(['git','cat-file','-e',d['frozen_go_ref']+':'+name],cwd=ROOT,capture_output=True).returncode==0
 if exists:assert git('show',d['frozen_go_ref']+':'+name)==git('show',HEAD+':'+name),name
for name,expected in d['pinned_sdk_sha256'].items():assert sha((Path('/workspace/toolchains/go1.26.7')/name).read_bytes())==expected,name
for prefix in d['protected_source_unchanged']:
 assert not git('diff','--name-only',PARENT,HEAD,'--',prefix).strip(),prefix
changed=git('diff','--name-only',SOURCE,HEAD).decode().splitlines()
assert not [name for name in changed if name.startswith('rust/') or name.startswith('.github/') or (name.startswith('scripts/') and not name.endswith('README.md'))],changed
old=ROOT/'migration/evidence/guard-doctor-config-paths-770/independent-4d78';o=json.loads((old/'retention.json').read_text())
result={'head':HEAD,'source':SOURCE,'parent':PARENT,'target_accessed':False,'executables_run':False,'source_files':len(d['source_sha256']),'current_unchanged_source_map':len(current_map),'historical_docs_changed':sorted(set(d['source_sha256'])-set(current_map)),'frozen_go_files':len(d['frozen_go_sha256']),'pinned_sdk_refs':len(d['pinned_sdk_sha256']),'protected_prefixes':len(d['protected_source_unchanged']),'current_retained_reports':retained(FINAL,d['retention']),'original_retained_reports':retained(old,o['records']),'current_raw_states':states(FINAL,'raw-owner-state-retention.json'),'original_raw_states':states(old,'raw-state-retention.json'),'final_docs_evidence_only':changed,'ELF_archives_pending_resource_allocation':True,'source_and_retained_provenance_pass':True}
Path('/tmp/symaira-guard770-config-paths-independent-source-verification.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k!='final_docs_evidence_only'}))
