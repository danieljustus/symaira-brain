from pathlib import Path
import hashlib,json,subprocess,sys
ROOT=Path('/workspace/symaira-guard770-config-paths');OLD='/tmp/symaira-guard770-config-paths-5bb-';NEW='/tmp/symaira-guard770-config-paths-independent-';results=[]
for name in ['owner','owner-semantic','parent-owner','parent-known-owner','fresh-owner','fresh-owner-semantic']:
 original=Path(OLD+'history-'+name+'.py');driver=Path(NEW+'history-'+name+'.py');driver.write_text(original.read_text().replace(OLD,NEW))
 log=Path(NEW+'history-'+name+'.log')
 with log.open('wb') as output:p=subprocess.run([sys.executable,str(driver)],cwd=ROOT,stdout=output,stderr=subprocess.STDOUT)
 assert p.returncode==0,(name,log)
 report=json.loads(Path(NEW+'history-'+name+'.json').read_text());assert len(report['results'])==5 and all(row['matched'] for row in report['results']),name
 results.append({'name':name,'pairs':5,'all_matched':True,'original_helper_sha256':hashlib.sha256(original.read_bytes()).hexdigest(),'fresh_helper_sha256':hashlib.sha256(driver.read_bytes()).hexdigest()})
 print(name,'5/5',flush=True)
Path(NEW+'history-receipt.json').write_text(json.dumps({'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),'actual_source':'5bbd42774b73760731801ca148663350b9770b47','original20_plus10_pairs':30,'results':results},indent=2)+'\n')
