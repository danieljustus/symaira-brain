from pathlib import Path
import hashlib,json,subprocess,sys
ROOT=Path('/workspace/symaira-guard770-config-paths')
PREFIX='/tmp/symaira-guard770-config-paths-independent-'
BASE='/tmp/symaira-guard770-config-paths-5bb-'
GO=PREFIX+'process-binaries/go';NATIVE=PREFIX+'process-binaries/native'
source='5bbd42774b73760731801ca148663350b9770b47'
# Adapt the already retained original drivers only to current immutable binary,
# repo and new output paths. All case generation/comparison/assertions remain.
for original,name in [(Path('/tmp/symaira-guard770-config-paths-previous-gates.py'),'previous-gates'),(Path(BASE+'scan-original9.py'),'scan-original9')]:
 text=original.read_text().replace(BASE,PREFIX)
 if name=='previous-gates':
  text=text.replace("'source':'fb2844b02b7c03b7c34650c6d3aed693c47b2997'","'source':'"+source+"'")
  text=text.replace("text=text.replace('/tmp/symaira-guard770-warnings-independent-',prefix+'previous-');", "text=text.replace('/workspace/symaira-guard770-diagnostics/target/debug/symguard',"+repr(NATIVE)+");text=text.replace('/tmp/symaira-guard770-warnings-independent-',prefix+'previous-');")
 helper=Path(PREFIX+name+'.py');helper.write_text(text)
 log=Path(PREFIX+name+'.log')
 with log.open('wb') as output: proc=subprocess.run([sys.executable,str(helper)],cwd=ROOT,stdout=output,stderr=subprocess.STDOUT)
 print(name,proc.returncode,flush=True)
 assert proc.returncode==0,log
