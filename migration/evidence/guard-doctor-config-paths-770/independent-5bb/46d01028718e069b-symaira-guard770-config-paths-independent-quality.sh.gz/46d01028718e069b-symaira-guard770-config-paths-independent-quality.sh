#!/usr/bin/env bash
set -euo pipefail
umask 022
cd /workspace/symaira-guard770-config-paths
. /home/agent/.cargo/env
export PATH=/workspace/toolchains/go1.26.7/bin:$PATH
export CARGO_TARGET_DIR=/workspace/symaira-guard770-diagnostics/target
export CARGO_INCREMENTAL=0 CARGO_PROFILE_DEV_DEBUG=0 CARGO_PROFILE_TEST_DEBUG=0 CARGO_BUILD_JOBS=2
floor() { python3 -c 'import shutil; assert shutil.disk_usage("/workspace").free >= 700*1024*1024, "disk floor"'; }
floor
cargo test --locked -p symbrain-core -p symbrain-guard-core -p symguard-cli --all-targets --all-features > /tmp/symaira-guard770-config-paths-independent-tests.log 2>&1
floor
cargo test --locked -p symbrain-guard-core --all-targets --all-features > /tmp/symaira-guard770-config-paths-independent-kernel-tests.log 2>&1
floor
cargo clippy --locked -p symbrain-core -p symbrain-guard-core -p symguard-cli --all-targets --all-features -- -D warnings > /tmp/symaira-guard770-config-paths-independent-clippy.log 2>&1
floor
cargo clippy --locked -p symbrain-guard-core --all-targets --all-features -- -D warnings > /tmp/symaira-guard770-config-paths-independent-kernel-clippy.log 2>&1
cargo fmt --all -- --check > /tmp/symaira-guard770-config-paths-independent-fmt.log 2>&1
/workspace/toolchains/bin/actionlint .github/workflows/ci.yml > /tmp/symaira-guard770-config-paths-independent-actionlint.log 2>&1
python3 - <<'PY'
import re
from pathlib import Path
for stage in ['tests','kernel-tests']:
 s=Path('/tmp/symaira-guard770-config-paths-independent-'+stage+'.log').read_text()
 rows=re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;',s)
 print(stage,tuple(sum(int(row[i]) for row in rows) for i in range(3)),len(rows),'summaries')
PY
