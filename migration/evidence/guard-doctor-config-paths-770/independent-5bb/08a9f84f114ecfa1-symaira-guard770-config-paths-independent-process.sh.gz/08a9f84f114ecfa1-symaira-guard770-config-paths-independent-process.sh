#!/usr/bin/env bash
set -euo pipefail
umask 022
cd /workspace/symaira-guard770-config-paths
. /home/agent/.cargo/env
export PATH=/workspace/toolchains/go1.26.7/bin:$PATH
export CARGO_TARGET_DIR=/workspace/symaira-guard770-diagnostics/target
export CARGO_INCREMENTAL=0 CARGO_PROFILE_DEV_DEBUG=0 CARGO_PROFILE_TEST_DEBUG=0 CARGO_BUILD_JOBS=2
python3 -c 'import shutil; assert shutil.disk_usage("/workspace").free >= 700*1024*1024'
bash scripts/guard-standalone-oracle/run.sh /tmp/symaira-guard770-config-paths-independent-process.json > /tmp/symaira-guard770-config-paths-independent-process.log 2>&1
cat /tmp/symaira-guard770-config-paths-independent-process.log
