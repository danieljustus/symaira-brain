from pathlib import Path
import hashlib,json,os,stat,subprocess,sys,tempfile,time
ROOT=Path('/workspace/symaira-guard770-config-paths');sys.path.insert(0,str(ROOT/'scripts/guard-standalone-oracle'));import replay
PREFIX='/tmp/symaira-guard770-config-paths-independent-';BINS={name:Path(PREFIX+'process-binaries/'+name) for name in ['go','native']}
CASES=[]
for family in ['xdg','home']:
 for boundary in ['missing-ancestor','file-ancestor','unicode-dotdot','raw-dotdot','empty-explicit']:
  CASES.append({'id':family+'-'+boundary,'family':family,'boundary':boundary,'contract':'full'})
CASES += [{'id':'empty-home-relative-default','boundary':'relative-default','contract':'full'},
          {'id':'explicit-space-path','boundary':'explicit-space','contract':'full'},
          {'id':'explicit-file-ancestor','boundary':'explicit-file','contract':'gated'},
          {'id':'semantic-skips-discovery-fifo','boundary':'skip-fifo','contract':'full'},
          {'id':'warning-with-anchor-type-firsterror','boundary':'anchor-error','contract':'full'},
          {'id':'warning-with-discovery-error-refuses-all','boundary':'discovery-error','contract':'gated'}]
def state(root):
 result={}
 for p in sorted(root.rglob('*')):
  info=p.lstat();row={'kind':stat.S_IFMT(info.st_mode),'mode':stat.S_IMODE(info.st_mode)}
  if p.is_symlink():row['target']=os.readlink(p)
  elif stat.S_ISREG(info.st_mode):row.update(hex=p.read_bytes().hex(),mtime_ns=info.st_mtime_ns)
  result[str(p.relative_to(root))]=row
 return result
def run(case,side,root):
 env=replay.setup(root,'empty');env.pop('SYMGUARD_CONFIG',None);boundary=case['boundary'];family=case.get('family','xdg');leaf=os.fsdecode(b'cfg-\xe2\x82<&>') if boundary=='raw-dotdot' else '雪cfg' if boundary=='unicode-dotdot' else 'cfg';base=root/leaf
 suffix=Path('symguard/config.toml') if family=='xdg' else Path('.config/symguard/config.toml');config=base/suffix;config.parent.mkdir(parents=True,exist_ok=True);config.write_bytes(b'novel_owner=1\n')
 spelling=str(root)+('/discard/../' if boundary in ['raw-dotdot','unicode-dotdot'] else '/blocker/../')+leaf
 if boundary in ['raw-dotdot','unicode-dotdot']:(root/'discard').mkdir()
 if boundary=='file-ancestor':(root/'blocker').write_bytes(b'owned non-directory')
 if family=='xdg':env['XDG_CONFIG_HOME']=spelling
 else:env.update(HOME=spelling,USERPROFILE=spelling);env.pop('XDG_CONFIG_HOME',None)
 if boundary=='empty-explicit':env['SYMGUARD_CONFIG']=''
 if boundary=='relative-default':
  env.pop('XDG_CONFIG_HOME',None);env.update(HOME='',USERPROFILE='');config=root/'project/.config/symguard/config.toml';config.parent.mkdir(parents=True);config.write_bytes(b'novel_owner=1\n')
 if boundary=='explicit-space':
  env['SYMGUARD_CONFIG']=' ';config=root/'project/ ';config.write_bytes(b'space_owner=1\n')
 if boundary=='explicit-file':
  (root/'blocker').write_bytes(b'owned non-directory');env['SYMGUARD_CONFIG']=spelling+'/'+str(suffix)
 if boundary=='skip-fifo':
  config.write_bytes(b'novel_owner=1\nsequence={enabled=true,threshold=1}\n');cursor=root/'home/.cursor/mcp.json';cursor.parent.mkdir(parents=True);os.mkfifo(cursor)
 if boundary in ['anchor-error','discovery-error']:
  log=root/'data/symguard/audit.log';log.parent.mkdir(parents=True);log.write_bytes(b'');Path(str(log)+'.anchor').write_bytes(b'{"entry_count":true}')
  if boundary=='discovery-error':
   cursor=root/'home/.cursor/mcp.json';cursor.parent.mkdir(parents=True);cursor.write_bytes(b'{bad')
 before=state(root);start=time.time();p=subprocess.run([str(BINS[side]),'doctor'],cwd=root/'project',env=env,capture_output=True,timeout=4);end=time.time();after=state(root)
 return {'exit_code':p.returncode,'stdout_hex':p.stdout.hex(),'stderr_hex':p.stderr.hex(),'normalized_stdout_hex':replay.normalized_stream(p.stdout,root,['doctor'],side=='native',True).hex(),'normalized_stderr_hex':replay.normalized_stream(p.stderr,root,['doctor'],side=='native',False).hex(),'files':replay.state_files(root,start,end,False),'before':before,'after':after,'readonly':before==after,'config_env_hex':{key:os.fsencode(value).hex() for key,value in env.items() if key in ['HOME','USERPROFILE','XDG_CONFIG_HOME','SYMGUARD_CONFIG']}}
rows=[]
with tempfile.TemporaryDirectory(prefix='guard770-independent-novel-') as directory:
 for i,case in enumerate(CASES):
  pair={side:run(case,side,Path(directory)/str(i)/side) for side in BINS};equal=replay.comparable(pair['go'])==replay.comparable(pair['native']);row=dict(**case,**pair,matched=equal,readonly=all(x['readonly'] for x in pair.values()))
  if case['contract']=='gated':row['accepted']=pair['go']['exit_code']==1 and pair['native']['exit_code']==1 and not pair['native']['stdout_hex'] and bytes.fromhex(pair['native']['stderr_hex'])==b'symguard doctor: unsupported native diagnostic state; no legacy fallback is available\n'
  else:row['accepted']=equal
  rows.append(row)
report={'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),'source':'5bbd42774b73760731801ca148663350b9770b47','native_windows_proof':False,'actual_binaries_sha256':{name:hashlib.sha256(path.read_bytes()).hexdigest() for name,path in BINS.items()},'total':len(rows),'full_equal':sum(r['matched'] for r in rows),'explicit_gates':sum(r['contract']=='gated' for r in rows),'results':rows}
Path(PREFIX+'novel.json').write_text(json.dumps(report,indent=2)+'\n')
print(report['total'],report['full_equal'],report['explicit_gates'],'accepted',sum(r['accepted'] and r['readonly'] for r in rows));assert all(r['accepted'] and r['readonly'] for r in rows)
