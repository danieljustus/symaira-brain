from pathlib import Path
import gzip,hashlib,json,os,shutil,subprocess,tempfile
ROOT=Path('/workspace/symaira-guard770-config-paths');BASE=Path('/tmp/symaira-guard770-config-paths-independent-process-windows-path-reference-artifacts');OUT=Path('/tmp/symaira-guard770-config-paths-independent-sdk-extra.json')
rows=[]
for prefix in ['a','ab','雪','雪a','é','éa','😀','\ud800','\udc00']:
 for base in [prefix+':/a/../../b',prefix+':/a/../../abcd',prefix+'/../cfg',prefix+'/a/../cfg','\\a\\..\\??',prefix+':','//host/share/'+prefix+'/..','\\\\?\\C:\\'+prefix+'\\..']:
  for parts in [['symguard','config.toml'],['.config','symguard','config.toml']]:rows.append({'base':base,'parts':parts})
with tempfile.TemporaryDirectory(prefix='guard770-independent-sdk-extra-') as tmp:
 owned=Path(tmp);bins={}
 for name in ['go-reference','native-reference']:
  p=owned/name;p.write_bytes(gzip.decompress((BASE/(name+'.gz')).read_bytes()));p.chmod(0o700);bins[name]=p
 goinput=[dict(Mode='join',BaseHex=r['base'].encode('utf-8','surrogatepass').hex(),Parts=r['parts']) for r in rows]
 expected=json.loads(subprocess.check_output([str(bins['go-reference'])],input=json.dumps(goinput).encode()))
 wire='\n'.join('\t'.join(['join',r['base'].encode('utf-16le','surrogatepass').hex(),*[p.encode().hex() for p in r['parts']]]) for r in rows)+'\n'
 native=subprocess.check_output([str(bins['native-reference'])],input=wire.encode()).decode().splitlines()
 # The public generated-path wrapper applies clean_units once more after join_units.
 clean_wire='\n'.join('clean\t'+s for s in native)+'\n'
 recleaned=subprocess.check_output([str(bins['native-reference'])],input=clean_wire.encode()).decode().splitlines()
 results=[]
 for row,go,native_once,native_twice in zip(rows,expected,native,recleaned):
  expected_units=bytes.fromhex(go).decode('utf-8','surrogatepass').encode('utf-16le','surrogatepass').hex()
  results.append(dict(**row,go_WTF8_hex=go,go_UTF16_hex=expected_units,native_join_units_hex=native_once,native_wrapper_reclean_hex=native_twice,matched=expected_units==native_once==native_twice))
 r={'source':'5bbd42774b73760731801ca148663350b9770b47','head':'7f6faa9924b3d25b5c796ee662b4544184c156d5','source_reference_only_not_native_windows':True,'actual_probe_SHA256':{k:hashlib.sha256(p.read_bytes()).hexdigest() for k,p in bins.items()},'total':len(results),'matched':sum(x['matched'] for x in results),'results':results}
 OUT.write_text(json.dumps(r,indent=2)+'\n');print(r['total'],r['matched']);assert r['matched']==r['total']
