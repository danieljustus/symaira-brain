from pathlib import Path
import gzip,hashlib,json,os,subprocess
old=Path('/workspace/symaira-usage768-argv/target');new=Path('/workspace/symaira-usage768-remaining/target');receipt=Path('/workspace/oracles/symaira-usage768-argv-eea73b7478e6-idle-binaries/receipt.json');r=json.loads(receipt.read_text());sha=lambda data:hashlib.sha256(data).hexdigest()
assert r['roundtrip_verified'] and not r['retired'] and r['users']==[] and len(r['executables'])==121 and len(r['unique'])==83
assert old.is_dir() and old.resolve()==old and not new.exists()
def users():
 found=[]
 for p in Path('/proc').iterdir():
  if not p.name.isdigit():continue
  for link in [p/'exe',p/'cwd',*list((p/'fd').glob('*'))]:
   try:v=os.readlink(link)
   except OSError:continue
   if v==str(old)or v.startswith(str(old)+'/'):found.append(dict(pid=p.name,link=str(link),value=v))
 assert not found,found
 return found
users()
for digest,row in r['unique'].items():
 data=gzip.decompress(Path(row['archive']).read_bytes());assert sha(data)==digest and len(data)==row['original_size']
for row in r['executables']:assert sha(Path(row['original_path']).read_bytes())==row['sha256']
for root in [old.parent,new.parent]:assert subprocess.run(['git','check-ignore','target/debug/symbrain'],cwd=root,stdout=subprocess.PIPE).returncode==0
users();old.rename(new)
out=Path('/workspace/symaira-usage768-remaining/migration/evidence/usage-next-768');out.mkdir(parents=True)
(out/'target-reuse.json').write_text(json.dumps(dict(original_receipt=str(receipt),original_receipt_sha256=sha(receipt.read_bytes()),old_target=str(old),new_target=str(new),original121_paths83_unique_roundtrip_verified=True,proc_users_before=[],no_second_target=True,permission='Root explicit exclusive target handoff after full independent bounded approval; preserve actual original39/38 and all original archives',operation='rename existing owned ignored target, no deletion/source changes',head_before_successor=subprocess.check_output(['git','rev-parse','HEAD'],cwd=new.parent,text=True).strip()),indent=2)+'\n');print('PASS121paths83SHA roundtrip, targetusers0; renamed ONLY released owned target')
