from pathlib import Path
root=Path('/workspace/symaira-usage768-remaining')
p=root/'rust/symbrain-cli/src/usage_cli.rs'
s=p.read_text().replace('run(&args, &mut stdout, &mut stderr, OutputFormat::Table)','invocation.run(&mut stdout, &mut stderr, OutputFormat::Table)');p.write_text(s)
p=root/'rust/symbrain-cli/src/lib.rs';s=p.read_text();start=s.index('/// Normalizes CLI arguments matching Go');end=s.index('\n}',start)+2
helper=s[start:end]
assert 'pub fn normalize_flags' in helper
(root/'rust/symbrain-cli/src/flag_normalization.rs').write_text('//! Shared Go flag normalization; public API retained without a grammar change.\nuse std::ffi::OsString;\n\n'+helper+'\n')
s=s[:start]+'mod flag_normalization;\npub use flag_normalization::normalize_flags;'+s[end:];p.write_text(s)
p=root/'scripts/usage-copilot-kimi-oracle/cases.py';s=p.read_text().replace("    row['gate'] = ''","    row['gate'] = ''\n    row['native_promoted'] = row['id'] == 'kimi-device-unicode-value'");p.write_text(s)
p=root/'scripts/usage-copilot-kimi-oracle/provider_test.go.txt';s=p.read_text().replace('Gate     string            `json:"gate"`','Gate     string            `json:"gate"`\n NativePromoted bool `json:"native_promoted"`').replace('for _, entry := range cases {','for _, entry := range cases {\n if entry.NativePromoted && entry.ID != "kimi-device-unicode-value" { t.Fatal("unknown promotion", entry.ID) }').replace('"gate": entry.Gate, "gated": entry.Gate != ""','"gate": entry.Gate, "native_promoted": entry.NativePromoted, "gated": (entry.Gate != "" && !entry.NativePromoted)');p.write_text(s)
p=root/'rust/symbrain-usage/src/copilot_kimi_oracle_tests.rs';s=p.read_text().replace('if cfg!(windows) { 9 } else { 8 }','if cfg!(windows) { 8 } else { 7 }');p.write_text(s)
p=root/'scripts/usage-copilot-kimi-oracle/receipt.py';s=p.read_text().replace("expected_gates=9 if sys.platform=='win32'else 8","expected_gates=8 if sys.platform=='win32'else 7\npromoted=[row for row in records if row.get('native_promoted')]\nassert len(promoted)==1 and promoted[0]['id']=='kimi-device-unicode-value' and promoted[0]['gate']=='unproven device header bytes' and not promoted[0]['gated']")
s=s.replace("'native_macos_windows':", "'native_promotions':[dict(id=row['id'],historical_gate=row['gate'],current_scope='full actual constructor/report/request/raw-header/read-only comparison') for row in promoted],'native_macos_windows':")
p.write_text(s)
for p in (root/'scripts').glob('usage-*-oracle/receipt.py'):
 s=p.read_text()
 if "'rust/symbrain-cli/src/lib.rs'" in s and "'rust/symbrain-cli/src/flag_normalization.rs'" not in s:
  s=s.replace("'rust/symbrain-cli/src/lib.rs'", "'rust/symbrain-cli/src/lib.rs','rust/symbrain-cli/src/flag_normalization.rs'");p.write_text(s)
