from pathlib import Path
import gzip,hashlib,json
repo=Path('/workspace/symaira-usage768-remaining');out=repo/'migration/evidence/usage-next-768/author-attempts';out.mkdir(parents=True,exist_ok=True);rows=[]
for p in sorted(Path('/tmp').glob('symaira-usage768-next-*')):
 paths=[p]if p.is_file()else list(p.rglob('*'))if p.suffix=='.evidence'else[]
 for item in paths:
  if not item.is_file():continue
  # Keep logs, actual inputs/reports/wire bytes and author helper scripts;
  # actual compiled executables are retained in their separate binary archive.
  if item.read_bytes()[:4]==b'\x7fELF':continue
  data=item.read_bytes();name=str(item.relative_to('/tmp')).replace('/','--')+'.gz';dest=out/name;dest.write_bytes(gzip.compress(data,mtime=0));assert gzip.decompress(dest.read_bytes())==data;rows.append(dict(original=str(item),retained=str(dest.relative_to(repo)),bytes=len(data),sha256=hashlib.sha256(data).hexdigest()))
(out/'receipt.json').write_text(json.dumps(dict(records=rows,count=len(rows),scope='All current author prototype/pass/fail logs, exact inputs/reports/wire bytes and helper scripts retained without discarding failures; dirty attempts are not clean-source acceptance. Earlier accepted and independent records unchanged.'),indent=2)+'\n');print(len(rows),'original author artifacts retained')
