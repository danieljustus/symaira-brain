from pathlib import Path
import gzip,hashlib,json,subprocess
repo=Path('/workspace/symaira-usage768-remaining');out=repo/'migration/evidence/usage-next-768/inherited-http-status-failure';out.mkdir(parents=True,exist_ok=True);sha=lambda b:hashlib.sha256(b).hexdigest()
paths=[Path('/tmp/symaira-usage768-next-device-dirty.log'),*Path('/tmp/symaira-usage768-next-device-dirty.evidence').glob('*'),Path('/tmp/symaira-usage768-next-device-prototype.log'),Path('/tmp/symaira-usage768-next-device-prototype2.log'),Path('/tmp/symaira-usage768-next-device-prototype2.json')]
records=[]
for p in paths:
 if p.is_file():
  b=p.read_bytes();dest=out/(p.parent.name+'-'+p.name+'.gz');dest.write_bytes(gzip.compress(b,mtime=0));assert gzip.decompress(dest.read_bytes())==b;records.append(dict(original=str(p),retained=str(dest.relative_to(repo)),sha256=sha(b),bytes=len(b)))
archive=Path('/workspace/oracles/symaira-usage768-next-inherited-status-binaries');archive.mkdir(exist_ok=True)
p=repo/'target/debug/deps/symbrain_usage-717883f361629f0c';data=p.read_bytes();dest=archive/(p.name+'.gz');dest.write_bytes(gzip.compress(data,mtime=0));assert gzip.decompress(dest.read_bytes())==data
sources={str(p.relative_to(repo)):sha(p.read_bytes())for p in [repo/'rust/symbrain-usage/src/transport.rs',repo/'rust/symbrain-usage/src/device_oracle_tests.rs',repo/'rust/symbrain-usage/src/device_oracle_wire_tests.rs',repo/'scripts/usage-next-oracle/device_test.go.txt',repo/'scripts/usage-next-oracle/device.py',repo/'scripts/usage-next-oracle/peer.py']}
receipt=dict(candidate_head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip(),candidate_dirty=True,records=records,actual_binary=dict(path=str(p),sha256=sha(data),bytes=len(data),gzip=str(dest),gzip_roundtrip=True),source_sha256=sources,scope='Original dirty actual hostname-verified Go/nativeTLS failure; inherited ureq status-as-error behavior. Actual failed test binary retained before correction. Prototype missing fixture path failure and successful canned32/7 both preserved.')
(out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');(archive/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(receipt['actual_binary'])
