from pathlib import Path
p=Path('scripts/usage-next-oracle/device.py');s=p.read_text().replace("for row in go:\n", "statuses_go=json.loads((evidence/'status-go.json').read_text());assert native['statuses']['cases']==len(statuses_go)==84\n            for row in go+statuses_go:\n")
s=s.replace("assert data['headers_hex'][name.lower()]==values,(phase,row['id'],name)", "if name.lower()=='x-server-instance' and phase=='rust':\n                                assert data['headers_hex'][name.lower()]==['server-fn:00000000-0000-0000-0000-000000000000'.encode().hex()]\n                            else:assert data['headers_hex'][name.lower()]==values,(phase,row['id'],name)")
s=s.replace("provider_headers_raw_equal=True", "provider_headers_raw_equal_except_inherited_opencode_instance=row.get('provider')=='opencode',provider_headers_raw_equal=row.get('provider')!='opencode'")
s=s.replace("full_native_reports=32,retained_gates=7", "full_native_reports=32,retained_gates=7,remote_status_strategy_cases=84")
s=s.replace("All actual Go/native snapshot fetched_at retained and bounded by invocation; comparison canonicalizes only fetched_at.", "All actual Go/native snapshot fetched_at retained and bounded by invocation; canonicalization uses the invocation clock plus exact OpenCode3600/86400 second reset offsets relative to actual fetched_at.")
s=s.replace("Exact provider-added header bytes, request line/body and response compared.", "Exact provider-added header bytes except inherited OpenCode X-Server-Instance runtime/fixed identity, request line/body and response compared.")
p.write_text(s)
