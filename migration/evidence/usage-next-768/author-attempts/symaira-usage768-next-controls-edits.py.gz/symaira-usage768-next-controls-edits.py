from pathlib import Path
p=Path('scripts/usage-next-oracle/device.py');s=p.read_text();needle="            peer.close();(evidence/'wire.json').write_text(json.dumps(peer.rows,indent=2)+'\\n');peer=None"
assert needle in s
replace="""            main_wire=list(peer.rows)
            controls=[]
            for kind,field,message in [('missing-device-case','go.json','left: 38'),('device-header-bytes','go.json','complete request/raw header bytes'),('remote-status-diagnostic','status-go.json','actual remote full status/report')]:
                path=evidence/field;original=path.read_bytes();rows=json.loads(original)
                if kind=='missing-device-case':rows.pop()
                elif kind=='device-header-bytes':rows[0]['requests'][0]['header_value_hex']['X-Msh-Device-Id']=['00']
                else:rows[0]['report']['providers'][0]['error']='owned incorrect401 diagnostic'
                path.write_text(json.dumps(rows));peer.phase='control-'+kind
                try:
                    command=['cargo','test','--locked','-p','symbrain-usage','--lib','device_oracle_matches_fresh_go','--','--ignored','--nocapture']
                    process=subprocess.run(command,cwd=repo,env=env,capture_output=True,timeout=120)
                    raw=process.stdout+process.stderr;(evidence/(kind+'.log')).write_bytes(raw)
                    assert process.returncode==101 and message.encode()in raw and b'1 failed'in raw,(kind,process.returncode,raw[-8000:])
                    controls.append(dict(id=kind,exit=process.returncode,intended_assertion=message,rejected=True,mutated_input_sha256=sha(path)))
                finally:path.write_bytes(original)
            (evidence/'controls.json').write_text(json.dumps(controls,indent=2)+'\\n')
            peer.close();(evidence/'wire.json').write_text(json.dumps(main_wire,indent=2)+'\\n');(evidence/'controls-wire.json').write_text(json.dumps(peer.rows[len(main_wire):],indent=2)+'\\n');peer=None"""
s=s.replace(needle,replace).replace("remote_status_strategy_cases=84", "remote_status_strategy_cases=84,negative_controls=controls")
p.write_text(s)
# Exact Go source file metadata and byte hashes on each side of all constructors.
helper='''
func ownedState768(root string) map[string]any {
 values:=map[string]any{};err:=filepath.Walk(root,func(path string,info os.FileInfo,err error)error{
 if err!=nil{return err};name,err:=filepath.Rel(root,path);if err!=nil{return err};hash:="";if info.Mode().IsRegular(){data,err:=os.ReadFile(path);if err!=nil{return err};sum:=sha256.Sum256(data);hash=hex.EncodeToString(sum[:])};values[name]=map[string]any{"mode":info.Mode().String(),"mtime_ns":strconv.FormatInt(info.ModTime().UnixNano(),10),"size":info.Size(),"sha256":hash};return nil});if err!=nil{panic(err)};return values
}
'''
for name in ['device_test.go.txt','status_test.go.txt']:
 p=Path('scripts/usage-next-oracle')/name;s=p.read_text()
 if name=='status_test.go.txt':
  s=s.replace('"context"','"context"\n "crypto/sha256"\n "reflect"\n "strconv"');s+=helper
 else:s=s.replace('"context"','"context"\n "reflect"')
 s=s.replace('started := time.Now()', 'beforeState:=ownedState768(home)\n        started := time.Now()')
 s=s.replace('finished := time.Now()', 'finished := time.Now()\n afterState:=ownedState768(home);if !reflect.DeepEqual(beforeState,afterState){t.Fatal(entry.ID,"owned state mutation")}')
 s=s.replace('"started": started,', '"filesystem":beforeState,"read_only":true,"started": started,')
 # Device already has read_only:true later, avoid duplicate map key.
 if name=='device_test.go.txt':s=s.replace(', "read_only": true}', '}')
 p.write_text(s)
